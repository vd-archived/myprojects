jQuery(function($) {
    $(document).ready(function() {
        $('#panelHandle').hover(function() {
            $('#sidePanel').stop(true, false).animate({
                'right': '-2px'
            }, 900);
        }, function() {
            jQuery.noConflict();
        });

        jQuery('#sidePanel').hover(function() {
            // Do nothing
        }, function() {

            jQuery.noConflict();
            jQuery('#sidePanel').animate({
                right: '-351px'
            }, 800);

        });
		$('.frontslogan h1').hide().appendTo('.frontslogan').each(function(i) {
			$(this).delay(2000 * i).slideDown(500);
		});
    });
});