var variableForFocus='';
function getMessageHTML() {
	var obj = document.getElementById("message");
	if (obj) {
		// For Firefox
		if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)) { // test for
			// Firefox/x.x
			// or
			// Firefox
			// x.x
			// (ignoring
			// remaining
			// digits);
			var ffversion = new Number(RegExp.$1) // capture x.x portion and
			// store as a number
			if (ffversion >= 4) {
				var msgString = '<ul>';
				var msgArray = obj.innerHTML.split("<td>");
				for (i = 1; i < msgArray.length; i++) {
				if($.trim(msgArray[i].split("</td>")[0]).length > 0)
					{
					msgString = msgString + "<li>"
							+ msgArray[i].split("</td>")[0];
					msgString = msgString + "</li>";
					}
				}
				msgString = msgString + "</ul>";
			}
		}
		// For IE 8
		if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) { // test for MSIE
			// x.x;
			var ieversion = new Number(RegExp.$1) // capture x.x portion and
			// store as a number
			if (ieversion >= 8) {
				var msgString = '<ul>';
				var msgArray = obj.innerHTML.split("<TD>");
				for (i = 1; i < msgArray.length; i++) {
					if($.trim(msgArray[i].split("</td>")[0]).length > 0)
					{
					msgString = msgString + "<li>"
							+ msgArray[i].split("</TD>")[0];
					msgString = msgString + "</li>";
					}
				}
				msgString = msgString + "</ul>";
				// window.alert(msgString);
				// disableFields(false);
			}
		}

		// alert(popupMessageType);
		if (popupMessageType == "INFO") {
			showSuccessMessage(msgString);
		} else if (popupMessageType == "WARN") {
			showWarningMessage(msgString);
		} else if (popupMessageType == "ERROR") {
			showErrorMessage(msgString);
		} else if (popupMessageType == "FATAL") {
			showFatalMessage(msgString);
		} else {
			showErrorMessage(msgString);
		}
		popup('popUpDiv');

	}

}

function customAlert(msgString) {
	var tempMsgString = '<ul>';
	tempMsgString = tempMsgString + "<li>"
	+ msgString;
	tempMsgString = tempMsgString + "</li>";
	msgString = tempMsgString + "</ul>";
	showErrorMessage(msgString);
	popup('popUpDiv');
}



function errorAlert(msgString) {
	var tempMsgString = '<ul>';
	var msgArray = msgString.split("\n");
	for (i = 0; i < msgArray.length; i++) {
		if($.trim(msgArray[i]).length>0){
			tempMsgString = tempMsgString + "<li>"+msgArray[i];
			tempMsgString = tempMsgString + "</li>";
		}
	}
	tempMsgString = tempMsgString + "</ul>";
	showErrorMessage(tempMsgString);
	popup('popUpDiv');
}


function infoAlert(msgString) {
	var tempMsgString = '<ul>';
	tempMsgString = tempMsgString + "<li>"
	+ msgString;
	tempMsgString = tempMsgString + "</li>";
	msgString = tempMsgString + "</ul>";
	showFatalMessage(msgString);
	popup('popUpDiv');
}

function confirmDelete(msgString) {
	var tempMsgString = '<ul>';
	tempMsgString = tempMsgString + "<li>"
	+ msgString;
	tempMsgString = tempMsgString + "</li>";
	msgString = tempMsgString + "</ul>";
	alertWarningMessage(msgString);
	popup('deletePopUpDiv');
}
function cofirmResetPswd(msgString) {
	var tempMsgString = '<ul>';
	tempMsgString = tempMsgString + "<li>"
	+ msgString;
	tempMsgString = tempMsgString + "</li>";
	msgString = tempMsgString + "</ul>";
	resetPswdWarningMessage(msgString);
	popup('resetpswdPopUpDiv');
}

function cofirmDelete(msgString) {
	var tempMsgString = '<ul>';
	tempMsgString = tempMsgString + "<li>"
	+ msgString;
	tempMsgString = tempMsgString + "</li>";
	msgString = tempMsgString + "</ul>";
	alertWarningMessage(msgString);
	popup('deletePopUpDiv');
}

function showpopup() {
	popup('confirmation_popUp');
}

function showpopupForLT2() {
	popup('confirmation_popUp_LP_TBLE2');	
}

function popup(windowname) {
	blanket_size(windowname);
	window_pos(windowname);
	toggle('blanket');
	toggle(windowname);
}

function setFocusAfterPopup() {
    if(variableForFocus){
        variableForFocus.focus();
        variableForFocus = '';
  }     
	
}

function setFocusOnOk() {

    $("input[id$='Ok']").focus();
    
}

// this will show the success message
function showSuccessMessage(popupMessage) {
	$('#successMessage').css('display', 'block');
	$('#warningMessage').css('display', 'none');
	$('#errorMessage').css('display', 'none');
	$('#fatalMessage').css('display', 'none');
	$("#popupTitleMessage").html("Success");
	$("#success_text").html(popupMessage);
}


// this will show the warning message
function showWarningMessage(popupMessage) {
	$('#successMessage').css('display', 'none');
	$('#warningMessage').css('display', 'block');
	$('#errorMessage').css('display', 'none');
	$('#fatalMessage').css('display', 'none');
	$("#popupTitleMessage").html("Warning");
	$("#warning_text").html(popupMessage);
}

function alertWarningMessage(popupMessage) {
	$('#warningMsg').css('display', 'block');
	$("#popupTitleMsg").html("Warning");
	$("#warning_txt").html(popupMessage);
}
function resetPswdWarningMessage(popupMessage) {
	$('#resetWarning').css('display', 'block');
	$("#popupTitle").html("Warning");
	$("#warning_txt_msg").html(popupMessage);
}

// this will show the error message
function showErrorMessage(popupMessage) {
	$('#successMessage').css('display', 'none');
	$('#warningMessage').css('display', 'none');
	$('#errorMessage').css('display', 'block');
	$('#fatalMessage').css('display', 'none');
	$("#popupTitleMessage").html("Error");
	$("#error_text").html(popupMessage);
}

// this will show the fatal message
function showFatalMessage(popupMessage) {
	$('#successMessage').css('display', 'none');
	$('#warningMessage').css('display', 'none');
	$('#errorMessage').css('display', 'none');
	$('#fatalMessage').css('display', 'block');
	$("#popupTitleMessage").html("Info");
	$("#fatal_text").html(popupMessage);
}

function toggle(div_id) {
	var el = document.getElementById(div_id);
	if (el.style.display == 'none') {
		el.style.display = 'block';
		setFocusOnOk();
	} else {
		el.style.display = 'none';
		setFocusAfterPopup();
	}
}
function blanket_size(popUpDivVar) {
	if (typeof window.innerWidth != 'undefined') {
		viewportheight = window.innerHeight;
	} else {
		viewportheight = document.documentElement.clientHeight;
	}
	if ((viewportheight > document.body.parentNode.scrollHeight)
			&& (viewportheight > document.body.parentNode.clientHeight)) {
		blanket_height = viewportheight;
	} else {
		if (document.body.parentNode.clientHeight > document.body.parentNode.scrollHeight) {
			blanket_height = document.body.parentNode.clientHeight;
		} else {
			blanket_height = document.body.parentNode.scrollHeight;
		}
	}
	var blanket = document.getElementById('blanket');
	blanket.style.height = blanket_height + 'px';
	var popUpDiv = document.getElementById(popUpDivVar);
	popUpDiv_height = blanket_height / 2 - 150;// 150 is half popup's height
	popUpDiv.style.top = popUpDiv_height + 'px';
}
function window_pos(popUpDivVar) {
	if (typeof window.innerWidth != 'undefined') {
		viewportwidth = window.innerHeight;
	} else {
		viewportwidth = document.documentElement.clientHeight;
	}
	if ((viewportwidth > document.body.parentNode.scrollWidth)
			&& (viewportwidth > document.body.parentNode.clientWidth)) {
		window_width = viewportwidth;
	} else {
		if (document.body.parentNode.clientWidth > document.body.parentNode.scrollWidth) {
			window_width = document.body.parentNode.clientWidth;
		} else {
			window_width = document.body.parentNode.scrollWidth;
		}
	}
	var popUpDiv = document.getElementById(popUpDivVar);
	window_width = window_width / 2 - 150;// 150 is half popup's width
	popUpDiv.style.left = window_width + 'px';
}
