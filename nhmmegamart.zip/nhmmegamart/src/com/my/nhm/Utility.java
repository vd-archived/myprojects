package com.my.nhm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.my.nhm.vo.UserVO;

public class Utility {
	public static UserVO isUserLoggedIn(HttpSession session) throws ServletException, IOException
	{
		UserVO user = (UserVO)session.getAttribute("user");
		return user;
	}
	
	public static String getNumberToStatus(Short status)
	{
		String result = NHM.APP.ENABLE;
		if(status==0)
		{
			result = NHM.APP.DISABLE;
		}
		return result;
	}
}
