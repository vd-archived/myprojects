package com.my.nhm.vo;

import java.util.Date;
import java.util.List;

public class BrandVO {
	private Integer id = null;
	private String name = null;
	private String description = null;
	private Short status = null;
	private Integer updateby = null;
	private Date updatedate = null;
	private List<ProductVO> products = null;
	
	public BrandVO(Integer id, String name, String description,
			Short status, Integer updateby) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.status = status;
		this.updateby = updateby;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Short getStatus() {
		return status;
	}
	public void setStatus(Short status) {
		this.status = status;
	}
	public Integer getUpdateby() {
		return updateby;
	}
	public void setUpdateby(Integer updateby) {
		this.updateby = updateby;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public List<ProductVO> getProducts() {
		return products;
	}

	public void setProducts(List<ProductVO> products) {
		this.products = products;
	}
}
