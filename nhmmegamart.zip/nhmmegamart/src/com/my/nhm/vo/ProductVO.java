package com.my.nhm.vo;

import java.util.Date;
import java.util.List;

public class ProductVO
{
/*	id               int(11) PK
	name             varchar(45)
	description      varchar(45)
	price            double
	brand            int(11)
	status           tinyint(4)
	updatedate       datetime
	updateby         int(11)
*/	
	private Integer id = null;
	private String name = null;
	private String description = null;
	private Double price = null;
	private Integer brandid = null;
	private Short status = null;
	private Integer updateby = null;
	private Date updatedate = null;
	private List<Integer> categoriesid = null;
	
	private List<CategoryVO> categories = null;
	private BrandVO brand = null;
	
	public ProductVO(Integer id, String name, String description, Double price,
			Integer brandid, Short status, Integer updateby,
			List<Integer> categoriesid) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.brandid = brandid;
		this.status = status;
		this.updateby = updateby;
		this.categoriesid = categoriesid;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getBrandid() {
		return brandid;
	}
	public void setBrandid(Integer brandid) {
		this.brandid = brandid;
	}
	public Short getStatus() {
		return status;
	}
	public void setStatus(Short status) {
		this.status = status;
	}
	public Integer getUpdateby() {
		return updateby;
	}
	public void setUpdateby(Integer updateby) {
		this.updateby = updateby;
	}
	public Date getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}
	public List<Integer> getCategoriesid() {
		return categoriesid;
	}
	public void setCategoriesid(List<Integer> categoriesid) {
		this.categoriesid = categoriesid;
	}
	public List<CategoryVO> getCategories() {
		return categories;
	}
	public void setCategories(List<CategoryVO> categories) {
		this.categories = categories;
	}
	public BrandVO getBrand() {
		return brand;
	}
	public void setBrand(BrandVO brand) {
		this.brand = brand;
	}
}
