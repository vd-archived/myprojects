package com.my.nhm.database;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import com.my.nhm.NHM;
import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.BrandVO;
import com.my.nhm.vo.CategoryVO;
import com.my.nhm.vo.ProductVO;
import com.my.nhm.vo.UserVO;

public class DatabaseUtil
{
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);

	private Connection connection = null;
	private String host = null;
	private String port = null;
	private String databasename = null;
	private String username = null;
	private String password = null;

	public DatabaseUtil()
	{
		host = APP_PROFILE_CONFIGURATION_READER.getProperty(NHM.DATABASE.HOST);
		port = APP_PROFILE_CONFIGURATION_READER.getProperty(NHM.DATABASE.PORT);
		databasename = APP_PROFILE_CONFIGURATION_READER.getProperty(NHM.DATABASE.DATABASE);
		username = APP_PROFILE_CONFIGURATION_READER.getProperty(NHM.DATABASE.USER);
		password = APP_PROFILE_CONFIGURATION_READER.getProperty(NHM.DATABASE.PASSWORD);
	}

	public void openConnection() throws IOException, ServletException
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			this.connection = DriverManager.getConnection("jdbc:mysql://"+this.host+":"+this.port+"/"+this.databasename, this.username, this.password);
		}
		catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		}
		catch (ClassNotFoundException e) {
			throw new ServletException("JDBC Driver not found.", e);
		}
	}

	public void closeConnection() throws IOException, ServletException
	{
		try
		{
			if(this.connection!=null)
			{
				this.connection.close();
			}
		}
		catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		}
	}

	public UserVO getUserByUserID(String userid) throws IOException, ServletException
	{
		UserVO user = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			rs = stmt.executeQuery("SELECT `id`, `userid`, `password`, `type`, `status`, `updatedate`, `updateby` FROM `user` where userid='" + userid + "'");
/*			if(rs.isFirst())
			{
				rs.n
			}*/
			while(rs.next()){
				System.out.println(rs.getObject(1).toString());
				System.out.println("\t\t\t");
				System.out.println(rs.getObject(2).toString());
				System.out.println("<br>");
			}
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(rs != null) {
					rs.close();
					rs = null;
				}
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return user;
	}
	
	public UserVO getUserByUserIDPassword(String userid, String password) throws IOException, ServletException
	{
		UserVO user = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			rs = stmt.executeQuery("SELECT `id`, `userid`, `password`, `type`, `status`, `updatedate`, `updateby` FROM `user` where userid='" + userid + "' and password='"+password+"' and status='1'");
			while(rs.next()){
				user = new UserVO((Integer)rs.getObject("id"), rs.getObject("userid").toString(), rs.getObject("type").toString(), new Boolean(rs.getObject("status").toString()));
				break;
			}
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(rs != null) {
					rs.close();
					rs = null;
				}
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return user;
	}
	
	public Boolean saveCategory(CategoryVO categoryVO) throws IOException, ServletException
	{
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			if(categoryVO!=null)
			{
				if(categoryVO.getId()==null)
				{
					System.out.println("INSERT INTO `category` (`name`, `description`, `status`, `updatedate`, `updateby`) VALUES ('"+categoryVO.getName()+"' , '"+ categoryVO.getDescription() +"', '"+categoryVO.getStatus()+"', NOW(), '"+categoryVO.getUpdateby()+"')");
					stmt.executeUpdate("INSERT INTO `category` (`name`, `description`, `status`, `updatedate`, `updateby`) VALUES ('"+categoryVO.getName()+"' , '"+ categoryVO.getDescription() +"', '"+categoryVO.getStatus()+"', NOW(), '"+categoryVO.getUpdateby()+"')");
				}
				else
				{
					System.out.println("UPDATE `category` SET `name` = '" + categoryVO.getName()+"', `description` = '"+categoryVO.getDescription() + "', `status` = '" + categoryVO.getStatus() + "', `updatedate` = now() , `updateby` = '" + categoryVO.getUpdateby() + " WHERE `id` = '" + categoryVO.getId() + "'");
					stmt.executeUpdate("UPDATE `category` SET `name` = '" + categoryVO.getName()+"', `description` = '"+categoryVO.getDescription() + "', `status` = '" + categoryVO.getStatus() + "', `updatedate` = now() , `updateby` = '" + categoryVO.getUpdateby() + " WHERE `id` = '" + categoryVO.getId() + "'");
				}
			}
			saved = Boolean.TRUE;
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return saved;
	}
	
	public List<CategoryVO> showAllCategory() throws IOException, ServletException
	{
		List<CategoryVO> catevories = new ArrayList<CategoryVO>();
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			rs = stmt.executeQuery("SELECT `id`, `name`, `description`, `status`, `updatedate`, `updateby` FROM `category`");
			while(rs.next()){
				CategoryVO cat = new CategoryVO((Integer)rs.getObject("id"), rs.getObject("name").toString(), rs.getObject("description").toString(), Short.parseShort(rs.getObject("status").toString()), (Integer)rs.getObject("updateby"));
				catevories.add(cat);
			}
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(rs != null) {
					rs.close();
					rs = null;
				}
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return catevories;
	}
	
	public Boolean deleteCategory(String id) throws IOException, ServletException
	{
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		try {
			if(id!=null)
			{
				this.openConnection();
				stmt = this.connection.createStatement();
				stmt.executeUpdate("DELETE FROM `category` WHERE id='"+id+"'");
			}
			saved = Boolean.TRUE;
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return saved;
	}
	
	public Boolean deleteProduct(String id) throws IOException, ServletException
	{
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		try {
			if(id!=null)
			{
				this.openConnection();
				stmt = this.connection.createStatement();
				stmt.executeUpdate("DELETE FROM `product` WHERE id='"+id+"'");
			}
			saved = Boolean.TRUE;
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return saved;
	}
	
	public Boolean saveBrand(BrandVO brandVO) throws IOException, ServletException
	{
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			if(brandVO!=null)
			{
				if(brandVO.getId()==null)
				{
					System.out.println("INSERT INTO `brand` (`name`, `description`, `status`, `updatedate`, `updateby`) VALUES ('"+brandVO.getName()+"' , '"+ brandVO.getDescription() +"', '"+brandVO.getStatus()+"', NOW(), '"+brandVO.getUpdateby()+"')");
					stmt.executeUpdate("INSERT INTO `brand` (`name`, `description`, `status`, `updatedate`, `updateby`) VALUES ('"+brandVO.getName()+"' , '"+ brandVO.getDescription() +"', '"+brandVO.getStatus()+"', NOW(), '"+brandVO.getUpdateby()+"')");
				}
				else
				{
					System.out.println("UPDATE `brand` SET `name` = '" + brandVO.getName()+"', `description` = '"+brandVO.getDescription() + "', `status` = '" + brandVO.getStatus() + "', `updatedate` = now() , `updateby` = '" + brandVO.getUpdateby() + " WHERE `id` = '" + brandVO.getId() + "'");
					stmt.executeUpdate("UPDATE `brand` SET `name` = '" + brandVO.getName()+"', `description` = '"+brandVO.getDescription() + "', `status` = '" + brandVO.getStatus() + "', `updatedate` = now() , `updateby` = '" + brandVO.getUpdateby() + " WHERE `id` = '" + brandVO.getId() + "'");
				}
			}
			saved = Boolean.TRUE;
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return saved;
	}
	
	public List<BrandVO> showAllBrand() throws IOException, ServletException
	{
		List<BrandVO> brands = new ArrayList<BrandVO>();
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			rs = stmt.executeQuery("SELECT `id`, `name`, `description`, `status`, `updatedate`, `updateby` FROM `brand`");
			while(rs.next()){
				BrandVO cat = new BrandVO((Integer)rs.getObject("id"), rs.getObject("name").toString(), rs.getObject("description").toString(), Short.parseShort(rs.getObject("status").toString()), (Integer)rs.getObject("updateby"));
				brands.add(cat);
			}
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(rs != null) {
					rs.close();
					rs = null;
				}
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return brands;
	}
	
	public Boolean deleteBrand(String id) throws IOException, ServletException
	{
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		try {
			if(id!=null)
			{
				this.openConnection();
				stmt = this.connection.createStatement();
				stmt.executeUpdate("DELETE FROM `brand` WHERE id='"+id+"'");
			}
			saved = Boolean.TRUE;
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return saved;
	}
	
	public Boolean saveProduct(ProductVO productVO) throws IOException, ServletException
	{
		Boolean saved = Boolean.FALSE;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			if(productVO!=null)
			{
				if(productVO.getId()==null)
				{
					System.out.println("INSERT INTO `product` (`name`, `description`, `price`, `brand`, `status`, `updatedate`, `updateby`) " + "VALUES ('" + productVO.getName() + "', '" + productVO.getDescription() + "', '" + productVO.getPrice() + "', '" + productVO.getBrandid() + "', '" + productVO.getStatus() + "', NOW(), '" + productVO.getUpdateby() + "')");
					stmt.executeUpdate("INSERT INTO `product` (`name`, `description`, `price`, `brand`, `status`, `updatedate`, `updateby`) VALUES ('" + productVO.getName() + "', '" + productVO.getDescription() + "', '" + productVO.getPrice() + "', '" + productVO.getBrandid() + "', '" + productVO.getStatus() + "', NOW(), '" + productVO.getUpdateby() + "')");
					if(productVO.getCategoriesid()!=null)
					{
						rs = stmt.executeQuery("SELECT `id` FROM `product` WHERE `name`='"+productVO.getName()+"'");
						while(rs.next())
						{
							Integer prodID = (Integer)rs.getObject("id");
							for(Integer catID: productVO.getCategoriesid())
							{
								System.out.println("INSERT INTO `product_category` (`product_id`, `category_id`) VALUES ('"+prodID+"', '"+catID+"')");
								stmt.executeUpdate("INSERT INTO `product_category` (`product_id`, `category_id`) VALUES ('"+prodID+"', '"+catID+"')");
							}
							break;
						}
					}
				}
				else
				{
					System.out.println("UPDATE `product` SET `name` = '" + productVO.getName() + "', `description` = '" + productVO.getDescription() + "', `price` = '" + productVO.getPrice() + "', `brand` = '" + productVO.getBrandid() + "', `status` = '" + productVO.getStatus() + "', `updatedate` = NOW(), `updateby` = '" + productVO.getUpdateby() + "' WHERE `id` = '" + productVO.getId() + "'");
					stmt.executeUpdate("UPDATE `product` SET `name` = '" + productVO.getName() + "', `description` = '" + productVO.getDescription() + "', `price` = '" + productVO.getPrice() + "', `brand` = '" + productVO.getBrandid() + "', `status` = '" + productVO.getStatus() + "', `updatedate` = NOW(), `updateby` = '" + productVO.getUpdateby() + "' WHERE `id` = '" + productVO.getId() + "'");

					System.out.println("DELETE FROM `product_category` WHERE `id` = '" + productVO.getId() + "'");
					stmt.executeUpdate("DELETE FROM `product_category` WHERE `id` = '" + productVO.getId() + "'");
					if(productVO.getCategoriesid()!=null)
					{
						for(Integer catID: productVO.getCategoriesid())
						{
							System.out.println("INSERT INTO `product_category` (`product_id`, `category_id`) VALUES ('"+productVO.getId()+"', '"+catID+"')");
							stmt.executeUpdate("INSERT INTO `product_category` (`product_id`, `category_id`) VALUES ('"+productVO.getId()+"', '"+catID+"')");
						}
					}
				}
			}
			saved = Boolean.TRUE;
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(rs != null) {
					rs.close();
					rs = null;
				}
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return saved;
	}
	
	public List<ProductVO> showAllProduct() throws IOException, ServletException
	{
		List<ProductVO> products = new ArrayList<ProductVO>();
		Boolean saved = Boolean.FALSE;
		Statement stmt = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		try {
			this.openConnection();
			stmt = this.connection.createStatement();
			rs = stmt.executeQuery("SELECT `id`, `name`, `description`, `price`, `brand`, `status`, `updatedate`, `updateby` FROM `product`");
			while(rs.next()){
				ProductVO prod = new ProductVO((Integer)rs.getObject("id"), rs.getObject("name").toString(), rs.getObject("description").toString(), (Double)rs.getObject("price"), (Integer)rs.getObject("brand"), Short.parseShort(rs.getObject("status").toString()), (Integer)rs.getObject("updateby"), null);
				List<CategoryVO> categoriesVO = new ArrayList<CategoryVO>();
				stmt1 = this.connection.createStatement();
				rs1 = stmt1.executeQuery("SELECT `id`, `name`, `description`, `status`, `updatedate`, `updateby` FROM `category` WHERE `id` IN (SELECT `category_id` FROM `product_category` WHERE `product_id`='"+prod.getId()+"')");
				while(rs1.next()){
					CategoryVO cat = new CategoryVO((Integer)rs1.getObject("id"), rs1.getObject("name").toString(), rs1.getObject("description").toString(), Short.parseShort(rs1.getObject("status").toString()), (Integer)rs1.getObject("updateby"));
					categoriesVO.add(cat);
				}
				prod.setCategories(categoriesVO);
								
				List<Integer> categoriesid = new ArrayList<Integer>();
				for(CategoryVO cat: categoriesVO)
				{
					categoriesid.add(cat.getId());
				}
				prod.setCategoriesid(categoriesid);
				
				stmt2 = this.connection.createStatement();
				rs2 = stmt2.executeQuery("SELECT `id`, `name`, `description`, `status`, `updatedate`, `updateby` FROM `brand` WHERE `id`='"+prod.getBrandid()+"'");
				while(rs2.next()){
					BrandVO bran = new BrandVO((Integer)rs2.getObject("id"), rs2.getObject("name").toString(), rs2.getObject("description").toString(), Short.parseShort(rs2.getObject("status").toString()), (Integer)rs2.getObject("updateby"));
					prod.setBrand(bran);
					break;
				}

				products.add(prod);
			}
		} catch (SQLException e) {
			throw new ServletException("Servlet Could not display records.", e);
		} finally {
			try {
				if(rs2 != null) {
					rs2.close();
					rs2 = null;
				}
				if(stmt2 != null) {
					stmt2.close();
					stmt2 = null;
				}
				if(rs1 != null) {
					rs1.close();
					rs1 = null;
				}
				if(stmt1 != null) {
					stmt1.close();
					stmt1 = null;
				}
				if(rs != null) {
					rs.close();
					rs = null;
				}
				if(stmt != null) {
					stmt.close();
					stmt = null;
				}
				this.closeConnection();
			} catch (SQLException e) {}
		}
		return products;
	}
}
