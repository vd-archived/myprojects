package com.my.nhm.model;

import java.util.Date;

import com.my.nhm.vo.UserVO;

public class User {
	private Integer id = null;
	private String userid = null;
	private String password = null;
	private String type = "";
	private Boolean status = null;
	private Date updatedate = null;
	private UserVO updateby = null;
	
	public User(Integer id, String userid, String type, Boolean status) {
		super();
		this.id = id;
		this.userid = userid;
		this.type = type;
		this.status = status;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public UserVO getUpdateby() {
		return updateby;
	}

	public void setUpdateby(UserVO updateby) {
		this.updateby = updateby;
	}
}
