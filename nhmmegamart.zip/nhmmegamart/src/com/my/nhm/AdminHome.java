package com.my.nhm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.UserVO;

/**
 * Servlet implementation class AdminHome
 */
@WebServlet("/AdminHome")
public class AdminHome extends HttpServlet
{
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);
    /**
     * @see HttpServlet#HttpServlet()
     */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher;
		UserVO user = Utility.isUserLoggedIn(request.getSession());
		if(user==null)
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else if(user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.ADMINUSER);
		}
		else
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.NORMALUSER);
		}
		dispatcher.forward(request, response);
	}
}
