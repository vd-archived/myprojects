package com.my.nhm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.my.nhm.database.DatabaseUtil;
import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.UserVO;

/**
 * Servlet implementation class Authenticate
 */
@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {

	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher;
		UserVO user = Utility.isUserLoggedIn(request.getSession());
		if(user==null)
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else if(user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.ADMINUSER);
		}
		else
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.NORMALUSER);
		}
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		
		RequestDispatcher dispatcher;
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if(username.equals("") || password.equals(""))
		{
			request.setAttribute("error", "User id and password can not be blank...");
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			DatabaseUtil dbUtil = new DatabaseUtil();
			UserVO user = dbUtil.getUserByUserIDPassword(username, password); 
			if(user!=null)
			{
				session.setAttribute("user", user);
				if(user.getType().equals(NHM.USERTYPE.ADMIN))
				{
					request.setAttribute("currentmenu", "menudashboard");
					dispatcher = request.getRequestDispatcher(NHM.JSP.ADMINUSER);
				}
				else
				{
					request.setAttribute("currentmenu", "menudashboard");
					dispatcher = request.getRequestDispatcher(NHM.JSP.NORMALUSER);
				}
			}
			else
			{
				request.setAttribute("error", "User id or password not matched...");
				dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
			}
		}
		dispatcher.forward(request, response);
	}

}
