package com.my.nhm;

public final class NHM {
		private NHM(){}
		
		public static final class APP
	    {
			private APP(){}
			public static final String APPLICATION_PROFILE      = "appProfile.xml";
			public static final String ENABLE      				= "Enable";
			public static final String DISABLE      			= "Disable";
	    }
		
		public static final class JSP
		{
			private JSP(){}
			public static final String LOGIN                    = "WEB-INF/jsp/login.jsp";
			public static final String ADMINUSER                = "WEB-INF/jsp/admin.jsp";
			public static final String NORMALUSER               = "WEB-INF/jsp/user.jsp";
			public static final String CATEGORYADD               = "WEB-INF/jsp/categoryadd.jsp";
			public static final String CATEGORYSHOW               = "WEB-INF/jsp/categoryshow.jsp";
			public static final String PRODUCTADD               = "WEB-INF/jsp/productadd.jsp";
			public static final String PRODUCTSHOW               = "WEB-INF/jsp/productshow.jsp";
			public static final String BRANDADD               = "WEB-INF/jsp/brandadd.jsp";
			public static final String BRANDSHOW               = "WEB-INF/jsp/brandshow.jsp";
		}
		
		public static final class USERTYPE
		{
			private USERTYPE(){}
			public static final String ADMIN                    = "ADMIN";
			public static final String NORMAL                   = "NORMAL";
		}
		
		public static final class DATABASE
	    {
			private DATABASE(){}
			public static final String HOST                     = "database.host";
			public static final String PORT                     = "database.port";
			public static final String DATABASE                 = "database.dbname";
			public static final String USER                     = "database.user";
			public static final String PASSWORD                 = "database.password";
	    }
}
