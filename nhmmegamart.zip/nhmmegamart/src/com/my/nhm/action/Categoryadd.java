package com.my.nhm.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.my.nhm.NHM;
import com.my.nhm.Utility;
import com.my.nhm.database.DatabaseUtil;
import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.CategoryVO;
import com.my.nhm.vo.UserVO;

/**
 * Servlet implementation class Categoryadd
 */
@WebServlet("/Categoryadd")
public class Categoryadd extends HttpServlet {
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserVO user = Utility.isUserLoggedIn(session);
		RequestDispatcher dispatcher;
		if(user==null || !user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.CATEGORYADD);
		}
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserVO user = Utility.isUserLoggedIn(session);
		RequestDispatcher dispatcher;
		if(user==null || !user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			String name = request.getParameter("name");
			String description = request.getParameter("description");
			String status = request.getParameter("status");
			if(name.equals("") || status.equals(""))
			{
				request.setAttribute("error", "Name or status can not be blank...");
				dispatcher = request.getRequestDispatcher(NHM.JSP.CATEGORYADD);
			}
			else
			{
				CategoryVO categoryVO = new CategoryVO(null, name, description, Short.parseShort(status), user.getId());
				DatabaseUtil dbUtil = new DatabaseUtil();
				if(dbUtil.saveCategory(categoryVO))
				{
					request.setAttribute("error", "Category successfully added...");
				}
				else
				{
					request.setAttribute("error", "Category failed to add...");
				}
				dispatcher = request.getRequestDispatcher(NHM.JSP.CATEGORYADD);
			}
		}
		dispatcher.forward(request, response);
		
	}

}
