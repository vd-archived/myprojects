package com.my.nhm.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.my.nhm.NHM;
import com.my.nhm.Utility;
import com.my.nhm.database.DatabaseUtil;
import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.BrandVO;
import com.my.nhm.vo.UserVO;

/**
 * Servlet implementation class Brandshow
 */
@WebServlet("/Brandshow")
public class Brandshow extends HttpServlet {
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserVO user = Utility.isUserLoggedIn(session);
		RequestDispatcher dispatcher;
		if(user==null || !user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			DatabaseUtil dbUtil = new DatabaseUtil();
			List<BrandVO>brands = dbUtil.showAllBrand();
			StringBuffer brandStr = new StringBuffer();
			for(BrandVO brand: brands)
			{
				brandStr.append("<tr>");
				brandStr.append("<td><input  type=\"checkbox\"/></td>");
				brandStr.append("<td>" + brand.getId() + "</td>");
				brandStr.append("<td>" + brand.getName() + "</td>");
				brandStr.append("<td>" + brand.getDescription() + "</td>");
				brandStr.append("<td>" + Utility.getNumberToStatus(brand.getStatus()) + "</td>");
				brandStr.append("<td class=\"options-width\">");
				brandStr.append("<a href=\"\" title=\"Edit\" class=\"icon-1 info-tooltip\"></a>");
				brandStr.append("<a href=\"branddelete?id=" + brand.getId() + "\" title=\"Delete\" class=\"icon-2 info-tooltip\"></a>");
//				brandStr.append("<a href=\"\" title=\"Edit\" class=\"icon-3 info-tooltip\"></a>");
//				brandStr.append("<a href=\"\" title=\"Edit\" class=\"icon-4 info-tooltip\"></a>");
//				brandStr.append("<a href=\"\" title=\"Edit\" class=\"icon-5 info-tooltip\"></a>");
				brandStr.append("</td>");
				brandStr.append("</tr>");
			}
			request.setAttribute("brands", brandStr);
			dispatcher = request.getRequestDispatcher(NHM.JSP.BRANDSHOW);
		}
		dispatcher.forward(request, response);
	}
}
