package com.my.nhm.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.my.nhm.NHM;
import com.my.nhm.Utility;
import com.my.nhm.database.DatabaseUtil;
import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.CategoryVO;
import com.my.nhm.vo.ProductVO;
import com.my.nhm.vo.UserVO;

/**
 * Servlet implementation class Categoryshow
 */
@WebServlet("/Categoryshow")
public class Productshow extends HttpServlet {
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserVO user = Utility.isUserLoggedIn(session);
		RequestDispatcher dispatcher;
		if(user==null || !user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			DatabaseUtil dbUtil = new DatabaseUtil();
			List<ProductVO>products = dbUtil.showAllProduct();
			StringBuffer prodBuffer = new StringBuffer();
			for(ProductVO prod: products)
			{
				prodBuffer.append("<tr>");
				prodBuffer.append("<td><input  type=\"checkbox\"/></td>");
				prodBuffer.append("<td>" + prod.getId() + "</td>");
				prodBuffer.append("<td>" + prod.getName() + "</td>");
				prodBuffer.append("<td>" + prod.getDescription() + "</td>");
				prodBuffer.append("<td>" + prod.getPrice() + "</td>");
				prodBuffer.append("<td>" + prod.getBrand().getName() + "</td>");
				prodBuffer.append("<td>");
					for(CategoryVO catVO: prod.getCategories())
					{
						prodBuffer.append(catVO.getName()+"<br />");
					}
				prodBuffer.append("</td>");
				prodBuffer.append("<td>" + Utility.getNumberToStatus(prod.getStatus()) + "</td>");
				prodBuffer.append("<td class=\"options-width\">");
				prodBuffer.append("<a href=\"\" title=\"Edit\" class=\"icon-1 info-tooltip\"></a>");
				prodBuffer.append("<a href=\"productdelete?id=" + prod.getId() + "\" title=\"Delete\" class=\"icon-2 info-tooltip\"></a>");
//				prodBuffer.append("<a href=\"\" title=\"Edit\" class=\"icon-3 info-tooltip\"></a>");
//				prodBuffer.append("<a href=\"\" title=\"Edit\" class=\"icon-4 info-tooltip\"></a>");
//				prodBuffer.append("<a href=\"\" title=\"Edit\" class=\"icon-5 info-tooltip\"></a>");
				prodBuffer.append("</td>");
				prodBuffer.append("</tr>");
			}
			request.setAttribute("products", prodBuffer);
			dispatcher = request.getRequestDispatcher(NHM.JSP.PRODUCTSHOW);
		}
		dispatcher.forward(request, response);
	}
}
