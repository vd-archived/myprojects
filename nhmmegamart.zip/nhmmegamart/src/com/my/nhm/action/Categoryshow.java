package com.my.nhm.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.my.nhm.NHM;
import com.my.nhm.Utility;
import com.my.nhm.database.DatabaseUtil;
import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.CategoryVO;
import com.my.nhm.vo.UserVO;

/**
 * Servlet implementation class Categoryshow
 */
@WebServlet("/Categoryshow")
public class Categoryshow extends HttpServlet {
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserVO user = Utility.isUserLoggedIn(session);
		RequestDispatcher dispatcher;
		if(user==null || !user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			DatabaseUtil dbUtil = new DatabaseUtil();
			List<CategoryVO>categories = dbUtil.showAllCategory();
			StringBuffer showCat = new StringBuffer();
			for(CategoryVO cat: categories)
			{
				showCat.append("<tr>");
				showCat.append("<td><input  type=\"checkbox\"/></td>");
				showCat.append("<td>" + cat.getId() + "</td>");
				showCat.append("<td>" + cat.getName() + "</td>");
				showCat.append("<td>" + cat.getDescription() + "</td>");
				showCat.append("<td>" + Utility.getNumberToStatus(cat.getStatus()) + "</td>");
				showCat.append("<td class=\"options-width\">");
				showCat.append("<a href=\"\" title=\"Edit\" class=\"icon-1 info-tooltip\"></a>");
				showCat.append("<a href=\"categorydelete?id=" + cat.getId() + "\" title=\"Delete\" class=\"icon-2 info-tooltip\"></a>");
//				showCat.append("<a href=\"\" title=\"Edit\" class=\"icon-3 info-tooltip\"></a>");
//				showCat.append("<a href=\"\" title=\"Edit\" class=\"icon-4 info-tooltip\"></a>");
//				showCat.append("<a href=\"\" title=\"Edit\" class=\"icon-5 info-tooltip\"></a>");
				showCat.append("</td>");
				showCat.append("</tr>");
			}
			request.setAttribute("categories", showCat);
			dispatcher = request.getRequestDispatcher(NHM.JSP.CATEGORYSHOW);
		}
		dispatcher.forward(request, response);
	}
}
