package com.my.nhm.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.my.nhm.NHM;
import com.my.nhm.Utility;
import com.my.nhm.database.DatabaseUtil;
import com.my.nhm.profile.ConfigurationReader;
import com.my.nhm.profile.ConfigurationReaderFactory;
import com.my.nhm.vo.BrandVO;
import com.my.nhm.vo.CategoryVO;
import com.my.nhm.vo.ProductVO;
import com.my.nhm.vo.UserVO;

/**
 * Servlet implementation class Productadd
 */
@WebServlet("/Productadd")
public class Productadd extends HttpServlet {
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(NHM.APP.APPLICATION_PROFILE);
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		UserVO user = Utility.isUserLoggedIn(session);
		RequestDispatcher dispatcher;
		if(user==null || !user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			DatabaseUtil dbUtil = new DatabaseUtil();
			List<CategoryVO>categories = dbUtil.showAllCategory();
			StringBuffer fieldBuffer = new StringBuffer();
			for(CategoryVO cat: categories)
			{
				if(fieldBuffer.length()>0)
				{
					fieldBuffer.append("<br clear=\"all\" />");
				}
				fieldBuffer.append("<span>&nbsp;"+cat.getName()+":<input name=\"categories\" type=\"checkbox\" value=\""+cat.getId()+"\" /></span>");
			}
			request.setAttribute("categories", fieldBuffer);
			List<BrandVO>brands = dbUtil.showAllBrand();
			StringBuffer brandStr = new StringBuffer();
			fieldBuffer = new StringBuffer();
			for(BrandVO brand: brands)
			{
				fieldBuffer.append("<option value=\""+brand.getId()+"\">"+brand.getName()+"</option>");
			}
			request.setAttribute("brands", fieldBuffer);
			dispatcher = request.getRequestDispatcher(NHM.JSP.PRODUCTADD);
		}
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserVO user = Utility.isUserLoggedIn(session);
		RequestDispatcher dispatcher = null;
		if(user==null || !user.getType().equals(NHM.USERTYPE.ADMIN))
		{
			dispatcher = request.getRequestDispatcher(NHM.JSP.LOGIN);
		}
		else
		{
			String name = request.getParameter("name");
			String price = request.getParameter("price");
			String description = request.getParameter("description");
			String brand = request.getParameter("brand");
			String[]categories = request.getParameterValues("categories");
			String status = request.getParameter("status");
//			image
			
			if(name.equals("") || price.equals("") || brand.equals("") || categories.length < 1 || status.equals(""))
			{
				request.setAttribute("error", "Name, price, brand, category and status can not be blank...");
			}
			else
			{
				List<Integer>categoriesid = new ArrayList<Integer>();
				for(String cat: categories)
				{
					categoriesid.add(Integer.parseInt(cat));
				}
				ProductVO productVO = new ProductVO(null, name, description, Double.parseDouble(price), Integer.parseInt(brand), Short.parseShort(status), user.getId(), categoriesid);
				DatabaseUtil dbUtil = new DatabaseUtil();
				if(dbUtil.saveProduct(productVO))
				{
					request.setAttribute("error", "Product successfully added...");
				}
				else
				{
					request.setAttribute("error", "Product failed to add...");
				}
//				dispatcher = request.getRequestDispatcher(NHM.JSP.PRODUCTADD);
			}
		}
		if(dispatcher==null)
		{
			doGet(request, response);
		}
		else
		{
			dispatcher.forward(request, response);
		}
	}

}
