
package com.my.nhm.profile;

import java.util.List;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class is responsible of reading messages from a data source. Data sources may vary in an application, they must
 * providetheir own implementations.
 */
public abstract class ConfigurationReader
{
	private static final Log LOGGER = LogFactory.getLog(ConfigurationReader.class);
    protected transient XMLConfiguration _config;

    /**
     * Default class constructor. We do not want applications to create instances without specifying a data source, so
     * this has been made private
     */
    private ConfigurationReader()
    {
    }

    /**
     * Initializes the name of the data source from which message strings need to be read.
     * 
     * @param dataSourceName Name of the data source.
     */
    protected ConfigurationReader(String configFileName)
    {
        try
        {
            _config = new XMLConfiguration(configFileName);
        }
        catch (ConfigurationException e)
        {
        	LOGGER.error("Error initializing the Configuration reader, with the file [" + configFileName + "]. Please see below for details. \n" + ExceptionUtils.getFullStackTrace(e));
        }
    }

    /**
     * Reads a boolean property from a data source, provided a string key to locate the property.
     * 
     * @param key Key to locate the property.
     * @return A boolean value.
     */
    public abstract boolean getBooleanProperty(String name);

    /**
     * Reads an integer property from a data source, provided a string key to locate the property.
     * 
     * @param key Key to locate the property.
     * @return An integer value.
     */
    public abstract int getIntegerProperty(String name);

    /**
     * <p>
     * Returns a list of property values sharing the same name.
     * </p>
     * <p>
     * For example, consider a configuration file containing the following section: <code>
     * <?xml version="1.0"?>
     * <Configuration>
     *    <Parent>
     *       <Child>Value 1</Child>
     *       <Child>Value 2</Child>
     *       <Child>Value 3</Child>
     *    </Parent>
     * </Configuration>
     * </code>
     * As can be seen, the <code>Child</code> property repeats itself in the configuration. The current method will
     * therefore return all values associated with this property.
     * </p>
     * 
     * @param name A {@link java.lang.String} containing property name.
     * @return A {@link java.util.List} of {@link java.lang.String} values containing all values available for the
     * property.
     */
    public abstract List<String> getList(String name);

    /**
     * Reads a string message from a data source, provided a string key to locate the message.
     * 
     * @param key Key to locate the message.
     * @return A text string.
     */
    public abstract String getProperty(String name);
}
