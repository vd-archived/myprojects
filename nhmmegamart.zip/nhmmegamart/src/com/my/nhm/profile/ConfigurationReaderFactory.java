/*
 * Filename:      MessageReaderFactory.java
 * Author:        Sapient
 * Creation date: November 03, 2006
 */
package com.my.nhm.profile;


/**
 * Creates instances of @see MessageReader.
 */
public final class ConfigurationReaderFactory
{
	private static final ConfigurationReaderFactory LOCAL_INSTANCE = new ConfigurationReaderFactory();

	/**
	 * Default constructor.  Made private to enforce Singleton pattern.
	 */
	private ConfigurationReaderFactory()
	{
	}

	/**
	 * Returns the singleton instance of the class.
	 * @return
	 */
	public static ConfigurationReaderFactory getInstance()
	{
		return LOCAL_INSTANCE;
	}

	/**
	 * Returns a @see MessageReader instance suitable for reading messages from a specified data source.
	 * 
	 * @param dataSourceName Name of the data source from which messages need to be read.
	 * @return A @see MessageReader instance.
	 */
	public ConfigurationReader getReader(final String dataSourceName)
	{
		return new XMLConfigurationReader(dataSourceName);
	}
}
