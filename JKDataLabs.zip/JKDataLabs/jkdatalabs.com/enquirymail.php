<?php
// multiple recipients
/*$to  = 'viveksingh0143@gmail.com' . ', '; // note the comma
$to .= 'jschamiyal@gmail.com' . ', '; // note the comma
$to .= 'info@jkdatalabs.com';*/
$to .= '';

// subject
$subject = 'Enquiry Call';

// message
$message = '
<html>
<head>
  <title>Enquiry call from users</title>
</head>
<body>
  <h2>User Details</h2>
  <p><strong>Name:</strong> ' . $_POST["cname"] . '</p>
  <p><strong>Company Name:</strong> ' . $_POST["company"] . '</p>
  <p><strong>E-Mail ID:</strong> ' . $_POST["email"] . '</p>
  <p><strong>Contact Number:</strong> ' . $_POST["phone"] . '</p>
  <p><strong>Fax Number:</strong> ' . $_POST["fax"] . '</p>
  <p><strong>Address:</strong> ' . $_POST["add1"] . '<br />' . $_POST["add2"] . '<br />ZIP: ' . $_POST["add3"] . '<br />' . $_POST["country"] . '</p>
  <br /><br />
  <h2>Interested In:</h2> <span style="color:#0033CC;">';
  if(isset($_POST["digitization"]))
  {
	  $message .= $_POST["digitization"] . ', ';
  }
  if(isset($_POST["website-development"]))
  {
	  $message .= $_POST["website-development"] . ', ';
  }
  if(isset($_POST["customized-software-solution"]))
  {
	  $message .= $_POST["customized-software-solution"] . ', ';
  }
  if(isset($_POST["search-engine-optimization"]))
  {
	  $message .= $_POST["search-engine-optimization"] . ', ';
  }
  if(isset($_POST["newsletter-design"]))
  {
	  $message .= $_POST["newsletter-design"];
  }
  $message .= '</span><br /><br /><h3>Requirements: <span style="color:#0033CC;">'. $_POST["describe"] . '</span></h3>
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
//$headers .= 'To: Jagdish Singh Chamiyal <jschamiyal@gmail.com>, Information <info@jkdatalabs.com>' . "\r\n";
$headers .= 'To: Jagdish Singh <jschamiyal@gmail.com>, Sales <sales@jkdatalabs.com>' . "\r\n";
$headers .= 'Bcc: Vivek Kumar Singh <viveksingh0143@gmail.com>' . "\r\n";
$headers .= 'From: JK Data Labs User Query<info@jkdatalabs.com>' . "\r\n";

// Mail it
mail($to, $subject, $message, $headers);
header ("Location: thanks.html");
exit;
?>