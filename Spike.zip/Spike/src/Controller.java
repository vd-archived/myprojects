import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import edu.uci.ics.crawler4j.crawler.CrawlConfig;
import edu.uci.ics.crawler4j.crawler.CrawlController;
import edu.uci.ics.crawler4j.fetcher.PageFetcher;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtConfig;
import edu.uci.ics.crawler4j.robotstxt.RobotstxtServer;


public class Controller {
	public static List<College>colleges = new ArrayList<College>();
	public static List<Course>courses = new ArrayList<Course>();
	public static List<String>courseName = new ArrayList<String>();
	
	public static void main(String[] args) throws Exception {
		String crawlStorageFolder = "d:/data/crawl/root";
		(new File(crawlStorageFolder)).mkdirs();
		int numberOfCrawlers = 1;

		CrawlConfig config = new CrawlConfig();
		config.setCrawlStorageFolder(crawlStorageFolder);
		config.setMaxDepthOfCrawling(2);

		/*
		 * Instantiate the controller for this crawl.
		 */
		PageFetcher pageFetcher = new PageFetcher(config);
		RobotstxtConfig robotstxtConfig = new RobotstxtConfig();
		RobotstxtServer robotstxtServer = new RobotstxtServer(robotstxtConfig, pageFetcher);
		CrawlController controller = new CrawlController(config, pageFetcher, robotstxtServer);
		
		controller.addSeed("http://www.study.cam.ac.uk/undergraduate/colleges/contacts.html");
		controller.addSeed("http://www.admin.cam.ac.uk/students/gradadmissions/prospec/studying/qualifdir/courses/index.html");
		controller.addSeed("http://www.study.cam.ac.uk/undergraduate/courses/");
		
		controller.start(MyCrawler.class, numberOfCrawlers);
		write();
	}
	
	public static void write()
	{
		StringBuffer collegeStr = new StringBuffer();
		Workbook wb = new HSSFWorkbook();
	    CreationHelper createHelper = wb.getCreationHelper();
	    Sheet collegeSheet = wb.createSheet("Colleges");
	    int rowIndex = 0;
		    Row row = collegeSheet.createRow((short)(rowIndex++));
	    	row.createCell(1).setCellValue("University");
	    	row.createCell(2).setCellValue("Name");
	    	row.createCell(3).setCellValue("Address");
	    	row.createCell(4).setCellValue("Telephone");
	    	row.createCell(5).setCellValue("E-Mail");
	    	row.createCell(6).setCellValue("Website");
    	
	    for(College college: colleges)
	    {
	    	row = collegeSheet.createRow((short)(rowIndex++));
	    	row.createCell(1).setCellValue(college.getUniversity());
	    	row.createCell(2).setCellValue(college.getName());
	    	row.createCell(3).setCellValue(college.getAddress());
	    	row.createCell(4).setCellValue(college.getTelephone());
	    	row.createCell(5).setCellValue(college.getEmail());
	    	row.createCell(6).setCellValue(college.getWebsite());
	    	collegeStr.append(college.getName() + "\n");
	    }

	    rowIndex = 0;
	    Sheet courseSheet = wb.createSheet("Course");
	    
	    row = courseSheet.createRow((short)(rowIndex++));
    	row.createCell(1).setCellValue("University");
    	row.createCell(2).setCellValue("Type");
    	row.createCell(3).setCellValue("Name");
    	row.createCell(4).setCellValue("College Link");
    	row.createCell(5).setCellValue("Apply Link");
//    	http://www.study.cam.ac.uk/undergraduate/apply/
//   	University name, type of course, Course name, college link, apply link

	    for(Course course: courses)
	    {
	    	row = courseSheet.createRow((short)(rowIndex++));
	    	row.createCell(1).setCellValue(course.getUniversity());
	    	row.createCell(2).setCellValue(course.getType());
	    	row.createCell(3).setCellValue(course.getName());
	    	row.createCell(4).setCellValue("Course Available to all colleges");
	    	row.createCell(5).setCellValue("http://www.study.cam.ac.uk/undergraduate/apply/");
	    }
	    File file = new File("Crawl.xls");
	    try
	    {
	    	FileOutputStream fileOut = new FileOutputStream(file);
		    wb.write(fileOut);
		    fileOut.close();
	    }
	    catch(Exception e){}
	    System.out.println("File is successfully write at " + file.getAbsolutePath());
	}
}