
public class College {
	private String university;
	private String name;
	private String address;
	private String telephone;
	private String website;
	private String email;
	
	public College() {
	}
	
	public College(String university) {
		super();
		this.university = university;
	}
	
	public College(String university, String name, String address, String telephone) {
		this(university);
		this.name = name;
		this.address = address;
		this.telephone = telephone;
	}
	
	public College(String university, String name, String address, String telephone, String website, String email) {
		this(university, name, address, telephone);
		this.website = website;
		this.email = email;
	}
	
	public College(String university, String name, String address, String telephone, String websiteAndEmailText) {
		this(university, name, address, telephone);
		String[]webEmail = websiteAndEmailText.split(" |\n");
		for(String str: webEmail)
		{
			str = str.trim();
			if(str.length() > 0)
			{
				if(str.indexOf("@") != -1)
				{
					this.email = str;
				}
				else
				{
					this.website = str;
				}
			}
		}
	}
	
	public void setWebsiteAndEmailText(String websiteAndEmailText) {
		String[]webEmail = websiteAndEmailText.split(" |\n");
		for(String str: webEmail)
		{
			str = str.trim();
			if(str.length() > 0)
			{
				if(str.indexOf("@") != -1)
				{
					this.email = str;
				}
				else
				{
					this.website = str;
				}
			}
		}
	}
	
	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getTelephone() {
		return telephone;
	}
	
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	
	public String getWebsite() {
		return website;
	}
	
	public void setWebsite(String website) {
		this.website = website;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
}
