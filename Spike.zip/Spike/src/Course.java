import java.util.List;


public class Course {
	private String university;
	private String type;
	private String name;
	private String ucas_code;
	private String duration;
	private String entry2012;
	private String openDaysEvent;
	private String relatedCourses;
	private String contactDetails;
	private String overview;
	private String courseOutline;
	private String entryRequirement;
	private String applyLink;
	List<College>colleges;
	
	public Course()
	{}
	
	public Course(String university)
	{
		this.university = university;
	}
	
	public Course(String type, String name, String ucas_code, String duration, String entry2012, String openDaysEvent, String relatedCourses, String contactDetails, String overview, String courseOutline, String entryRequirement, String applyLink, List<College> colleges) {
		super();
		this.type = type;
		this.name = name;
		this.ucas_code = ucas_code;
		this.duration = duration;
		this.entry2012 = entry2012;
		this.openDaysEvent = openDaysEvent;
		this.relatedCourses = relatedCourses;
		this.contactDetails = contactDetails;
		this.overview = overview;
		this.courseOutline = courseOutline;
		this.entryRequirement = entryRequirement;
		this.applyLink = applyLink;
		this.colleges = colleges;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUcas_code() {
		return ucas_code;
	}

	public void setUcas_code(String ucas_code) {
		this.ucas_code = ucas_code;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getEntry2012() {
		return entry2012;
	}

	public void setEntry2012(String entry2012) {
		this.entry2012 = entry2012;
	}

	public String getOpenDaysEvent() {
		return openDaysEvent;
	}

	public void setOpenDaysEvent(String openDaysEvent) {
		this.openDaysEvent = openDaysEvent;
	}

	public String getRelatedCourses() {
		return relatedCourses;
	}

	public void setRelatedCourses(String relatedCourses) {
		this.relatedCourses = relatedCourses;
	}

	public String getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(String contactDetails) {
		this.contactDetails = contactDetails;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getCourseOutline() {
		return courseOutline;
	}

	public void setCourseOutline(String courseOutline) {
		this.courseOutline = courseOutline;
	}

	public String getEntryRequirement() {
		return entryRequirement;
	}

	public void setEntryRequirement(String entryRequirement) {
		this.entryRequirement = entryRequirement;
	}

	public String getApplyLink() {
		return applyLink;
	}

	public void setApplyLink(String applyLink) {
		this.applyLink = applyLink;
	}

	public List<College> getColleges() {
		return colleges;
	}

	public void setColleges(List<College> colleges) {
		this.colleges = colleges;
	}
}