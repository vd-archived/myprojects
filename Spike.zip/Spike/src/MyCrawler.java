import java.io.StringReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.crawler.WebCrawler;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.url.WebURL;

public class MyCrawler extends WebCrawler {

	private final static Pattern FILTERS = Pattern.compile(".*(\\.(css|js|bmp|gif|jpe?g" 
			+ "|png|tiff?|mid|mp2|mp3|mp4"
			+ "|wav|avi|mov|mpeg|ram|m4v|pdf" 
			+ "|rm|smil|wmv|swf|wma|zip|rar|gz))$");

	/**
	 * You should implement this function to specify whether
	 * the given url should be crawled or not (based on your
	 * crawling logic).
	 */
	@Override
	public boolean shouldVisit(WebURL url) {
		String href = url.getURL().toLowerCase();
		Boolean shouldVisit = !FILTERS.matcher(href).matches() && (href.startsWith("http://www.admin.cam.ac.uk/students/gradadmissions/prospec/studying/qualifdir/courses/") || href.startsWith("http://www.admin.cam.ac.uk/students/gradadmissions/prospec/studying/qualifdir/courses/index.html") || href.startsWith("http://www.study.cam.ac.uk/undergraduate/colleges/contacts.html") || (href.startsWith("http://www.study.cam.ac.uk/undergraduate/courses/") && !href.endsWith(".html")));
		return shouldVisit;
	}

	/**
	 * This function is called when a page is fetched and ready 
	 * to be processed by your program.
	 */
	@Override
	public void visit(Page page) {
		try
		{
			String url = page.getWebURL().getURL();
			System.out.println("'" + url + "' is in process.......");
			if(url.equalsIgnoreCase("http://www.study.cam.ac.uk/undergraduate/courses/"))
			{
				return;
			}
			HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
			if (htmlParseData != null) {
				if (htmlParseData instanceof HtmlParseData) {
					if(url.startsWith("http://www.study.cam.ac.uk/undergraduate/colleges/contacts.html"))
					{
						String html = htmlParseData.getHtml();
						Integer startIndex = html.indexOf("<table ", html.indexOf("<h3>College Contacts</h3>"));
						Integer endIndex   = html.indexOf("</table>", startIndex) + 8;
						String table = html.substring(startIndex, endIndex);
						table = table.replace("&nbsp;", " ").replace("<br>", "<br />");
						try {
							DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
							DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
							Document doc = dBuilder.parse(new InputSource(new StringReader(table)));
							doc.getDocumentElement().normalize();
							NodeList trList = doc.getElementsByTagName("tr");
							for (int i = 1; i < trList.getLength(); i++) {
								Node trNode = trList.item(i);
								College college = new College("University of Cambridge"); 
								if (trNode.getNodeType() == Node.ELEMENT_NODE) {
									NodeList tdList = ((Element)trNode).getElementsByTagName("td");
									int k = 0;
									for (int j = 0; j < tdList.getLength(); j++) {
										Node tdNode = tdList.item(j);
										if (tdNode.getNodeType() == Node.ELEMENT_NODE) {
											Element tdElement = (Element) tdNode;
											if(k == 0)
											{
												college.setName(formatString(tdElement.getTextContent()));
											}
											else if(k == 1)
											{
												college.setAddress(formatString(tdElement.getTextContent()));
											}
											else if(k == 2)
											{
												college.setTelephone(formatString(tdElement.getTextContent()));
											}
											else if(k == 3)
											{
												college.setWebsiteAndEmailText(formatString(tdElement.getTextContent()));
											}
										}
										k++;
									}
									Controller.colleges.add(college);
								}
							}
						} catch (Exception e) {
							//e.printStackTrace();
						}
					}
					else if(url.startsWith("http://www.admin.cam.ac.uk/students/gradadmissions/prospec/studying/qualifdir/courses/") && !url.endsWith("index.html"))
					{
						String html = htmlParseData.getHtml();
						Integer startIndex = html.indexOf("<div id=\"content-primary\"");
						Integer endIndex   = html.indexOf("<div id=\"content-secondary\"", startIndex);
						String siteContent = html.substring(startIndex, endIndex);
						siteContent = siteContent.replace("&nbsp;", " ").replace("<br>", "<br />");
						Pattern pattern = Pattern.compile("<h3(>|([^>]+>))(.*?)</h3>", Pattern.CASE_INSENSITIVE);
					    Matcher matcher = pattern.matcher(siteContent);
					    while (matcher.find()) {
					    	String name = matcher.group().replaceAll("<[^>]+>", "");
					    	if(!Controller.courseName.contains(name) && !name.equalsIgnoreCase("A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P | Q | R | S | T | U | V | W | X | Y | Z"))
					    	{
					    		Course course = new Course("University of Cambridg");
								course.setName(name);
								course.setColleges(Controller.colleges);
								course.setType("Graduate");
								Controller.courses.add(course);
								Controller.courseName.add(name);
					    	}
					    }
					}
					else if(url.startsWith("http://www.study.cam.ac.uk/undergraduate/courses/"))
					{
						String html = htmlParseData.getHtml();
						html = formatHTML(html);
						Integer startIndex = html.indexOf("<section id=\"primary\"");
						Integer endIndex   = html.indexOf("</section>", startIndex) + 10;
						String section = html.substring(startIndex, endIndex);
						section = section.replace("&nbsp;", " ").replace("<br>", "<br />");
						try {
							DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
							DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
							Document doc = dBuilder.parse(new InputSource(new StringReader(section)));
							doc.getDocumentElement().normalize();
							Element root = doc.getDocumentElement();
							Course course = new Course("University of Cambridg");
							course.setName(root.getElementsByTagName("h3").item(0).getTextContent());
							course.setColleges(Controller.colleges);
							course.setType("Undergraduate");
							
							Element tabs = (Element)((Element)root.getElementsByTagName("div").item(0)).getElementsByTagName("div").item(0);
							NodeList divList = tabs.getElementsByTagName("div");
							for (int i = 1; i < divList.getLength(); i++) {
								Element divNode = (Element)divList.item(i);
								if (divNode.getNodeType() == Node.ELEMENT_NODE) {
									String ID = divNode.getAttribute("id");
									if(ID != null)
									{
										if(ID.equalsIgnoreCase("Factfile"))
										{
											NodeList trList = divNode.getElementsByTagName("tr");
											for (int j = 1; j < trList.getLength(); j++) {
												Element trNode = (Element)trList.item(i);
												if (trNode.getNodeType() == Node.ELEMENT_NODE) {
													NodeList tdList = trNode.getElementsByTagName("td");
													if(tdList.getLength() == 2)
													{
														String heading = tdList.item(0).getTextContent().trim();
														String headValue = formatString(tdList.item(1).getTextContent().trim());
														if(heading.equalsIgnoreCase("UCAS code"))
														{
															course.setUcas_code(headValue);
														}
														else if(heading.equalsIgnoreCase("Duration"))
														{
															course.setDuration(headValue);
														}
														else if(heading.equalsIgnoreCase("Colleges"))
														{
	//														course.setColleges(colleges).setUcas_code(headValue);
														}
														else if(heading.equalsIgnoreCase("2012 entry"))
														{
															course.setEntry2012(headValue);
														}
														else if(heading.equalsIgnoreCase("Open days and events 2013"))
														{
															course.setOpenDaysEvent(headValue);
														}
														else if(heading.equalsIgnoreCase("Related courses"))
														{
															course.setRelatedCourses(headValue);
														}
														else if(heading.equalsIgnoreCase("Contact details"))
														{
															course.setContactDetails(headValue);
														}
													}
												}
											}
										}
										else if(ID.equalsIgnoreCase("Overview"))
										{
											course.setOverview(divNode.getTextContent());
										}
										else if(ID.equalsIgnoreCase("Course-Outline"))
										{
											course.setCourseOutline(divNode.getTextContent());
										}
										else if(ID.equalsIgnoreCase("Entry-Requirements"))
										{
											course.setEntryRequirement(divNode.getTextContent());
										}
										else if(ID.equalsIgnoreCase("Further-Resources"))
										{
	
										}
									}
								}
							}
							Controller.courses.add(course);
						} catch (Exception e) {
//							e.printStackTrace();
						}
					}
				}
			} else {
				System.out.println("Couldn't parse the content of the page.");
			}
		}
		catch(Exception exx)
		{}
	}
	
	private String formatString(String str)
	{
		str = str.replaceAll("  +", " ");
		return str;
	}
	
	private String formatHTML(String html)
	{
		return html.replace("&", "&amp;");
//		 return StringEscapeUtils.escapeHtml(html);
	}
}
