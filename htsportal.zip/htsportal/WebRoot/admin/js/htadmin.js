$("#selectall").click(function(){
  	if($(this).is(':checked')){
		jQuery.each($(".row_select"), function() {
		   $(this).attr('checked', true);
		});
  	}else{
  		jQuery.each($(".row_select"), function() {
		   $(this).attr('checked', false);
		});
  	}
});
function submitForm(publicationdelete){
	$("#"+publicationdelete).submit();
}
