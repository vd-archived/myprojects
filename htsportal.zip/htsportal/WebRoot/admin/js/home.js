	/* Disable right click script start */
	function clickIE() {if (document.all) {(message);return false;}}
	function clickNS(e) {if
	(document.layers||(document.getElementById&&!document.all)) {
	if (e.which==2||e.which==3) {(message);return false;}}}
	if (document.layers)
	{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
	else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
	document.oncontextmenu=new Function("return false");
	/* Disable right click script end */
	
	
	var fadeDuration=2000;
	var slideDuration=4000;
	var currentIndex=1;
	var nextIndex=1;
	
	function imageSwitch() {
		nextIndex =currentIndex+1;
		if(nextIndex > $('ul.slideshow li').length)
		{
			nextIndex =1;
		}
		$("ul.slideshow li:nth-child("+nextIndex+")").addClass('show').animate({opacity: 1.0}, fadeDuration);
		$("ul.slideshow li:nth-child("+currentIndex+")").animate({opacity: 0.0}, fadeDuration).removeClass('show');
		currentIndex = nextIndex;
	}
	
	$(function() {
	    setInterval( "imageSwitch()", 5000 );
	});
	
	function filterForWeb(publication)
	{
		publication = publication.replace("&","%26");
		publication = publication.replace(" ","+");
		return publication;
	}
