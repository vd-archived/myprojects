$(document).ready(function() {
	$("#top-member").click(function () {
		$(".login-section").slideToggle("slow");
	});
	$(".login-section #cancel_button").click(function () {
		$(".login-section").slideUp("slow");
	});
	$(".box_shortintro_rows_showlessdiv").click(function(){
		$(this).css("display", "none");
		$(this).siblings(".box_shortintro_rows_showalldiv").css("display", "block");
		$(this).siblings(".listchilds").css("overflow", "hidden");
		$(this).siblings(".listchilds").animate({height: '100px'}, 1500);
	});
	$(".box_shortintro_rows_showalldiv").click(function(){
		$(this).css("display", "none");
		$(this).siblings(".box_shortintro_rows_showlessdiv").css("display", "block");
		$(this).siblings(".listchilds").css("max-height", "100%");
		$(this).siblings(".listchilds").animate({height: '100%'}, 1500);
		$(this).siblings(".listchilds").css("overflow", "visible");
	});
});


function inputFocus(i){
    if(i.value==i.defaultValue){ i.value=""; i.style.color="#000"; }
}
function inputBlur(i){
    if(i.value==""){ i.value=i.defaultValue; i.style.color="#888"; }
}