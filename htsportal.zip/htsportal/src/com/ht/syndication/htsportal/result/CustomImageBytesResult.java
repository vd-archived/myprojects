package com.ht.syndication.htsportal.result;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.ht.syndication.htsportal.action.OldImageAction;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.Result;

public class CustomImageBytesResult implements Result {
	public void execute(ActionInvocation invocation) throws Exception {
		OldImageAction action = (OldImageAction) invocation.getAction();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.getOutputStream().write(action.getCustomImageInBytes());
		response.setContentType(action.getCustomContentType());
		response.getOutputStream().flush();
	}
}
