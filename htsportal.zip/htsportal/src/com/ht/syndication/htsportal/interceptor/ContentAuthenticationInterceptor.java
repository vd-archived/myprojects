package com.ht.syndication.htsportal.interceptor;

import java.util.ArrayList;
import java.util.List;

import com.ht.syndication.htsportal.domain.RoleStatus;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class ContentAuthenticationInterceptor implements Interceptor
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5136289903772100888L;
	private List<String> excludeAction;

	/**
	 * 
	 */
	public void init() 
	{
		excludeAction = new ArrayList<String>();
		excludeAction.add("authenticateuser");
		excludeAction.add("login");
		excludeAction.add("authenticateuser.action");
		excludeAction.add("login.action");
	}

	/**
	 * 
	 */
	public String intercept(ActionInvocation actionInvocation) throws Exception 
	{
		final ActionContext context = actionInvocation.getInvocationContext();
		if(excludeAction.contains(actionInvocation.getProxy().getActionName()))
		{
			return actionInvocation.invoke();
		}
		UserVO userVO = ((UserVO) context.getSession().get(HTSPortal.UserConst));
		if (userVO == null) 
		{
			return "NEED_LOGIN";
		}
		else if(!userVO.getRole().equals(RoleStatus.CONTENT_ADMIN) && !userVO.getRole().equals(RoleStatus.SITE_ADMIN))
		{
			return "UNAUTHORIZED_LOGIN";
		}
		else 
		{
			return actionInvocation.invoke();
		}
	}

	/**
	 * 
	 */
	public void destroy() 
	{
		// TODO Auto-generated method stub
	}
}
