package com.ht.syndication.htsportal;

import java.util.Enumeration;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;

public class HTSPortalListener implements ServletContextListener
{
	private static final Log LOGGER = LogFactory.getLog(HTSPortalListener.class);
	
	public void contextDestroyed(ServletContextEvent arg0) {
		LOGGER.info("Destroy HTSPortal Listener");
	}
 
	public void contextInitialized(ServletContextEvent event) 
	{
		LOGGER.info("Initialize HTSPortal Listener");
		Properties properties = new Properties();
        ServletContext servletContext = event.getServletContext();
        Enumeration<?> keys = servletContext.getInitParameterNames();
        while (keys.hasMoreElements()) 
        {
            String key = (String) keys.nextElement();
            String value = servletContext.getInitParameter(key);
            properties.setProperty(key, value);
        }
 		properties.setProperty("APP_RROT", event.getServletContext().getRealPath("/"));
		HTSPortal.SERVLETCONTEXT = properties;
		Utility.saveIntroductionXMLStartup();
	}
}