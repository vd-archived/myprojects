package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.CategoryVO;
/**
 * A data access object (DAO) providing persistence and search support for Categorys
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.ht.syndication.htsportal.domain.Category
 * @author MyEclipse Persistence Tools
 */

public class CategoryDaoImpl extends CategoryDaoBase
{
    @SuppressWarnings("unchecked")
    @Override
    public Object load(final int transform, final Integer id)
    {
        final Criteria query = super.getSession().createCriteria(Category.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Category)entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Category.class);
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);

        return results;
    }
    
    /**
     * 
     */
    public Category categoryVOToEntity(CategoryVO categoryVO) 
    {
        Category entity = this.load(categoryVO.getId());
        if (entity == null)
        {
            entity = Category.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
        entity.setUpdatedate(new Date());
        this.categoryVOToEntity(categoryVO, entity, false);

        return entity;
    }

    /**
     * 
     */
	public Category load(String name) {
		final Criteria query = super.getSession().createCriteria(Category.class);
        query.add(Restrictions.eq("name", name));
        final Object entity = query.uniqueResult();
        return (Category)entity;
	}
}