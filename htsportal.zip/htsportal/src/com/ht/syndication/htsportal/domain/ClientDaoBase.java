
package com.ht.syndication.htsportal.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.ClientVO;

public abstract class ClientDaoBase extends HibernateDaoSupport implements ClientDao 
{
	public Object load(final int transform, final Integer id) 
	{
        if (id == null) 
		{
			throw new IllegalArgumentException("Client.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ClientImpl.class, id);
		return transformEntity(transform, (Client) entity);
	}

	public Client load(Integer id) 
	{
		return (Client) this.load(TRANSFORM_NONE, id);
	}
	
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Client.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ClientImpl.class, name);
		return transformEntity(transform, (Client) entity);
	}

	public Client loadByName(String name) 
	{
		return (Client) this.loadByName(TRANSFORM_NONE, name);
	}	

	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}

	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(ClientImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	public Client create(Client client) 
	{
		return (Client) this.create(TRANSFORM_NONE, client);
	}

	public Object create(final int transform, final Client client) 
	{
		if (client == null) 
		{
			throw new IllegalArgumentException("Client.create - 'client' can not be null");
		}
		this.getHibernateTemplate().save(client);
		return this.transformEntity(transform, client);
	}

	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Client.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Client) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	public Client create(Integer id, String name, String details, Short type, Short status, Short revenueinterval) 
	{
		return (Client) this.create(TRANSFORM_NONE, id, name, details, type, status, revenueinterval);
	}

	public java.lang.Object create(final int transform, Integer id, String name, String details, Short type, Short status, Short revenueinterval) 
	{
		Client entity = new ClientImpl();
		entity.setId(id);
		entity.setName(name);
		entity.setDetails(details);
		entity.setType(type);
		entity.setStatus(status);
		entity.setRevenueinterval(revenueinterval);
		return this.create(transform, entity);
	}

	public void update(Client client) 
	{
		if (client == null) 
		{
			throw new IllegalArgumentException("Client.update - 'client' can not be null");
		}
		this.getHibernateTemplate().update(client);
	}

	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Client.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((Client) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	public void remove(Client client) 
	{
		if (client == null) 
		{
			throw new IllegalArgumentException("Client.remove - 'client' can not be null");
		}
		this.getHibernateTemplate().delete(client);
	}

	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Client.remove - 'id' can not be null");
		}
		Client entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Client.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	protected Object transformEntity(final int transform, final Client entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_CLIENTVO	:	target = toClientVO(entity);
				break;
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}

	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
		    case TRANSFORM_CLIENTVO	:	toClientVOCollection(entities);
			break;
		    case TRANSFORM_NONE			: 
		    default						:
		}
	}

	public final void toClientVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities, CLIENTVO_TRANSFORMER);
		}
	}

	protected ClientVO toClientVO(Object[] row) 
	{
		ClientVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Client) 
				{
					target = this.toClientVO((Client) object);
					break;
				}
			}
		}
		return target;
	}

	private Transformer CLIENTVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Client) 
    			{
    				result = toClientVO((Client) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toClientVO((Object[]) input);
    			}
    			return result;
    		}
    	};

	public final void clientVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof ClientVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, clientVOToEntityTransformer);
		}
	}

	private final Transformer clientVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return clientVOToEntity((ClientVO) input);
    		}
    	};

	public void toClientVO(Client client, ClientVO target) 
	{
		target.setId(client.getId());
		target.setName(client.getName());
		target.setDetails(client.getDetails());
		target.setType(client.getType());
		List<String>pubs = new ArrayList<String>();
		for(Publication pub: client.getPublication())
		{
			pubs.add(pub.getId().toString());
		}
		target.setPublications(pubs);
		target.setStatus(client.getStatus());
		target.setRevenueinterval(client.getRevenueinterval());
	}

	public ClientVO toClientVO(final Client entity) 
	{
		final ClientVO target = new ClientVO();
		this.toClientVO(entity, target);
		return target;
	}

	public void clientVOToEntity(ClientVO client, Client target, Boolean copyIfNull) 
	{
		if (copyIfNull || (client.getId() != null)) 
		{
			target.setId(client.getId());
		}
		if (copyIfNull || client.getName() != null) 
		{
			target.setName(client.getName());
		}
		if (copyIfNull || client.getDetails() != null) 
		{
			target.setDetails(client.getDetails());
		}
		if (copyIfNull || client.getType() != null) 
		{
			target.setType(client.getType());
		}
		if (copyIfNull || client.getStatus() != null) 
		{
			target.setStatus(client.getStatus());
		}
		if (copyIfNull || client.getRevenueinterval() != null) 
		{
			target.setRevenueinterval(client.getRevenueinterval());
		}
	}
	
	public Client clientVOToEntity(ClientVO client)
	{
		Client entity = Client.Factory.newInstance();
		this.clientVOToEntity(client, entity, Boolean.FALSE);
		return entity;
	}
}