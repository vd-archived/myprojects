package com.ht.syndication.htsportal.domain;

public class RevenueImpl extends Revenue 
{
	
}
