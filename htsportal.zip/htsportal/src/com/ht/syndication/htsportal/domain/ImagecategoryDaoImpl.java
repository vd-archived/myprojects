package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.ImagecategoryVO;

public class ImagecategoryDaoImpl extends ImagecategoryDaoBase
{
    @SuppressWarnings("unchecked")
    @Override
    public Object load(final int transform, final Integer id)
    {
        final Criteria query = super.getSession().createCriteria(Imagecategory.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Imagecategory)entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Imagecategory.class);
        query.addOrder(Order.desc("priority"));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAllActive(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Imagecategory.class);
        query.add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.addOrder(Order.desc("priority"));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }

    /**
     * 
     */
    public Imagecategory imagecategoryVOToEntity(ImagecategoryVO imagecategoryVO) 
    {
        Imagecategory entity = this.load(imagecategoryVO.getId());
        if (entity == null)
        {
            entity = Imagecategory.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
        entity.setUpdatedate(new Date());
        this.imagecategoryVOToEntity(imagecategoryVO, entity, false);

        return entity;
    }

    /**
     * 
     */
	public Imagecategory load(String name) {
		final Criteria query = super.getSession().createCriteria(Imagecategory.class);
        query.add(Restrictions.eq("name", name));
        final Object entity = query.uniqueResult();
        return (Imagecategory)entity;
	}
}