
package com.ht.syndication.htsportal.domain;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.ClientRevenuesVO;
import com.ht.syndication.htsportal.transfer.RevenueVO;

public abstract class RevenueDaoBase extends HibernateDaoSupport implements RevenueDao 
{
	public Object load(final int transform, final Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Revenue.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(RevenueImpl.class,id);
		return transformEntity(transform,(Revenue) entity);
	}

	public Revenue load(Integer id) 
	{
		return (Revenue) this.load(TRANSFORM_NONE, id);
	}
	
	public Collection loadByPublicationClientDateRange(Publication publication, Client client, final Date startDate, final Date endDate)
	{
		return this.loadByPublicationClientDateRange(TRANSFORM_NONE, publication, client, startDate, endDate);
	}

	public Revenue loadByPublicationClientDate(Publication publication, Client client, final Date date)
	{
		return (Revenue) this.loadByPublicationClientDate(TRANSFORM_NONE, publication, client, date);
	}
	
	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}


	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(RevenueImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	public Revenue create(Revenue revenue) 
	{
		return (Revenue) this.create(TRANSFORM_NONE, revenue);
	}

	public Object create(final int transform, final Revenue revenue) 
	{
		if (revenue == null) 
		{
			throw new IllegalArgumentException("Revenue.create - 'revenue' can not be null");
		}
		this.getHibernateTemplate().save(revenue);
		return this.transformEntity(transform, revenue);
	}

	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Revenue.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Revenue) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	public Revenue create(Integer id, Publication publication, Client client, Date date, Double amount, Short status) 
	{
		return (Revenue) this.create(TRANSFORM_NONE, id, publication, client, date, amount, status);
	}

	public Object create(final int transform, Integer id, Publication publication, Client client, Date date, Double amount, Short status) 
	{
		Date currDate = new Date();
		Revenue entity = Revenue.Factory.newInstance();
		entity.setId(id);
		entity.setPublication(publication);
		entity.setClient(client);
		entity.setDate(date);
		entity.setAmount(amount);
		entity.setStatus(status);
		entity.setCreatedate(currDate);
		entity.setUpdatedate(currDate);
		return this.create(transform, entity);
	}
	
	public void update(Revenue revenue) 
	{
		if (revenue == null) 
		{
			throw new IllegalArgumentException("Revenue.update - 'revenue' can not be null");
		}
		this.getHibernateTemplate().update(revenue);
	}

	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Revenue.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((Revenue) entityIterator.next());
						}
						return null;
					}
				}, true);
	}
	
	public void remove(Revenue revenue) 
	{
		if (revenue == null) 
		{
			throw new IllegalArgumentException("Revenue.remove - 'revenue' can not be null");
		}
		this.getHibernateTemplate().delete(revenue);
	}
	
	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Revenue.remove - 'id' can not be null");
		}
		Revenue entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}
	
	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Revenue.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}
	
	protected Object transformEntity(final int transform, final Revenue entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
				case TRANSFORM_REVENUEVO	:	target = toRevenueVO(entity);
				break;
				case TRANSFORM_NONE			: 
				default						:	target = entity;
			}
		}
		return target;
	}
	
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
			case TRANSFORM_REVENUEVO	:	toRevenueVOCollection(entities);
			break;
			case TRANSFORM_CLIENT_REVENUE	:	toClientRevenuesVOCollection(entities);
			break;
			case TRANSFORM_NONE			: 
			default						:
		}
	}
	
	protected Map transformMap(final int transform, final Collection<Revenue> entities) 
	{
		final Map result = new HashMap();
		if(transform == TRANSFORM_PUBLICATION_REVENUEINTEGER)
		{
			for(Revenue revenue: entities)
			{
				result.put(revenue.getClient().getId(), revenue.getAmount());
			}
		}
		else
		{
			for(Revenue revenue: entities)
			{
				result.put(revenue.getClient().getName(), revenue.getAmount());
			}
		}
		return result;
	}
	
	public final void toClientRevenuesVOCollection(Collection entities) 
	{
		if (entities != null)
		{
			CollectionUtils.transform(entities, CLIENT_REVENUEVO_TRANSFORMER);
		}
	}
	
	public final void toRevenueVOCollection(Collection entities) 
	{
		if (entities != null)
		{
			CollectionUtils.transform(entities, REVENUEVO_TRANSFORMER);
		}
	}
	
	protected ClientRevenuesVO toClientRevenuesVO(Object[] row) 
	{
		ClientRevenuesVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Revenue) 
				{
					target = this.toClientRevenuesVO((Revenue) object);
					break;
				}
			}
		}
		return target;
	}
	
	protected RevenueVO toRevenueVO(Object[] row) 
	{
		RevenueVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Revenue) 
				{
					target = this.toRevenueVO((Revenue) object);
					break;
				}
			}
		}
		return target;
	}

	private Transformer CLIENT_REVENUEVO_TRANSFORMER = new Transformer() 
	{
		public Object transform(Object input) 
		{
			Object result = null;
			if (input instanceof Revenue) 
			{
				result = toClientRevenuesVO((Revenue) input);
			} 
			else if (input instanceof Object[]) 
			{
				result = toClientRevenuesVO((Object[]) input);
			}
			return result;
		}
	};
	
	private Transformer REVENUEVO_TRANSFORMER = new Transformer() 
		{
			public Object transform(Object input) 
			{
				Object result = null;
				if (input instanceof Revenue) 
				{
					result = toRevenueVO((Revenue) input);
				} 
				else if (input instanceof Object[]) 
				{
					result = toRevenueVO((Object[]) input);
				}
				return result;
			}
		};
		
	public final void revenueVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof RevenueVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, RevenueVOToEntityTransformer);
		}
	}

	private final Transformer RevenueVOToEntityTransformer = new Transformer() 
		{
			public Object transform(Object input) 
			{
				return revenueVOToEntity((RevenueVO) input);
			}
		};

	public void toClientRevenuesVO(Revenue source, ClientRevenuesVO target) 
	{
		target.setId(source.getId());
		target.addRevenue(source.getDate(), source.getAmount());
	}
		
	public void toRevenueVO(Revenue source, RevenueVO target) 
	{
		target.setId(source.getId());
		target.setPublication(source.getPublication().getId().toString());
		target.setClient(source.getClient().getId().toString());
		target.setDate(source.getDate());
		target.setAmount(source.getAmount());
		target.setStatus(source.getStatus());
	}

	public ClientRevenuesVO toClientRevenuesVO(final Revenue entity) 
	{
		final ClientRevenuesVO target = new ClientRevenuesVO();
		this.toClientRevenuesVO(entity, target);
		return target;
	}
	
	public RevenueVO toRevenueVO(final Revenue entity) 
	{
		final RevenueVO target = new RevenueVO();
		this.toRevenueVO(entity, target);
		return target;
	}
	

	public void revenueVOToEntity(RevenueVO source, Revenue target, Boolean copyIfNull) 
	{
		if (copyIfNull || (source.getId() != null))
		{
			target.setId(source.getId());
		}
		if (copyIfNull || (source.getDate() != null))
		{
			target.setDate(source.getDate());
		}
		if (copyIfNull || (source.getAmount() != null))
		{
			target.setAmount(source.getAmount());
		}
		if (copyIfNull || (source.getStatus() != null))
		{
			target.setStatus(source.getStatus());
		}
	}
	
	public Revenue revenueVOToEntity(RevenueVO revenue)
	{
		Revenue entity = Revenue.Factory.newInstance();
		this.revenueVOToEntity(revenue, entity, Boolean.FALSE);
		return entity;
	}
	
	public Date getDateAccordingTimeInterval(final Date date, Short timeInterval)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime((Date)date.clone());
        Integer interval = 12/timeInterval;
        Integer monthInterval = calendar.get(Calendar.MONTH)/interval;
        calendar.set(Calendar.MONTH, (interval*monthInterval));
        calendar.set(Calendar.DATE, 1);
        return calendar.getTime();
	}
}