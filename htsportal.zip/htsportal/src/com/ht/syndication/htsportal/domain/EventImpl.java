package com.ht.syndication.htsportal.domain;

public class EventImpl extends Event {

}
