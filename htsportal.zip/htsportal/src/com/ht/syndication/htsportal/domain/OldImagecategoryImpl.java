package com.ht.syndication.htsportal.domain;

/**
 * PublicationImpl entity. @author MyEclipse Persistence Tools
 */
public class OldImagecategoryImpl extends OldImagecategory 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2163951120571621427L;
}
