package com.ht.syndication.htsportal.domain;

import java.util.Collection;

import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;

public interface ImagetagsDao
{
	public final static int TRANSFORM_NONE = 0;
	public final static int TRANSFORM_IMAGETAGSVO = 1;
	public final static int TRANSFORM_IMAGETAGSFULLVO = 2;
	public void toImagetagsVO(Imagetags source, ImagetagsVO target);
	public ImagetagsVO toImagetagsVO(Imagetags entity);
	public void toImagetagsVOCollection(Collection entities);
	
	public void toImagetagsFullVO(Imagetags source, ImagetagsFullVO target);
	public ImagetagsFullVO toImagetagsFullVO(Imagetags entity);
	public void toImagetagsFullVOCollection(Collection entities);
	
	public void imagetagsVOToEntity(ImagetagsVO source, Imagetags target, Boolean copyIfNull);
	public Imagetags imagetagsVOToEntity(ImagetagsVO imagetagsVO);
	public void imagetagsVOToEntityCollection(Collection instances);
	public Imagetags load(Integer id);
	public Imagetags load(String name);
	public Object load(int transform, Integer id);
	public Collection loadAll(final int transform);
	public Collection loadAllActive(final int transform);
	public Collection loadAllActiveByParent(final int transform, Integer parent);
	public Collection loadAllByType(final int transform, Short type);
	public Imagetags create(Imagetags imagetags);
	public Object create(int transform, Imagetags imagetags);
	public Collection create(Collection entities);
	public Collection create(int transform, Collection entities);
	public void update(Imagetags imagetags);
	public void update(Collection entities);
	public void remove(Imagetags imagetags);
	public void remove(Integer id);
	public void remove(Collection entities);
}