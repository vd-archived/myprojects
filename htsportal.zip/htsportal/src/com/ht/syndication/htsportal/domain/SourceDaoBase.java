
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.domain.Source.Factory;
import com.ht.syndication.htsportal.transfer.SourceVO;

/**
 * <p>
 * Source Base DAO Class: is able to create, update, remove, load, and find
 * objects of type <code>com.ht.syndication.htsportal.domain.Source</code>.
 * </p>
 * 
 * @see com.ht.syndication.htsportal.domain.Source
 */
public abstract class SourceDaoBase extends HibernateDaoSupport	implements SourceDao 
{
	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#load(int,
	 *      String)
	 */
	public Object load(final int transform, final Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Source.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(SourceImpl.class,id);
		return transformEntity(transform,(Source) entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#load(String)
	 */
	public Source load(Integer id) 
	{
		return (Source) this.load(TRANSFORM_NONE, id);
	}

	/**
	 * @see SourceDao#load(int,
	 *      String)
	 */
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Source.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(SourceImpl.class, name);
		return transformEntity(transform, (Source) entity);
	}

	/**
	 * @see SourceDao#load(String)
	 */
	public Source loadByName(String name) 
	{
		return (Source) this.loadByName(TRANSFORM_NONE, name);
	}
	
	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#loadAll()
	 */
	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}
	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#loadAll(int)
	 */
	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(SourceImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	public Collection loadAllActive() 
	{
		return this.loadAllActive(TRANSFORM_NONE);
	}
	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#loadAll(int)
	 */
	public Collection loadAllActive(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(SourceImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#create(com.ht.syndication.htsportal.domain.Source)
	 */
	public Source create(Source source) 
	{
		return (Source) this.create(TRANSFORM_NONE, source);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#create(int transform,
	 *      com.ht.syndication.htsportal.domain.Source)
	 */
	public Object create(final int transform, final Source source) 
	{
		if (source == null) 
		{
			throw new IllegalArgumentException("Source.create - 'source' can not be null");
		}
		this.getHibernateTemplate().save(source);
		return this.transformEntity(transform, source);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#create(java.util.Collection)
	 */
	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#create(int,
	 *      java.util.Collection)
	 */
	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Source.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Source) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#create(String,
	 *      String, String, Short)
	 */
	public Source create(Integer id, String name, String details, Short status) 
	{
		return (Source) this.create(TRANSFORM_NONE, id, name, details, status);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#create(int,
	 *      String, String, String,
	 *      Short)
	 */
	public Object create(final int transform, Integer id, String name, String details, Short status) 
	{
		Source entity = Source.Factory.newInstance();
		entity.setId(id);
		entity.setName(name);
		entity.setDetails(details);
		entity.setStatus(status);
		return this.create(transform, entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#update(com.ht.syndication.htsportal.domain.Source)
	 */
	public void update(Source source) 
	{
		if (source == null) 
		{
			throw new IllegalArgumentException("Source.update - 'source' can not be null");
		}
		this.getHibernateTemplate().update(source);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#update(java.util.Collection)
	 */
	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Source.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((Source) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#remove(com.ht.syndication.htsportal.domain.Source)
	 */
	public void remove(Source source) 
	{
		if (source == null) 
		{
			throw new IllegalArgumentException("Source.remove - 'source' can not be null");
		}
		this.getHibernateTemplate().delete(source);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#remove(String)
	 */
	public void remove(Integer id) 
	{
		if (id < 1) 
		{
			throw new IllegalArgumentException("Source.remove - 'id' can not be null");
		}
		Source entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#remove(java.util.Collection)
	 */
	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Source.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	/**
	 * Allows transformation of entities into value objects (or something else
	 * for that matter), when the <code>transform</code> flag is set to one of
	 * the constants defined in
	 * <code>com.ht.syndication.htsportal.domain.SourceDao</code>, please note
	 * that the {@link #TRANSFORM_NONE} constant denotes no transformation, so
	 * the entity itself will be returned.
	 * <p/>
	 * This method will return instances of these types:
	 * <ul>
	 * <li>{@link com.ht.syndication.htsportal.domain.Source} -
	 * {@link #TRANSFORM_NONE}</li>
	 * <li>{@link com.ht.syndication.htsportal.transfer.SourceVO} -
	 * {@link TRANSFORM_USERVO}</li>
	 * </ul>
	 * 
	 * If the integer argument value is unknown {@link #TRANSFORM_NONE} is
	 * assumed.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            {@link com.ht.syndication.htsportal.domain.SourceDao}
	 * @param entity
	 *            an entity that was found
	 * @return the transformed entity (i.e. new value object, etc)
	 * @see #transformEntities(int,java.util.Collection)
	 */
	protected Object transformEntity(final int transform, final Source entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
    			case TRANSFORM_SOURCEVO	:	target = toSourceVO(entity);
    			break;
    			case TRANSFORM_NONE		: 
    			default					:	target = entity;
			}
		}
		return target;
	}

	/**
	 * Transforms a collection of entities using the
	 * {@link #transformEntity(int,com.ht.syndication.htsportal.domain.Source)}
	 * method. This method does not instantiate a new collection.
	 * <p/>
	 * This method is to be used internally only.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            <code>com.ht.syndication.htsportal.domain.SourceDao</code>
	 * @param entities
	 *            the collection of entities to transform
	 * @see #transformEntity(int,com.ht.syndication.htsportal.domain.Source)
	 */
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
    		case TRANSFORM_SOURCEVO	:	toSourceVOCollection(entities);
    		break;
    		case TRANSFORM_NONE		: 
    		default					:
	    }
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#toSourceVOCollection(java.util.Collection)
	 */
	public final void toSourceVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities,	PUBLICATIONVO_TRANSFORMER);
		}
	}

	/**
	 * Default implementation for transforming the results of a report query
	 * into a value object. This implementation exists for convenience reasons
	 * only. It needs only be overridden in the {@link SourceDaoImpl} class if you
	 * intend to use reporting queries.
	 * 
	 * @see com.ht.syndication.htsportal.domain.SourceDao#toSourceVO(com.ht.syndication.htsportal.domain.Source)
	 */
	protected SourceVO toSourceVO(Object[] row) 
	{
		SourceVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Source) 
				{
					target = this.toSourceVO((Source) object);
					break;
				}
			}
		}
		return target;
	}

	/**
	 * This anonymous transformer is designed to transform entities or report
	 * query results (which result in an array of objects) to
	 * {@link com.ht.syndication.htsportal.transfer.SourceVO} using the Jakarta
	 * Commons-Collections Transformation API.
	 */
	private Transformer PUBLICATIONVO_TRANSFORMER = new Transformer() 
	    {
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Source) 
    			{
    				result = toSourceVO((Source) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toSourceVO((Object[]) input);
    			}
    			return result;
    		}
	    };

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#userVOToEntityCollection(java.util.Collection)
	 */
	public final void sourceVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof SourceVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances,SourceVOToEntityTransformer);
		}
	}
	
	/**
	 * 
	 */
	private final Transformer SourceVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return sourceVOToEntity((SourceVO) input);
    		}
    	};

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#toSourceVO(com.ht.syndication.htsportal.domain.Source,
	 *      com.ht.syndication.htsportal.transfer.SourceVO)
	 */
	public void toSourceVO(Source source,SourceVO target) 
	{
		target.setId(source.getId());
		target.setName(source.getName());
		target.setDetails(source.getDetails());
		target.setStatus(source.getStatus());
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#toSourceVO(com.ht.syndication.htsportal.domain.Source)
	 */
	public SourceVO toSourceVO(final Source entity) 
	{
		final SourceVO target = new SourceVO();
		this.toSourceVO(entity, target);
		return target;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SourceDao#userVOToEntity(com.ht.syndication.htsportal.transfer.SourceVO,
	 *      com.ht.syndication.htsportal.domain.Source)
	 */
	public void sourceVOToEntity(SourceVO source,Source target,boolean copyIfNull) 
	{
		if (copyIfNull || (source.getId() != null)) 
		{
			target.setId(source.getId());
		}
		if (copyIfNull || source.getName() != null) 
		{
			if(!source.getName().equals(target.getName()))
			{
				this.changeStatusForIndex(target);
			}
			target.setName(source.getName());
		}
		if (copyIfNull || source.getDetails() != null) 
		{
			target.setDetails(source.getDetails());
		}
		if (copyIfNull || source.getStatus() != null) 
		{
			if(source.getStatus().equals(AccessStatus.DISABLE) && !source.getStatus().equals(target.getStatus()))
			{
				this.changeStatusForIndex(target);
			}
		    target.setStatus(source.getStatus());
		}
	}
	
	/**
	 * 
	 */
	public Source sourceVOToEntity(SourceVO source)
	{
		Source entity = Factory.newInstance();
		this.sourceVOToEntity(source, entity, Boolean.FALSE);
		return entity;
	}
	
	/**
	 * 
	 * @param source
	 */
	private void changeStatusForIndex(Source source)
	{
		if(source.getId() != null)
		{
			for(Content content:source.getContent())
			{
				if(content.getIndexdate() != null)
				{
					content.setIndexdate(null);
				}
			}
		}
	}

}