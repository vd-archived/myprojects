package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.UserVO;

/**
 * A data access object (DAO) providing persistence and search support for Users
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.ht.syndication.htsportal.domain.User
 * @author MyEclipse Persistence Tools
 */

public class UserDaoImpl extends UserDaoBase
{
	  	@SuppressWarnings("unchecked")
	  	@Override
	    public Object load(final int transform, final String username)
	    {
	  		final Criteria query = super.getSession().createCriteria(User.class);
	        query.add(Restrictions.eq("username", username).ignoreCase());
	        final Object entity = query.uniqueResult();
	        return this.transformEntity(transform, (User)entity);
	    }
	  	
	  	@SuppressWarnings("unchecked")
	  	@Override
	  	public Collection loadAll(final int transform, final String username)
	    {
	  		final Criteria query = super.getSession().createCriteria(User.class);
	        query.add(Restrictions.eq("username", username).ignoreCase());
	        final Collection entities = query.list();
	        transformEntities(transform, entities);
	        return entities;
	    }
	  	
	  	@SuppressWarnings("unchecked")
	  	@Override
	  	public Collection loadAllByRoles(final int transform, final List<Short> roles)
	    {
	  		final Criteria query = super.getSession().createCriteria(User.class);
	  		for(Short role: roles)
	  		{
	  			query.add(Restrictions.in("role", roles));
	  		}
	        final Collection entities = query.list();
	        transformEntities(transform, entities);
	        return entities;
	    }
	  	

		public User userVOToEntity(UserVO userVO) 
		{
			User entity = this.load(userVO.getUsername());
	        if (entity == null)
	        {
	            entity = User.Factory.newInstance();
	            entity.setCreateDate(new Date());
	        }
	       	entity.setUpdateDate(new Date());
	        this.userVOToEntity(userVO, entity, false);
	        return entity;
		}
}