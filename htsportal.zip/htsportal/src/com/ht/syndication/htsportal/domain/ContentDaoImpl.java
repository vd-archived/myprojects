package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.ContentVO;
/**
 * A data access object (DAO) providing persistence and search support for Contents
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.ht.syndication.htsportal.domain.Content
 * @author MyEclipse Persistence Tools
 */

public class ContentDaoImpl extends ContentDaoBase
{
  	@SuppressWarnings("unchecked")
  	@Override
    public Object load(final int transform, final Integer id)
    {
  		final Criteria query = super.getSession().createCriteria(Content.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Content)entity);
    }
  	
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Content.class);
        query.addOrder(Order.asc("updatedate").ignoreCase());

        final Collection results = query.list();

        this.transformEntities(transform, results);

        return results;
    }
    
    /**
     * 
     */
	public Content contentVOToEntity(ContentVO contentVO) 
	{
		Content entity = this.load(contentVO.getUniqueid());
        if (entity == null)
        {
            entity = Content.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
       	entity.setUpdatedate(new Date());
       	entity.setIndexdate(null);
        this.contentVOToEntity(contentVO, entity, false);

        return entity;
	}
	
  	@SuppressWarnings("unchecked")
  	@Override
    public Collection indexedContent(final int transform)
    {
  		return indexedContent(transform, null);
    }
  	
  	@SuppressWarnings("unchecked")
  	@Override
    public Collection indexedContent(final int transform, Integer maxprocess)
    {
        final Criteria query = super.getSession().createCriteria(Content.class);
        query.add(Restrictions.isNull("indexdate"));
        query.add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.createCriteria("category").add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.createCriteria("publication").add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.createCriteria("source").add(Restrictions.ne("status", AccessStatus.DISABLE));
        if(maxprocess!=null)
        	query.setMaxResults(maxprocess);
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
  	
    public Collection indexedContent(final int transform, Integer maxprocess,Set<String> uniqueIds)
    {
        final Criteria query = super.getSession().createCriteria(Content.class);
        query.add(Restrictions.isNull("indexdate"));
        query.add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.createCriteria("category").add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.createCriteria("publication").add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.createCriteria("source").add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.add(Restrictions.in("uniqueid", uniqueIds));
/*        if(maxprocess!=null)
        	query.setMaxResults(maxprocess);
*/        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }


  	/**
  	 * 
  	 */
  	public boolean checkHeadline(Content contentObj)
  	{
  		final Criteria query = super.getSession().createCriteria(Content.class);
  		query.add(Restrictions.eq("headline", contentObj.getHeadline()));
  		query.add(Restrictions.eq("publication", contentObj.getPublication()));
  		final List results = query.list();
  		if(results !=null && results.size()>0)
  		{
  			return Boolean.FALSE;
  		}
  		return Boolean.TRUE;
  	}

  	/**
  	 * 
  	 */
	public Object load(final int transform, String uniqueID) 
	{
  		final Criteria query = super.getSession().createCriteria(Content.class);
        query.add(Restrictions.eq("uniqueid", uniqueID));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Content)entity);
	}


}