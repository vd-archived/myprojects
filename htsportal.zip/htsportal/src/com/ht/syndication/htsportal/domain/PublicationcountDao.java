package com.ht.syndication.htsportal.domain;

import java.util.Collection;

import com.ht.syndication.htsportal.transfer.PublicationcountVO;


public interface PublicationcountDao
{
	public final static int TRANSFORM_NONE = 0;

	public final static int TRANSFORM_PUBLICATIONCOUNTVO = 1;
	
	public void toPublicationcountVO(Publicationcount source, PublicationcountVO target);
	
	public PublicationcountVO toPublicationcountVO(Publicationcount entity);

	public void publicationcountVOToEntity(PublicationcountVO publicationcount, Publicationcount target, Boolean copyIfNull);
	
	public Publicationcount publicationcountVOToEntity(PublicationcountVO publicationcountVO);
	
	public Publicationcount load(Integer id);
	
	public Object load(int transform, Integer id);
	
	public Collection loadAll();
	
	public Collection loadAll(final int transform);
	
	public Publicationcount create(Publicationcount publicationcount);
	
	public Object create(int transform, Publicationcount publicationcount);
	
	public Collection create(Collection entities);
	
	public Collection create(int transform, Collection entities);
	
	
	public void update(Publicationcount publicationcount);
	
	public void update(Collection entities);
	
	public void remove(Publicationcount publicationcount);
	
	public void remove(Integer id);
	
	public void remove(Collection entities);
}
