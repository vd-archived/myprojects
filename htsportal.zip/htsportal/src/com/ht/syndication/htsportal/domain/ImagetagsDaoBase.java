package com.ht.syndication.htsportal.domain;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;

public abstract class ImagetagsDaoBase extends HibernateDaoSupport implements ImagetagsDao 
{
	
	@Override
	public void toImagetagsVO(Imagetags source, ImagetagsVO target) {
		target.setId(source.getId());
		target.setName(source.getName());
		target.setDetails(source.getDetails());
		target.setWeight(source.getWeight());
		target.setType(source.getType());
		target.setStatus(source.getStatus());
		if(source.getParent()!=null)
			target.setParent(source.getParent().getId());
		else
			target.setParent(null);
	}
	
	@Override
	public void toImagetagsFullVO(Imagetags source, ImagetagsFullVO target) {
		target.setId(source.getId());
		target.setName(source.getName());
		target.setDetails(source.getDetails());
		target.setWeight(source.getWeight());
		target.setType(source.getType());
		target.setStatus(source.getStatus());
		Collection<Imagetags> childs = source.getChilds();
		if(childs != null && childs.size() > 0)
		{
			List<ImagetagsFullVO> tempChilds = new ArrayList<ImagetagsFullVO>();
			for(Imagetags temp: childs)
			{
				tempChilds.add(toImagetagsFullVO(temp));
			}
			target.setChilds(tempChilds);
		}
	}

	@Override
	public ImagetagsVO toImagetagsVO(Imagetags entity) {
		final ImagetagsVO target = new ImagetagsVO();
		this.toImagetagsVO(entity, target);
		return target;
	}
	
	@Override
	public ImagetagsFullVO toImagetagsFullVO(Imagetags entity) {
		final ImagetagsFullVO target = new ImagetagsFullVO();
		this.toImagetagsFullVO(entity, target);
		return target;
	}

	@Override
	public void toImagetagsVOCollection(Collection entities) {
		if (entities != null) 
		{
			CollectionUtils.transform(entities, IMAGETAGSVO_TRANSFORMER);
		}
	}
	
	@Override
	public void toImagetagsFullVOCollection(Collection entities) {
		if (entities != null) 
		{
			CollectionUtils.transform(entities, IMAGETAGSFULLVO_TRANSFORMER);
		}
	}

	@Override
	public void imagetagsVOToEntity(ImagetagsVO source, Imagetags target, Boolean copyIfNull) {
		if (copyIfNull || source.getId() != null) 
		{
			target.setId(source.getId());
		}
        if (copyIfNull || source.getName() != null) 
        {
            target.setName(source.getName());
            /*if(!source.getName().equals(target.getName()))
			{
				this.changeStatusForIndex(target);
			}*/
        }
		if (copyIfNull || source.getDetails() != null) 
		{
			target.setDetails(source.getDetails());
		}
		if (copyIfNull || source.getWeight() != null) 
		{
			target.setWeight(source.getWeight());
		}
		if (copyIfNull || source.getType() != null) 
		{
			target.setType(source.getType());
		}
		if (copyIfNull || source.getStatus() != null) 
        {
			/*if(source.getStatus().equals(AccessStatus.DISABLE) && !source.getStatus().equals(target.getStatus()))
			{
				this.changeStatusForIndex(target);
			}*/
            target.setStatus(source.getStatus());

        }
	}

	@Override
	public void imagetagsVOToEntityCollection(Collection instances) {
		if(instances !=null)
		{
			for(final Iterator iterator = instances.iterator(); iterator.hasNext();)
			{
				if(!(iterator.next() instanceof ImagetagsVO))
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, ImagetagsVOToEntityTransformer);
		}
	}

	@Override
	public Imagetags load(Integer id) {
		return (Imagetags) this.load(TRANSFORM_NONE, id);
	}

	@Override
	public Imagetags load(String name) {
		return (Imagetags) this.load(TRANSFORM_NONE, name);
	}
	
	public Object load(final int transform, final String name) {
		if(name==null)
		{
			throw new IllegalArgumentException("Imagetags.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ImagetagsImpl.class, name);
		return transformEntity(transform, (Imagetags)entity);
	}

	@Override
	public Object load(final int transform, final Integer id) {
		if (id == null) 
		{
			throw new IllegalArgumentException("Imagetags.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ImagetagsImpl.class, id);
		return transformEntity(transform, (Imagetags) entity);
	}

	@Override
	public Collection loadAll(int transform) {
		final Collection results = this.getHibernateTemplate().loadAll(ImagetagsImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	@Override
	public Collection loadAllActive(int transform) {
		final Collection results = this.getHibernateTemplate().loadAll(ImagetagsImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	@Override
	public Collection loadAllActiveByParent(final int transform, Integer parent) {
		final Collection results = this.getHibernateTemplate().loadAll(ImagetagsImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	@Override
	public Collection loadAllByType(final int transform, Short type) {
		final Collection results = this.getHibernateTemplate().loadAll(ImagetagsImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	@Override
	public Imagetags create(Imagetags imagetags) {
		return (Imagetags) this.create(TRANSFORM_NONE, imagetags);
	}

	@Override
	public Object create(int transform, Imagetags imagetags) {
		if(imagetags == null)
		{
			throw new IllegalArgumentException("Imagetags.create - 'imagetags' can not be null");
		}
		this.getHibernateTemplate().save(imagetags);
		return this.transformEntity(transform, imagetags);
	}

	@Override
	public Collection create(Collection entities) {
		return create(TRANSFORM_NONE, entities);
	}

	@Override
	public Collection create(final int transform, final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Imagetags.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
					new HibernateCallback() {
						@Override
						public Object doInHibernate(Session session) throws HibernateException, SQLException {
							for(Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
							{
								create(transform, (Imagetags)entityIterator.next());
							}
							return null;
						}
					}, true
				);
		return entities;
	}

	@Override
	public void update(Imagetags imagetags) {
		if(imagetags == null)
		{
			throw new IllegalArgumentException("Imagetags.update - 'imagetags' can not be null");
		}
		this.getHibernateTemplate().update(imagetags);

	}

	@Override
	public void update(final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Imagetags.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
			new HibernateCallback() {
				@Override
				public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
					for(Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
					{
						update((Imagetags)entityIterator.next());
					}
					return null;
				}
			}, true
		);
	}

	@Override
	public void remove(Imagetags imagetags) {
		if(imagetags == null)
		{
			throw new IllegalArgumentException("Imagetags.remove - 'imagetags' can not be null");
		}
		this.getHibernateTemplate().delete(imagetags);
	}

	@Override
	public void remove(Integer id) {
		if(id == null)
		{
			throw new IllegalArgumentException("Imagetags.remove - 'id' can not be null");
		}
		Imagetags imagetags = this.load(id);
		if (imagetags != null) 
		{
			this.remove(imagetags);
		}
	}

	@Override
	public void remove(final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Imagetags.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}
	
	private Transformer IMAGETAGSVO_TRANSFORMER = new Transformer() 
	{
		public Object transform(Object input) 
		{
			Object result = null;
			if (input instanceof Imagetags)
			{
				result = toImagetagsVO((Imagetags) input);
			} 
			else if (input instanceof Object[])
			{
				result = toImagetagsVO((Object[]) input);
			}
			return result;
		}
	};
	
	private Transformer IMAGETAGSFULLVO_TRANSFORMER = new Transformer() 
	{
		public Object transform(Object input) 
		{
			Object result = null;
			if (input instanceof Imagetags)
			{
				result = toImagetagsFullVO((Imagetags) input);
			} 
			else if (input instanceof Object[])
			{
				result = toImagetagsFullVO((Object[]) input);
			}
			return result;
		}
	};
	
	protected ImagetagsVO toImagetagsVO(Object[] row) 
	{
		ImagetagsVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Imagetags) 
				{
					target = this.toImagetagsVO((Imagetags) object);
					break;
				}
			}
		}
		return target;
	}
	
	protected ImagetagsFullVO toImagetagsFullVO(Object[] row) 
	{
		ImagetagsFullVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Imagetags) 
				{
					target = this.toImagetagsFullVO((Imagetags) object);
					break;
				}
			}
		}
		return target;
	}
	
	private final Transformer ImagetagsVOToEntityTransformer = new Transformer() 
	{
		public Object transform(Object input) 
		{
			return imagetagsVOToEntity((ImagetagsVO) input);
		}
	};
	
	protected Object transformEntity(final int transform, final Imagetags entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_IMAGETAGSVO	:  	target = toImagetagsVO(entity);
					break;
			    case TRANSFORM_IMAGETAGSFULLVO	:  	target = toImagetagsFullVO(entity);
				break;
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}
	
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
    		case TRANSFORM_IMAGETAGSVO	:	toImagetagsVOCollection(entities);
    		break;
    		case TRANSFORM_IMAGETAGSFULLVO	:	toImagetagsFullVOCollection(entities);
    		break;
    		case TRANSFORM_NONE			: 
    		default						:
		}
	}
}
