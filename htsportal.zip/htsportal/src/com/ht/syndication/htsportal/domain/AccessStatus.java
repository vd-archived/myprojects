package com.ht.syndication.htsportal.domain;

public interface AccessStatus
{
	public static final Short DISABLE = 0;
	
	public static final Short FULL_ACCESS = 1;
	
	public static final Short SHORT_ACCESS = 2;
	
	public static final Short FULL_RESTRICTED = 3;
	
	public static final Short INACTIVE = 4;
	
	public static final Short ENABLE = 1;
	
	public static final Short IMAGE_UPLOADED = 2;
}
