package com.ht.syndication.htsportal.domain;

import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.EventVO;

public abstract class EventDaoBase extends HibernateDaoSupport implements EventDao 
{
	
	@Override
	public void toEventVO(Event source, EventVO target) {
		target.setId(source.getId());
		target.setName(source.getName());
		target.setDetails(source.getDetails());
		target.setStatus(source.getStatus());
		target.setWeight(source.getWeight());
	}

	@Override
	public EventVO toEventVO(Event entity) {
		final EventVO target = new EventVO();
		this.toEventVO(entity, target);
		return target;
	}

	@Override
	public void toEventVOCollection(Collection entities) {
		if (entities != null) 
		{
			CollectionUtils.transform(entities, EVENTVO_TRANSFORMER);
		}
	}

	@Override
	public void eventVOToEntity(EventVO source, Event target, Boolean copyIfNull) {
		if (copyIfNull || source.getId() != null) 
		{
			target.setId(source.getId());
		}
        if (copyIfNull || source.getName() != null) 
        {
            target.setName(source.getName());
            /*if(!source.getName().equals(target.getName()))
			{
				this.changeStatusForIndex(target);
			}*/
        }
		if (copyIfNull || source.getDetails() != null) 
		{
			target.setDetails(source.getDetails());
		}
		if (copyIfNull || source.getStatus() != null) 
        {
			/*if(source.getStatus().equals(AccessStatus.DISABLE) && !source.getStatus().equals(target.getStatus()))
			{
				this.changeStatusForIndex(target);
			}*/
            target.setStatus(source.getStatus());

        }
		if (copyIfNull || source.getWeight() != null) 
		{
			target.setWeight(source.getWeight());
		}
	}

	@Override
	public void eventVOToEntityCollection(Collection instances) {
		if(instances !=null)
		{
			for(final Iterator iterator = instances.iterator(); iterator.hasNext();)
			{
				if(!(iterator.next() instanceof EventVO))
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, EventVOToEntityTransformer);
		}
	}

	@Override
	public Event load(Integer id) {
		return (Event) this.load(TRANSFORM_NONE, id);
	}

	@Override
	public Event load(String name) {
		return (Event) this.load(TRANSFORM_NONE, name);
	}
	
	public Object load(final int transform, final String name) {
		if(name==null)
		{
			throw new IllegalArgumentException("Event.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(EventImpl.class, name);
		return transformEntity(transform, (Event)entity);
	}

	@Override
	public Object load(final int transform, final Integer id) {
		if (id == null) 
		{
			throw new IllegalArgumentException("Event.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(EventImpl.class, id);
		return transformEntity(transform, (Event) entity);
	}

	@Override
	public Collection loadAll(int transform) {
		final Collection results = this.getHibernateTemplate().loadAll(EventImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	@Override
	public Collection loadAllActive(int transform) {
		final Collection results = this.getHibernateTemplate().loadAll(EventImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	@Override
	public Event create(Event event) {
		return (Event) this.create(TRANSFORM_NONE, event);
	}

	@Override
	public Object create(int transform, Event event) {
		if(event == null)
		{
			throw new IllegalArgumentException("Event.create - 'event' can not be null");
		}
		this.getHibernateTemplate().save(event);
		return this.transformEntity(transform, event);
	}

	@Override
	public Collection create(Collection entities) {
		return create(TRANSFORM_NONE, entities);
	}

	@Override
	public Collection create(final int transform, final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Event.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
					new HibernateCallback() {
						@Override
						public Object doInHibernate(Session session) throws HibernateException, SQLException {
							for(Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
							{
								create(transform, (Event)entityIterator.next());
							}
							return null;
						}
					}, true
				);
		return entities;
	}

	@Override
	public void update(Event event) {
		if(event == null)
		{
			throw new IllegalArgumentException("Event.update - 'event' can not be null");
		}
		this.getHibernateTemplate().update(event);

	}

	@Override
	public void update(final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Event.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
			new HibernateCallback() {
				@Override
				public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
					for(Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
					{
						update((Event)entityIterator.next());
					}
					return null;
				}
			}, true
		);
	}

	@Override
	public void remove(Event event) {
		if(event == null)
		{
			throw new IllegalArgumentException("Event.remove - 'event' can not be null");
		}
		this.getHibernateTemplate().delete(event);
	}

	@Override
	public void remove(Integer id) {
		if(id == null)
		{
			throw new IllegalArgumentException("Event.remove - 'id' can not be null");
		}
		Event event = this.load(id);
		if (event != null) 
		{
			this.remove(event);
		}
	}

	@Override
	public void remove(final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Event.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}
	
	private Transformer EVENTVO_TRANSFORMER = new Transformer() 
	{
		public Object transform(Object input) 
		{
			Object result = null;
			if (input instanceof Event)
			{
				result = toEventVO((Event) input);
			} 
			else if (input instanceof Object[])
			{
				result = toEventVO((Object[]) input);
			}
			return result;
		}
	};
	
	protected EventVO toEventVO(Object[] row) 
	{
		EventVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Event) 
				{
					target = this.toEventVO((Event) object);
					break;
				}
			}
		}
		return target;
	}
	
	private final Transformer EventVOToEntityTransformer = new Transformer() 
	{
		public Object transform(Object input) 
		{
			return eventVOToEntity((EventVO) input);
		}
	};
	
	protected Object transformEntity(final int transform, final Event entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_EVENTVO	:  	target = toEventVO(entity);
					break;
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}
	
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
    		case TRANSFORM_EVENTVO	:	toEventVOCollection(entities);
    		break;
    		case TRANSFORM_NONE			: 
    		default						:
		}
	}
}
