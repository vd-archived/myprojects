package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

/**
 * Category entity provides the base persistence definition of the
 * Category entity. @author MyEclipse Persistence Tools
 */

public abstract class Imagetags implements Serializable 
{
	private Integer id;
	private String name;
	private String details;
	private Integer weight = 0;
	private Short status;
	private Short type = 1;
	private Date createdate;
	private Date updatedate;
	private String updateby;
	private Collection<Image> images;
	private Collection<Imagetags> childs;
	private Imagetags parent;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public Integer getWeight() {
		return weight;
	}
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	public Short getStatus() {
		return status;
	}
	public void setStatus(Short status) {
		this.status = status;
	}
	public Short getType() {
		return type;
	}
	public void setType(Short type) {
		this.type = type;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}
	public String getUpdateby() {
		return updateby;
	}
	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}
	public Collection<Image> getImages() {
		return images;
	}
	public void setImages(Collection<Image> images) {
		this.images = images;
	}
	public Collection<Imagetags> getChilds() {
		return childs;
	}
	public void setChilds(Collection<Imagetags> childs) {
		this.childs = childs;
	}
	public Imagetags getParent() {
		return parent;
	}
	public void setParent(Imagetags parent) {
		this.parent = parent;
	}
	
	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Imagetags}.
		 */
		public static Imagetags newInstance()
		{
			return new ImagetagsImpl();
		}
		
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Event}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static Imagetags newInstance(Integer id, String name, String details, Short type, Short status, Date createdate, Date updatedate, String updateby, Collection<Image> images, Collection<Imagetags> childs, Imagetags parent)
		{
			final Imagetags entity = new ImagetagsImpl();
			entity.setId(id);
			entity.setName(name);
			entity.setDetails(details);
			entity.setType(type);
			entity.setStatus(status);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setUpdateby(updateby);
			entity.setImages(images);
			entity.setChilds(childs);
			entity.setParent(parent);
			return entity;
		}
	}
}