package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

public class Content 
{
	
	private Integer id;
	
	/**
	 * @return the id
	 */
	public Integer getId() 
	{
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}

	private String headline;

	/**
	 * @return the headline
	 */
	public String getHeadline() 
	{
		return headline;
	}
	
	private Source source;
	
	/**
	 * @return the source
	 */
	public Source getSource() 
	{
		return source;
	}
	/**
	 * @param source the source to set
	 */
	public void setSource(Source source) 
	{
		this.source = source;
	}
	/**
	 * @param headline the headline to set
	 */
	public void setHeadline(String headline) 
	{
		this.headline = headline;
	}
	
	private String news;
	
	/**
	 * @return the news
	 */
	public String getNews() 
	{
		return news;
	}
	/**
	 * @param news the news to set
	 */
	public void setNews(String news) 
	{
		this.news = news;
	}
	
	private String byline;
	
	/**
	 * @return the byline
	 */
	public String getByline() 
	{
		return byline;
	}
	/**
	 * @param byline the byline to set
	 */
	public void setByline(String byline) 
	{
		this.byline = byline;
	}
	
	private String section;
	
	/**
	 * @return the section
	 */
	public String getSection() 
	{
		return section;
	}
	/**
	 * @param section the section to set
	 */
	public void setSection(String section) 
	{
		this.section = section;
	}
	
	private String uniqueid;
	
	/**
	 * @return the uniqueid
	 */
	public String getUniqueid() 
	{
		return uniqueid;
	}
	/**
	 * @param uniqueid the uniqueid to set
	 */
	public void setUniqueid(String uniqueid) 
	{
		this.uniqueid = uniqueid;
	}
	
	private String location;
	
	/**
	 * @return the location
	 */
	public String getLocation() 
	{
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) 
	{
		this.location = location;
	}
	
	private String copyright;

	/**
	 * @return the copyright
	 */
	public String getCopyright() 
	{
		return copyright;
	}
	/**
	 * @param copyright the copyright to set
	 */
	public void setCopyright(String copyright) 
	{
		this.copyright = copyright;
	}
	
	private Short status;

	/**
	 * @return the status
	 */
	public Short getStatus() 
	{
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Short status) 
	{
		this.status = status;
	}
	

	
	private String updatedby;
	
	/**
	 * @return the updatedby
	 */
	public String getUpdatedby() 
	{
		return updatedby;
	}
	/**
	 * @param updatedby the updatedby to set
	 */
	public void setUpdatedby(String updatedby) 
	{
		this.updatedby = updatedby;
	}
	
	private Publication publication;

	/**
	 * @return the publication
	 */
	public Publication getPublication() 
	{
		return publication;
	}
	/**
	 * @param publication the publication to set
	 */
	public void setPublication(Publication publication) 
	{
		this.publication = publication;
	}
	
	private Date contentdate;
	
	/**
	 * 
	 * @return
	 */
	public Date getContentdate() 
	{
		return contentdate;
	}
	/**
	 * @param content_date the content_date to set
	 */
	public void setContentdate(Date contentdate) 
	{
		this.contentdate = contentdate;
	}
	
	private Date createdate;

	/**
	 * @return the createdate
	 */
	public Date getCreatedate() 
	{
		return createdate;
	}
	/**
	 * @param createdate the createdate to set
	 */
	public void setCreatedate(Date createdate) 
	{
		this.createdate = createdate;
	}
	
	private Date updatedate;

	/**
	 * @return the updatedate
	 */
	public Date getUpdatedate() 
	{
		return updatedate;
	}
	/**
	 * @param updatedate the updatedate to set
	 */
	public void setUpdatedate(Date updatedate) 
	{
		this.updatedate = updatedate;
	}
	
	private Date indexdate;

	/**
	 * @return the indexdate
	 */
	public Date getIndexdate() 
	{
		return indexdate;
	}
	/**
	 * @param indexdate the indexdate to set
	 */
	public void setIndexdate(Date indexdate) 
	{
		this.indexdate = indexdate;
	}
	
	private Collection<Category> category = new HashSet<Category>();
	
	/**
	 * @return the category
	 */
	public Collection<Category> getCategory() 
	{
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(Collection<Category> category) 
	{
		this.category = category;
	}
	

	
	public Content() 
	{
		super();
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Content}.
		 */
		public static Content newInstance()
		{
			return new ContentImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static Content newInstance(Integer id, Source source, String headline, String news, String byline, String section, String uniqueid, String location, String copyright, String updatedby, Publication publication, Date contentdate, Date createdate, Date updatedate, Date indexdate, Short status)
		{
			final Content entity = new ContentImpl();
			
			entity.setId(id);
			entity.setSource(source);
			entity.setHeadline(headline);
			entity.setNews(news);
			entity.setByline(byline);
			entity.setSection(section);
			entity.setUniqueid(uniqueid);
			entity.setLocation(location);
			entity.setCopyright(copyright);
			entity.setUpdatedby(updatedby);
			entity.setPublication(publication);
			entity.setContentdate(contentdate);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setIndexdate(indexdate);
			entity.setStatus(status);
			
			return entity;
		}
	}
	
}
