package com.ht.syndication.htsportal.domain;

/**
 * PublicationImpl entity. @author MyEclipse Persistence Tools
 */
public class PublicationImpl extends Publication 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5066699689465219644L;
	/**
	 * 
	 */

}
