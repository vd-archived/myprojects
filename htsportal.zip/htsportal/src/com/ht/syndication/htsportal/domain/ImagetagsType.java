package com.ht.syndication.htsportal.domain;

public interface ImagetagsType
{
	public static final Short NORMAL = 1;
	
	public static final Short SECTION = 2;
	
	public static final String[] typeName = {"","Normal","Section"};
}
