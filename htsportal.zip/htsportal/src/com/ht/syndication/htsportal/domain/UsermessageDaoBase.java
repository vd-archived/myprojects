
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.UsermessageVO;

/**
 * <p>
 * Usermessage Base DAO Class: is able to create, update, remove, load, and find
 * objects of type <code>com.ht.syndication.htsportal.domain.Usermessage</code>.
 * </p>
 * 
 * @see com.ht.syndication.htsportal.domain.Usermessage
 */
public abstract class UsermessageDaoBase extends HibernateDaoSupport implements UsermessageDao 
{
	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#load(int,
	 *      java.lang.String)
	 */
	public java.lang.Object load(final int transform, final Integer id) 
	{
        if (id == null) 
		{
			throw new IllegalArgumentException("Usermessage.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(UsermessageImpl.class, id);
		return transformEntity(transform, (Usermessage) entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#load(java.lang.String)
	 */
	public Usermessage load(Integer id) 
	{
		return (Usermessage) this.load(TRANSFORM_NONE, id);
	}
	
	/**
	 * @see UsermessageDao#load(int,
	 *      java.lang.String)
	 */
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Usermessage.load - 'name' can not be null");
		}
		final java.lang.Object entity = this.getHibernateTemplate().get(UsermessageImpl.class, name);
		return transformEntity(transform, (Usermessage) entity);
	}

	/**
	 * @see UsermessageDao#load(java.lang.String)
	 */
	public Usermessage loadByName(String name) 
	{
		return (Usermessage) this.loadByName(TRANSFORM_NONE, name);
	}	

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#loadAll()
	 */
	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}
	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#loadAll(int)
	 */
	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(UsermessageImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#create(com.ht.syndication.htsportal.domain.Usermessage)
	 */
	public Usermessage create(Usermessage usermessage) 
	{
		return (Usermessage) this.create(TRANSFORM_NONE, usermessage);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#create(int transform,
	 *      com.ht.syndication.htsportal.domain.Usermessage)
	 */
	public Object create(final int transform, final Usermessage usermessage) 
	{
		if (usermessage == null) 
		{
			throw new IllegalArgumentException("Usermessage.create - 'usermessage' can not be null");
		}
		this.getHibernateTemplate().save(usermessage);
		return this.transformEntity(transform, usermessage);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#create(java.util.Collection)
	 */
	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#create(int,
	 *      java.util.Collection)
	 */
	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Usermessage.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Usermessage) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#create(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.Short)
	 */
	public Usermessage create(Integer id, String email, String firstname, String lastname, String website, String message, String contactno, Short status) 
	{
		return (Usermessage) this.create(TRANSFORM_NONE, id, email, firstname, lastname, website, message, contactno, status);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#create(int,
	 *      Integer , String , String , String , String , String 
	 *      java.lang.Short)
	 */

	public java.lang.Object create(final int transform, Integer id, String email, String firstname, String lastname, String organisationName, String message, String contactno, Short status) 
	{
		Usermessage entity = new UsermessageImpl();
		entity.setId(id);
		entity.setEmail(email);
		entity.setFirstname(firstname);
		entity.setLastname(lastname);
		entity.setOrganisationName(organisationName);
		entity.setMessage(message);
		entity.setContactno(contactno);
		entity.setStatus(status);
		return this.create(transform, entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#update(com.ht.syndication.htsportal.domain.Usermessage)
	 */
	public void update(Usermessage usermessage) 
	{
		if (usermessage == null) 
		{
			throw new IllegalArgumentException("Usermessage.update - 'usermessage' can not be null");
		}
		this.getHibernateTemplate().update(usermessage);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#update(java.util.Collection)
	 */
	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Usermessage.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(new HibernateCallback()
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((com.ht.syndication.htsportal.domain.Usermessage) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#remove(com.ht.syndication.htsportal.domain.Usermessage)
	 */
	public void remove(Usermessage usermessage) 
	{
		if (usermessage == null) 
		{
			throw new IllegalArgumentException("Usermessage.remove - 'usermessage' can not be null");
		}
		this.getHibernateTemplate().delete(usermessage);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#remove(java.lang.String)
	 */
	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Usermessage.remove - 'id' can not be null");
		}
		Usermessage entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#remove(java.util.Collection)
	 */
	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Usermessage.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	/**
	 * Allows transformation of entities into value objects (or something else
	 * for that matter), when the <code>transform</code> flag is set to one of
	 * the constants defined in
	 * <code>com.ht.syndication.htsportal.domain.UsermessageDao</code>, please note
	 * that the {@link #TRANSFORM_NONE} constant denotes no transformation, so
	 * the entity itself will be returned.
	 * <p/>
	 * This method will return instances of these types:
	 * <ul>
	 * <li>{@link com.ht.syndication.htsportal.domain.Usermessage} -
	 * {@link #TRANSFORM_NONE}</li>
	 * <li>{@link com.ht.syndication.htsportal.transfer.UsermessageVO} -
	 * {@link TRANSFORM_USERVO}</li>
	 * </ul>
	 * 
	 * If the integer argument value is unknown {@link #TRANSFORM_NONE} is
	 * assumed.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            {@link com.ht.syndication.htsportal.domain.UsermessageDao}
	 * @param entity
	 *            an entity that was found
	 * @return the transformed entity (i.e. new value object, etc)
	 * @see #transformEntities(int,java.util.Collection)
	 */
	protected Object transformEntity(final int transform, final Usermessage entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_USERMESSAGEVO:   target = toUsermessageVO(entity);
				break;
			    case TRANSFORM_NONE: 
			    default: target = entity;
			}
		}
		return target;
	}

	/**
	 * Transforms a collection of entities using the
	 * {@link #transformEntity(int,com.ht.syndication.htsportal.domain.Usermessage)}
	 * method. This method does not instantiate a new collection.
	 * <p/>
	 * This method is to be used internally only.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            <code>com.ht.syndication.htsportal.domain.UsermessageDao</code>
	 * @param entities
	 *            the collection of entities to transform
	 * @see #transformEntity(int,com.ht.syndication.htsportal.domain.Usermessage)
	 */
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
		    case TRANSFORM_USERMESSAGEVO:    toUsermessageVOCollection(entities);
			break;
		    case TRANSFORM_NONE: 
		    default:
		}
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#toUsermessageVOCollection(java.util.Collection)
	 */
	public final void toUsermessageVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities, USERMESSAGEVO_TRANSFORMER);
		}
	}

	/**
	 * Default implementation for transforming the results of a report query
	 * into a value object. This implementation exists for convenience reasons
	 * only. It needs only be overridden in the {@link UsermessageDaoImpl} class if you
	 * intend to use reporting queries.
	 * 
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#toUsermessageVO(com.ht.syndication.htsportal.domain.Usermessage)
	 */
	protected UsermessageVO toUsermessageVO(Object[] row) 
	{
		UsermessageVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Usermessage) 
				{
					target = this.toUsermessageVO((Usermessage) object);
					break;
				}
			}
		}
		return target;
	}

	/**
	 * This anonymous transformer is designed to transform entities or report
	 * query results (which result in an array of objects) to
	 * {@link com.ht.syndication.htsportal.transfer.UsermessageVO} using the Jakarta
	 * Commons-Collections Transformation API.
	 */
	private Transformer USERMESSAGEVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Usermessage) 
    			{
    				result = toUsermessageVO((Usermessage) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toUsermessageVO((Object[]) input);
    			}
    			return result;
    		}
    	};

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#userVOToEntityCollection(java.util.Collection)
	 */
	public final void usermessageVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof UsermessageVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, UsermessageVOToEntityTransformer);
		}
	}

	private final Transformer UsermessageVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return usermessageVOToEntity((UsermessageVO) input);
    		}
    	};

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#toUsermessageVO(com.ht.syndication.htsportal.domain.Usermessage,
	 *      com.ht.syndication.htsportal.transfer.UsermessageVO)
	 */
	public void toUsermessageVO(Usermessage usermessage, UsermessageVO target) 
	{
		target.setId(usermessage.getId());
		target.setEmail(usermessage.getEmail());
		target.setFirstname(usermessage.getFirstname());
		target.setLastname(usermessage.getLastname());
		target.setOrganisationName(usermessage.getOrganisationName());
		target.setMessage(usermessage.getMessage());
		target.setContactno(usermessage.getContactno());
		target.setStatus(usermessage.getStatus());
		target.setCreatedate(usermessage.getCreatedate());
		target.setTo(usermessage.getTo());
		target.setCc(usermessage.getCc());
		target.setBcc(usermessage.getBcc());
		target.setSubject(usermessage.getSubject());
		target.setComments(usermessage.getComments());
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#toUsermessageVO(com.ht.syndication.htsportal.domain.Usermessage)
	 */
	public UsermessageVO toUsermessageVO(final Usermessage entity) 
	{
		final UsermessageVO target = new UsermessageVO();
		this.toUsermessageVO(entity, target);
		return target;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.UsermessageDao#userVOToEntity(com.ht.syndication.htsportal.transfer.UsermessageVO,
	 *      com.ht.syndication.htsportal.domain.Usermessage)
	 */
	public void usermessageVOToEntity(UsermessageVO usermessage, Usermessage target, boolean copyIfNull) 
	{
		if (copyIfNull || (usermessage.getId() != null)) 
		{
			target.setId(usermessage.getId());
		}
		if (copyIfNull || (usermessage.getEmail() != null)) 
		{
			target.setEmail(usermessage.getEmail());
		}
		if (copyIfNull || (usermessage.getFirstname() != null)) 
		{
			target.setFirstname(usermessage.getFirstname());
		}
		if (copyIfNull || (usermessage.getLastname() != null)) 
		{
			target.setLastname(usermessage.getLastname());
		}
		if (copyIfNull || (usermessage.getOrganisationName() != null)) 
		{
			target.setOrganisationName(usermessage.getOrganisationName());
		}
		if (copyIfNull || (usermessage.getMessage() != null)) 
		{
			target.setMessage(usermessage.getMessage());
		}
		if (copyIfNull || (usermessage.getContactno() != null)) 
		{
			target.setContactno(usermessage.getContactno());
		}
		if (copyIfNull || (usermessage.getStatus() != null)) 
		{
			target.setStatus(usermessage.getStatus());
		}
		if (copyIfNull || (usermessage.getCreatedate() != null)) 
		{
			target.setCreatedate(usermessage.getCreatedate());
		}
		if (copyIfNull || (usermessage.getTo() != null)) 
		{
			target.setTo(usermessage.getTo());
		}
		if (copyIfNull || (usermessage.getCc() != null)) 
		{
			target.setCc(usermessage.getCc());
		}
		if (copyIfNull || (usermessage.getBcc() != null)) 
		{
			target.setBcc(usermessage.getBcc());
		}
		if (copyIfNull || (usermessage.getSubject() != null)) 
		{
			target.setSubject(usermessage.getSubject());
		}
		if (copyIfNull || (usermessage.getComments() != null)) 
		{
			target.setComments(usermessage.getComments());
		}
	}
	
	/**
	 * 
	 */
	public Usermessage usermessageVOToEntity(UsermessageVO usermessage)
	{
		Usermessage entity = Usermessage.Factory.newInstance();
		this.usermessageVOToEntity(usermessage, entity, Boolean.FALSE);
		return entity;
	}

}