package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

public class Image {
	private Integer id;
	private String name;
	private String extension;
	private String title;
	private String author;
	private String details;
	private String type;
	private String orientation;
	private String editorial;
	private String keywords;
	private String copyright;
	private String width;
	private String height;
	private String resolution;
	private Short status;
	private String checksum;
	private Date capturedate;
	private Date indexdate;
	private Date createdate;
	private Date updatedate;
	private String updateby;
	private Event event;
	private Collection<Imagetags> imagetags = new HashSet<Imagetags>();
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOrientation() {
		return orientation;
	}
	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}
	public String getEditorial() {
		return editorial;
	}
	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public String getCopyright() {
		return copyright;
	}
	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	public Short getStatus() {
		return status;
	}
	public void setStatus(Short status) {
		this.status = status;
	}
	public String getChecksum() {
		return checksum;
	}
	public Date getCapturedate() {
		return capturedate;
	}
	public void setCapturedate(Date capturedate) {
		this.capturedate = capturedate;
	}
	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}
	public Date getIndexdate() {
		return indexdate;
	}
	public void setIndexdate(Date indexdate) {
		this.indexdate = indexdate;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Date getUpdatedate() {
		return updatedate;
	}
	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}
	public String getUpdateby() {
		return updateby;
	}
	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}
	public Event getEvent() {
		return event;
	}
	public void setEvent(Event event) {
		this.event = event;
	}
	public Collection<Imagetags> getImagetags() {
		return imagetags;
	}
	public void setImagetags(Collection<Imagetags> imagetags) {
		this.imagetags = imagetags;
	}
	


	public static final class Factory
	{
		/**
		 *  Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Image}.
		 */
		public static Image newInstance()
		{
			return new ImageImpl(); 
		}
		
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Image}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */
		
		public static Image newInstance(Integer id, String name, String extension, String title, String author, String details, String type, String orientation, String editorial, String keywords, String copyright, String width, String height, String resolution, Short status, String checksum, Date capturedate, Date indexdate, Date createdate, Date updatedate, String updateby, Event event, Collection<Imagetags> imagetags)
		{
			final Image entity = new ImageImpl();
			entity.setId(id);
			entity.setName(name);
			entity.setExtension(extension);
			entity.setTitle(title);
			entity.setAuthor(author);
			entity.setDetails(details);
			entity.setType(type);
			entity.setOrientation(orientation);
			entity.setEditorial(editorial);
			entity.setKeywords(keywords);
			entity.setCopyright(copyright);
			entity.setWidth(width);
			entity.setHeight(height);
			entity.setResolution(resolution);
			entity.setStatus(status);
			entity.setChecksum(checksum);
			entity.setCapturedate(capturedate);
			entity.setIndexdate(indexdate);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setUpdateby(updateby);
			entity.setEvent(event);
			entity.setImagetags(imagetags);
			return entity;
		}
	}
}
