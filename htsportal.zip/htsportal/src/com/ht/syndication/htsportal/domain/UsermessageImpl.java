package com.ht.syndication.htsportal.domain;

/**
 * PublicationImpl entity. @author MyEclipse Persistence Tools
 */
public class UsermessageImpl extends com.ht.syndication.htsportal.domain.Usermessage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6497312130806570010L;

	/**
	 * 
	 */
}
