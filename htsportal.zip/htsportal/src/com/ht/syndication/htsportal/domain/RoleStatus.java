package com.ht.syndication.htsportal.domain;

public interface RoleStatus
{
	public static final Short SITE_ADMIN = 1;
	
	public static final Short GRAPHICS_ADMIN = 2;
	
	public static final Short CONTENT_ADMIN = 3;
	
	public static final Short VENDOR = 4;
	
	public static final Short CLIENT = 5;
	
	public static final Short VISITORS = 6;
	
	public static final Short REVENUEADMIN = 7;
	
	public static final String[] roleName= {"","Site Administrator","Graphics Administrator", "Content Administrator", "Vendor", "Client", "Visitor", "Revenue Admin"};
}
