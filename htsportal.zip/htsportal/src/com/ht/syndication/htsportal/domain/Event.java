package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

/**
 * Source entity provides the base persistence definition of the
 * Source entity. @author MyEclipse Persistence Tools
 */

public abstract class Event implements Serializable 
{
	private Integer id;
	private String name;
	private String details;
	private Short status;
	private Date createdate;
	private Date updatedate;
	private String updateby;
	private Collection<Image> images;
	private Integer weight;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public String getUpdateby() {
		return updateby;
	}

	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}

	public Collection<Image> getImages() {
		return images;
	}

	public void setImages(Collection<Image> images) {
		this.images = images;
	}
	
	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}



	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Event}.
		 */
		public static Event newInstance()
		{
			return new EventImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Event}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static Event newInstance(Integer id, String name, String details, Integer weight, Short status, Date createdate, Date updatedate, String updateby, Collection<Image> images)
		{
			final Event entity = new EventImpl();
			entity.setId(id);
			entity.setName(name);
			entity.setDetails(details);
			entity.setWeight(weight);
			entity.setStatus(status);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setUpdateby(updateby);
			entity.setImages(images);
			return entity;
		}
	}
}