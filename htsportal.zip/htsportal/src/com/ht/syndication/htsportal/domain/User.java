package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

/**
 * 
 */
public abstract class User implements Serializable
{
	/**
	 * The serial version UID of this class. Needed for serialization.
	 */
	private static final long serialVersionUID = -1332780906214444039L;

	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private Short status;
	private Short role;
	private Date createDate;
	private Date updateDate;
	private String updateBy;
	private Collection<Publication> publication = new HashSet<Publication>();
	
	public String getUsername()
	{
		return this.username;
	}
	public void setUsername(String username)
	{
		this.username = username;
	}

	public String getPassword()
	{
		return this.password;
	}
	public void setPassword(String password)
	{
		this.password = password;
	}
	public String getFirstName()
	{
		return this.firstName;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	public String getLastName()
	{
		return this.lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Short getStatus()
	{
		return this.status;
	}
	public void setStatus(Short status)
	{
		this.status = status;
	}
	public Short getRole()
	{
		return this.role;
	}
	public void setRole(Short role)
	{
		this.role = role;
	}
	public Date getCreateDate()
	{
		return this.createDate;
	}
	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}
	public Date getUpdateDate()
	{
		return this.updateDate;
	}
	public void setUpdateDate(Date updateDate)
	{
		this.updateDate = updateDate;
	}
	public String getUpdateBy()
	{
		return this.updateBy;
	}
	public void setUpdateBy(String updateBy)
	{
		this.updateBy = updateBy;
	}
	public Collection<Publication> getPublication() {
		return publication;
	}
	public void setPublication(Collection<Publication> publication) {
		this.publication = publication;
	}

	/**
	 * Returns <code>true</code> if the argument is an User instance and all identifiers for this entity
	 * equal the identifiers of the argument entity. Returns <code>false</code> otherwise.
	 */
	public boolean equals(Object object)
	{
		if (this == object)
		{
			return true;
		}
		if (!(object instanceof User))
		{
			return false;
		}
		final User that = (User)object;
		if (this.username == null || that.getUsername() == null || !this.username.equals(that.getUsername()))
		{
			return false;
		}
		return true;
	}

	/**
	 * Returns a hash code based on this entity's identifiers.
	 */
	public int hashCode()
	{
		int hashCode = 0;
		hashCode = 29 * hashCode + (username == null ? 0 : username.hashCode());

		return hashCode;
	}

	/**
	 * Constructs new instances of {@link com.ht.syndication.htsportal.domain.User}.
	 */
	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}.
		 */
		public static User newInstance()
		{
			return new UserImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */
		public static User newInstance(String username, String firstName, String lastName, String email, Short status, Short role)
		{
			final User entity = new UserImpl();
			entity.setUsername(username);
			entity.setFirstName(firstName);
			entity.setLastName(lastName);
			entity.setEmail(email);
			entity.setStatus(status);
			entity.setRole(role);
			return entity;
		}
		
		public static User newInstance(String username, String firstName, String lastName, String email, Short status, Short role, Collection<Publication> publication)
		{
			final User entity = newInstance(username, firstName, lastName, email, status, role);
			entity.setPublication(publication);
			return entity;
		}
	}
}