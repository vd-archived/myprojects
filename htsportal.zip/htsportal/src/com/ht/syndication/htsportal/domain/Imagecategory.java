package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * Category entity provides the base persistence definition of the
 * Category entity. @author MyEclipse Persistence Tools
 */

public abstract class Imagecategory implements Serializable 
{

   /**
	 * 
	 */
	private static final long serialVersionUID = 1910474852129575724L;
	
	private Integer id;

	/**
	 * @return the id
	 */
	public Integer getId() 
	{
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	private String name;
	/**
	 * @return the name
	 */
	public java.lang.String getName() 
	{
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) 
	{
		this.name = name;
	}
	
	private String details;
	/**
	 * @return the details
	 */
	public java.lang.String getDetails() 
	{
		return details;
	}
	
	/**
	 * @param details the details to set
	 */
	public void setDetails(String details) 
	{
		this.details = details;
	}
	
    private String updatedby;
	
	/**
	 * @return the updatedby
	 */
	public java.lang.String getUpdatedby() 
	{
		return updatedby;
	}

	/**
	 * @param updatedby the updatedby to set
	 */
	public void setUpdatedby(String updatedby) 
	{
		this.updatedby = updatedby;
	}
	
    private Date createdate;

	/**
	 * @return the createdate
	 */
	public Date getCreatedate()
	{
		return createdate;
	}

	/**
	 * @param createdate the createdate to set
	 */
	public void setCreatedate(Date createdate) 
	{
		this.createdate = createdate;
	}
	
    private Date updatedate;

	/**
	 * @return the updatedate
	 */
	public Date getUpdatedate() 
	{
		return updatedate;
	}

	/**
	 * @param updatedate the updatedate to set
	 */
	public void setUpdatedate(Date updatedate) 
	{
		this.updatedate = updatedate;
	}
	
    private Short status;

	/**
	 * @return the status
	 */
	public Short getStatus() 
	{
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Short status) 
	{
		this.status = status;
	}
	
	private Short highlight;
	
	public Short getHighlight() {
		return highlight;
	}

	public void setHighlight(Short highlight) {
		this.highlight = highlight;
	}

	private Integer priority;
	
	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	/** default constructor */
	public Imagecategory() 
	{
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Imagecategory}.
		 */
		public static Imagecategory newInstance()
		{
			return new ImagecategoryImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static Imagecategory newInstance(int id, String name, String details, String updatedby, Date createdate, Date updatedate, Short highlight, Integer priority, Short status)
		{
			final Imagecategory entity = new ImagecategoryImpl();
			entity.setId(id);
			entity.setName(name);
			entity.setDetails(details);
			entity.setUpdatedby(updatedby);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setStatus(status);
			entity.setHighlight(highlight);
			entity.setPriority(priority);
			return entity;
		}
	}
}