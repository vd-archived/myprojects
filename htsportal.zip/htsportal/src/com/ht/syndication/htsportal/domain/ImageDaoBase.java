package com.ht.syndication.htsportal.domain;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;
import com.ht.syndication.htsportal.util.ListObject;

public abstract class ImageDaoBase extends HibernateDaoSupport implements ImageDao {

	
	@Override
	public void toImageVO(Image source, ImageVO target) {
		target.setId(source.getId());
		target.setName(source.getName());
		target.setExtension(source.getExtension());
		target.setTitle(source.getTitle());
		target.setAuthor(source.getAuthor());
		target.setDetails(source.getDetails());
		target.setType(source.getType());
		target.setOrientation(source.getOrientation());
		target.setEditorial(source.getEditorial());
		target.setKeywords(source.getKeywords());
		target.setCopyright(source.getCopyright());
		target.setWidth(source.getWidth());
		target.setHeight(source.getHeight());
		target.setResolution(source.getResolution());
		target.setStatus(source.getStatus());
		target.setChecksum(source.getChecksum());
		target.setCapturedate(source.getCapturedate());
		if(source.getEvent()!=null)
		{
			target.setEvent(source.getEvent().getId());
		}
		Collection<Imagetags>imageTags = source.getImagetags();
		if(imageTags != null)
		{
			List<Integer>tempImageTags = new ArrayList<Integer>();
			for(Imagetags temp: imageTags)
			{
				tempImageTags.add(temp.getId());
			}
			target.setTags(tempImageTags);
		}
	}

	public void toImageFullVO(Image source, ImageFullVO target) {
		toImageVO(source, target);
		if(source.getEvent() != null)
		{
			target.setEventDetails(ListObject.Factory.newInstance(source.getEvent().getId(), source.getEvent().getName()));
		}
		Collection<Imagetags>imageTags = source.getImagetags();
		if(imageTags != null)
		{
			List<ListObject>tempImageTags = new ArrayList<ListObject>();
			for(Imagetags temp: imageTags)
			{
				tempImageTags.add(ListObject.Factory.newInstance(temp.getId(), temp.getName()));
			}
			target.setTagsDetails(tempImageTags);
		}
	}

	@Override
	public ImageVO toImageVO(Image entity) {
		final ImageVO target = new ImageVO();
		this.toImageVO(entity, target);
		return target;
	}
	
	public ImageFullVO toImageFullVO(Image entity) {
		final ImageFullVO target = new ImageFullVO();
		this.toImageFullVO(entity, target);
		return target;
	}
	
	@Override
	public void toImageVOCollection(Collection entities) {
		if (entities != null) 
		{
			CollectionUtils.transform(entities, IMAGEVO_TRANSFORMER);
		}
	}

	@Override
	public void imageVOToEntity(ImageVO source, Image target, Boolean copyIfNull) {
		if (copyIfNull || source.getId() != null)
		{
			target.setId(source.getId());
		}
		if (copyIfNull || source.getName() != null)
		{
			target.setName(source.getName());
		}
		if (copyIfNull || source.getExtension() != null)
		{
			target.setExtension(source.getExtension());
		}
		if (copyIfNull || source.getTitle() != null)
		{
			target.setTitle(source.getTitle());
		}
		if (copyIfNull || source.getAuthor() != null)
		{
			target.setAuthor(source.getAuthor());
		}
		if (copyIfNull || source.getDetails() != null)
		{
			target.setDetails(source.getDetails());
		}
		if (copyIfNull || source.getType() != null)
		{
			target.setType(source.getType());
		}
		if (copyIfNull || source.getOrientation() != null)
		{
			target.setOrientation(source.getOrientation());
		}
		if (copyIfNull || source.getEditorial() != null)
		{
			target.setEditorial(source.getEditorial());
		}
		if (copyIfNull || source.getKeywords() != null)
		{
			target.setKeywords(source.getKeywords());
		}
		if (copyIfNull || source.getCopyright() != null)
		{
			target.setCopyright(source.getCopyright());
		}
		if (copyIfNull || source.getWidth() != null)
		{
			target.setWidth(source.getWidth());
		}
		if (copyIfNull || source.getHeight() != null)
		{
			target.setHeight(source.getHeight());
		}
		if (copyIfNull || source.getResolution() != null)
		{
			target.setResolution(source.getResolution());
		}
		if (copyIfNull || source.getStatus() != null)
		{
			/*if(source.getStatus().equals(AccessStatus.DISABLE) && !source.getStatus().equals(target.getStatus()))
			{
				this.changeStatusForIndex(target);
			}*/
			target.setStatus(source.getStatus());
		}
		if (copyIfNull || source.getChecksum() != null)
		{
			target.setChecksum(source.getChecksum());
		}
		if (copyIfNull || source.getCapturedate() != null)
		{
			target.setCapturedate(source.getCapturedate());
		}
		/*if (copyIfNull || source.getEvent() != null)
		{
			target.setEvent(source.getEvent());
		}
		if (copyIfNull || source.getTags() != null)
		{
			target.setTags(source.getTags());
		}*/
	}

	@Override
	public Image imageVOToEntity(ImageVO source) {
		final Image target = new Image();
		this.imageVOToEntity(source, target, Boolean.FALSE);
		return target;
	}

	@Override
	public void imageVOToEntityCollection(Collection instances) {
		if(instances !=null)
		{
			for(final Iterator iterator = instances.iterator(); iterator.hasNext();)
			{
				if(!(iterator.next() instanceof ImageVO))
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, ImageVOToEntityTransformer);
		}
	}

	@Override
	public Image load(Integer id) {
		return (Image) this.load(TRANSFORM_NONE, id);
	}

	@Override
	public Image load(String name) {
		return (Image) this.load(TRANSFORM_NONE, name);
	}

	@Override
	public Object load(int transform, Integer id) {
		if (id == null) 
		{
			throw new IllegalArgumentException("Image.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ImageImpl.class, id);
		return transformEntity(transform, (Image) entity);
	}
	
	@Override
	public Object load(int transform, String name) {
		if (name == null) 
		{
			throw new IllegalArgumentException("Image.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ImageImpl.class, name);
		return transformEntity(transform, (Image) entity);
	}
	
	@Override
	public Collection loadAll(int transform) {
		final Collection results = this.getHibernateTemplate().loadAll(ImageImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	@Override
	public Collection loadAllActive(int transform) {
		final Collection results = this.getHibernateTemplate().loadAll(ImageImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	@Override
	public Image create(Image image) {
		return (Image) this.create(TRANSFORM_NONE, image);
	}

	@Override
	public Object create(int transform, Image image) {
		if(image == null)
		{
			throw new IllegalArgumentException("Image.create - 'image' can not be null");
		}
		this.getHibernateTemplate().save(image);
		return this.transformEntity(transform, image);
	}

	@Override
	public Collection create(Collection entities) {
		return create(TRANSFORM_NONE, entities);
	}

	@Override
	public Collection create(final int transform, final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Image.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
					new HibernateCallback() {
						@Override
						public Object doInHibernate(Session session) throws HibernateException, SQLException {
							for(Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
							{
								create(transform, (Image)entityIterator.next());
							}
							return null;
						}
					}, true
				);
		return entities;
	}

	@Override
	public void update(Image image) {
		if(image == null)
		{
			throw new IllegalArgumentException("Image.update - 'image' can not be null");
		}
		this.getHibernateTemplate().update(image);
	}

	@Override
	public void update(final Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Image.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() {
					@Override
					public Object doInHibernate(Session arg0) throws HibernateException, SQLException {
						for(Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
						{
							update((Image)entityIterator.next());
						}
						return null;
					}
				}, true
			);
	}

	@Override
	public void remove(Image image) {
		if(image == null)
		{
			throw new IllegalArgumentException("Image.remove - 'image' can not be null");
		}
		this.getHibernateTemplate().delete(image);
	}

	@Override
	public void remove(Integer id) {
		if(id == null)
		{
			throw new IllegalArgumentException("Image.remove - 'id' can not be null");
		}
		Image image = this.load(id);
		if (image != null) 
		{
			this.remove(image);
		}
	}

	@Override
	public void remove(Collection entities) {
		if(entities == null)
		{
			throw new IllegalArgumentException("Image.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);

	}
	
	private Transformer IMAGEVO_TRANSFORMER = new Transformer() 
	{
		public Object transform(Object input) 
		{
			Object result = null;
			if (input instanceof Image)
			{
				result = toImageVO((Image) input);
			} 
			else if (input instanceof Object[])
			{
				result = toImageVO((Object[]) input);
			}
			return result;
		}
	};
	
	private Transformer IMAGEFULLVO_TRANSFORMER = new Transformer() 
	{
		public Object transform(Object input) 
		{
			Object result = null;
			if (input instanceof Image)
			{
				result = toImageFullVO((Image) input);
			} 
			else if (input instanceof Object[])
			{
				result = toImageFullVO((Object[]) input);
			}
			return result;
		}
	};
	
	protected ImageFullVO toImageFullVO(Object[] row) 
	{
		ImageFullVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Image) 
				{
					target = this.toImageFullVO((Image) object);
					break;
				}
			}
		}
		return target;
	}
	
	protected ImageVO toImageVO(Object[] row) 
	{
		ImageVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Image) 
				{
					target = this.toImageVO((Image) object);
					break;
				}
			}
		}
		return target;
	}
	
	private final Transformer ImageVOToEntityTransformer = new Transformer() 
	{
		public Object transform(Object input) 
		{
			return imageVOToEntity((ImageVO) input);
		}
	};
	
	protected Object transformEntity(final int transform, final Image entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_IMAGEVO	:  	target = toImageVO(entity);
					break;
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}
	
	public void toImageFullVOCollection(Collection entities) {
		if (entities != null) 
		{
			CollectionUtils.transform(entities, IMAGEFULLVO_TRANSFORMER);
		}
	}
	
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
    		case TRANSFORM_IMAGEVO	:	toImageVOCollection(entities);
    		break;
    		case TRANSFORM_SOLRIMAGEVO	:	toImageFullVOCollection(entities);
    		break;
    		case TRANSFORM_NONE			: 
    		default						:
		}
	}
}
