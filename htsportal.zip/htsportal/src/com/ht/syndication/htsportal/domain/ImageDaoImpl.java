package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.ImageVO;

public class ImageDaoImpl extends ImageDaoBase {

	@Override
    public Object load(final int transform, final Integer id)
    {
  		final Criteria query = super.getSession().createCriteria(Image.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Image)entity);
    }
	
	@Override
	public Object loadByChecksum(int transform, String checksum) {
		final Criteria query = super.getSession().createCriteria(Image.class);
        query.add(Restrictions.eq("checksum", checksum));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Image)entity);
	}

    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Image.class);
        query.addOrder(Order.asc("updatedate"));
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
	@Override
	public Collection loadAllInactiveImages(int transform) {
		return loadAllInactiveImages(transform, null);
	}

	@Override
	public Collection loadAllInactiveImages(int transform, Integer maxprocess) {
		final Criteria query = super.getSession().createCriteria(Image.class);
        query.add(Restrictions.ne("status", AccessStatus.ENABLE));
        query.addOrder(Order.asc("updatedate").ignoreCase());
        if(maxprocess!=null)
        	query.setMaxResults(maxprocess);
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
	}
    
    @Override
    public Collection loadAllNotIndexed(final int transform)
    {
        return loadAllNotIndexed(transform, null);
    }
    
    @Override
    public Collection loadAllNotIndexed(final int transform, Integer maxprocess)
    {
    	final Criteria query = super.getSession().createCriteria(Image.class);
        query.add(Restrictions.isNull("indexdate"));
        query.add(Restrictions.ne("status", AccessStatus.DISABLE));
//        query.add(Restrictions.ne("status", AccessStatus.ENABLE));
//        query.createCriteria("event").add(Restrictions.ne("status", AccessStatus.DISABLE));
//        query.createCriteria("imagetags").add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.addOrder(Order.asc("updatedate"));
        if(maxprocess!=null)
        	query.setMaxResults(maxprocess);
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
    @Override
    public Collection loadAllActive(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Image.class);
        query.add(Restrictions.eq("status", 1));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        
        return results;
    }
    
	public Image imageVOToEntity(ImageVO imageVO) 
	{
		Image entity = this.load(imageVO.getId());
        if (entity == null)
        {
            entity = Image.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
       	entity.setUpdatedate(new Date());
        this.imageVOToEntity(imageVO, entity, false);
        return entity;
	}

	/**
	 * 
	 */
	public Image load(String name) 
	{
  		final Criteria query = super.getSession().createCriteria(Image.class);
        query.add(Restrictions.eq("name", name));
        final Object entity = query.uniqueResult();
        return (Image)entity;
	}
}