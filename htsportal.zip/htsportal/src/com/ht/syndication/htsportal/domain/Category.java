package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

/**
 * Category entity provides the base persistence definition of the
 * Category entity. @author MyEclipse Persistence Tools
 */

public abstract class Category implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3136518124740960714L;

   private Integer id;

	/**
	 * @return the id
	 */
	public Integer getId() 
	{
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	private String name;
	/**
	 * @return the name
	 */
	public java.lang.String getName() 
	{
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) 
	{
		this.name = name;
	}
	
	private String details;
	/**
	 * @return the details
	 */
	public java.lang.String getDetails() 
	{
		return details;
	}
	
	/**
	 * @param details the details to set
	 */
	public void setDetails(String details) 
	{
		this.details = details;
	}
	
    private String updatedby;
	
	/**
	 * @return the updatedby
	 */
	public java.lang.String getUpdatedby() 
	{
		return updatedby;
	}

	/**
	 * @param updatedby the updatedby to set
	 */
	public void setUpdatedby(String updatedby) 
	{
		this.updatedby = updatedby;
	}
	
    private Date createdate;

	/**
	 * @return the createdate
	 */
	public Date getCreatedate()
	{
		return createdate;
	}

	/**
	 * @param createdate the createdate to set
	 */
	public void setCreatedate(Date createdate) 
	{
		this.createdate = createdate;
	}
	
    private Date updatedate;

	/**
	 * @return the updatedate
	 */
	public Date getUpdatedate() 
	{
		return updatedate;
	}

	/**
	 * @param updatedate the updatedate to set
	 */
	public void setUpdatedate(Date updatedate) 
	{
		this.updatedate = updatedate;
	}
	
    private Short status;

	/**
	 * @return the status
	 */
	public Short getStatus() 
	{
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Short status) 
	{
		this.status = status;
	}
	
    private Collection<Content> content = new HashSet<Content>();
    
    /**
     * @return the content
     */
    public Collection<Content> getContent() 
    {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(Collection<Content> content) 
    {
        this.content = content;
    }
	

	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdate == null) ? 0 : createdate.hashCode());
		result = prime * result + ((details == null) ? 0 : details.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + status;
		result = prime * result + ((updatedate == null) ? 0 : updatedate.hashCode());
		result = prime * result + ((updatedby == null) ? 0 : updatedby.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj) 
		{
			return true;
		}
		if (obj == null) 
		{
			return false;
		}
		if (!(obj instanceof Category)) 
		{
			return false;
		}
		Category other = (Category) obj;
		if (createdate == null) 
		{
			if (other.createdate != null) 
			{
				return false;
			}
		} 
		else if (!createdate.equals(other.createdate)) 
		{
			return false;
		}
		if (details == null) 
		{
			if (other.details != null) 
			{
				return false;
			}
		} 
		else if (!details.equals(other.details)) 
		{
			return false;
		}
		if (id != other.id) 
		{
			return false;
		}
		if (name == null) 
		{
			if (other.name != null) 
			{
				return false;
			}
		} 
		else if (!name.equals(other.name)) 
		{
			return false;
		}
		if (status != other.status) 
		{
			return false;
		}
		if (updatedate == null) 
		{
			if (other.updatedate != null) 
			{
				return false;
			}
		} 
		else if (!updatedate.equals(other.updatedate)) 
		{
			return false;
		}
		if (updatedby == null) 
		{
			if (other.updatedby != null) 
			{
				return false;
			}
		} 
		else if (!updatedby.equals(other.updatedby)) 
		{
			return false;
		}
		return true;
	}

	/** default constructor */
	public Category() 
	{
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Category}.
		 */
		public static Category newInstance()
		{
			return new CategoryImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static Category newInstance(int id, String name, String details, String updatedby, Date createdate, Date updatedate, Short status)
		{
			final Category entity = new CategoryImpl();
			entity.setId(id);
			entity.setName(name);
			entity.setDetails(details);
			entity.setUpdatedby(updatedby);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setStatus(status);
			return entity;
		}
	}
}