
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.ImagecategoryVO;

public abstract class ImagecategoryDaoBase extends HibernateDaoSupport implements ImagecategoryDao 
{
	public Object load(final int transform, final Integer id) 
	{
        if (id == null) 
		{
			throw new IllegalArgumentException("Imagecategory.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ImagecategoryImpl.class, id);
		return transformEntity(transform, (Imagecategory) entity);
	}

	public Imagecategory load(Integer id) 
	{
		return (Imagecategory) this.load(TRANSFORM_NONE, id);
	}
	
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Source.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ImagecategoryImpl.class, name);
		return transformEntity(transform, (Imagecategory) entity);
	}

	public Imagecategory loadByName(String name) 
	{
		return (Imagecategory) this.loadByName(TRANSFORM_NONE, name);
	}	

	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}

	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(ImagecategoryImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	public Collection loadAllActive() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}

	public Collection loadAllActive(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(ImagecategoryImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	public Imagecategory create(Imagecategory imagecategory) 
	{
		return (Imagecategory) this.create(TRANSFORM_NONE, imagecategory);
	}

	public Object create(final int transform, final Imagecategory imagecategory) 
	{
		if (imagecategory == null) 
		{
			throw new IllegalArgumentException("Imagecategory.create - 'imagecategory' can not be null");
		}
		this.getHibernateTemplate().save(imagecategory);
		return this.transformEntity(transform, imagecategory);
	}

	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Imagecategory.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Imagecategory) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	public Imagecategory create(Integer id, String name, String details, Short highlight, Integer priority, Short status) 
	{
		return (Imagecategory) this.create(TRANSFORM_NONE, id, name, details, highlight, priority, status);
	}

	public java.lang.Object create(final int transform, Integer id, String name, String details, Short highlight, Integer priority, Short status) 
	{
		Imagecategory entity = new ImagecategoryImpl();
		entity.setId(id);
		entity.setName(name);
		entity.setDetails(details);
		entity.setHighlight(highlight);
		entity.setPriority(priority);
		entity.setStatus(status);
		return this.create(transform, entity);
	}

	public void update(Imagecategory imagecategory) 
	{
		if (imagecategory == null) 
		{
			throw new IllegalArgumentException("Imagecategory.update - 'imagecategory' can not be null");
		}
		this.getHibernateTemplate().update(imagecategory);
	}

	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Imagecategory.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((com.ht.syndication.htsportal.domain.Imagecategory) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	public void remove(Imagecategory imagecategory) 
	{
		if (imagecategory == null) 
		{
			throw new IllegalArgumentException("Imagecategory.remove - 'imagecategory' can not be null");
		}
		this.getHibernateTemplate().delete(imagecategory);
	}

	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Imagecategory.remove - 'id' can not be null");
		}
		Imagecategory entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Imagecategory.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	protected Object transformEntity(final int transform, final Imagecategory entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_IMAGECATEGORYVO	:	target = toImagecategoryVO(entity);
				break;
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}

	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
		    case TRANSFORM_IMAGECATEGORYVO	:	toImagecategoryVOCollection(entities);
			break;
		    case TRANSFORM_NONE			: 
		    default						:
		}
	}

	public final void toImagecategoryVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities, IMAGECATEGORYVO_TRANSFORMER);
		}
	}

	protected ImagecategoryVO toImagecategoryVO(Object[] row) 
	{
		ImagecategoryVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Imagecategory) 
				{
					target = this.toImagecategoryVO((Imagecategory) object);
					break;
				}
			}
		}
		return target;
	}

	private Transformer IMAGECATEGORYVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Imagecategory) 
    			{
    				result = toImagecategoryVO((Imagecategory) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toImagecategoryVO((Object[]) input);
    			}
    			return result;
    		}
    	};

	public final void imagecategoryVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof ImagecategoryVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, ImagecategoryVOToEntityTransformer);
		}
	}

	private final Transformer ImagecategoryVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return imagecategoryVOToEntity((ImagecategoryVO) input);
    		}
    	};

	public void toImagecategoryVO(Imagecategory imagecategory, ImagecategoryVO target) 
	{
		target.setId(imagecategory.getId());
		target.setName(imagecategory.getName());
		target.setDetails(imagecategory.getDetails());
		target.setPriority(imagecategory.getPriority());
		target.setHighlight(imagecategory.getHighlight());
		target.setStatus(imagecategory.getStatus());
	}

	public ImagecategoryVO toImagecategoryVO(final Imagecategory entity) 
	{
		final ImagecategoryVO target = new ImagecategoryVO();
		this.toImagecategoryVO(entity, target);
		return target;
	}

	public void imagecategoryVOToEntity(ImagecategoryVO imagecategory, Imagecategory target, boolean copyIfNull) 
	{
		if (copyIfNull || (imagecategory.getId() != null)) 
		{
			target.setId(imagecategory.getId());
		}
		if (copyIfNull || imagecategory.getName() != null) 
		{
			target.setName(imagecategory.getName());
		}
		if (copyIfNull || imagecategory.getDetails() != null) 
		{
			target.setDetails(imagecategory.getDetails());
		}
		if (copyIfNull || imagecategory.getPriority() != null) 
		{
			target.setPriority(imagecategory.getPriority());
		}
		if (copyIfNull || imagecategory.getHighlight() != null) 
		{
			target.setHighlight(imagecategory.getHighlight());
		}
		if (copyIfNull || imagecategory.getStatus() != null) 
		{
			target.setStatus(imagecategory.getStatus());
		}
	}
	
	/**
	 * 
	 */
	public Imagecategory imagecategoryVOToEntity(ImagecategoryVO imagecategory)
	{
		Imagecategory entity = Imagecategory.Factory.newInstance();
		this.imagecategoryVOToEntity(imagecategory, entity, Boolean.FALSE);
		return entity;
	}
}