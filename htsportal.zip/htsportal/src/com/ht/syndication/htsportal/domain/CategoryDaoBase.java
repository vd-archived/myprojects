
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.CategoryVO;

/**
 * <p>
 * Category Base DAO Class: is able to create, update, remove, load, and find
 * objects of type <code>com.ht.syndication.htsportal.domain.Category</code>.
 * </p>
 * 
 * @see com.ht.syndication.htsportal.domain.Category
 */
public abstract class CategoryDaoBase extends HibernateDaoSupport implements CategoryDao 
{
	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#load(int,
	 *      java.lang.String)
	 */
	public Object load(final int transform, final Integer id) 
	{
        if (id == null) 
		{
			throw new IllegalArgumentException("Category.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(CategoryImpl.class, id);
		return transformEntity(transform, (Category) entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#load(java.lang.String)
	 */
	public Category load(Integer id) 
	{
		return (Category) this.load(TRANSFORM_NONE, id);
	}
	
	/**
	 * @see CategoryDao#load(int,
	 *      java.lang.String)
	 */
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Source.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(CategoryImpl.class, name);
		return transformEntity(transform, (Category) entity);
	}

	/**
	 * @see CategoryDao#load(java.lang.String)
	 */
	public Category loadByName(String name) 
	{
		return (Category) this.loadByName(TRANSFORM_NONE, name);
	}	

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#loadAll()
	 */
	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}
	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#loadAll(int)
	 */
	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(CategoryImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#create(com.ht.syndication.htsportal.domain.Category)
	 */
	public Category create(Category category) 
	{
		return (Category) this.create(TRANSFORM_NONE, category);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#create(int transform,
	 *      com.ht.syndication.htsportal.domain.Category)
	 */
	public Object create(final int transform, final Category category) 
	{
		if (category == null) 
		{
			throw new IllegalArgumentException("Category.create - 'category' can not be null");
		}
		this.getHibernateTemplate().save(category);
		return this.transformEntity(transform, category);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#create(java.util.Collection)
	 */
	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#create(int,
	 *      java.util.Collection)
	 */
	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Category.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Category) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#create(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.Short)
	 */
	public Category create(Integer id, String name, String details, Short status) 
	{
		return (Category) this.create(TRANSFORM_NONE, id, name, details, status);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#create(int,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.Short)
	 */
	public java.lang.Object create(final int transform, Integer id, String name, String details, Short status) 
	{
		Category entity = new CategoryImpl();
		entity.setId(id);
		entity.setName(name);
		entity.setDetails(details);
		entity.setStatus(status);
		return this.create(transform, entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#update(com.ht.syndication.htsportal.domain.Category)
	 */
	public void update(Category category) 
	{
		if (category == null) 
		{
			throw new IllegalArgumentException("Category.update - 'category' can not be null");
		}
		this.getHibernateTemplate().update(category);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#update(java.util.Collection)
	 */
	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Category.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((com.ht.syndication.htsportal.domain.Category) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#remove(com.ht.syndication.htsportal.domain.Category)
	 */
	public void remove(Category category) 
	{
		if (category == null) 
		{
			throw new IllegalArgumentException("Category.remove - 'category' can not be null");
		}
		this.getHibernateTemplate().delete(category);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#remove(java.lang.String)
	 */
	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Category.remove - 'id' can not be null");
		}
		Category entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#remove(java.util.Collection)
	 */
	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Category.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	/**
	 * Allows transformation of entities into value objects (or something else
	 * for that matter), when the <code>transform</code> flag is set to one of
	 * the constants defined in
	 * <code>com.ht.syndication.htsportal.domain.CategoryDao</code>, please note
	 * that the {@link #TRANSFORM_NONE} constant denotes no transformation, so
	 * the entity itself will be returned.
	 * <p/>
	 * This method will return instances of these types:
	 * <ul>
	 * <li>{@link com.ht.syndication.htsportal.domain.Category} -
	 * {@link #TRANSFORM_NONE}</li>
	 * <li>{@link com.ht.syndication.htsportal.transfer.CategoryVO} -
	 * {@link TRANSFORM_USERVO}</li>
	 * </ul>
	 * 
	 * If the integer argument value is unknown {@link #TRANSFORM_NONE} is
	 * assumed.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            {@link com.ht.syndication.htsportal.domain.CategoryDao}
	 * @param entity
	 *            an entity that was found
	 * @return the transformed entity (i.e. new value object, etc)
	 * @see #transformEntities(int,java.util.Collection)
	 */
	protected Object transformEntity(final int transform, final Category entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_CATEGORYVO	:	target = toCategoryVO(entity);
				break;
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}

	/**
	 * Transforms a collection of entities using the
	 * {@link #transformEntity(int,com.ht.syndication.htsportal.domain.Category)}
	 * method. This method does not instantiate a new collection.
	 * <p/>
	 * This method is to be used internally only.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            <code>com.ht.syndication.htsportal.domain.CategoryDao</code>
	 * @param entities
	 *            the collection of entities to transform
	 * @see #transformEntity(int,com.ht.syndication.htsportal.domain.Category)
	 */
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
		    case TRANSFORM_CATEGORYVO	:	toCategoryVOCollection(entities);
			break;
		    case TRANSFORM_NONE			: 
		    default						:
		}
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#toCategoryVOCollection(java.util.Collection)
	 */
	public final void toCategoryVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities, PUBLICATIONVO_TRANSFORMER);
		}
	}

	/**
	 * Default implementation for transforming the results of a report query
	 * into a value object. This implementation exists for convenience reasons
	 * only. It needs only be overridden in the {@link CategoryDaoImpl} class if you
	 * intend to use reporting queries.
	 * 
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#toCategoryVO(com.ht.syndication.htsportal.domain.Category)
	 */
	protected CategoryVO toCategoryVO(Object[] row) 
	{
		CategoryVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Category) 
				{
					target = this.toCategoryVO((Category) object);
					break;
				}
			}
		}
		return target;
	}

	/**
	 * This anonymous transformer is designed to transform entities or report
	 * query results (which result in an array of objects) to
	 * {@link com.ht.syndication.htsportal.transfer.CategoryVO} using the Jakarta
	 * Commons-Collections Transformation API.
	 */
	private Transformer PUBLICATIONVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Category) 
    			{
    				result = toCategoryVO((Category) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toCategoryVO((Object[]) input);
    			}
    			return result;
    		}
    	};

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#userVOToEntityCollection(java.util.Collection)
	 */
	public final void categoryVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof CategoryVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, CategoryVOToEntityTransformer);
		}
	}

	private final Transformer CategoryVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return categoryVOToEntity((CategoryVO) input);
    		}
    	};

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#toCategoryVO(com.ht.syndication.htsportal.domain.Category,
	 *      com.ht.syndication.htsportal.transfer.CategoryVO)
	 */
	public void toCategoryVO(Category category, CategoryVO target) 
	{
		target.setId(category.getId());
		target.setName(category.getName());
		target.setDetails(category.getDetails());
		target.setStatus(category.getStatus());
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#toCategoryVO(com.ht.syndication.htsportal.domain.Category)
	 */
	public CategoryVO toCategoryVO(final Category entity) 
	{
		final CategoryVO target = new CategoryVO();
		this.toCategoryVO(entity, target);
		return target;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.CategoryDao#userVOToEntity(com.ht.syndication.htsportal.transfer.CategoryVO,
	 *      com.ht.syndication.htsportal.domain.Category)
	 */
	public void categoryVOToEntity(CategoryVO category, Category target, boolean copyIfNull) 
	{
		if (copyIfNull || (category.getId() != null)) 
		{
			target.setId(category.getId());
		}
		if (copyIfNull || category.getName() != null) 
		{
			if(!category.getName().equals(target.getName()))
			{
				this.changeStatusForIndex(target);
			}
			target.setName(category.getName());
		}
		if (copyIfNull || category.getDetails() != null) 
		{
			target.setDetails(category.getDetails());
		}
		if (copyIfNull || category.getStatus() != null) 
		{
			if(category.getStatus().equals(AccessStatus.DISABLE) && !category.getStatus().equals(target.getStatus()))
			{
				this.changeStatusForIndex(target);
			}
			target.setStatus(category.getStatus());
		}
	}
	
	/**
	 * 
	 */
	public Category categoryVOToEntity(CategoryVO category)
	{
		Category entity = Category.Factory.newInstance();
		this.categoryVOToEntity(category, entity, Boolean.FALSE);
		return entity;
	}
	
	/**
	 * 
	 * @param source
	 */
	private void changeStatusForIndex(Category category)
	{
		if(category.getId() != null)
		{
			for(Content content:category.getContent())
			{
				if(content.getIndexdate() != null)
				{
					content.setIndexdate(null);
				}
			}
		}
	}


}