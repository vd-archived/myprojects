package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.UsermessageVO;
/**
 * A data access object (DAO) providing persistence and search support for Usermessages
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.ht.syndication.htsportal.domain.Usermessage
 * @author MyEclipse Persistence Tools
 */

public class UsermessageDaoImpl extends UsermessageDaoBase
{
    @SuppressWarnings("unchecked")
    @Override
    public Object load(final int transform, final Integer id)
    {
        final Criteria query = super.getSession().createCriteria(Usermessage.class);
        query.add(Restrictions.eq("id", id));
        final java.lang.Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Usermessage)entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Usermessage.class);
        query.add(Restrictions.ne("status", AccessStatus.DISABLE));
        query.addOrder(Order.desc("createdate"));
        final Collection results = query.list();
        this.transformEntities(transform, results);

        return results;
    }
    
    /**
     * 
     */
    public Usermessage usermessageVOToEntity(UsermessageVO usermessageVO) 
    {
        Usermessage entity = this.load(usermessageVO.getId());
        if (entity == null)
        {
            entity = Usermessage.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
        else
        {
            entity.setUpdatedate(new Date());
        }
        this.usermessageVOToEntity(usermessageVO, entity, false);

        return entity;
    }

	public Usermessage load(String name) {
		final Criteria query = super.getSession().createCriteria(Usermessage.class);
        query.add(Restrictions.eq("name", name));
        final java.lang.Object entity = query.uniqueResult();
        return (Usermessage)entity;
	}
}