package com.ht.syndication.htsportal.domain;

/**
 * PublicationImpl entity. @author MyEclipse Persistence Tools
 */
public class SourceImpl extends Source 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2982703397660244854L;
}
