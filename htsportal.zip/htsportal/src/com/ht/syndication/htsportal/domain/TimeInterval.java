package com.ht.syndication.htsportal.domain;

public interface TimeInterval
{
	public static final Short YEARLY = 1;
	
	public static final Short HALF_YEARLY = 2;
	
	public static final Short THRICE_YEARLY = 3;
	
	public static final Short QUARTERLY = 4;
	
	public static final Short MONTHLY = 12;

	public static final String[] intervalName = {"","Yearly","Half Yearly", "Thrice Yearly", "Quarterly", "", "", "", "", "", "", "", "Monthly"};
}