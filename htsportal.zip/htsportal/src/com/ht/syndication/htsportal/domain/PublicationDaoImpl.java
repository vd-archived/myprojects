package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.PublicationVO;

/**
 * A data access object (DAO) providing persistence and search support for Users
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.ht.syndication.htsportal.domain.User
 * @author MyEclipse Persistence Tools
 */

public class PublicationDaoImpl extends PublicationDaoBase
{
  	@SuppressWarnings("unchecked")
  	@Override
    public Object load(final int transform, final Integer id)
    {
  		final Criteria query = super.getSession().createCriteria(Publication.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        
        return this.transformEntity(transform, (Publication)entity);
    }
  	
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Publication.class);
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);

        return results;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAllByUser(final int transform, final User user)
    {
        final Criteria query = super.getSession().createCriteria(Publication.class);
        query.add(Restrictions.eq("owner", user));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAllActive(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Publication.class);
        query.add(Restrictions.eq("publication.status", 1));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
    /**
     * 
     */
	public Publication publicationVOToEntity(PublicationVO publicationVO) 
	{
		Publication entity = this.load(publicationVO.getId());
        if (entity == null)
        {
            entity = Publication.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
       	entity.setUpdatedate(new Date());
        this.publicationVOToEntity(publicationVO, entity, false);

        return entity;
	}

	/**
	 * 
	 */
	public Publication load(String name) 
	{
  		final Criteria query = super.getSession().createCriteria(Publication.class);
        query.add(Restrictions.eq("name", name));
        final Object entity = query.uniqueResult();
        
        return (Publication)entity;
	}
}