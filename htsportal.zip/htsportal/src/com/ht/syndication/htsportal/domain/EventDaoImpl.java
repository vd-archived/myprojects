package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.EventVO;

public class EventDaoImpl extends EventDaoBase {

  	@Override
    public Object load(final int transform, final Integer id)
    {
  		final Criteria query = super.getSession().createCriteria(Event.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        
        return this.transformEntity(transform, (Event)entity);
    }
  	
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Event.class);
        query.addOrder(Order.asc("weight"));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        
        return results;
    }
    
    @Override
    public Collection loadAllActive(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Event.class);
        query.add(Restrictions.eq("event.status", 1));
        query.addOrder(Order.asc("weight"));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        
        return results;
    }
    
    /**
     * 
     */
	public Event eventVOToEntity(EventVO eventVO) 
	{
		Event entity = this.load(eventVO.getId());
        if (entity == null)
        {
            entity = Event.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
       	entity.setUpdatedate(new Date());
        this.eventVOToEntity(eventVO, entity, false);

        return entity;
	}

	/**
	 * 
	 */
	public Event load(String name) 
	{
  		final Criteria query = super.getSession().createCriteria(Event.class);
        query.add(Restrictions.eq("name", name));
        final Object entity = query.uniqueResult();
        
        return (Event)entity;
	}
}
