package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.SubscriptionVO;
/**
 * A data access object (DAO) providing persistence and search support for Subscriptions
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.ht.syndication.htsportal.domain.Subscription
 * @author MyEclipse Persistence Tools
 */

public class SubscriptionDaoImpl extends SubscriptionDaoBase
{
    @SuppressWarnings("unchecked")
    @Override
    public Object load(final int transform, final Integer id)
    {
        final Criteria query = super.getSession().createCriteria(Subscription.class);
        query.add(Restrictions.eq("id", id));
        final java.lang.Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Subscription)entity);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Subscription.class);
        query.addOrder(Order.desc("createdate"));
        final Collection results = query.list();
        this.transformEntities(transform, results);

        return results;
    }
    
    /**
     * 
     */
    public Subscription subscriptionVOToEntity(SubscriptionVO subscriptionVO) 
    {
        Subscription entity = this.load(subscriptionVO.getId());
        if (entity == null)
        {
            entity = Subscription.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
        else
        {
            entity.setUpdatedate(new Date());
        }
        this.subscriptionVOToEntity(subscriptionVO, entity, false);

        return entity;
    }

	public Subscription load(String name) {
		final Criteria query = super.getSession().createCriteria(Subscription.class);
        query.add(Restrictions.eq("name", name));
        final java.lang.Object entity = query.uniqueResult();
        return (Subscription)entity;
	}
}