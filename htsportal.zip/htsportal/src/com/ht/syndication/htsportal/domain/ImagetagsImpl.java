package com.ht.syndication.htsportal.domain;

public class ImagetagsImpl extends Imagetags{

}
