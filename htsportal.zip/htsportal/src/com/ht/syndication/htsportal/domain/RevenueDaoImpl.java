package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.RevenueVO;

public class RevenueDaoImpl extends RevenueDaoBase
{
  	@SuppressWarnings("unchecked")
  	@Override
    public Object load(final int transform, final Integer id)
    {
  		final Criteria query = super.getSession().createCriteria(Revenue.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Revenue)entity);
    }

  	@SuppressWarnings("unchecked")
  	@Override
  	public Collection loadByPublicationClientDateRange(int transform, Publication publication, Client client, final Date startDate, final Date endDate)
    {
  		final Criteria query = super.getSession().createCriteria(Revenue.class);
  		query.add(Restrictions.eq("publication", publication));
  		query.add(Restrictions.eq("client", client));
  		query.add(Restrictions.between("date", startDate, endDate));
//  		query.add(Restrictions.eq("date", this.getDateAccordingTimeInterval(date, client.getRevenueinterval())));
  		final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
  	
  	@SuppressWarnings("unchecked")
  	@Override
    public Object loadByPublicationClientDate(final int transform, final Publication publication, final Client client, final Date date)
    {
  		final Criteria query = super.getSession().createCriteria(Revenue.class);
  		query.add(Restrictions.eq("publication", publication));
  		query.add(Restrictions.eq("client", client));
  		query.add(Restrictions.eq("date", this.getDateAccordingTimeInterval(date, client.getRevenueinterval())));
        final Object entity = query.uniqueResult();
        return this.transformEntity(transform, (Revenue)entity);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Revenue.class);
        query.addOrder(Order.asc("date").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public Collection loadAllByPublicationDate(final int transform, Publication publication, Date date)
    {
  		final Criteria query = super.getSession().createCriteria(Revenue.class);
  		query.add(Restrictions.eq("publication", publication));
  		if(publication.getClient().size() > 0)
  		{
  			Disjunction disjunction = Restrictions.disjunction();
	  		for(Client client: publication.getClient())
	  		{
	  			Criterion criterion = Restrictions.and(Restrictions.eq("client", client), Restrictions.eq("date", this.getDateAccordingTimeInterval(date, client.getRevenueinterval())));
	  			disjunction.add(criterion);
	  		}
	  		query.add(disjunction);
  		}
  		else
  		{
  			query.add(Restrictions.eq("date", date));
  		}
  		final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }

    public Revenue revenueVOToEntity(RevenueVO revenueVO) 
	{
		Revenue entity = null;
		if(revenueVO.getId() != null)
		{
			entity = this.load(revenueVO.getId());
		}
		if (entity == null)
        {
			entity = Revenue.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
		entity.setUpdatedate(new Date());
        this.revenueVOToEntity(revenueVO, entity, false);
        Date date = entity.getDate();
  		entity.setDate(date);
  		return entity;
	}
    
    public Revenue revenueVOToEntity(Publication publication, Client client, RevenueVO revenueVO) 
 	{
    	Date date = getDateAccordingTimeInterval(revenueVO.getDate(), client.getRevenueinterval());
 		Revenue entity = null;
		entity = this.loadByPublicationClientDate(publication, client, date);
 		if (entity == null)
        {
 			entity = Revenue.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
 		entity.setPublication(publication);
 		entity.setClient(client);
 		entity.setUpdatedate(new Date());
        this.revenueVOToEntity(revenueVO, entity, false);
        
        entity.setDate(date);
   		return entity;
 	}
}