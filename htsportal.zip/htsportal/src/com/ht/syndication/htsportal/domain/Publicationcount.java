package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

public class Publicationcount implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5389273754184290971L;
	
	private Integer id;
	private Date date;
	private BigInteger transmit;
	private Publication publication;
	private Short status;
	private Date createdate;
	private Date updatedate;
	private String updatedby;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public BigInteger getTransmit() {
		return transmit;
	}

	public void setTransmit(BigInteger transmit) {
		this.transmit = transmit;
	}

	public Publication getPublication() {
		return publication;
	}

	public void setPublication(Publication publication) {
		this.publication = publication;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Publicationcount}.
		 */
		public static Publicationcount newInstance()
		{
			return new PublicationcountImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static Publicationcount newInstance(Integer id, Date date, BigInteger transmit, Publication publication, Short status, Date createdate, Date updatedate, String updatedby)
		{
			final Publicationcount entity = new PublicationcountImpl();
			entity.setId(id);
			entity.setDate(date);
			entity.setTransmit(transmit);
			entity.setPublication(publication);
			entity.setStatus(status);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setUpdatedby(updatedby);
			return entity;
		}
	}
	
}
