package com.ht.syndication.htsportal.domain;

public class ContentImpl extends Content 
{
	
}
