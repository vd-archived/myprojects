
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.ContentVO;
import com.ht.syndication.htsportal.util.HTSPortal;

/**
 * <p>
 * Content Base DAO Class: is able to create, update, remove, load, and find
 * objects of type <code>Content</code>.
 * </p>
 * 
 * @see Content
 */
public abstract class ContentDaoBase extends HibernateDaoSupport implements ContentDao 
{

	/**
	 * @see ContentDao#load(int,
	 *      java.lang.String)
	 */
	public Object load(final int transform, final Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Content.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(ContentImpl.class,id);
		return transformEntity(transform,(Content) entity);
	}

	/**
	 * @see ContentDao#load(java.lang.String)
	 */
	public Content load(Integer id) 
	{
		return (Content) this.load(TRANSFORM_NONE, id);
	}
	
	/**
	 * @see ContentDao#load(java.lang.String)
	 */
	public Content load(String id) 
	{
		return (Content) this.load(TRANSFORM_NONE, id);
	}


	/**
	 * @see ContentDao#loadAll()
	 */
	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}
	/**
	 * @see ContentDao#loadAll(int)
	 */
	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(ContentImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	/**
	 * 
	 */
	public Collection indexedContent() 
	{
		return this.loadAll(TRANSFORM_CONTENTSOLRVO);
	}
	
	/**
	 * 
	 */
	public Collection indexedContent(final int transform) 
	{
		return indexedContent(transform, null);
	}
	
	/**
	 * 
	 */
	public Collection indexedContent(final int transform, Integer maxprocess) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(ContentImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	/**
	 * @see ContentDao#create(Content)
	 */
	public Content create(Content content) 
	{
		return (Content) this.create(TRANSFORM_NONE, content);
	}

	/**
	 * @see ContentDao#create(int transform,
	 *      Content)
	 */
	public Object create(final int transform, final Content content) 
	{
		if (content == null) 
		{
			throw new IllegalArgumentException("Content.create - 'content' can not be null");
		}
		this.getHibernateTemplate().save(content);
		return this.transformEntity(transform, content);
	}

	/**
	 * @see ContentDao#create(Collection)
	 */
	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	/**
	 * @see ContentDao#create(int,
	 *      Collection)
	 */
	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Content.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Content) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	/**
	 * @see ContentDao#create(String,
	 *      String, String, Short)
	 */
	public Content create(Integer id, Source source, String headline, String news, String byline, String section, String uniqueid, String location, String copyright, String updatedby, Publication publication, Date content_date, Date createdate, Date updatedate, Short status) 
	{
		return (Content) this.create(TRANSFORM_NONE, id, source, headline, news, byline, section, uniqueid, location, copyright, updatedby, publication, content_date, createdate, updatedate, status);
	}

	/**
	 * @see ContentDao#create(int,
	 *      String, String, String,
	 *      Short)
	 */
	public Object create(final int transform, Integer id, Source source, String headline, String news, String byline, String section, String uniqueid, String location, String copyright, String updatedby, Publication publication, Date content_date, Date createdate, Date updatedate, Short status) 
	{
		Content entity = Content.Factory.newInstance();
		entity.setId(id);
		entity.setSource(source);
		entity.setHeadline(headline);
		entity.setNews(news);
		entity.setByline(byline);
		entity.setSection(section);
		entity.setUniqueid(uniqueid);
		entity.setLocation(location);
		entity.setCopyright(copyright);
		entity.setUpdatedby(updatedby);
		entity.setPublication(publication);
		entity.setContentdate(content_date);
		entity.setCreatedate(createdate);
		entity.setUpdatedate(updatedate);
		entity.setStatus(status);
		return this.create(transform, entity);
	}

	/**
	 * @see ContentDao#update(Content)
	 */
	public void update(Content content) 
	{
		if (content == null) 
		{
			throw new IllegalArgumentException("Content.update - 'content' can not be null");
		}
		this.getHibernateTemplate().update(content);
	}

	/**
	 * @see ContentDao#update(Collection)
	 */
	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Content.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((Content) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	/**
	 * @see ContentDao#remove(Content)
	 */
	public void remove(Content content) 
	{
		if (content == null) 
		{
			throw new IllegalArgumentException("Content.remove - 'content' can not be null");
		}
		this.getHibernateTemplate().delete(content);
	}

	/**
	 * @see ContentDao#remove(String)
	 */
	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Content.remove - 'id' can not be null");
		}
		Content entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	/**
	 * @see ContentDao#remove(Collection)
	 */
	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Content.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	/**
	 * Allows transformation of entities into value objects (or something else
	 * for that matter), when the <code>transform</code> flag is set to one of
	 * the constants defined in
	 * <code>ContentDao</code>, please note
	 * that the {@link #TRANSFORM_NONE} constant denotes no transformation, so
	 * the entity itself will be returned.
	 * <p/>
	 * This method will return instances of these types:
	 * <ul>
	 * <li>{@link Content} -
	 * {@link #TRANSFORM_NONE}</li>
	 * <li>{@link com.ht.syndication.htsportal.transfer.ContentVO} -
	 * {@link TRANSFORM_USERVO}</li>
	 * </ul>
	 * 
	 * If the integer argument value is unknown {@link #TRANSFORM_NONE} is
	 * assumed.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            {@link ContentDao}
	 * @param entity
	 *            an entity that was found
	 * @return the transformed entity (i.e. new value object, etc)
	 * @see #transformEntities(int,Collection)
	 */
	protected Object transformEntity(final int transform, final Content entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
				case TRANSFORM_CONTENTVO	:	target = toContentVO(entity);
				break;
				case TRANSFORM_NONE			: 
				default						:	target = entity;
			}
		}
		return target;
	}

	/**
	 * Transforms a collection of entities using the
	 * {@link #transformEntity(int,Content)}
	 * method. This method does not instantiate a new collection.
	 * <p/>
	 * This method is to be used internally only.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            <code>ContentDao</code>
	 * @param entities
	 *            the collection of entities to transform
	 * @see #transformEntity(int,Content)
	 */
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
			case TRANSFORM_CONTENTVO	:	toContentVOCollection(entities);
			break;
			case TRANSFORM_NONE			: 
			default						:
		}
	}

	/**
	 * @see ContentDao#toContentVOCollection(Collection)
	 */
	public final void toContentVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities, CONTENTVO_TRANSFORMER);
		}
	}
	
	/**
	 * Default implementation for transforming the results of a report query
	 * into a value object. This implementation exists for convenience reasons
	 * only. It needs only be overridden in the {@link ContentDaoImpl} class if you
	 * intend to use reporting queries.
	 * 
	 * @see ContentDao#toContentVO(Content)
	 */
	protected ContentVO toContentVO(Object[] row) 
	{
		ContentVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Content) 
				{
					target = this.toContentVO((Content) object);
					break;
				}
			}
		}
		return target;
	}
	
	
	/**
	 * This anonymous transformer is designed to transform entities or report
	 * query results (which result in an array of objects) to
	 * {@link com.ht.syndication.htsportal.transfer.ContentVO} using the Jakarta
	 * Commons-Collections Transformation API.
	 */
	private Transformer CONTENTVO_TRANSFORMER = new Transformer() 
		{
			public Object transform(Object input) 
			{
				Object result = null;
				if (input instanceof Content) 
				{
					result = toContentVO((Content) input);
				} 
				else if (input instanceof Object[]) 
				{
					result = toContentVO((Object[]) input);
				}
				return result;
			}
		};
		
	/**
	 * @see ContentDao#userVOToEntityCollection(Collection)
	 */
	public final void contentVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof ContentVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, ContentVOToEntityTransformer);
		}
	}

	private final Transformer ContentVOToEntityTransformer = new Transformer() 
		{
			public Object transform(Object input) 
			{
				return contentVOToEntity((ContentVO) input);
			}
		};

	/**
	 * @see ContentDao#toContentVO(Content,
	 *      com.ht.syndication.htsportal.transfer.ContentVO)
	 */
	public void toContentVO(Content content,ContentVO target) 
	{
		target.setId(content.getId());
		target.setHeadline(content.getHeadline());
		target.setNews(content.getNews());
		target.setByline(content.getByline());
		target.setSection(content.getSection());
		target.setLocation(content.getLocation());
		target.setCopyright(content.getCopyright());
		target.setUniqueid(content.getUniqueid());
		target.setContentdate(content.getContentdate());
		target.setIndexdate(content.getIndexdate());
		target.setStatus(content.getStatus());
		target.setPublication(content.getPublication().getName());
		target.setSource(content.getSource().getName());
		target.setCategory(toArrayOfName(content.getCategory()));
		if(content.getPublication().getExclusive() == 1)
		{
			target.setExclusive(HTSPortal.YES);
		}
		else
		{
			target.setExclusive(HTSPortal.NO);
		}
	}
	
	public String[] toArrayOfName(Collection<Category> category)
	{
		String[]result = new String[category.size()];
		int counter = 0;
		for(Object cat: category.toArray()){
			Category temp = (Category)cat;
			result[counter++] = temp.getName();
		}
		return result;
	}

	/**
	 * @see ContentDao#toContentVO(Content)
	 */
	public ContentVO toContentVO(final Content entity) 
	{
		final ContentVO target = new ContentVO();
		this.toContentVO(entity, target);
		return target;
	}
	

	/**
	 * @see ContentDao#userVOToEntity(com.ht.syndication.htsportal.transfer.ContentVO,
	 *      Content)
	 */
	public void contentVOToEntity(ContentVO content, Content target, boolean copyIfNull) 
	{
		if (copyIfNull || (content.getId() != null)) 
		{
			target.setId(content.getId());
		}
		if (copyIfNull || (content.getHeadline() != null)) 
		{
			target.setHeadline(content.getHeadline());
		}
		if (copyIfNull || (content.getNews() != null)) 
		{
			target.setNews(content.getNews());
		}
		if (copyIfNull || (content.getByline() != null)) 
		{
			target.setByline(content.getByline());
		}
		if (copyIfNull || (content.getSection() != null)) 
		{
			target.setSection(content.getSection());
		}
		if (copyIfNull || (content.getLocation() != null)) 
		{
			target.setLocation(content.getLocation());
		}
		if (copyIfNull || (content.getCopyright() != null)) 
		{
			target.setCopyright(content.getCopyright());
		}
		if (copyIfNull || (content.getUniqueid() != null)) 
		{
			target.setUniqueid(content.getUniqueid());
		}
		if (copyIfNull || (content.getContentdate() != null)) 
		{
			target.setContentdate(content.getContentdate());
		}
		if (copyIfNull || (content.getIndexdate() != null)) 
		{
			target.setIndexdate(content.getIndexdate());
		}
		if (copyIfNull || content.getStatus() != null) 
		{
			target.setStatus(content.getStatus());
		}
	}
	/**
	 * 
	 */
	public Content contentVOToEntity(ContentVO content)
	{
		Content entity = Content.Factory.newInstance();
		this.contentVOToEntity(content, entity, Boolean.FALSE);
		return entity;
	}

}