package com.ht.syndication.htsportal.domain;

import java.util.Collection;

import com.ht.syndication.htsportal.transfer.EventVO;

public interface EventDao
{
	public final static int TRANSFORM_NONE = 0;
	public final static int TRANSFORM_EVENTVO = 1;
	public void toEventVO(Event source, EventVO target);
	public EventVO toEventVO(Event entity);
	public void toEventVOCollection(Collection entities);
	public void eventVOToEntity(EventVO source, Event target, Boolean copyIfNull);
	public Event eventVOToEntity(EventVO eventVO);
	public void eventVOToEntityCollection(Collection instances);
	public Event load(Integer id);
	public Event load(String name);
	public Object load(int transform, Integer id);
	public Collection loadAll(final int transform);
	public Collection loadAllActive(final int transform);
	public Event create(Event event);
	public Object create(int transform, Event event);
	public Collection create(Collection entities);
	public Collection create(int transform, Collection entities);
	public void update(Event event);
	public void update(Collection entities);
	public void remove(Event event);
	public void remove(Integer id);
	public void remove(Collection entities);
}