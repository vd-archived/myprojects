
package com.ht.syndication.htsportal.domain;

import java.util.Collection;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.PublicationcountVO;

public abstract class PublicationcountDaoBase extends HibernateDaoSupport implements PublicationcountDao 
{
	public void toPublicationcountVO(Publicationcount source, PublicationcountVO target) 
	{
		target.setId(source.getPublication().getId());
		target.setName(source.getPublication().getName());
		target.setDate(source.getDate());
		target.setTransmit(source.getTransmit());
		target.setStatus(source.getStatus());
	}
	
	public PublicationcountVO toPublicationcountVO(Publicationcount entity) {
		final PublicationcountVO target = new PublicationcountVO();
		this.toPublicationcountVO(entity, target);
		return target;
	}

	
	public void publicationcountVOToEntity(PublicationcountVO source, Publicationcount target, Boolean copyIfNull) {
		if (copyIfNull || (source.getDate() != null))
		{
			target.setDate(source.getDate());
		}
		if (copyIfNull || (source.getTransmit() != null))
		{
			target.setTransmit(source.getTransmit());
		}
		if (copyIfNull || (source.getStatus() != null))
		{
			target.setStatus(source.getStatus());
		}
	}

	public Publicationcount publicationcountVOToEntity(PublicationcountVO publicationcountVO) {
		Publicationcount entity = Publicationcount.Factory.newInstance();
		this.publicationcountVOToEntity(publicationcountVO, entity, Boolean.FALSE);
		return entity;
	}


	public Publicationcount load(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object load(int transform, Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection loadAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection loadAll(int transform) {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection create(Collection entities) {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection create(int transform, Collection entities) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Publicationcount publicationcount) {
		// TODO Auto-generated method stub
		
	}

	public void update(Collection entities) {
		// TODO Auto-generated method stub
		
	}

	public void remove(Publicationcount publicationcount) {
		// TODO Auto-generated method stub
		
	}

	public void remove(Integer id) {
		// TODO Auto-generated method stub
		
	}

	public void remove(Collection entities) {
		// TODO Auto-generated method stub
		
	}
	
	public Publicationcount create(Publicationcount publicationcount) 
	{
		return (Publicationcount) this.create(TRANSFORM_NONE, publicationcount);
	}

	public Object create(final int transform, final Publicationcount publicationcount) 
	{
		if (publicationcount == null) 
		{
			throw new IllegalArgumentException("Publicationcount.create - 'publicationcount' can not be null");
		}
		this.getHibernateTemplate().save(publicationcount);
		return this.transformEntity(transform, publicationcount);
	}

	protected Object transformEntity(final int transform, final Publicationcount entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
				case TRANSFORM_PUBLICATIONCOUNTVO	:	target = toPublicationcountVO(entity);
				break;
				case TRANSFORM_NONE			        : 
				default						        :	target = entity;
			}
		}
		return target;
	}
}