package com.ht.syndication.htsportal.domain;

import com.ht.syndication.htsportal.transfer.PublicationcountVO;


public class PublicationcountDaoImpl extends PublicationcountDaoBase
{
	public Publicationcount publicationcountVOToEntity(PublicationcountVO publicationcountVO)
	{
		Publicationcount entity = null;
		return entity;
	}

}