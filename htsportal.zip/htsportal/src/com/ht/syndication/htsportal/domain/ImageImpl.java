package com.ht.syndication.htsportal.domain;

public class ImageImpl extends Image {

}
