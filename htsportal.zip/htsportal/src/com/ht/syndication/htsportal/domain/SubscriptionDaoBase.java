
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.SubscriptionVO;

/**
 * <p>
 * Subscription Base DAO Class: is able to create, update, remove, load, and find
 * objects of type <code>com.ht.syndication.htsportal.domain.Subscription</code>.
 * </p>
 * 
 * @see com.ht.syndication.htsportal.domain.Subscription
 */
public abstract class SubscriptionDaoBase extends HibernateDaoSupport implements SubscriptionDao 
{
	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#load(int,
	 *      java.lang.String)
	 */
	public java.lang.Object load(final int transform, final Integer id) 
	{
        if (id == null) 
		{
			throw new IllegalArgumentException("Subscription.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(SubscriptionImpl.class, id);
		return transformEntity(transform, (Subscription) entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#load(java.lang.String)
	 */
	public Subscription load(Integer id) 
	{
		return (Subscription) this.load(TRANSFORM_NONE, id);
	}
	
	/**
	 * @see SubscriptionDao#load(int,
	 *      java.lang.String)
	 */
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Subscription.load - 'name' can not be null");
		}
		final java.lang.Object entity = this.getHibernateTemplate().get(SubscriptionImpl.class, name);
		return transformEntity(transform, (Subscription) entity);
	}

	/**
	 * @see SubscriptionDao#load(java.lang.String)
	 */
	public Subscription loadByName(String name) 
	{
		return (Subscription) this.loadByName(TRANSFORM_NONE, name);
	}	

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#loadAll()
	 */
	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}
	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#loadAll(int)
	 */
	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(SubscriptionImpl.class);
		this.transformEntities(transform, results);
		return results;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#create(com.ht.syndication.htsportal.domain.Subscription)
	 */
	public Subscription create(Subscription subscription) 
	{
		return (Subscription) this.create(TRANSFORM_NONE, subscription);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#create(int transform,
	 *      com.ht.syndication.htsportal.domain.Subscription)
	 */
	public Object create(final int transform, final Subscription subscription) 
	{
		if (subscription == null) 
		{
			throw new IllegalArgumentException("Subscription.create - 'subscription' can not be null");
		}
		this.getHibernateTemplate().save(subscription);
		return this.transformEntity(transform, subscription);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#create(java.util.Collection)
	 */
	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#create(int,
	 *      java.util.Collection)
	 */
	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Subscription.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (Subscription) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#create(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.Short)
	 */
	 
	public Subscription create(Integer id, Integer articlecount, String reproduced, String publicationname, 
			 Integer publicationcirculation, String otherdetails, String companyname, String address, 
			 String email, String phone, String country, String message, Short status) 
	{
		return (Subscription) this.create(TRANSFORM_NONE, id, articlecount, reproduced, publicationname, 
				 publicationcirculation, otherdetails, companyname, address, email, phone, country, message, status);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#create(int,
	 *      Integer , String , String , String , String , String 
	 *      java.lang.Short)vivek
	 */

	public java.lang.Object create(final int transform, Integer id, Integer articlecount, String reproduced, String publicationname, 
			 Integer publicationcirculation, String otherdetails, String companyname, String address, 
			 String email, String phone, String country, String message, Short status) 
	{
		Subscription entity = new SubscriptionImpl();
		entity.setId(id);
		entity.setArticlecount(articlecount);
		entity.setReproduced(reproduced);
		entity.setPublicationname(publicationname);
		entity.setPublicationcirculation(publicationcirculation);
		entity.setOtherdetails(otherdetails);
		entity.setCompanyname(companyname);
		entity.setAddress(address);
		entity.setEmail(email);
		entity.setPhone(phone);
		entity.setCountry(country);
		entity.setMessage(message);
		entity.setStatus(status);
		return this.create(transform, entity);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#update(com.ht.syndication.htsportal.domain.Subscription)
	 */
	public void update(Subscription subscription) 
	{
		if (subscription == null) 
		{
			throw new IllegalArgumentException("Subscription.update - 'subscription' can not be null");
		}
		this.getHibernateTemplate().update(subscription);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#update(java.util.Collection)
	 */
	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Subscription.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(new HibernateCallback()
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((com.ht.syndication.htsportal.domain.Subscription) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#remove(com.ht.syndication.htsportal.domain.Subscription)
	 */
	public void remove(Subscription subscription) 
	{
		if (subscription == null) 
		{
			throw new IllegalArgumentException("Subscription.remove - 'subscription' can not be null");
		}
		this.getHibernateTemplate().delete(subscription);
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#remove(java.lang.String)
	 */
	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Subscription.remove - 'id' can not be null");
		}
		Subscription entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#remove(java.util.Collection)
	 */
	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Subscription.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	/**
	 * Allows transformation of entities into value objects (or something else
	 * for that matter), when the <code>transform</code> flag is set to one of
	 * the constants defined in
	 * <code>com.ht.syndication.htsportal.domain.SubscriptionDao</code>, please note
	 * that the {@link #TRANSFORM_NONE} constant denotes no transformation, so
	 * the entity itself will be returned.
	 * <p/>
	 * This method will return instances of these types:
	 * <ul>
	 * <li>{@link com.ht.syndication.htsportal.domain.Subscription} -
	 * {@link #TRANSFORM_NONE}</li>
	 * <li>{@link com.ht.syndication.htsportal.transfer.SubscriptionVO} -
	 * {@link TRANSFORM_USERVO}</li>
	 * </ul>
	 * 
	 * If the integer argument value is unknown {@link #TRANSFORM_NONE} is
	 * assumed.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            {@link com.ht.syndication.htsportal.domain.SubscriptionDao}
	 * @param entity
	 *            an entity that was found
	 * @return the transformed entity (i.e. new value object, etc)
	 * @see #transformEntities(int,java.util.Collection)
	 */
	protected Object transformEntity(final int transform, final Subscription entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_SUBSCRIPTIONVO:   target = toSubscriptionVO(entity);
				break;
			    case TRANSFORM_NONE: 
			    default: target = entity;
			}
		}
		return target;
	}

	/**
	 * Transforms a collection of entities using the
	 * {@link #transformEntity(int,com.ht.syndication.htsportal.domain.Subscription)}
	 * method. This method does not instantiate a new collection.
	 * <p/>
	 * This method is to be used internally only.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            <code>com.ht.syndication.htsportal.domain.SubscriptionDao</code>
	 * @param entities
	 *            the collection of entities to transform
	 * @see #transformEntity(int,com.ht.syndication.htsportal.domain.Subscription)
	 */
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
		    case TRANSFORM_SUBSCRIPTIONVO:    toSubscriptionVOCollection(entities);
			break;
		    case TRANSFORM_NONE: 
		    default:
		}
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#toSubscriptionVOCollection(java.util.Collection)
	 */
	public final void toSubscriptionVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities, SUBSCRIPTIONVO_TRANSFORMER);
		}
	}

	/**
	 * Default implementation for transforming the results of a report query
	 * into a value object. This implementation exists for convenience reasons
	 * only. It needs only be overridden in the {@link SubscriptionDaoImpl} class if you
	 * intend to use reporting queries.
	 * 
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#toSubscriptionVO(com.ht.syndication.htsportal.domain.Subscription)
	 */
	protected SubscriptionVO toSubscriptionVO(Object[] row) 
	{
		SubscriptionVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Subscription) 
				{
					target = this.toSubscriptionVO((Subscription) object);
					break;
				}
			}
		}
		return target;
	}

	/**
	 * This anonymous transformer is designed to transform entities or report
	 * query results (which result in an array of objects) to
	 * {@link com.ht.syndication.htsportal.transfer.SubscriptionVO} using the Jakarta
	 * Commons-Collections Transformation API.
	 */
	private Transformer SUBSCRIPTIONVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Subscription) 
    			{
    				result = toSubscriptionVO((Subscription) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toSubscriptionVO((Object[]) input);
    			}
    			return result;
    		}
    	};

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#userVOToEntityCollection(java.util.Collection)
	 */
	public final void subscriptionVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof SubscriptionVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, SubscriptionVOToEntityTransformer);
		}
	}

	private final Transformer SubscriptionVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return subscriptionVOToEntity((SubscriptionVO) input);
    		}
    	};

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#toSubscriptionVO(com.ht.syndication.htsportal.domain.Subscription,
	 *      com.ht.syndication.htsportal.transfer.SubscriptionVO)vivek
	 */
	public void toSubscriptionVO(Subscription subscription, SubscriptionVO target) 
	{
		target.setId(subscription.getId());
		target.setArticlecount(subscription.getArticlecount());
		target.setReproduced(subscription.getReproduced());
		target.setPublicationname(subscription.getPublicationname());
		target.setPublicationcirculation(subscription.getPublicationcirculation());
		target.setOtherdetails(subscription.getOtherdetails());
		target.setCompanyname(subscription.getCompanyname());
		target.setAddress(subscription.getAddress());
		target.setEmail(subscription.getEmail());
		target.setPhone(subscription.getPhone());
		target.setCountry(subscription.getCountry());
		target.setMessage(subscription.getMessage());
		target.setEmailto(subscription.getEmailto());
		target.setCc(subscription.getCc());
		target.setBcc(subscription.getBcc());
		target.setEmailsubject(subscription.getEmailsubject());
		target.setStatus(subscription.getStatus());
		target.setCreatedate(subscription.getCreatedate());
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#toSubscriptionVO(com.ht.syndication.htsportal.domain.Subscription)
	 */
	public SubscriptionVO toSubscriptionVO(final Subscription entity) 
	{
		final SubscriptionVO target = new SubscriptionVO();
		this.toSubscriptionVO(entity, target);
		return target;
	}

	/**
	 * @see com.ht.syndication.htsportal.domain.SubscriptionDao#userVOToEntity(com.ht.syndication.htsportal.transfer.SubscriptionVO,
	 *      com.ht.syndication.htsportal.domain.Subscription)
	 */
	public void subscriptionVOToEntity(SubscriptionVO subscription, Subscription target, boolean copyIfNull) 
	{
		if (copyIfNull || (subscription.getId() != null)) 
		{
			target.setId(subscription.getId());
		}
		if (copyIfNull || (subscription.getArticlecount() != null)) 
		{
			target.setArticlecount(subscription.getArticlecount());
		}
		if (copyIfNull || (subscription.getReproduced() != null)) 
		{
			target.setReproduced(subscription.getReproduced());
		}
		if (copyIfNull || (subscription.getPublicationname() != null)) 
		{
			target.setPublicationname(subscription.getPublicationname());
		}
		if (copyIfNull || (subscription.getPublicationcirculation() != null)) 
		{
			target.setPublicationcirculation(subscription.getPublicationcirculation());
		}
		if (copyIfNull || (subscription.getOtherdetails() != null)) 
		{
			target.setOtherdetails(subscription.getOtherdetails());
		}
		if (copyIfNull || (subscription.getCompanyname() != null)) 
		{
			target.setCompanyname(subscription.getCompanyname());
		}
		if (copyIfNull || (subscription.getAddress() != null)) 
		{
			target.setAddress(subscription.getAddress());
		}
		if (copyIfNull || (subscription.getEmail() != null)) 
		{
			target.setEmail(subscription.getEmail());
		}
		if (copyIfNull || (subscription.getPhone() != null)) 
		{
			target.setPhone(subscription.getPhone());
		}
		if (copyIfNull || (subscription.getCountry() != null)) 
		{
			target.setCountry(subscription.getCountry());
		}
		if (copyIfNull || (subscription.getMessage() != null)) 
		{
			target.setMessage(subscription.getMessage());
		}
		if (copyIfNull || (subscription.getEmailto() != null)) 
		{
			target.setEmailto(subscription.getEmailto());
		}
		if (copyIfNull || (subscription.getCc() != null)) 
		{
			target.setCc(subscription.getCc());
		}
		if (copyIfNull || (subscription.getBcc() != null)) 
		{
			target.setBcc(subscription.getBcc());
		}
		if (copyIfNull || (subscription.getEmailsubject() != null)) 
		{
			target.setEmailsubject(subscription.getEmailsubject());
		}
		if (copyIfNull || (subscription.getStatus() != null)) 
		{
			target.setStatus(subscription.getStatus());
		}
		if (copyIfNull || (subscription.getCreatedate() != null)) 
		{
			target.setCreatedate(subscription.getCreatedate());
		}
	}
	
	/**
	 * 
	 */
	public Subscription subscriptionVOToEntity(SubscriptionVO subscription)
	{
		Subscription entity = Subscription.Factory.newInstance();
		this.subscriptionVOToEntity(subscription, entity, Boolean.FALSE);
		return entity;
	}

}