package com.ht.syndication.htsportal.domain;

import java.util.Collection;

import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;



public interface ImageDao
{
	public final static int TRANSFORM_NONE = 0;
	public final static int TRANSFORM_IMAGEVO = 1;
	public final static int TRANSFORM_SOLRIMAGEVO = 2;
	public void toImageVO(Image source, ImageVO target);
	public ImageVO toImageVO(Image entity);
	public void toImageVOCollection(Collection entities);
	
	public void toImageFullVO(Image source, ImageFullVO target);
	public ImageFullVO toImageFullVO(Image entity);
	public void toImageFullVOCollection(Collection entities);
	
	public void imageVOToEntity(ImageVO source, Image target, Boolean copyIfNull);
	public Image imageVOToEntity(ImageVO imageVO);
	public void imageVOToEntityCollection(Collection instances);
	
	public Image load(Integer id);
	public Image load(String name);
	
	public Object load(int transform, Integer id);
	public Object load(int transform, String name);
	
	public Collection loadAll(final int transform);
	public Collection loadAllActive(final int transform);
	public Collection loadAllInactiveImages(final int transform);
	public Collection loadAllInactiveImages(final int transform, Integer maxprocess);
	public Collection loadAllNotIndexed(final int transform);
	public Collection loadAllNotIndexed(final int transform, Integer maxprocess);

	public Image create(Image image);
	public Object create(int transform, Image image);
	public Collection create(Collection entities);
	public Collection create(int transform, Collection entities);
	
	public void update(Image image);
	public void update(Collection entities);
	
	public void remove(Image image);
	public void remove(Integer id);
	public void remove(Collection entities);
	
	public Object loadByChecksum(int transform, String checksum);
}