package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

/**
 * Category entity provides the base persistence definition of the
 * Category entity. @author MyEclipse Persistence Tools
 */

public abstract class Client implements Serializable 
{


	/**
	 * 
	 */
	private static final long serialVersionUID = 5811227258974434908L;

	private Integer id;
	private String name;
	private String details;
	private Short type;
	private Short status;
	private Short revenueinterval;
	private String updatedby;
	private Date createdate;
	private Date updatedate;
	private Collection<Publication> publication = new HashSet<Publication>();
	private Collection<Revenue> revenue = new HashSet<Revenue>();


	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDetails() {
		return details;
	}
	
	public void setDetails(String details) {
		this.details = details;
	}
	
	public Short getType() {
		return type;
	}
	
	public void setType(Short type) {
		this.type = type;
	}
	
	public Short getStatus() {
		return status;
	}
	
	public void setStatus(Short status) {
		this.status = status;
	}
	
	public Short getRevenueinterval() {
		return revenueinterval;
	}

	public void setRevenueinterval(Short revenueinterval) {
		this.revenueinterval = revenueinterval;
	}

	public String getUpdatedby() {
		return updatedby;
	}
	
	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}
	
	public Date getCreatedate() {
		return createdate;
	}
	
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	
	public Date getUpdatedate() {
		return updatedate;
	}
	
	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}
	
	public Collection<Publication> getPublication() {
		return publication;
	}
	
	public void setPublication(Collection<Publication> publication) {
		this.publication = publication;
	}

	public Collection<Revenue> getRevenue() {
		return revenue;
	}

	public void setRevenue(Collection<Revenue> revenue) {
		this.revenue = revenue;
	}

	/** default constructor */
	public Client() 
	{
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Client}.
		 */
		public static Client newInstance()
		{
			return new ClientImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */
		
		public static Client newInstance(Integer id, String name, String details, Short type, Short status, Short revenueinterval, String updatedby, Date createdate, Date updatedate)
		{
			final Client entity = new ClientImpl();
			entity.setId(id);
			entity.setName(name);
			entity.setDetails(details);
			entity.setType(type);
			entity.setStatus(status);
			entity.setRevenueinterval(revenueinterval);
			entity.setUpdatedby(updatedby);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			return entity;
		}
	}
}