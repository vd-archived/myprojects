
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.ImagecategoryVO;

public abstract class OldImagecategoryDaoBase extends HibernateDaoSupport implements OldImagecategoryDao 
{
	public Object load(final int transform, final Integer id) 
	{
        if (id == null) 
		{
			throw new IllegalArgumentException("Imagecategory.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(OldImagecategoryImpl.class, id);
		return transformEntity(transform, (OldImagecategory) entity);
	}

	public OldImagecategory load(Integer id) 
	{
		return (OldImagecategory) this.load(TRANSFORM_NONE, id);
	}
	
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Source.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(OldImagecategoryImpl.class, name);
		return transformEntity(transform, (OldImagecategory) entity);
	}

	public OldImagecategory loadByName(String name) 
	{
		return (OldImagecategory) this.loadByName(TRANSFORM_NONE, name);
	}	

	public Collection loadAll() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}

	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(OldImagecategoryImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	public Collection loadAllActive() 
	{
		return this.loadAll(TRANSFORM_NONE);
	}

	public Collection loadAllActive(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(OldImagecategoryImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	public OldImagecategory create(OldImagecategory oldImagecategory) 
	{
		return (OldImagecategory) this.create(TRANSFORM_NONE, oldImagecategory);
	}

	public Object create(final int transform, final OldImagecategory oldImagecategory) 
	{
		if (oldImagecategory == null) 
		{
			throw new IllegalArgumentException("Imagecategory.create - 'imagecategory' can not be null");
		}
		this.getHibernateTemplate().save(oldImagecategory);
		return this.transformEntity(transform, oldImagecategory);
	}

	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Imagecategory.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform, (OldImagecategory) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}

	public OldImagecategory create(Integer id, String name, String details, Short highlight, Integer priority, Short status) 
	{
		return (OldImagecategory) this.create(TRANSFORM_NONE, id, name, details, highlight, priority, status);
	}

	public java.lang.Object create(final int transform, Integer id, String name, String details, Short highlight, Integer priority, Short status) 
	{
		OldImagecategory entity = new OldImagecategoryImpl();
		entity.setId(id);
		entity.setName(name);
		entity.setDetails(details);
		entity.setHighlight(highlight);
		entity.setPriority(priority);
		entity.setStatus(status);
		return this.create(transform, entity);
	}

	public void update(OldImagecategory oldImagecategory) 
	{
		if (oldImagecategory == null) 
		{
			throw new IllegalArgumentException("Imagecategory.update - 'imagecategory' can not be null");
		}
		this.getHibernateTemplate().update(oldImagecategory);
	}

	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Imagecategory.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((com.ht.syndication.htsportal.domain.OldImagecategory) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	public void remove(OldImagecategory oldImagecategory) 
	{
		if (oldImagecategory == null) 
		{
			throw new IllegalArgumentException("Imagecategory.remove - 'imagecategory' can not be null");
		}
		this.getHibernateTemplate().delete(oldImagecategory);
	}

	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Imagecategory.remove - 'id' can not be null");
		}
		OldImagecategory entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Imagecategory.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	protected Object transformEntity(final int transform, final OldImagecategory entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_IMAGECATEGORYVO	:	target = toImagecategoryVO(entity);
				break;
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}

	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
		    case TRANSFORM_IMAGECATEGORYVO	:	toImagecategoryVOCollection(entities);
			break;
		    case TRANSFORM_NONE			: 
		    default						:
		}
	}

	public final void toImagecategoryVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities, IMAGECATEGORYVO_TRANSFORMER);
		}
	}

	protected ImagecategoryVO toImagecategoryVO(Object[] row) 
	{
		ImagecategoryVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof OldImagecategory) 
				{
					target = this.toImagecategoryVO((OldImagecategory) object);
					break;
				}
			}
		}
		return target;
	}

	private Transformer IMAGECATEGORYVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof OldImagecategory) 
    			{
    				result = toImagecategoryVO((OldImagecategory) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toImagecategoryVO((Object[]) input);
    			}
    			return result;
    		}
    	};

	public final void imagecategoryVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof ImagecategoryVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances, ImagecategoryVOToEntityTransformer);
		}
	}

	private final Transformer ImagecategoryVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return imagecategoryVOToEntity((ImagecategoryVO) input);
    		}
    	};

	public void toImagecategoryVO(OldImagecategory oldImagecategory, ImagecategoryVO target) 
	{
		target.setId(oldImagecategory.getId());
		target.setName(oldImagecategory.getName());
		target.setDetails(oldImagecategory.getDetails());
		target.setPriority(oldImagecategory.getPriority());
		target.setHighlight(oldImagecategory.getHighlight());
		target.setStatus(oldImagecategory.getStatus());
	}

	public ImagecategoryVO toImagecategoryVO(final OldImagecategory entity) 
	{
		final ImagecategoryVO target = new ImagecategoryVO();
		this.toImagecategoryVO(entity, target);
		return target;
	}

	public void imagecategoryVOToEntity(ImagecategoryVO imagecategory, OldImagecategory target, boolean copyIfNull) 
	{
		if (copyIfNull || (imagecategory.getId() != null)) 
		{
			target.setId(imagecategory.getId());
		}
		if (copyIfNull || imagecategory.getName() != null) 
		{
			target.setName(imagecategory.getName());
		}
		if (copyIfNull || imagecategory.getDetails() != null) 
		{
			target.setDetails(imagecategory.getDetails());
		}
		if (copyIfNull || imagecategory.getPriority() != null) 
		{
			target.setPriority(imagecategory.getPriority());
		}
		if (copyIfNull || imagecategory.getHighlight() != null) 
		{
			target.setHighlight(imagecategory.getHighlight());
		}
		if (copyIfNull || imagecategory.getStatus() != null) 
		{
			target.setStatus(imagecategory.getStatus());
		}
	}
	
	/**
	 * 
	 */
	public OldImagecategory imagecategoryVOToEntity(ImagecategoryVO imagecategory)
	{
		OldImagecategory entity = OldImagecategory.Factory.newInstance();
		this.imagecategoryVOToEntity(imagecategory, entity, Boolean.FALSE);
		return entity;
	}
}