package com.ht.syndication.htsportal.domain;

import java.util.Date;

public class Revenue 
{
	private Integer id;
	private Publication publication;
	private Client client;
	private Date date;
	private Double amount;
	private Short status;
	private Date createdate;
	private Date updatedate;
	private String updatedby;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Publication getPublication() {
		return publication;
	}

	public void setPublication(Publication publication) {
		this.publication = publication;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public Revenue() 
	{
		super();
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Revenue}.
		 */
		public static Revenue newInstance()
		{
			return new RevenueImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static Revenue newInstance(Integer id, Publication publication, Client client, Date date, Double amount, Short status, Date createdate, Date updatedate, String updatedby)
		{
			final Revenue entity = new RevenueImpl();
			entity.setId(id);
			entity.setPublication(publication);
			entity.setClient(client);
			entity.setDate(date);
			entity.setAmount(amount);
			entity.setStatus(status);
			entity.setCreatedate(createdate);
			entity.setUpdatedate(updatedate);
			entity.setUpdatedby(updatedby);
			return entity;
		}
	}
	
}
