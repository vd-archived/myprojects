package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.ht.syndication.htsportal.transfer.ImagetagsVO;

public class ImagetagsDaoImpl extends ImagetagsDaoBase {

  	@Override
    public Object load(final int transform, final Integer id)
    {
  		final Criteria query = super.getSession().createCriteria(Imagetags.class);
        query.add(Restrictions.eq("id", id));
        final Object entity = query.uniqueResult();
        
        return this.transformEntity(transform, (Imagetags)entity);
    }
  	
    @Override
    public Collection loadAll(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Imagetags.class);
        query.addOrder(Order.asc("weight"));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        
        return results;
    }
    
    @Override
    public Collection loadAllActive(final int transform)
    {
        final Criteria query = super.getSession().createCriteria(Imagetags.class);
        query.add(Restrictions.eq("imagetags.status", 1));
        query.addOrder(Order.asc("weight"));
        query.addOrder(Order.asc("name").ignoreCase());
        final Collection results = query.list();
        this.transformEntities(transform, results);
        
        return results;
    }
    
    @Override
    public Collection loadAllActiveByParent(final int transform, Integer parent)
    {
    	final Criteria query = super.getSession().createCriteria(Imagetags.class);
        query.add(Restrictions.eq("status", AccessStatus.ENABLE));
        if(parent==null)
        {
        	query.add(Restrictions.isNull("parent"));
        }
        else
        {
        	query.add(Restrictions.eq("parent", parent));
        }
        query.addOrder(Order.asc("weight"));
        query.addOrder(Order.asc("name").ignoreCase());
        
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
    @Override
    public Collection loadAllByType(final int transform, Short type)
    {
    	final Criteria query = super.getSession().createCriteria(Imagetags.class);
        query.add(Restrictions.eq("status", AccessStatus.ENABLE));
        if(type==null)
        {
        	query.add(Restrictions.isNull("parent"));
        }
        else
        {
        	query.add(Restrictions.eq("type", type));
        }
        query.addOrder(Order.asc("weight"));
        query.addOrder(Order.asc("name").ignoreCase());
        
        final Collection results = query.list();
        this.transformEntities(transform, results);
        return results;
    }
    
/*    @Override
	public Collection loadAllByExpression(final int transform, Collection<Criteria> criterias, Collection<Order> orders) {
		final Collection results = this.getHibernateTemplate().loadAll(ImagetagsImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
  */  
    /**
     * 
     */
	public Imagetags imagetagsVOToEntity(ImagetagsVO imagetagsVO) 
	{
		Imagetags entity = this.load(imagetagsVO.getId());
        if (entity == null)
        {
            entity = Imagetags.Factory.newInstance();
            entity.setCreatedate(new Date());
        }
       	entity.setUpdatedate(new Date());
        this.imagetagsVOToEntity(imagetagsVO, entity, false);

        return entity;
	}

	/**
	 * 
	 */
	public Imagetags load(String name) 
	{
  		final Criteria query = super.getSession().createCriteria(Imagetags.class);
        query.add(Restrictions.eq("name", name));
        final Object entity = query.uniqueResult();
        
        return (Imagetags)entity;
	}
}
