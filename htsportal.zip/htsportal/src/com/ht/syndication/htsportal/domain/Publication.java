package com.ht.syndication.htsportal.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

/**
 * Publication entity provides the base persistence definition of the
 * Publication entity. @author MyEclipse Persistence Tools
 */

public abstract class Publication implements Serializable 
{
	/**
	 *
	 */
	private static final long serialVersionUID = 2782216268083714245L;
	
    private Integer id;

    /**
     * 
     * @return
     */
	public Integer getId() 
	{
		return id;
	}
	
	/**
	 * 
	 * @param id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}

    private String name;
    
    /**
     * 
     * @return
     */
	public String getName() 
	{
		return name;
	}

	/**
	 * 
	 * @param name
	 */
	public void setName(String name) 
	{
		this.name = name;
	}

    private String shortname;

    /**
     * 
     * @return
     */
    public String getShortname()
    {
        return shortname;
    }
    
    /**
     * 
     * @param shortname
     */
    public void setShortname(String shortname)
    {
        this.shortname = shortname;
    }
    
    private String details;

    /**
     * 
     * @return
     */
    public String getDetails() 
    {
		return details;
	}

    /**
     * 
     * @param details
     */
	public void setDetails(String details) 
	{
		this.details = details;
	}

    private String weburl;

    /**
     * 
     * @return
     */
	public String getWeburl() 
	{
		return weburl;
	}

	/**
	 * 
	 * @param weburl
	 */
	public void setWeburl(String weburl) 
	{
		this.weburl = weburl;
	}

    private String email;

    /**
     * 
     * @return
     */
	public String getEmail() 
	{
		return email;
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(String email) 
	{
		this.email = email;
	}
	
    private String address;

	/**
	 * 
	 * @return
	 */
    public String getAddress() 
    {
		return address;
	}

    /**
     * 
     * @param address
     */
	public void setAddress(String address) 
	{
		this.address = address;
	}
	
	private String phone;

	/**
	 * 
	 * @return
	 */
	public String getPhone() 
	{
		return phone;
	}

	/**
	 * 
	 * @param phone
	 */
	public void setPhone(String phone) 
	{
		this.phone = phone;
	}

	private String fax;

	/**
	 * 
	 * @return
	 */
	public String getFax() 
	{
		return fax;
	}

	/**
	 * 
	 * @param fax
	 */
	public void setFax(String fax) 
	{
		this.fax = fax;
	}

    private String contactperson1;

	public String getContactperson1() 
	{
		return contactperson1;
	}

	public void setContactperson1(String contactperson1) 
	{
		this.contactperson1 = contactperson1;
	}
	
    private String contactperson2;

    /**
     * 
     * @return
     */
	public String getContactperson2() 
	{
		return contactperson2;
	}

	/**
	 * 
	 * @param contactperson2
	 */
	public void setContactperson2(String contactperson2) 
	{
		this.contactperson2 = contactperson2;
	}
	
    private String contactperson3;

    /**
     * 
     * @return
     */
	public String getContactperson3() 
	{
		return contactperson3;
	}

	/**
	 * 
	 * @param contactperson3
	 */
	public void setContactperson3(String contactperson3) 
	{
		this.contactperson3 = contactperson3;
	}

	private String otherinfo;

	/**
	 * 
	 * @return
	 */
	public String getOtherinfo() 
	{
		return otherinfo;
	}

	public void setOtherinfo(String otherinfo) {
		this.otherinfo = otherinfo;
	}

    private Short exclusive;

    /**
     * 
     * @return
     */
	public Short getExclusive() 
	{
		return exclusive;
	}

	/**
	 * 
	 * @param Exclusive
	 */
	public void setExclusive(Short exclusive) 
	{
		this.exclusive = exclusive;
	}
	
	private Short newsTicker;

    private Short status;

    /**
     * 
     * @return
     */
	public Short getStatus() 
	{
		return status;
	}

	/**
	 * 
	 * @param status
	 */
	public void setStatus(Short status) 
	{
		this.status = status;
	}

	
	private Date createdate;

	/**
	 * 
	 * @return
	 */
	public Date getCreatedate() 
	{
		return createdate;
	}

	/**
	 * 
	 * @param createdate
	 */
	public void setCreatedate(Date createdate) 
	{
		this.createdate = createdate;
	}

    private Date updatedate;

    /**
     * 
     * @return
     */
	public Date getUpdatedate() 
	{
		return updatedate;
	}

	/**
	 * 
	 * @param updatedate
	 */
	public void setUpdatedate(Date updatedate) 
	{
		this.updatedate = updatedate;
	}
	
    private String updatedby;

	/**
	 * 
	 * @return
	 */
	public String getUpdatedby() 
	{
		return updatedby;
	}

	public void setUpdatedby(String updatedby) 
	{
		this.updatedby = updatedby;
	}
	
	private Collection<Content> content = new HashSet<Content>();
	
	/**
	 * @return the content
	 */
	public Collection<Content> getContent() 
	{
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(Collection<Content> content) 
	{
		this.content = content;
	}
	
	private User owner;

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	private Collection<Client> client = new HashSet<Client>();
	
	public Collection<Client> getClient() {
		return client;
	}

	public void setClient(Collection<Client> client) {
		this.client = client;
	}

	private Collection<Revenue> revenue = new HashSet<Revenue>();
	
	public Collection<Revenue> getRevenue() {
		return revenue;
	}

	public void setRevenue(Collection<Revenue> revenue) {
		this.revenue = revenue;
	}

	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj) 
		{
			return true;
		}
		if (obj == null) 
		{
			return false;
		}
		if (!(obj instanceof Publication)) 
		{
			return false;
		}
		Publication other = (Publication) obj;
		if (id == null) 
		{
			if (other.id != null) 
			{
				return false;
			}
		} 
		else if (!id.equals(other.id)) 
		{
			return false;
		}
		return true;
	}

	/** default constructor */
	public Publication() 
	{
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}.
		 */
		public static Publication newInstance()
		{
			return new PublicationImpl();
		}

		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */
		public static Publication newInstance(Integer id, String shortname, String name, String details, String weburl, String email, String address, String phone, String fax, String contactperson1, String contactperson2, String contactperson3, String otherinfo, Short status)
		{
			final Publication entity = new PublicationImpl();
			entity.setId(id);
			entity.setShortname(shortname);
			entity.setName(name);
			entity.setDetails(details);
			entity.setWeburl(weburl);
			entity.setEmail(email);
			entity.setAddress(address);
			entity.setPhone(phone);
			entity.setFax(fax);
			entity.setContactperson1(contactperson1);
			entity.setContactperson2(contactperson2);
			entity.setContactperson3(contactperson3);
			entity.setOtherinfo(otherinfo);
			entity.setStatus(status);
			return entity;
		}
		
		public static Publication newInstance(Integer id, String shortname, String name, String details, String weburl, String email, String address, String phone, String fax, String contactperson1, String contactperson2, String contactperson3, String otherinfo, Short status, User owner)
		{
			final Publication entity = newInstance(id, shortname, name, details, weburl, email, address, phone, fax, contactperson1, contactperson2, contactperson3, otherinfo, status);
			entity.setOwner(owner);
			return entity;
		}
	}

	public Short getNewsTicker() {
		return newsTicker;
	}

	public void setNewsTicker(Short newsTicker) {
		this.newsTicker = newsTicker;
	}

}