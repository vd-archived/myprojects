package com.ht.syndication.htsportal.domain;

import java.util.Date;

/**
 * Category entity provides the base persistence definition of the
 * Category entity. @author MyEclipse Persistence Tools
 */

public abstract class Subscription implements java.io.Serializable {
	

	private Integer id;
	private Integer articlecount;
	private String reproduced;
	private String publicationname;
	private Integer publicationcirculation;
	private String otherdetails;
	private String companyname;
	private String address;
	private String email;
	private String phone;
	private String country;
	private String message;
	private String emailto;
	private String cc;
	private String bcc;
	private String emailsubject;
	private Short status;
	private Date createdate;
	private Date updatedate;
	private String updatedby;

	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getArticlecount() {
		return articlecount;
	}

	public void setArticlecount(Integer articlecount) {
		this.articlecount = articlecount;
	}

	public String getReproduced() {
		return reproduced;
	}

	public void setReproduced(String reproduced) {
		this.reproduced = reproduced;
	}

	public String getPublicationname() {
		return publicationname;
	}

	public void setPublicationname(String publicationname) {
		this.publicationname = publicationname;
	}

	public Integer getPublicationcirculation() {
		return publicationcirculation;
	}

	public void setPublicationcirculation(Integer publicationcirculation) {
		this.publicationcirculation = publicationcirculation;
	}

	public String getOtherdetails() {
		return otherdetails;
	}

	public void setOtherdetails(String otherdetails) {
		this.otherdetails = otherdetails;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getEmailto() {
		return emailto;
	}

	public void setEmailto(String emailto) {
		this.emailto = emailto;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) {
		this.bcc = bcc;
	}

	public String getEmailsubject() {
		return emailsubject;
	}

	public void setEmailsubject(String emailsubject) {
		this.emailsubject = emailsubject;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	/** default constructor */
	public Subscription() 
	{
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.Subscription}.
		 */
		public static Subscription newInstance()
		{
			return new SubscriptionImpl();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.domain.User}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */
		
		

		public static Subscription newInstance(Integer id, Integer articlecount, 
				String reproduced, String publicationname, Integer publicationcirculation,
				String otherdetails, String companyname, String address,
				String email, String phone, String country, String message,
				String emailto, String cc, String bcc, String emailsubject,
				Short status)
		{
			final Subscription entity = new SubscriptionImpl();
			
			entity.setId(id);
			entity.setArticlecount(articlecount);
			entity.setReproduced(reproduced);
			entity.setPublicationname(publicationname);
			entity.setPublicationcirculation(publicationcirculation);
			entity.setOtherdetails(otherdetails);
			entity.setCompanyname(companyname);
			entity.setAddress(address);
			entity.setEmail(email);
			entity.setPhone(phone);
			entity.setCountry(country);
			entity.setMessage(message);
			entity.setEmailto(emailto);
			entity.setCc(cc);
			entity.setBcc(bcc);
			entity.setEmailsubject(emailsubject);
			entity.setStatus(status);
			return entity;
		}
	}
}