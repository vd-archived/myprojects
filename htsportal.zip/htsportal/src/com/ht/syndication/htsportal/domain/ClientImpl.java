package com.ht.syndication.htsportal.domain;

/**
 * PublicationImpl entity. @author MyEclipse Persistence Tools
 */
public class ClientImpl extends Client 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6529253762844302951L;


}
