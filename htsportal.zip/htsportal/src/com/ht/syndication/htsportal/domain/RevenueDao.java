package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Date;

import com.ht.syndication.htsportal.transfer.RevenueVO;

public interface RevenueDao
{
	public final static int TRANSFORM_NONE = 0;

	public final static int TRANSFORM_REVENUEVO = 1;
	
	public final static int TRANSFORM_CLIENT_REVENUE = 2;
	
	public final static int TRANSFORM_PUBLICATION_REVENUESTRING = 3;
	
	public final static int TRANSFORM_PUBLICATION_REVENUEINTEGER = 4;
	
	public void toRevenueVO(Revenue revenue, RevenueVO target);
	
	public RevenueVO toRevenueVO(Revenue entity);

	public void toRevenueVOCollection(Collection entities);

	public void revenueVOToEntity(RevenueVO revenue, Revenue target, Boolean copyIfNull);
	
	public Revenue revenueVOToEntity(RevenueVO revenueVO);
	
	public Revenue revenueVOToEntity(Publication publication, Client client ,RevenueVO revenueVO);
	
	public void revenueVOToEntityCollection(Collection instances);
	
	public Revenue load(Integer id);
	
	public Object load(int transform, Integer id);
	
	public Revenue loadByPublicationClientDate(Publication publication, Client client, final Date date);
	
	public Object loadByPublicationClientDate(int transform, Publication publication, Client client, Date date);
	
	public Collection loadByPublicationClientDateRange(Publication publication, Client client, final Date startDate, final Date endDate);
	
	public Collection loadByPublicationClientDateRange(int transform, Publication publication, Client client, final Date startDate, final Date endDate);
	
	public Collection loadAllByPublicationDate(final int transform, Publication publication, Date date);
	
	public Collection loadAll();
	
	public Collection loadAll(final int transform);
	
	public Revenue create(Revenue revenue);
	
	public Object create(int transform, Revenue revenue);
	
	public Collection create(Collection entities);
	
	public Collection create(int transform, Collection entities);
	
	public Revenue create(Integer id, Publication publication, Client client, Date date, Double amount, Short status);
	
	public Object create( int transform, Integer id, Publication publication, Client client, Date date, Double amount, Short status);
	
	public void update(Revenue revenue);
	
	public void update(Collection entities);
	
	public void remove(Revenue revenue);
	
	public void remove(Integer id);
	
	public void remove(Collection entities);
}
