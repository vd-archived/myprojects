
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.UserVO;

/**
 * <p>
 * User Base DAO Class: is able to create, update, remove, load, and find
 * objects of type <code>User</code>.
 * </p>
 *
 * @see User
 */
public abstract class UserDaoBase extends HibernateDaoSupport implements UserDao
{

    /**
     * @see UserDao#load(int, String)
     */
    public Object load(final int transform, final String username)
    {
        if (username == null)
        {
            throw new IllegalArgumentException("User.load - 'username' can not be null");
        }
        final Object entity = this.getHibernateTemplate().get(UserImpl.class, username);
        return transformEntity(transform, (User)entity);
    }

    /**
     * @see UserDao#load(String)
     */
    public User load(String username)
    {
        return (User)this.load(TRANSFORM_NONE, username);
    }

    /**
     * @see UserDao#loadAll()
     */
    public Collection loadAll()
    {
        return this.loadAll(TRANSFORM_NONE);
    }

    /**
     * @see UserDao#loadAll(int)
     */
    public Collection loadAll(final int transform)
    {
        final Collection results = this.getHibernateTemplate().loadAll(UserImpl.class);
        this.transformEntities(transform, results);
        return results;
    }
    
    /**
     * @see UserDao#loadAll()
     */
    public Collection loadAllByRoles(List<Short> roles)
    {
        return this.loadAllByRoles(TRANSFORM_NONE, roles);
    }

    /**
     * @see UserDao#loadAll(int)
     */
    public Collection loadAllByRoles(final int transform, List<Short> roles)
    {
        final Collection results = this.getHibernateTemplate().loadAll(UserImpl.class);
        this.transformEntities(transform, results);
        return results;
    }

    /**
     * @see UserDao#create(User)
     */
    public User create(User user)
    {
        return (User)this.create(TRANSFORM_NONE, user);
    }

    /**
     * @see UserDao#create(int transform, User)
     */
    public Object create(final int transform, final User user)
    {
        if (user == null)
        {
            throw new IllegalArgumentException("User.create - 'user' can not be null");
        }
        this.getHibernateTemplate().save(user);
        return this.transformEntity(transform, user);
    }

    /**
     * @see UserDao#create(Collection)
     */
    public Collection create(final Collection entities)
    {
        return create(TRANSFORM_NONE, entities);
    }

    /**
     * @see UserDao#create(int, Collection)
     */
    public Collection create(final int transform, final Collection entities)
    {
        if (entities == null)
        {
            throw new IllegalArgumentException("User.create - 'entities' can not be null");
        }
        this.getHibernateTemplate().execute(
            new HibernateCallback()
            {
                public Object doInHibernate(Session session) throws HibernateException
                {
                    for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
                    {
                        create(transform, (User)entityIterator.next());
                    }
                    return null;
                }
            },
            true);
        return entities;
    }

    /**
     * @see UserDao#create(String, String, Boolean, Boolean)
     */
    public User create(String username, String password, String firstName, String lastName, String email, Short role, Short status, List<Publication> publication)
    {
        return (User)this.create(TRANSFORM_NONE, username, password, firstName, lastName, email, role, status, publication);
    }

    /**
     * @see UserDao#create(int, String, String, Boolean, Short)
     */
    public Object create(final int transform, String username, String password, String firstName, String lastName, String email, Short role, Short status, List<Publication> publication)
    {
        User entity = new UserImpl();
        entity.setUsername(username);
        entity.setPassword(password);
        entity.setFirstName(firstName);
        entity.setLastName(lastName);
        entity.setEmail(email);
        entity.setRole(role);
        entity.setStatus(status);
        entity.setPublication(publication);
        return this.create(transform, entity);
    }

    /**
     * @see UserDao#update(User)
     */
    public void update(User user)
    {
        if (user == null)
        {
            throw new IllegalArgumentException("User.update - 'user' can not be null");
        }
        this.getHibernateTemplate().update(user);
    }

    /**
     * @see UserDao#update(Collection)
     */
    public void update(final Collection entities)
    {
        if (entities == null)
        {
            throw new IllegalArgumentException("User.update - 'entities' can not be null");
        }
        this.getHibernateTemplate().execute(
            new HibernateCallback()
            {
                public Object doInHibernate(Session session) throws HibernateException
                {
                    for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();)
                    {
                        update((User)entityIterator.next());
                    }
                    return null;
                }
            },
            true);
    }

    /**
     * @see UserDao#remove(User)
     */
    public void remove(User user)
    {
        if (user == null)
        {
            throw new IllegalArgumentException("User.remove - 'user' can not be null");
        }
        this.getHibernateTemplate().delete(user);
    }

    /**
     * @see UserDao#remove(String)
     */
    public void remove(String username)
    {
        if (username == null)
        {
            throw new IllegalArgumentException("User.remove - 'username' can not be null");
        }
        User entity = this.load(username);
        if (entity != null)
        {
            this.remove(entity);
        }
    }

    /**
     * @see UserDao#remove(Collection)
     */
    public void remove(Collection entities)
    {
        if (entities == null)
        {
            throw new IllegalArgumentException("User.remove - 'entities' can not be null");
        }
        this.getHibernateTemplate().deleteAll(entities);
    }
    /**
     * @see UserDao#loadAll(String)
     */
    public Collection loadAll(final String username)
    {
    	return loadAll(TRANSFORM_NONE, username);
    }
    
    public Collection loadAll(final int transform, final String username)
    {
    	final Collection results = this.getHibernateTemplate().loadAll(UserImpl.class);
        this.transformEntities(transform, results);
        return results;
    }

    /**
     * Allows transformation of entities into value objects
     * (or something else for that matter), when the <code>transform</code>
     * flag is set to one of the constants defined in <code>UserDao</code>, please note
     * that the {@link #TRANSFORM_NONE} constant denotes no transformation, so the entity itself
     * will be returned.
     * <p/>
     * This method will return instances of these types:
     * <ul>
     *   <li>{@link User} - {@link #TRANSFORM_NONE}</li>
     *   <li>{@link UserVO} - {@link TRANSFORM_USERVO}</li>
     * </ul>
     *
     * If the integer argument value is unknown {@link #TRANSFORM_NONE} is assumed.
     *
     * @param transform one of the constants declared in {@link UserDao}
     * @param entity an entity that was found
     * @return the transformed entity (i.e. new value object, etc)
     * @see #transformEntities(int,Collection)
     */
    protected Object transformEntity(final int transform, final User entity)
    {
        Object target = null;
        if (entity != null)
        {
            switch (transform)
            {
                case TRANSFORM_USERVO 	:	target = toUserVO(entity);
                break;
                case TRANSFORM_NONE 	: 
                default					:   target = entity;
            }
        }
        return target;
    }

    /**
     * Transforms a collection of entities using the
     * {@link #transformEntity(int,User)}
     * method. This method does not instantiate a new collection.
     * <p/>
     * This method is to be used internally only.
     *
     * @param transform one of the constants declared in <code>UserDao</code>
     * @param entities the collection of entities to transform
     * @see #transformEntity(int,User)
     */
    protected void transformEntities(final int transform, final Collection entities)
    {
        switch (transform)
        {
            case TRANSFORM_USERVO :	toUserVOCollection(entities);
            break;
            case TRANSFORM_NONE : 
            default:
        }
    }

    /**
     * @see UserDao#toUserVOCollection(Collection)
     */
    public final void toUserVOCollection(Collection entities)
    {
        if (entities != null)
        {
            CollectionUtils.transform(entities, USERVO_TRANSFORMER);
        }
    }

    /**
     * Default implementation for transforming the results of a report query into a value object. This
     * implementation exists for convenience reasons only. It needs only be overridden in the
     * {@link UserDaoImpl} class if you intend to use reporting queries.
     * @see UserDao#toUserVO(User)
     */
    protected UserVO toUserVO(Object[] row)
    {
        UserVO target = null;
        if (row != null)
        {
            final int numberOfObjects = row.length;
            for (int ctr = 0; ctr < numberOfObjects; ctr++)
            {
                final Object object = row[ctr];
                if (object instanceof User)
                {
                    target = this.toUserVO((User)object);
                    break;
                }
            }
        }
        return target;
    }

    /**
     * This anonymous transformer is designed to transform entities or report query results
     * (which result in an array of objects) to {@link UserVO}
     * using the Jakarta Commons-Collections Transformation API.
     */
    private Transformer USERVO_TRANSFORMER = new Transformer()
        {
            public Object transform(Object input)
            {
                Object result = null;
                if (input instanceof User)
                {
                    result = toUserVO((User)input);
                }
                else if (input instanceof Object[])
                {
                    result = toUserVO((Object[])input);
                }
                return result;
            }
        };

    /**
     * @see UserDao#userVOToEntityCollection(Collection)
     */
    public final void userVOToEntityCollection(Collection instances)
    {
        if (instances != null)
        {
            for (final Iterator iterator = instances.iterator(); iterator.hasNext();)
            {
                // - remove an objects that are null or not of the correct instance
                if (!(iterator.next() instanceof UserVO))
                {
                    iterator.remove();
                }
            }
            CollectionUtils.transform(instances, UserVOToEntityTransformer);
        }
    }

    private final Transformer UserVOToEntityTransformer = 
        new Transformer()
        {
            public Object transform(Object input)
            {
                return userVOToEntity((UserVO)input);
            }
        };


    /**
     * @see UserDao#toUserVO(User, UserVO)
     */
    public void toUserVO(User source, UserVO target)
    {
    	target.setUsername(source.getUsername());
        target.setFirstName(source.getFirstName());
        target.setLastName(source.getLastName());
        target.setEmail(source.getEmail());
        target.setRole(source.getRole());
        target.setStatus(source.getStatus());
    }

    /**
     * @see UserDao#toUserVO(User)
     */
    public UserVO toUserVO(final User entity)
    {
        final UserVO target = new UserVO();
        this.toUserVO(entity, target);
        return target;
    }
    
    /**
     * @see UserDao#userVOToEntity(UserVO, User)
     */
    public void userVOToEntity(UserVO source, User target, boolean copyIfNull)
    {
        if (copyIfNull || source.getUsername() != null)
        {
            target.setUsername(source.getUsername());
        }
        if (copyIfNull || source.getPassword() != null)
        {
            target.setPassword(source.getPassword());
        }
        if (copyIfNull || source.getFirstName() != null)
        {
            target.setFirstName(source.getFirstName());
        }
        if (copyIfNull || source.getLastName() != null)
        {
            target.setLastName(source.getLastName());
        }
        if (copyIfNull || source.getEmail() != null)
        {
            target.setEmail(source.getEmail());
        }
        if (copyIfNull || source.getStatus() != null)
        {
            target.setStatus(source.getStatus());
        }
        if (copyIfNull || source.getRole() != null)
        {
            target.setRole(source.getRole());
        }
    }
    
}