
package com.ht.syndication.htsportal.domain;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.PublicationVO;

/**
 * <p>
 * User Base DAO Class: is able to create, update, remove, load, and find
 * objects of type <code>User</code>.
 * </p>
 * 
 * @see User
 */
public abstract class PublicationDaoBase extends HibernateDaoSupport implements PublicationDao 
{
	/**
	 * @see UserDao#load(int,
	 *      String)
	 */
	public Object load(final int transform, final Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Publication.load - 'id' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(PublicationImpl.class,id);
		return transformEntity(transform, (Publication) entity);
	}

	/**
	 * @see PublicationDao#load(Integer)
	 */
	public Publication load(Integer id) 
	{
		return (Publication) this.load(TRANSFORM_NONE, id);
	}
	
	/**
	 * @see PublicationDao#load(int,
	 *      String)
	 */
	public Object loadByName(final int transform, final String name) 
	{
		if (name == null) 
		{
			throw new IllegalArgumentException("Publication.load - 'name' can not be null");
		}
		final Object entity = this.getHibernateTemplate().get(PublicationImpl.class, name);
		return transformEntity(transform, (Publication) entity);
	}
	
	public Collection loadAllByUser(User user)
	{
		return loadAllByUser(TRANSFORM_NONE, user);
	}

	/**
	 * @see PublicationDao#load(String)
	 */
	public Publication loadByName(String name) 
	{
		return (Publication) this.loadByName(TRANSFORM_NONE, name);
	}

	/**
	 * @see PublicationDao#loadAll(int)
	 */
	public Collection loadAll(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(PublicationImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	/**
	 * @see PublicationDao#loadAllActive(int)
	 */
	public Collection loadAllActive(final int transform) 
	{
		final Collection results = this.getHibernateTemplate().loadAll(PublicationImpl.class);
		this.transformEntities(transform, results);
		return results;
	}
	
	/**
	 * @see UserDao#create(User)
	 */
	public Publication create(Publication publication) 
	{
		return (Publication) this.create(TRANSFORM_NONE, publication);
	}

	/**
	 * @see UserDao#create(int transform,
	 *      User)
	 */
	public Object create(final int transform,	final Publication publication) 
	{
		if (publication == null) 
		{
			throw new IllegalArgumentException("Publication.create - 'publication' can not be null");
		}
		this.getHibernateTemplate().save(publication);
		return this.transformEntity(transform, publication);
	}

	/**
	 * @see UserDao#create(Collection)
	 */
	public Collection create(final Collection entities) 
	{
		return create(TRANSFORM_NONE, entities);
	}

	/**
	 * @see UserDao#create(int,
	 *      Collection)
	 */
	public Collection create(final int transform, final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Publication.create - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() 
				{
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							create(transform,(Publication) entityIterator.next());
						}
						return null;
					}
				}, true);
		return entities;
	}


	/**
	 * @see UserDao#update(User)
	 */
	public void update(Publication publication) 
	{
		if (publication == null) 
		{
			throw new IllegalArgumentException("Publication.update - 'publication' can not be null");
		}
		this.getHibernateTemplate().update(publication);
	}

	/**
	 * @see UserDao#update(Collection)
	 */
	public void update(final Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Publication.update - 'entities' can not be null");
		}
		this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) throws HibernateException 
					{
						for (Iterator entityIterator = entities.iterator(); entityIterator.hasNext();) 
						{
							update((Publication) entityIterator.next());
						}
						return null;
					}
				}, true);
	}

	/**
	 * @see UserDao#remove(User)
	 */
	public void remove(Publication publication) 
	{
		if (publication == null) 
		{
			throw new IllegalArgumentException("Publication.remove - 'publication' can not be null");
		}
		this.getHibernateTemplate().delete(publication);
	}

	/**
	 * @see UserDao#remove(String)
	 */
	public void remove(Integer id) 
	{
		if (id == null) 
		{
			throw new IllegalArgumentException("Publication.remove - 'id' can not be null");
		}
		Publication entity = this.load(id);
		if (entity != null) 
		{
			this.remove(entity);
		}
	}

	/**
	 * @see UserDao#remove(Collection)
	 */
	public void remove(Collection entities) 
	{
		if (entities == null) 
		{
			throw new IllegalArgumentException("Publication.remove - 'entities' can not be null");
		}
		this.getHibernateTemplate().deleteAll(entities);
	}

	/**
	 * Allows transformation of entities into value objects (or something else
	 * for that matter), when the <code>transform</code> flag is set to one of
	 * the constants defined in
	 * <code>UserDao</code>, please note
	 * that the {@link #TRANSFORM_NONE} constant denotes no transformation, so
	 * the entity itself will be returned.
	 * <p/>
	 * This method will return instances of these types:
	 * <ul>
	 * <li>{@link User} -
	 * {@link #TRANSFORM_NONE}</li>
	 * <li>{@link com.ht.syndication.htsportal.transfer.UserVO} -
	 * {@link TRANSFORM_USERVO}</li>
	 * </ul>
	 * 
	 * If the integer argument value is unknown {@link #TRANSFORM_NONE} is
	 * assumed.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            {@link UserDao}
	 * @param entity
	 *            an entity that was found
	 * @return the transformed entity (i.e. new value object, etc)
	 * @see #transformEntities(int,Collection)
	 */
	protected Object transformEntity(final int transform, final Publication entity) 
	{
		Object target = null;
		if (entity != null) 
		{
			switch (transform) 
			{
			    case TRANSFORM_PUBLISHERVO	:  	target = toPublicationVO(entity);
				break;
				
			    case TRANSFORM_PUBLISHER_SHORTVO	:  	target = toPublicationShortVO(entity);
				break;
			    
			    case TRANSFORM_NONE			: 
			    default						:	target = entity;
			}
		}
		return target;
	}

	/**
	 * Transforms a collection of entities using the
	 * {@link #transformEntity(int,User)}
	 * method. This method does not instantiate a new collection.
	 * <p/>
	 * This method is to be used internally only.
	 * 
	 * @param transform
	 *            one of the constants declared in
	 *            <code>UserDao</code>
	 * @param entities
	 *            the collection of entities to transform
	 * @see #transformEntity(int,User)
	 */
	protected void transformEntities(final int transform, final Collection entities) 
	{
		switch (transform) 
		{
    		case TRANSFORM_PUBLISHERVO	:	toPublicationVOCollection(entities);
    		break;
    		case TRANSFORM_PUBLISHER_SHORTVO	:	toPublicationShortVOCollection(entities);
    		break;
    		case TRANSFORM_NONE			: 
    		default						:
		}
	}

	/**
	 * @see UserDao#toUserVOCollection(Collection)
	 */
	public final void toPublicationVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities,PUBLICATIONVO_TRANSFORMER);
		}
	}
	
	public final void toPublicationShortVOCollection(Collection entities) 
	{
		if (entities != null) 
		{
			CollectionUtils.transform(entities,PUBLICATIONSHORTVO_TRANSFORMER);
		}
	}

	/**
	 * Default implementation for transforming the results of a report query
	 * into a value object. This implementation exists for convenience reasons
	 * only. It needs only be overridden in the {@link UserDaoImpl} class if you
	 * intend to use reporting queries.
	 * 
	 * @see UserDao#toUserVO(User)
	 */
	protected PublicationVO toPublicationVO(Object[] row) 
	{
		PublicationVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Publication) 
				{
					target = this
							.toPublicationVO((Publication) object);
					break;
				}
			}
		}
		return target;
	}
	
	protected PublicationShortVO toPublicationShortVO(Object[] row) 
	{
		PublicationShortVO target = null;
		if (row != null) 
		{
			final int numberOfObjects = row.length;
			for (int ctr = 0; ctr < numberOfObjects; ctr++) 
			{
				final Object object = row[ctr];
				if (object instanceof Publication) 
				{
					target = this.toPublicationShortVO((Publication) object);
					break;
				}
			}
		}
		return target;
	}

	private Transformer PUBLICATIONVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Publication) 
    			{
    				result = toPublicationVO((Publication) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toPublicationVO((Object[]) input);
    			}
    			return result;
    		}
    	};
    	
    private Transformer PUBLICATIONSHORTVO_TRANSFORMER = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			Object result = null;
    			if (input instanceof Publication) 
    			{
    				result = toPublicationShortVO((Publication) input);
    			} 
    			else if (input instanceof Object[]) 
    			{
    				result = toPublicationShortVO((Object[]) input);
    			}
    			return result;
    		}
    	};

	/**
	 * @see UserDao#userVOToEntityCollection(Collection)
	 */
	public final void publicationVOToEntityCollection(Collection instances) 
	{
		if (instances != null) 
		{
			for (final Iterator iterator = instances.iterator(); iterator.hasNext();) 
			{
				if (!(iterator.next() instanceof PublicationVO)) 
				{
					iterator.remove();
				}
			}
			CollectionUtils.transform(instances,PublicationVOToEntityTransformer);
		}
	}

	private final Transformer PublicationVOToEntityTransformer = new Transformer() 
    	{
    		public Object transform(Object input) 
    		{
    			return publicationVOToEntity((PublicationVO) input);
    		}
    	};

	public void toPublicationVO(Publication source, PublicationVO target) 
	{
		target.setId(source.getId());
		target.setShortname(source.getShortname());
		target.setName(source.getName());
		target.setDetails(source.getDetails());
		target.setWeburl(source.getWeburl());
		target.setEmail(source.getEmail());
		target.setAddress(source.getAddress());
		target.setPhone(source.getPhone());
		target.setFax(source.getFax());
		target.setContactperson1(source.getContactperson1());
		target.setContactperson2(source.getContactperson2());
		target.setContactperson3(source.getContactperson3());
		target.setOtherinfo(source.getOtherinfo());
		target.setStatus(source.getStatus());
		if(source.getOwner() != null)
		{
			target.setOwner(source.getOwner().getUsername());
		}
		if(source.getExclusive() == 1)
		{
			target.setExclusive(Boolean.TRUE.toString());
		}
		else
		{
			target.setExclusive(Boolean.FALSE.toString());
		}
		if(source.getNewsTicker() == 1)
		{
			target.setNewsTicker(Boolean.TRUE.toString());
		}
		else
		{
			target.setNewsTicker(Boolean.FALSE.toString());
		}
	}
    	
	public void toPublicationShortVO(Publication source, PublicationShortVO target) 
	{
		target.setId(source.getId());
		target.setShortname(source.getShortname());
		target.setName(source.getName());
		target.setStatus(source.getStatus());
	}

	/**
	 * @see UserDao#toUserVO(User)
	 */
	public PublicationVO toPublicationVO(final Publication entity) 
	{
		final PublicationVO target = new PublicationVO();
		this.toPublicationVO(entity, target);
		return target;
	}
	
	public PublicationShortVO toPublicationShortVO(final Publication entity) 
	{
		final PublicationShortVO target = new PublicationShortVO();
		this.toPublicationShortVO(entity, target);
		return target;
	}
	

	/**
	 * @see UserDao#userVOToEntity(com.ht.syndication.htsportal.transfer.UserVO,
	 *      User)
	 */
	public void publicationVOToEntity(PublicationVO source, Publication target, boolean copyIfNull) 
	{
		if (copyIfNull || source.getId() != null) 
		{
			target.setId(source.getId());
		}
        if (copyIfNull || source.getShortname() != null) 
        {
            target.setShortname(source.getShortname());
        }
		if (copyIfNull || source.getName() != null) 
		{
			if(!source.getName().equals(target.getName()))
			{
				this.changeStatusForIndex(target);
			}
			target.setName(source.getName());
		}
		if (copyIfNull || source.getDetails() != null) 
		{
			target.setDetails(source.getDetails());
		}
		if (copyIfNull || source.getWeburl() != null) 
		{
			target.setWeburl(source.getWeburl());
		}
		if (copyIfNull || source.getEmail() != null) 
		{
			target.setEmail(source.getEmail());
		}
		if (copyIfNull || source.getAddress() != null) 
		{
			target.setAddress(source.getAddress());
		}
		if (copyIfNull || source.getPhone() != null) 
		{
			target.setPhone(source.getPhone());
		}
		if (copyIfNull || source.getFax() != null) 
		{
			target.setFax(source.getFax());
		}
        if (copyIfNull || source.getStatus() != null) 
        {
			if(source.getStatus().equals(AccessStatus.DISABLE) && !source.getStatus().equals(target.getStatus()))
			{
				this.changeStatusForIndex(target);
			}
            target.setStatus(source.getStatus());

        }
        if (copyIfNull || source.getExclusive() != null) 
        {
        	if(Boolean.parseBoolean(source.getExclusive()))
			{
				target.setExclusive(Short.parseShort("1"));
			}
			else
			{
				target.setExclusive(Short.parseShort("0"));
			}
			this.changeStatusForIndex(target);
        	
        }

        if (copyIfNull || source.getNewsTicker() != null) 
        {
			if(Boolean.parseBoolean(source.getNewsTicker()))
			{
				target.setNewsTicker(Short.parseShort("1"));
			}
			else
			{
				target.setNewsTicker(Short.parseShort("0"));
			}
        }

		if (copyIfNull || source.getContactperson1() != null) 
		{
			target.setContactperson1(source.getContactperson1());
		}
		if (copyIfNull || source.getContactperson2() != null) 
		{
			target.setContactperson2(source.getContactperson2());
		}
		if (copyIfNull || source.getContactperson3() != null) 
		{
			target.setContactperson3(source.getContactperson3());
		}
		if (copyIfNull || source.getOtherinfo() != null) 
		{
			target.setOtherinfo(source.getOtherinfo());
		}
	}
	
	/**
	 * 
	 * @param publication
	 */
	private void changeStatusForIndex(Publication publication)
	{
		if(publication.getId() != null)
		{
			for(Content content:publication.getContent())
			{
				if(content.getIndexdate() != null)
				{
					content.setIndexdate(null);
				}
			}
		}
	}

}