package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;
import java.util.List;

/**
 * 
 */
public class ClientVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5953736217389422960L;

	public ClientVO() 
	{
		this.id = null;
		this.name = null;
		this.details = null;
		this.type = null;
		this.status = null;
		this.revenueinterval = null;
	}

	public ClientVO(String name, String details, Short status, Short revenueinterval) 
	{
		super();
		this.name = name;
		this.details = details;
		this.status = status;
		this.revenueinterval = revenueinterval;
	}
	
	public ClientVO(String name, String details, Short type, Short status, Short revenueinterval) 
	{
		this(name, details, status, revenueinterval);
		this.type = type;
	}
	
	public ClientVO(Integer id, String name, String details, Short revenueinterval) 
	{
		this(name, details, null, revenueinterval);
		this.id = id;
	}

	public ClientVO(Integer id, String name, String details, Short status, Short revenueinterval) 
	{
		this(name, details, status, revenueinterval);
		this.id = id;
	}
	
	public ClientVO(Integer id, String name, String details, Short type, Short status, Short revenueinterval) 
	{
		this(name, details, type, status, revenueinterval);
		this.id = id;
	}

	/**
	 * Copies constructor from other UserVO
	 * 
	 * @param otherBean
	 *            , cannot be <code>null</code>
	 * @throws NullPointerException
	 *             if the argument is <code>null</code>
	 */
	public ClientVO(ClientVO otherBean) 
	{
		this(otherBean.id, otherBean.name, otherBean.details, otherBean.type, otherBean.status, otherBean.revenueinterval);
	}

	/**
	 * Copies all properties from the argument value object into this value
	 * object.
	 */
	public void copy(ClientVO otherBean) 
	{
		if (otherBean != null) 
		{
			this.setId(otherBean.getId());
			this.setName(otherBean.getName());
			this.setDetails(otherBean.getDetails());
			this.setType(otherBean.getType());
			this.setStatus(otherBean.getStatus());
		}
	}

	private Integer id;
	private String name;
	private String details;
	private Short type;
	private Short status;
	private Short revenueinterval;
	private List<String>publications;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}
	
	public Short getRevenueinterval() {
		return revenueinterval;
	}

	public void setRevenueinterval(Short revenueinterval) {
		this.revenueinterval = revenueinterval;
	}

	public List<String> getPublications() {
		return publications;
	}

	public void setPublications(List<String> publications) {
		this.publications = publications;
	}
}