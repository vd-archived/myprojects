package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 */
public class RevenueVO implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 8035894048518868650L;

	public RevenueVO() 
	{
		this.id = null;
		this.publication = null;
		this.client = null;
		this.date = null;
		this.amount = null;
		this.status = null;
	}

	public RevenueVO(String publication, String client, Date date, Double amount, Short status) 
	{
		super();
		this.publication = publication;
		this.client = client;
		this.date = date;
		this.amount = amount;
		this.status = status;
	}
	
	public RevenueVO(Integer id, String publication, String client, Date date, Double amount, Short status) 
	{
		this(publication, client, date, amount, status);
		this.id = id;
	}
	
	public RevenueVO(RevenueVO otherBean) 
	{
		this(otherBean.id, otherBean.publication, otherBean.client, otherBean.date, otherBean.amount, otherBean.status);
	}

	/**
	 * Copies all properties from the argument value object into this value
	 * object.
	 */
	public void copy(RevenueVO otherBean) 
	{
		if (otherBean != null) 
		{
			this.setId(otherBean.getId());
			this.setPublication(otherBean.getPublication());
			this.setClient(otherBean.getClient());
			this.setDate(otherBean.getDate());
			this.setAmount(otherBean.getAmount());
			this.setStatus(otherBean.getStatus());
		}
	}

	private Integer id;
	private String publication;
	private String client;
	private Date date;
	private Double amount;
	private Short status;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPublication() {
		return publication;
	}

	public void setPublication(String publication) {
		this.publication = publication;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}
}