package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.ht.syndication.htsportal.util.ListObject;

/**
 * 
 */
public class ClientRevenuesVO extends ClientVO implements Serializable{

	public ClientRevenuesVO()
	{
		super();
	}
	
	public ClientRevenuesVO(ClientVO otherBean)
	{
		super(otherBean);
		this.revenues = new ArrayList<ListObject>();
	}
	
	private List<ListObject> revenues;
	private Double revenue;

	public Double getRevenue() {
		this.revenue = 0.0;
		for(ListObject keyVal: getRevenues())
		{
			this.revenue += (Double)keyVal.getValue();
		}
		return this.revenue;
	}

	public List<ListObject> getRevenues() {
		return revenues;
	}

	public void setRevenues(List<ListObject> revenues) {
		this.revenues = revenues;
	}
	
	public void addRevenue(ListObject revenue) {
		this.revenues.add(revenue);
	}
	
	public void addRevenue(Object date, Object ammount) {
		this.addRevenue(ListObject.Factory.newInstance(date, ammount));
	}
}