package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * 
 */
public class SubscriptionVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1478426321382239920L;

	public SubscriptionVO() 
	{
		this(null, null, null, null, null, null, null, null, null, null, null);
	}
	
	public SubscriptionVO(Integer articlecount, String reproduced, String publicationname, Integer publicationcirculation, String otherdetails, String companyname, String address, String email, String phone, String country, String message) {
		super();
		this.articlecount = articlecount;
		this.reproduced = reproduced;
		this.publicationname = publicationname;
		this.publicationcirculation = publicationcirculation;
		this.otherdetails = otherdetails;
		this.companyname = companyname;
		this.address = address;
		this.email = email;
		this.phone = phone;
		this.country = country;
		this.message = message;
		this.createdate = Calendar.getInstance().getTime();
	}

	/**
	 * Copies constructor from other SubscriptionVO
	 * 
	 * @param otherBean
	 *            , cannot be <code>null</code>
	 * @throws NullPointerException
	 *             if the argument is <code>null</code>
	 */

	public SubscriptionVO(SubscriptionVO otherBean) 
	{
		this.id = otherBean.getId();
		this.articlecount = otherBean.getArticlecount();
		this.reproduced = otherBean.getReproduced();
		this.publicationname = otherBean.getPublicationname();
		this.publicationcirculation = otherBean.getPublicationcirculation();
		this.otherdetails = otherBean.getOtherdetails();
		this.companyname = otherBean.getCompanyname();
		this.address = otherBean.getAddress();
		this.email = otherBean.getEmail();
		this.phone = otherBean.getPhone();
		this.country = otherBean.getCountry();
		this.message = otherBean.getMessage();
		this.emailto = otherBean.getEmailto();
		this.cc = otherBean.getCc();
		this.bcc = otherBean.getBcc();
		this.emailsubject = otherBean.getEmailsubject();
		this.status = otherBean.getStatus();
		this.createdate = otherBean.getCreatedate();
	}

	/**
	 * Copies all properties from the argument value object into this value
	 * object.
	 */
	public void copy(SubscriptionVO otherBean) 
	{
		if (otherBean != null) 
		{
			this.id = otherBean.getId();
			this.articlecount = otherBean.getArticlecount();
			this.reproduced = otherBean.getReproduced();
			this.publicationname = otherBean.getPublicationname();
			this.publicationcirculation = otherBean.getPublicationcirculation();
			this.otherdetails = otherBean.getOtherdetails();
			this.companyname = otherBean.getCompanyname();
			this.address = otherBean.getAddress();
			this.email = otherBean.getEmail();
			this.phone = otherBean.getPhone();
			this.country = otherBean.getCountry();
			this.message = otherBean.getMessage();
			this.emailto = otherBean.getEmailto();
			this.cc = otherBean.getCc();
			this.bcc = otherBean.getBcc();
			this.emailsubject = otherBean.getEmailsubject();
			this.status = otherBean.getStatus();
			this.createdate = otherBean.getCreatedate();
		}
	}
	
	private Integer id;
	private Integer articlecount;
	private String reproduced;
	private String publicationname;
	private Integer publicationcirculation;
	private String otherdetails;
	private String companyname;
	private String address;
	private String email;
	private String phone;
	private String country;
	private String message;
	private String emailto;
	private String cc;
	private String bcc;
	private String emailsubject;
	private Short status;
	private Date createdate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getArticlecount() {
		return articlecount;
	}

	public void setArticlecount(Integer articlecount) {
		this.articlecount = articlecount;
	}

	public String getReproduced() {
		return reproduced;
	}

	public void setReproduced(String reproduced) {
		this.reproduced = reproduced;
	}

	public String getPublicationname() {
		return publicationname;
	}

	public void setPublicationname(String publicationname) {
		this.publicationname = publicationname;
	}

	public Integer getPublicationcirculation() {
		return publicationcirculation;
	}

	public void setPublicationcirculation(Integer publicationcirculation) {
		this.publicationcirculation = publicationcirculation;
	}

	public String getOtherdetails() {
		return otherdetails;
	}

	public void setOtherdetails(String otherdetails) {
		this.otherdetails = otherdetails;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getEmailto() {
		return emailto;
	}

	public void setEmailto(String emailto) {
		this.emailto = emailto;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) {
		this.bcc = bcc;
	}

	public String getEmailsubject() {
		return emailsubject;
	}

	public void setEmailsubject(String emailsubject) {
		this.emailsubject = emailsubject;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
}