package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;

/**
 * 
 */
public class CategoryVO implements Serializable {
	/**
     * 
     */
    private static final long serialVersionUID = 4043201796291958681L;

    /**
	 * The serial version UID of this class. Needed for serialization.
	 */

	public CategoryVO() 
	{
		this.id = null;
		this.name = null;
		this.details = null;
		this.status = null;
	}

	public CategoryVO(String name, String details, Short status) 
	{
		super();
		this.name = name;
		this.details = details;
		this.status = status;
	}
	
	public CategoryVO(Integer id, String name, String details) 
	{
		super();
		this.id = id;
		this.name = name;
		this.details = details;
	}

	public CategoryVO(Integer id, String name, String details, Short status) 
	{
		this.id = id;
		this.name = name;
		this.details = details;
		this.status = status;
	}

	/**
	 * Copies constructor from other UserVO
	 * 
	 * @param otherBean
	 *            , cannot be <code>null</code>
	 * @throws NullPointerException
	 *             if the argument is <code>null</code>
	 */
	public CategoryVO(CategoryVO otherBean) 
	{
		this(otherBean.id, otherBean.name, otherBean.details, otherBean.status);
	}

	/**
	 * Copies all properties from the argument value object into this value
	 * object.
	 */
	public void copy(CategoryVO otherBean) 
	{
		if (otherBean != null) 
		{
			this.setId(otherBean.getId());
			this.setName(otherBean.getName());
			this.setDetails(otherBean.getDetails());
			this.setStatus(otherBean.getStatus());
		}
	}

	private Integer id;

	/**
	 * @return the id
	 */
	public Integer getId() 
	{
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}

	   private String name;
	/**
	 * @return the name
	 */
	public String getName() 
	{
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) 
	{
		this.name = name;
	}
	
    private String details;
	/**
	 * @return the details
	 */
	public String getDetails() 
	{
		return details;
	}

	/**
	 * @param details
	 *            the details to set
	 */
	public void setDetails(String details) 
	{
		this.details = details;
	}

	private Short status;
	/**
	 * @return the status
	 */
	public Short getStatus() 
	{
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(Short status) 
	{
		this.status = status;
	}
	
    private String message;
    /**
     * 
     * @return
     */
    public String getMessage() 
    {
        return message;
    }

    /**
     * 
     * @param message
     */
    public void setMessage(String message) 
    {
        this.message = message;
    }
    
    
    private String oldName;
    

    public String getOldName() {
		return oldName;
	}

	public void setOldName(String oldName) {
		this.oldName = oldName;
	}

	
}