package com.ht.syndication.htsportal.transfer;

import com.ht.syndication.htsportal.util.Utility;


public class OldImageVO {

	private String imageName;
	private String category;

	public OldImageVO(String imageName) 
	{
	    super();
	    this.imageName =  imageName;
	}
	
   public OldImageVO(String imageName, String imageCaption) 
   {
	        this(imageName);
	        this.imageCaption = imageCaption;
   }
   
   public OldImageVO(String imageName, String imageCaption, String category) 
	{
		this(imageName, imageCaption);
		this.category = category;
	}

	public String getImageName() 
	{
		return imageName;
	}

	public void setImageName(String imageName) 
	{
		this.imageName = imageName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
   String imageCaption;

    public String getImageCaption() 
    {
        return imageCaption;
    }

    public void setImageCaption(String imageCaption) 
    {
        this.imageCaption = imageCaption;
    }

	public String getEncodedImageName() {
		return Utility.forcefullyURLEncoded(this.getImageName());
	}
}
