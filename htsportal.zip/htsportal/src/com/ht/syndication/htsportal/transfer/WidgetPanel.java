package com.ht.syndication.htsportal.transfer;

import java.util.ArrayList;
import java.util.List;

public class WidgetPanel implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 356355212889989103L;

	private Integer uniequeID = null;
	private String headline = null;
	private List<PublicationTab>publicationTabs = new ArrayList<PublicationTab>();
	
	public Integer getUniequeID() {
		if(uniequeID == null) {
			return headline.hashCode();
		}
		else {
			return uniequeID;
		}
	}
	public void setUniequeID(Integer uniequeID) {
		this.uniequeID = uniequeID;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public List<PublicationTab> getPublicationTabs() {
		return publicationTabs;
	}
	public void setPublicationTabs(List<PublicationTab> publicationTabs) {
		this.publicationTabs = publicationTabs;
	}
}