package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;

import com.ht.syndication.htsportal.domain.AccessStatus;

/**
 * 
 */
public class ImagecategoryVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4505621781832278953L;

	public ImagecategoryVO() 
	{
		this.id = null;
		this.name = null;
		this.details = null;
		this.status = null;
	}

	public ImagecategoryVO(String name, String details, Short status) 
	{
		super();
		this.name = name;
		this.details = details;
		this.status = status;
	}
	
	public ImagecategoryVO(Integer id, String name, String details) 
	{
		super();
		this.id = id;
		this.name = name;
		this.details = details;
	}

	public ImagecategoryVO(Integer id, String name, String details, Short status) 
	{
		this.id = id;
		this.name = name;
		this.details = details;
		this.status = status;
	}
	
	public ImagecategoryVO(Integer id, String name, String details, Short status, Short highlight, Integer priority) 
	{
		this.id = id;
		this.name = name;
		this.details = details;
		this.status = status;
		this.highlight = highlight;
		this.priority = priority;
	}

	/**
	 * Copies constructor from other UserVO
	 * 
	 * @param otherBean
	 *            , cannot be <code>null</code>
	 * @throws NullPointerException
	 *             if the argument is <code>null</code>
	 */
	public ImagecategoryVO(ImagecategoryVO otherBean) 
	{
		this(otherBean.id, otherBean.name, otherBean.details, otherBean.status, otherBean.highlight, otherBean.priority);
	}

	/**
	 * Copies all properties from the argument value object into this value
	 * object.
	 */
	public void copy(ImagecategoryVO otherBean) 
	{
		if (otherBean != null) 
		{
			this.setId(otherBean.getId());
			this.setName(otherBean.getName());
			this.setDetails(otherBean.getDetails());
			this.setStatus(otherBean.getStatus());
			this.setHighlight(otherBean.getHighlight());
			this.setPriority(otherBean.getPriority());
		}
	}

	private Integer id;

	/**
	 * @return the id
	 */
	public Integer getId() 
	{
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}

	   private String name;
	/**
	 * @return the name
	 */
	public String getName() 
	{
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) 
	{
		this.name = name;
	}
	
    private String details;
	/**
	 * @return the details
	 */
	public String getDetails() 
	{
		return details;
	}

	/**
	 * @param details
	 *            the details to set
	 */
	public void setDetails(String details) 
	{
		this.details = details;
	}

	private Short status;
	/**
	 * @return the status
	 */
	public Short getStatus() 
	{
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(Short status) 
	{
		this.status = status;
	}
	
    private String message;
    /**
     * 
     * @return
     */
    public String getMessage() 
    {
        return message;
    }

    /**
     * 
     * @param message
     */
    public void setMessage(String message) 
    {
        this.message = message;
    }
    
    
    private String oldName;
    

    public String getOldName() {
		return oldName;
	}

	public void setOldName(String oldName) {
		this.oldName = oldName;
	}

	private Short highlight;
	
	public Short getHighlight() {
		return highlight;
	}

	public void setHighlight(Short highlight) {
		this.highlight = highlight;
	}

	private Integer priority;
	
	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	
	public String getHighlightStatusInString()
	{
		if(this.highlight==AccessStatus.ENABLE)
			return "true";
		else
			return "false";
	}
}