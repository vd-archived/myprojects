package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * 
 */
public class UsermessageVO implements Serializable {
	/**
     * 
     */
	private static final long serialVersionUID = -7114340933378729279L;

	/**
	 * The serial version UID of this class. Needed for serialization.
	 */

	public UsermessageVO() 
	{
		this.id = null;
		this.email = null;
		this.firstname = null;
		this.lastname = null;
		this.organisationName = null;
		this.message = null;
		this.contactno = null;
		this.status = null;
		this.createdate = null;
		this.to = null;
		this.cc = null;
		this.bcc = null;
		this.subject = null;
	}

	public UsermessageVO(String email, String firstname, String lastname, String organisationName, String message, String contactno, Short status) 
	{
		super();
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
		this.organisationName = organisationName;
		this.message = message;
		this.contactno = contactno;
		this.contactno = contactno;
		this.status = status;
		this.createdate = Calendar.getInstance().getTime();
	}

	/**
	 * Copies constructor from other UserVO
	 * 
	 * @param otherBean
	 *            , cannot be <code>null</code>
	 * @throws NullPointerException
	 *             if the argument is <code>null</code>
	 */

	public UsermessageVO(UsermessageVO otherBean) 
	{
		this.id = otherBean.getId();
		this.email = otherBean.getEmail();
		this.firstname = otherBean.getFirstname();
		this.lastname = otherBean.getLastname();
		this.organisationName = otherBean.getOrganisationName();
		this.message = otherBean.getMessage();
		this.contactno = otherBean.getContactno();
		this.status = otherBean.getStatus();
		this.createdate = otherBean.getCreatedate();
		this.to = otherBean.getTo();
		this.cc = otherBean.getCc();
		this.bcc = otherBean.getBcc();
		this.subject = otherBean.getSubject();
		this.comments = otherBean.getComments();
	}

	/**
	 * Copies all properties from the argument value object into this value
	 * object.
	 */
	public void copy(UsermessageVO otherBean) 
	{
		if (otherBean != null) 
		{
			this.id = otherBean.getId();
			this.email = otherBean.getEmail();
			this.firstname = otherBean.getFirstname();
			this.lastname = otherBean.getLastname();
			this.organisationName = otherBean.getOrganisationName();
			this.message = otherBean.getMessage();
			this.message = otherBean.getContactno();
			this.status = otherBean.getStatus();
			this.createdate = otherBean.getCreatedate();
			this.to = otherBean.getTo();
			this.cc = otherBean.getCc();
			this.bcc = otherBean.getBcc();
			this.subject = otherBean.getSubject();
			this.comments = otherBean.getComments();
		}
	}
	
	private Integer id;
	private String email;
	private String firstname;
	private String lastname;
	private String organisationName;
	private String message;
	private String contactno;
	private Short status;
	private Date createdate;
	private String to;
	private String cc;
	private String bcc;
	private String subject;
	private String comments;
	

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the firstname
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @param firstname the firstname to set
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the contact no
	 */
	public String getContactno() {
		return contactno;
	}

	/**
	 * @param set contact no
	 */
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	/**
	 * @return the status
	 */
	public Short getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Short status) {
		this.status = status;
	}

	/**
	 * @return the createdate
	 */
	public Date getCreatedate() {
		return createdate;
	}

	/**
	 * @param createdate the createdate to set
	 */
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	/**
	 * @return the to
	 */
	public String getTo() {
		return to;
	}

	/**
	 * @param to the to to set
	 */
	public void setTo(String to) {
		this.to = to;
	}

	/**
	 * @return the cc
	 */
	public String getCc() {
		return cc;
	}

	/**
	 * @param cc the cc to set
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}

	/**
	 * @return the bcc
	 */
	public String getBcc() {
		return bcc;
	}

	/**
	 * @param bcc the bcc to set
	 */
	public void setBcc(String bcc) {
		this.bcc = bcc;
	}

	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}
	
	
}