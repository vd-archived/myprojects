package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 */
public class ImageWidgetVO extends ImagecategoryVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7266351272544111597L;

	private List<ImageVO>images = new ArrayList<ImageVO>();

	public List<ImageVO> getImages() {
		return images;
	}

	public void setImages(List<ImageVO> images) {
		this.images = images;
	}
}