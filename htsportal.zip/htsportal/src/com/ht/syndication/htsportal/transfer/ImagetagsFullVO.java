package com.ht.syndication.htsportal.transfer;

import java.util.ArrayList;
import java.util.List;

public class ImagetagsFullVO extends ImagetagsVO
{
	public ImagetagsFullVO()
	{
		super();
	}

	public ImagetagsFullVO(String name, String details, Integer weight, Short type, Short status)
	{
		super(name, details, weight, type, status, null);
	}

	public ImagetagsFullVO(Integer id, String name, String details, Integer weight, Short type, Short status)
	{
		super(id, name, details, weight, type, status, null);
	}

	public ImagetagsFullVO(Integer id, String name, String details, Integer weight, Short type, Short status, Integer level) {
		super(id, name, details, weight, type, status, null, level);
	}

	public ImagetagsFullVO(Integer id, String name, String details, Integer weight, Short type, Short status, ImagetagsFullVO parentVO, List<ImagetagsFullVO> childs) {
		super(id, name, details, weight, type, status, parentVO.getId());
		this.parentVO = parentVO;
		this.childs = childs;
	}
	
	public ImagetagsFullVO(Integer id, String name, String details, Integer weight, Short type, Short status, List<ImagetagsFullVO> childs) {
		super(id, name, details, weight, type, status, null);
		this.childs = childs;
	}
	
	public ImagetagsFullVO(Integer id, String name, String details, Integer weight, Short type, Short status, ImagetagsFullVO parentVO) {
		super(id, name, details, weight, type, status, parentVO.getId());
		this.parentVO = parentVO;
	}

	private ImagetagsFullVO parentVO = null;
	private List<ImagetagsFullVO> childs = new ArrayList<ImagetagsFullVO>();
	public ImagetagsFullVO getParentVO() {
		return parentVO;
	}

	public void setParentVO(ImagetagsFullVO parentVO) {
		this.parentVO = parentVO;
	}

	public List<ImagetagsFullVO> getChilds() {
		return childs;
	}

	public void setChilds(List<ImagetagsFullVO> childs) {
		this.childs = childs;
	}
}
