package com.ht.syndication.htsportal.transfer;



public class ImagetagsVO
{
	public ImagetagsVO()
	{
		super();
	}
	
	public ImagetagsVO(Integer id, String name)
	{
		this();
		this.id = id;
		this.name = name;
	}
	
	public ImagetagsVO(String name, String details, Integer weight, Short type, Short status, Integer parent)
	{
		this();
		this.name = name;
		this.details = details;
		this.weight = weight;
		this.type = type;
		this.status = status;
		this.parent = parent;
	}

	public ImagetagsVO(Integer id, String name, String details, Integer weight, Short type, Short status, Integer parent)
	{
		this(name, details, weight, type, status, parent);
		this.setId(id);
	}

	public ImagetagsVO(Integer id, String name, String details, Integer weight, Short type, Short status, Integer parent, Integer level) {
		this(id, name, details, weight, type, status, parent);
		this.level = level;
	}

	private Integer id;
	private String name;
	private String details;
	private Integer weight;
	private Short type;
	private Short status;
	private Integer parent;
	private Integer level;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDetails() {
		return details;
	}
	
	public void setDetails(String details) {
		this.details = details;
	}
	
	public Integer getWeight() {
		return weight;
	}
	
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	
	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public Short getStatus() {
		return status;
	}
	
	public void setStatus(Short status) {
		this.status = status;
	}
	
	public Integer getParent() {
		return parent;
	}
	
	public void setParent(Integer parent) {
		this.parent = parent;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}
}
