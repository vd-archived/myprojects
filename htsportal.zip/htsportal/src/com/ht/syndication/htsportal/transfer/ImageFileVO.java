package com.ht.syndication.htsportal.transfer;


public class ImageFileVO {

	private String imageName;
	private String imageType;
	private Integer imageLength;
	private byte[] imageBytes;
	private Boolean downloadable;
	
	public byte[] getImageBytes() {
		return imageBytes;
	}
	
	public void setImageBytes(byte[] imageBytes) {
		this.imageBytes = imageBytes;
	}
	
	public String getImageType() {
		return imageType;
	}
	
	public void setImageType(String imageType) {
		this.imageType = imageType;
	}
	
	public Integer getImageLength() {
		return imageLength;
	}
	
	public void setImageLength(Integer imageLength) {
		this.imageLength = imageLength;
	}
	
	public Boolean getDownloadable() {
		return downloadable;
	}
	
	public void setDownloadable(Boolean downloadable) {
		this.downloadable = downloadable;
	}
	
	public String getImageName() {
		return imageName;
	}
	
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	
	public ImageFileVO(String imageName, String imageType, byte[] imageBytes) {
		super();
		this.imageName = imageName;
		this.imageType = imageType;
		this.imageLength = imageBytes.length;
		this.imageBytes = imageBytes;
		this.downloadable = Boolean.FALSE;
	}
	
	public ImageFileVO(String imageName, String imageType, byte[] imageBytes, Boolean downloadable) {
		this(imageName, imageType, imageBytes);
		this.downloadable = downloadable;
	}
}