package com.ht.syndication.htsportal.transfer;

/**
 * 
 */
public class LoginVO
    implements java.io.Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 3957316214611291146L;

    public LoginVO()
    {
        this.user = null;
        this.message = null;
    }

    public LoginVO(com.ht.syndication.htsportal.transfer.UserVO user, java.lang.String message)
    {
        this.user = user;
        this.message = message;
    }

    /**
     * Copies constructor from other LoginVO
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws java.lang.NullPointerException if the argument is <code>null</code>
     */
    public LoginVO(LoginVO otherBean)
    {
        this(otherBean.getUser(), otherBean.getMessage());
    }

    /**
     * Copies all properties from the argument value object into this value object.
     */
    public void copy(LoginVO otherBean)
    {
        if (otherBean != null)
        {
            this.setUser(otherBean.getUser());
            this.setMessage(otherBean.getMessage());
        }
    }

    private java.lang.String message;

    /**
     * 
     * @return
     */
	public java.lang.String getMessage() {
		return message;
	}

	public void setMessage(java.lang.String message) {
		this.message = message;
	}
    
	private com.ht.syndication.htsportal.transfer.UserVO user;


	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
    
    

}