package com.ht.syndication.htsportal.transfer;

import java.util.ArrayList;
import java.util.List;

public class PublicationTab extends PublicationShortVO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6361594105267187834L;
	private List<ArticleVO>articles = new ArrayList<ArticleVO>();
	
	public PublicationTab() {
		super();
	}
	
	public List<ArticleVO> getArticles() {
		return articles;
	}
	
	public void setArticles(List<ArticleVO> articles) {
		this.articles = articles;
	}
}