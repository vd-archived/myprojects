package com.ht.syndication.htsportal.transfer;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * 
 */
public class PublicationcountVO extends PublicationShortVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8294263874729061127L;

	public PublicationcountVO() {
		super();
	}
	
	private Date date;
	private BigInteger transmit;
	
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public BigInteger getTransmit() {
		return transmit;
	}
	
	public void setTransmit(BigInteger transmit) {
		this.transmit = transmit;
	}
	
}