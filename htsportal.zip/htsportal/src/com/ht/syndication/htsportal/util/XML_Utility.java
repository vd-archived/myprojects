package com.ht.syndication.htsportal.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;

import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.JDOMException;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;


public class XML_Utility {
	
	private static final Log LOGGER = LogFactory.getLog(XML_Utility.class);
	
	private StringBuffer errorString = null;
	private StringBuffer xmlSrc = null;
	private StringBuffer pageUrl = null;
	private List<ListObject> xsltParameters = null;
	
    
    public XML_Utility() {
    	errorString = new StringBuffer();
    	xmlSrc = new StringBuffer();
    	pageUrl = new StringBuffer();
    	xsltParameters = new ArrayList<ListObject>();
    }
    
    public XML_Utility(String inputXML) {
    	errorString = new StringBuffer();
    	xmlSrc = new StringBuffer();
    	pageUrl = new StringBuffer();
    	setRequestURL(inputXML);
    	xsltParameters = new ArrayList<ListObject>();
    }
    
    public StringBuffer getXMLSrc()
    {
    	return xmlSrc;
    }
    
    public void addXsltParameters(String name, String value)
    {
   		xsltParameters.add(ListObject.Factory.newInstance(name, value));
    }
    
    public void clearXsltParameters()
    {
    	 xsltParameters.clear();
    }
    
    public boolean setRequestURL(String inputXML){
    	xmlSrc = this.getContent(inputXML);
    	if(xmlSrc!=null)
    	{
    		xmlSrc = new StringBuffer(xmlSrc.toString().replaceAll("\r", "<br />"));
    	}
    	return true;
    }
    
    public boolean setForwardPageURL(StringBuffer pageUrl){
    	this.pageUrl = pageUrl;
    	return true;
    }
    
    public boolean setForwardPageURL(String pageUrl){
    	return setForwardPageURL(new StringBuffer(pageUrl));
    }
    
    public StringBuffer getErrorString(){
    	return errorString;
    }
    
    public StringBuffer transform(String inputXSLT){
    	return transformXMLUsingXSLT(xmlSrc, inputXSLT);
    }
    
    public boolean transformXML(String inputXML, String inputXSLT, String outputFile){
    	return transformXML(new File(inputXML), new File(inputXSLT), new File(outputFile));
    }
    
    public boolean transformXML(File inputXML, File inputXSLT, File outputFile){
    	if(!inputXML.exists()){
    		errorString.append("Input XML File Not Exists [Given Path="+inputXML.getAbsolutePath()+"]\n");
    		LOGGER.error("Input XML File Not Exists [Given Path="+inputXML.getAbsolutePath()+"]\n");
    	}
    	if(!inputXSLT.exists()){
    		errorString.append("Input XSLT File Not Exists [Given Path="+inputXSLT.getAbsolutePath()+"]\n");
    		LOGGER.error("Input XSLT File Not Exists [Given Path="+inputXSLT.getAbsolutePath()+"]\n");
    	}
    	if(!outputFile.exists()){
    		try {
			    outputFile.getParentFile().mkdirs();
			}catch (Exception e) {
				LOGGER.error(e.getLocalizedMessage()+"\n"+ e.getMessage());
			}
    	}
    	StringBuffer xmlSRC = this.getFileContent(inputXML);
    	if(errorString.length()>0){
    		LOGGER.error("Transformation Failed...");
			return false;
		}
    	xmlSRC = this.transformXMLUsingXSLT(xmlSRC, inputXSLT.getAbsolutePath());
    	if(errorString.length()>0){
    		LOGGER.error("Transformation Failed...");
			return false;
		}
		if(!writeFile(xmlSRC, outputFile)){
			LOGGER.error("Transformation Failed...");
			return false;
		}
		LOGGER.info("Transformation Completed Successfully");
    	return true;
    }
    
    public StringBuffer transformXML(File inputXML, File inputXSLT){
    	if(!inputXML.exists()){
    		LOGGER.error("Input XML File Not Exists [Given Path="+inputXML.getAbsolutePath()+"]\n");
    		errorString.append("Input XML File Not Exists [Given Path="+inputXML.getAbsolutePath()+"]\n");
    	}
    	if(!inputXSLT.exists()){
    		LOGGER.error("Input XSLT File Not Exists [Given Path="+inputXSLT.getAbsolutePath()+"]\n");
    		errorString.append("Input XSLT File Not Exists [Given Path="+inputXSLT.getAbsolutePath()+"]\n");
    	}
    	StringBuffer xmlSRC = this.getFileContent(inputXML);
    	if(errorString.length()>0){
    		LOGGER.error("Transformation Failed...");
			return null;
		}
    	xmlSRC = this.transformXMLUsingXSLT(xmlSRC, inputXSLT.getAbsolutePath());
    	if(errorString.length()>0){
    		LOGGER.error("Transformation Failed...");
			return null;
		}
    	LOGGER.info("Transformation Completed Successfully");
    	return xmlSRC;
    }
    
    private StringBuffer transformXMLUsingXSLT(StringBuffer xmlSrc, String xsltPath)
    {
        xmlSrc = new StringBuffer(xmlSrc.toString().replace("&", "&amp;"));
        java.io.InputStream input = new ByteArrayInputStream(xmlSrc.toString().getBytes());
        java.io.OutputStream output = null;
        try{
            output = new java.io.OutputStream(){
                private StringBuilder string = new StringBuilder();
//                @Override
                public void write(int b) throws IOException {
                    this.string.append((char)b);
                }
                public String toString(){
                    return this.string.toString();
                }
            };
            javax.xml.transform.TransformerFactory tFactory = javax.xml.transform.TransformerFactory.newInstance();
            javax.xml.transform.Transformer transformer = tFactory.newTransformer(new javax.xml.transform.stream.StreamSource(xsltPath));
            for(ListObject listObject: xsltParameters)
            {
            	if(listObject.getValue()!=null)
            	{
            		transformer.setParameter(listObject.getKey().toString(), listObject.getValue().toString());
            	}
            }
           	transformer.setParameter("pageUrl", pageUrl);
            transformer.transform(new javax.xml.transform.stream.StreamSource(input), new javax.xml.transform.stream.StreamResult(output));
        }catch(Exception e){
        	LOGGER.error(e.getLocalizedMessage()+"\n"+e.getMessage());
        	errorString.append(e.getLocalizedMessage()+"\n"+e.getMessage()+"\n");
        }
        return new StringBuffer(output.toString().replace("&amp;", "&"));
    }
    
    public StringBuffer getContent(String url) {
    	java.net.URL oracle = null;
        java.io.BufferedReader in = null;
        StringBuffer pageContent = new StringBuffer("");
    	try{
	        oracle = new java.net.URL(url);
	        in = new java.io.BufferedReader(new java.io.InputStreamReader(oracle.openStream()));
	        String inputLine = "";
	        while ((inputLine = in.readLine()) != null)
	            pageContent = pageContent.append(inputLine).append("\n");
	        in.close();
    	}catch(Exception e){
    		e.printStackTrace();
    		return null;
    	}finally{
    		try{
    			in.close();
    		}catch(Exception e){}
    	}
        return pageContent;
    }
    
    private StringBuffer getFileContent(File file)
    {
        StringBuffer fileContent = new StringBuffer();
        FileInputStream fis = null;
        try
        {
            fis = new FileInputStream(file);
            int ch;
            while((ch=fis.read())!=-1)
                fileContent.append((char)ch);
            fis.close();
        }catch(Exception e){
        	LOGGER.error(e.getLocalizedMessage()+"\n"+e.getMessage()+"\n");
        	errorString.append(e.getLocalizedMessage()+"\n"+e.getMessage()+"\n");
            return null;
        }finally
        {
            try
            {
                if(fis!=null)
                    fis.close();
            }catch(Exception e){/*e.printStackTrace();*/}
        }
        return fileContent;
    }
    
    public boolean writeFile(StringBuffer srcContent, File desFile){
        FileChannel desChannel = null;
        try{
            if(desFile.exists())
                desFile.delete();
            desChannel = new java.io.RandomAccessFile(desFile, "rw").getChannel();
            byte[] bytes = srcContent.toString().getBytes();   
            java.nio.MappedByteBuffer mbb = desChannel.map(FileChannel.MapMode.READ_WRITE,0, bytes.length);
            mbb.put(ByteBuffer.wrap(bytes));
            desChannel.close();
            return true;
        }catch(Exception e){
        	LOGGER.error(e.getLocalizedMessage()+"\n"+e.getMessage()+"\n");
        	errorString.append(e.getLocalizedMessage()+"\n"+e.getMessage()+"\n");
            return false;
        }finally {
            try{
                if(desChannel != null) {
                    desChannel.close();
                }
            }catch(Exception e){/*e.printStackTrace();*/}
        }
    }
    
    public ListObject getTypeNameDetails(String filePath, String childName, String name)
	{
    	if(name.startsWith("\""))
    	{
    		name = name.substring(1);
    	}
    	if(name.endsWith("\""))
    	{
    		name = name.substring(0, name.length()-1);
    	}
    	ListObject result = null;
		File xmlFile = new File(ServletActionContext.getServletContext().getRealPath(filePath));
		Document document = null;
		if(xmlFile.exists())
		{
			SAXBuilder builder = new SAXBuilder();
			try
			{
	            document = builder.build(xmlFile);
	            Element root = document.getRootElement();
	            List children = root.getChildren(childName);
	            int i = 0;
	            for (i = 0; i < children.size(); i++) {
	                Element row = (Element) children.get(i);
	                if(row.getChild("name").getText().equals(name))
	                {
	                	result = ListObject.Factory.newInstance(name, row.getChild("intro").getText());
	                	break;
	                }
	            }
	        } catch (JDOMException e) {
	        	LOGGER.error(e.getLocalizedMessage()+"\n"+e.getMessage());
	        } catch (IOException e) {
	        	LOGGER.error(e.getLocalizedMessage()+"\n"+e.getMessage());
	        }
		}
		return result;
	}
    
    public Boolean isInteger(String number)
    {
    	Boolean result = Boolean.FALSE;
    	try
    	{
    		Integer.parseInt(number);
    		result = Boolean.TRUE;
    	}
    	catch(Exception e)
    	{
    		
    	}
    	
    	return result;
    }
    
    public Document getXMLDocument(URL xmlURL)
    {
    	Document document = null;
		SAXBuilder builder = new SAXBuilder();
		try
		{
            document = builder.build(xmlURL);
        } catch (JDOMException e) {
        	LOGGER.error(e.getMessage());
        } catch (IOException e) {
        	LOGGER.error(e.getMessage());
        }
    	return document;
    }
}