package com.ht.syndication.htsportal.util;


public class ListObject implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9093728967096528413L;
	private Object key, value;

	/**
	 * @return the key
	 */
	public Object getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(Object key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(Object value) {
		this.value = value;
	}
	
	/** default constructor */
	public ListObject() 
	{
	}

	public static final class Factory
	{
		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.util.ListObject}.
		 */
		public static ListObject newInstance()
		{
			return new ListObject();
		}


		/**
		 * Constructs a new instance of {@link com.ht.syndication.htsportal.util.ListObject}, taking all possible properties
		 * (except the identifier(s))as arguments.
		 */

		public static ListObject newInstance(Object key, Object value)
		{
			final ListObject entity = new ListObject();
			entity.setKey(key);
			entity.setValue(value);
			return entity;
		}
	}
	
}
