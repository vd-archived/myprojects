package com.ht.syndication.htsportal.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ht.syndication.htsportal.ServiceLocator;

public class ImageUtility {
	
	private static final Log LOGGER = LogFactory.getLog(ContentUtility.class);
	
	public void indexImage()
	{
		try
		{
			ServiceLocator.instance().getImageService().indexImage();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.error("Error on Index Image "+ex.getMessage());
		}
		
	}
	
	public void saveImage()
	{
		try
		{
			ServiceLocator.instance().getImageService().saveBatchImages(HTSPortal.ADMIN);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.error("Error on Index Image "+ex.getMessage());
		}
	}
}