package com.ht.syndication.htsportal.util;
import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;
import com.ht.syndication.htsportal.service.ContentServiceImpl;


public class ReadXML {

	private static final Log LOGGER = LogFactory.getLog(ReadXML.class);
	private Document doc;
	public Element root;

	public void setRoot(File file)
	{
		try {
			SAXBuilder builder = new SAXBuilder();
			doc = builder.build(file);
			root = doc.getRootElement();
		} catch (Exception e) {
			LOGGER.error("Unable to Set XML Root of file [" + file.getName() + "]:: " + e.getMessage());
		}
	}

	/**
	 * @param node,parent
	 * @param name
	 * @return
	 */
	public Element getChildByName(Element node,String name)
	{
		Element returnNode = null;
		List list = node.getChildren();
		for(int i = 0; i < list.size(); i++)
		{
			Element subNode = (Element) list.get(i);
			returnNode = getChildByRecursion(subNode,name);
			if(returnNode != null && returnNode.getName().equals(name))
				break;
		}
		return returnNode;
	}
	
	/**
	 * @param node,parent
	 * @param name
	 * @return
	 */
	public Element getChildByRecursion(Element node,String name)
	{
		Element returnNode = null;
		
		if(node.getName().equals(name))
			return node;
		
		List list = node.getChildren();
		for(int i = 0; i < list.size(); i++)
		{
			Element subNode = (Element) list.get(i);
			returnNode = getChildByRecursion(subNode,name);
			if(returnNode != null && returnNode.getName().equals(name))
				break;
		}
		return returnNode;
	}
}
