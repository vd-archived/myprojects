package com.ht.syndication.htsportal.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ht.syndication.htsportal.ServiceLocator;

//Table Name: news_transaction


public class ContentUtility 
{
    private static final Log LOGGER = LogFactory.getLog(ContentUtility.class);
	public void saveContent()
	{
		try
		{
			ServiceLocator.instance().getContentService().saveBatchContent(HTSPortal.ADMIN);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.error("Error on Batch Save Content "+ex.getMessage());

		}
	}
	
	public void indexContent()
	{
		try
		{
			ServiceLocator.instance().getContentService().indexContent();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.error("Error on Index Content "+ex.getMessage());
		}
	}

}