package com.ht.syndication.htsportal.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.imageio.ImageIO;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.struts2.ServletActionContext;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Metadata;
import com.drew.metadata.iptc.IptcDirectory;
import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.ImagetagsType;
import com.ht.syndication.htsportal.domain.RoleStatus;
import com.ht.syndication.htsportal.domain.TimeInterval;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.JDOMException;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;
import com.ht.syndication.htsportal.org.jdom.output.Format;
import com.ht.syndication.htsportal.org.jdom.output.XMLOutputter;
import com.ht.syndication.htsportal.transfer.ArticleVO;
import com.ht.syndication.htsportal.transfer.CategoryVO;
import com.ht.syndication.htsportal.transfer.EventVO;
import com.ht.syndication.htsportal.transfer.ImageVO;
import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.PublicationVO;
import com.ht.syndication.htsportal.transfer.SourceVO;

public final class Utility {

	private static final Log LOGGER = LogFactory.getLog(Utility.class);

	private Utility(){}

	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private static final ConfigurationReader FTP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.FTP_PROFILE);

	public static String dateToString(Date date, String format){
		String result = null;
		try{
			SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.ENGLISH);
			result = formatter.format(date);
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		return result;
	}

	public static String dateToString(Date date, final int format){
		if(format==-1)
		{
			return dateToString(date, "dd-MMM-yy");
		}
		else if(format==0)/* 0: for default content create Date Format*/
		{
			return dateToString(date, "dd/MM/yyyy");
		}
		else if(format==1)/* 1: for default jquery Date Format*/
		{
			return dateToString(date, "EEEE, d MMMM, yyyy");
		}
		else if(format==2)/* 2: for default coder Date Format*/
		{
			return dateToString(date, "dd-MM-yy hh:mm:ss");
		}
		else if(format==3)/* 3: for default update Date Format*/
		{
			return dateToString(date, "MMM d, yyyy hh:mm:ss a");
		}
		else if(format==4)/* 0: for default content create Date Format*/
		{
			return dateToString(date, "MMMM yyyy");
		}
		else if(format==5)/* 0: for default content create Date Format*/
		{
			return dateToString(date, "MMM-yy");
		}
		else if(format==6)/* 0: for default content create Date Format*/
		{
			return dateToString(date, "M/dd/yyyy");
		}
		else if(format==7)/* 0: for default content create Date Format*/
		{
			return dateToString(date, "dd MMMM");
		}
		else
		{
			return dateToString(date, "EEEE, d MMMM, yyyy");
		}
	}

	public static Date stringToDate(String date, String format, Boolean isNullOk){
		Date result = null;
		try{
			SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.ENGLISH);
			result = formatter.parse(date);
		}catch(Exception e){
			LOGGER.error(e.getMessage());
		}
		if(!isNullOk && result == null)
		{
			result = Calendar.getInstance().getTime();
		}
		return result;
	}

	public static Date stringToDate(String date, Integer format, Boolean isNullOk){
		if(format==null)
		{
			return stringToDate(date, "dd-MMM-yy", isNullOk);
		}
		else if(format==0)/* 0: for default content create Date Format*/
		{
			return stringToDate(date, "dd/MM/yyyy", isNullOk);
		}
		else if(format==1)/* 1: for default jquery Date Format*/
		{
			return stringToDate(date, "EEEE, d MMMM, yyyy", isNullOk);
		}
		else if(format==2)/* 2: for default coder Date Format*/
		{
			return stringToDate(date, "dd-MM-yy hh:mm:ss", isNullOk);
		}
		else if(format==3)/* 3: for default update Date Format*/
		{
			return stringToDate(date, "MMM d, yyyy hh:mm:ss a", isNullOk);
		}
		else if(format==4)/* 0: for default content create Date Format*/
		{
			return stringToDate(date, "MMMM yyyy", isNullOk);
		}
		else if(format==5)/* 0: for default content create Date Format*/
		{
			return stringToDate(date, "MMM-yy", isNullOk);
		}
		else if(format==6)/* 0: for default content create Date Format*/
		{
			return stringToDate(date, "M/dd/yyyy", isNullOk);
		}
		else if(format==7)/* 0: for default content create Date Format*/
		{
			return stringToDate(date, "dd/M", isNullOk);
		}
		else if(format==8)/* 0: for default content create Date Format*/
		{
			return stringToDate(date, "EEE MMM dd HH:mm:ss z yyyy", isNullOk);
		}
		else
		{
			return stringToDate(date, "EEEE, d MMMM, yyyy", isNullOk);
		}
	}

	public static Date stringToDate(String date, Integer format){
		return stringToDate(date, format, Boolean.FALSE);
	}
	
	public static String toSolrDate(Date date)
	{
		SimpleDateFormat SOLR_DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat SOLR_TIME_FORMATTER = new SimpleDateFormat("HH:mm:ss");
		return SOLR_DATE_FORMATTER.format(date) + "T" + SOLR_TIME_FORMATTER.format(date) + "Z";

	}

	public static String getAccessStatusName(Short value)
	{
		switch(value)
		{
		case 0:
			return "DISABLE";
		case 1:
			return "FULL_ACCESS";
		case 2:
			return "SHORT_ACCESS";
		case 3:
			return "FULL_RESTRICTED";
		default:
			return "FULL_RESTRICTED";
		}
	}

	public static String getPublicationAccessStatus(String publicationName)
	{
		File publicationFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("PUBLICATION_INTRO_XML")));
		Document document = null;
		if(publicationFile.exists())
		{
			SAXBuilder builder = new SAXBuilder();
			try
			{
				document = builder.build(publicationFile);
				Element root = document.getRootElement();
				List publications = root.getChildren("publication");
				int i = 0;
				for (i = 0; i < publications.size(); i++) {
					Element row = (Element) publications.get(i);
					if(row.getChild("name").getText().equals(publicationName))
					{
						return getAccessStatusName(Short.parseShort(row.getChild("status").getText()));
					}
				}
				if(i >=publications.size())
				{
					return getAccessStatusName(Short.parseShort("0"));
				}
			} catch (JDOMException e) {
				LOGGER.error(e.getMessage());
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
			return getAccessStatusName(Short.parseShort("0"));
		}
		else
		{
			return getAccessStatusName(Short.parseShort("0"));
		}
	}

	public static Boolean saveIntroductionXML(String type, Integer id, String name, String intro, Short status, String newsTicker, Integer priority)
	{
		String filePath = null;
		String rootName = null;
		String childName = null;
		if(type.equalsIgnoreCase(HTSPortal.XMLFile.SOURCE))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("SOURCE_INTRO_XML");
			rootName = "sources";
			childName = "source";
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.CATEGORY))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("CATEGORY_INTRO_XML");
			rootName = "categories";
			childName = "category";
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.IMAGE))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_INTRO_XML");
			rootName = "categories";
			childName = "category";
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.PUBLICATION))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("PUBLICATION_INTRO_XML");
			rootName = "publications";
			childName = "publication";
		}
		LOGGER.info("filePath="+filePath);
		LOGGER.info("actualPath="+ServletActionContext.getServletContext().getRealPath(filePath));
		File xmlFile = new File(ServletActionContext.getServletContext().getRealPath(filePath));
		Document document = null;
		if(xmlFile.exists())
		{
			SAXBuilder builder = new SAXBuilder();
			try
			{
				document = builder.build(xmlFile);
				Element root = document.getRootElement();
				List categories = root.getChildren(childName);
				int i = 0;
				for (i = 0; i < categories.size(); i++) {
					Element row = (Element) categories.get(i);
					if(row.getChild("id").getText().equals(id.toString()))
					{
						if(childName.equalsIgnoreCase("publication"))
						{
							row.getAttribute("newsTicker").setValue(newsTicker.toLowerCase());
						}
						else if(type.equalsIgnoreCase(HTSPortal.XMLFile.IMAGE))
						{
							row.getAttribute("highlight").setValue(newsTicker.toLowerCase());
							row.getAttribute("priority").setValue(priority.toString());
						}
						row.getChild("name").setText(replaceBadCharacter(name));
						row.getChild("intro").setText(replaceBadCharacter(intro));
						row.getChild("status").setText(replaceBadCharacter(status+""));
						break;
					}
				}
				if(i >=categories.size())
				{
					Element child = new Element(childName);
					if(childName.equalsIgnoreCase("publication"))
					{
						child.setAttribute("newsTicker",newsTicker.toLowerCase());
					}
					else if(type.equalsIgnoreCase(HTSPortal.XMLFile.IMAGE))
					{
						child.setAttribute("highlight", newsTicker.toLowerCase());
						child.setAttribute("priority", priority.toString());
					}
					child.addContent(new Element("id").setText(replaceBadCharacter(id.toString())));
					child.addContent(new Element("name").setText(replaceBadCharacter(name)));
					child.addContent(new Element("intro").setText(replaceBadCharacter(intro)));
					child.addContent(new Element("status").setText(replaceBadCharacter(status+"")));
					root.addContent(child);
				}
			} catch (JDOMException e) {
				LOGGER.error(e.getMessage());
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		}
		else
		{
			document = new Document();
			Element root = new Element(rootName);
			Element child = new Element(childName);
			if(childName.equalsIgnoreCase("publication"))
			{
				child.setAttribute("newsTicker", newsTicker.toLowerCase());
			}
			else if(type.equalsIgnoreCase(HTSPortal.XMLFile.IMAGE))
			{
				child.setAttribute("highlight", newsTicker.toLowerCase());
				child.setAttribute("priority", priority.toString());
			}
			child.addContent(new Element("id").setText(replaceBadCharacter(id.toString())));
			child.addContent(new Element("name").setText(replaceBadCharacter(name)));
			child.addContent(new Element("intro").setText(replaceBadCharacter(intro)));
			child.addContent(new Element("status").setText(replaceBadCharacter(status+"")));
			root.addContent(child);
			document.setContent(root);
		}
		writeXMLDocument(document, xmlFile);
		return Boolean.TRUE;
	}

	public static Boolean deleteIntroductionXML(String type, Integer id)
	{
		String filePath = null;
		String rootName = null;
		String childName = null;
		if(type.equalsIgnoreCase(HTSPortal.XMLFile.SOURCE))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("SOURCE_INTRO_XML");
			rootName = "sources";
			childName = "source";
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.CATEGORY))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("CATEGORY_INTRO_XML");
			rootName = "categories";
			childName = "category";
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.IMAGE))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_INTRO_XML");
			rootName = "categories";
			childName = "category";
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.PUBLICATION))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("PUBLICATION_INTRO_XML");
			rootName = "publications";
			childName = "publication";
		}
		LOGGER.info("filePath="+filePath);
		LOGGER.info("actualPath="+ServletActionContext.getServletContext().getRealPath(filePath));
		File xmlFile = new File(ServletActionContext.getServletContext().getRealPath(filePath));
		Document document = null;
		if(xmlFile.exists())
		{
			SAXBuilder builder = new SAXBuilder();
			try
			{
				document = builder.build(xmlFile);
				Element root = document.getRootElement();
				List categories = root.getChildren(childName);
				int i = 0;
				for (i = 0; i < categories.size(); i++) {
					Element row = (Element) categories.get(i);
					if(row.getChild("id").getText().equals(id.toString()))
					{
						categories.remove(i);
						break;
					}
				}
			} catch (JDOMException e) {
				LOGGER.error(e.getMessage());
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
			writeXMLDocument(document, xmlFile);
		}
		return Boolean.TRUE;
	}

	@SuppressWarnings("unused")
	public static Boolean saveMenu(String type, String oldName, String name, Short status, Short highlight, Integer priority)
	{
		String nameEncoded = Utility.forcefullyURLEncoded(name);
		name = replaceBadCharacter(name);
		if(oldName != null)
		{
			oldName = replaceBadCharacter(oldName);
		}
		if(status.equals(AccessStatus.DISABLE))
		{
			if(oldName != null)
				deleteMenu(type, oldName);
		}
		else
		{
			String filePath = null;
			String hrefPath = null;
			if(type.equalsIgnoreCase(HTSPortal.XMLFile.SOURCE))
			{
				filePath = HTSPortal.SERVLETCONTEXT.getProperty("SOURCE_MENU");
				hrefPath = HTSPortal.SERVLETCONTEXT.getProperty("SOURCE_MENU_HREF");
			}
			else if(type.equalsIgnoreCase(HTSPortal.XMLFile.CATEGORY))
			{
				filePath = HTSPortal.SERVLETCONTEXT.getProperty("CATEGORY_MENU");
				hrefPath = HTSPortal.SERVLETCONTEXT.getProperty("CATEGORY_MENU_HREF");
			}
			else if(type.equalsIgnoreCase(HTSPortal.XMLFile.IMAGE))
			{
				filePath = HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_MENU");
				hrefPath = HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_MENU_HREF");
			}
			File menuFile = new File(ServletActionContext.getServletContext().getRealPath(filePath));
			Document document = null;
			if(menuFile.exists())
			{
				SAXBuilder builder = new SAXBuilder();
				try
				{
					Element existingrow = null; 
					document = builder.build(menuFile);
					Element root = document.getRootElement();
					List lilist = root.getChildren("li");
					int i = 0;
					for (i = 0; i < lilist.size(); i++) {
						Element row = (Element) lilist.get(i);
						if(row.getChild("a").getText().equals(oldName))
						{
							Boolean positionChanged = Boolean.FALSE;
							if(highlight!=null)
							{
								if(highlight.equals(AccessStatus.ENABLE))
								{
									row.getChild("a").setAttribute("class", "highlightmenu");
								}
								else if(highlight.equals(AccessStatus.DISABLE))
								{
									row.getChild("a").removeAttribute("class");
								}
							}
							if(priority!=null)
							{
								if(!row.getChild("a").getAttributeValue("priority").equals(priority.toString()))
								{
									row.getChild("a").setAttribute("priority", priority.toString());
									positionChanged = Boolean.TRUE;
								}
							}
							row.getChild("a").setAttribute("href", replaceBadCharacter(hrefPath.replaceAll("##HREFVALUE##", nameEncoded)));
							row.getChild("a").setText(name);
							if(positionChanged)
							{
								existingrow = (Element)row.clone();
								lilist.remove(i);
							}
							break;
						}
					}
					if(existingrow != null)
					{
						String prePriority = existingrow.getChild("a").getAttributeValue("priority");
						i = 0;
						for (i = 0; i < lilist.size(); i++) {
							Element row = (Element) lilist.get(i);
							if(Utility.convertToInteger(row.getChild("a").getAttributeValue("priority"), 10) < priority)
							{
								break;
							}
						}
						lilist.add(i, existingrow);
					}
					else if(i >=lilist.size())
					{
						if(priority!=null)
						{
							i = 0;
							for (i = 0; i < lilist.size(); i++) {
								Element row = (Element) lilist.get(i);
								if(Utility.convertToInteger(row.getChild("a").getAttributeValue("priority"), 10) < priority)
								{
									break;
								}
							}
						}
						Element li = new Element("li");
						Element child = new Element("a");
						if(highlight!=null)
						{
							if(highlight.equals(AccessStatus.ENABLE))
							{
								child.setAttribute("class", "highlightmenu");
							}
						}
						if(priority!=null)
						{
							child.setAttribute("priority", priority.toString());
						}
						child.setAttribute("href", replaceBadCharacter(hrefPath.replaceAll("##HREFVALUE##", nameEncoded)));
						child.setText(name);
						li.addContent(child);
						if(priority!=null)
						{
							lilist.add(i, li);
						}
						else
						{
							root.addContent(li);
						}
					}
				} catch (JDOMException e) {
					LOGGER.error(e.getMessage());
				} catch (IOException e) {
					LOGGER.error(e.getMessage());
				}
			}
			else
			{
				document = new Document();
				Element root = new Element("ul");
				root.setAttribute("class", "single");
				Element li = new Element("li");
				root.addContent(li);
				Element child = new Element("a");
				if(highlight!=null)
				{
					if(highlight.equals(AccessStatus.ENABLE))
					{
						child.setAttribute("class", "highlightmenu");
					}
				}
				if(priority!=null)
				{
					child.setAttribute("priority", priority.toString());
				}
				child.setAttribute("href", replaceBadCharacter(hrefPath.replaceAll("##HREFVALUE##", nameEncoded)));
				child.setText(name);
				li.addContent(child);
				document.setContent(root);
			}
			writeXMLDocument(document, menuFile);
		}
		return Boolean.TRUE;
	}

	public static Boolean deleteMenu(String type, String name)
	{
		String filePath = null;
		if(type.equalsIgnoreCase(HTSPortal.XMLFile.SOURCE))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("SOURCE_MENU");
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.CATEGORY))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("CATEGORY_MENU");
		}
		else if(type.equalsIgnoreCase(HTSPortal.XMLFile.IMAGE))
		{
			filePath = HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_MENU");
		}
		if(name!=null)
		{
			name = name.replace("&", "%26");
		}
		File menuFile = new File(ServletActionContext.getServletContext().getRealPath(filePath));
		Document document = null;
		if(menuFile.exists())
		{
			SAXBuilder builder = new SAXBuilder();
			try
			{
				document = builder.build(menuFile);
				Element root = document.getRootElement();
				List lilist = root.getChildren("li");
				int i = 0;
				for (i = 0; i < lilist.size(); i++) {
					Element row = (Element) lilist.get(i);
					if(row.getChild("a").getText().equals(name))
					{
						lilist.remove(i);
						break;
					}
				}
			} catch (JDOMException e) {
				LOGGER.error(e.getMessage());
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
			writeXMLDocument(document, menuFile);
		}
		return Boolean.TRUE;
	}

	
	public static SourceVO[] resetContentSource()
	{
		Properties property = HTSPortal.SERVLETCONTEXT;
		String rootPath = property.getProperty("APP_RROT");
		File xmlFile = new File(rootPath, property.getProperty("SOURCE_INTRO_XML"));
		File menuFile = new File(rootPath, property.getProperty("SOURCE_MENU"));
		deleteFileOnExit(xmlFile);
		deleteFileOnExit(menuFile);
		
		Document xmldocument = new Document();
		Document menudocument = new Document();

		Element xmlroot = new Element("sources");
		Element menuroot = new Element("ul");
		menuroot.setAttribute("class", "navmenu");

		SourceVO[]sources = ServiceLocator.instance().getSourceService().getAllSource();
		for(SourceVO sourceVO: sources)
		{
			Element child = new Element("source");
			child.addContent(new Element("id").setText(replaceBadCharacter(sourceVO.getId().toString())));
			child.addContent(new Element("name").setText(replaceBadCharacter(sourceVO.getName())));
			child.addContent(new Element("intro").setText(replaceBadCharacter(sourceVO.getDetails())));
			child.addContent(new Element("status").setText(replaceBadCharacter(sourceVO.getStatus()+"")));
			xmlroot.addContent(child);
			if(sourceVO.getStatus().equals(AccessStatus.ENABLE))
			{
				Element li = new Element("li");
				menuroot.addContent(li);
				Element a = new Element("a");
				a.setAttribute("href", replaceBadCharacter(property.getProperty("SOURCE_MENU_HREF").replace("/##WEBROOT##/", APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL)).replace("##HREFVALUE##", Utility.forcefullyURLEncoded(sourceVO.getName()))));
				a.setText(replaceBadCharacter(sourceVO.getName()));
				li.addContent(a);
			}
		}
		xmldocument.setContent(xmlroot);
		writeXMLDocument(xmldocument, xmlFile);

		menudocument.setContent(menuroot);
		writeXMLDocument(menudocument, menuFile);

		return sources;
	}
	
	public static CategoryVO[] resetContentCategory()
	{
		Properties property = HTSPortal.SERVLETCONTEXT;
		String rootPath = property.getProperty("APP_RROT");
		File xmlFile = new File(rootPath, property.getProperty("CATEGORY_INTRO_XML"));
		File menuFile = new File(rootPath, property.getProperty("CATEGORY_MENU"));
		deleteFileOnExit(xmlFile);
		deleteFileOnExit(menuFile);
		
		Document xmldocument = new Document();
		Document menudocument = new Document();

		Element xmlroot = new Element("categories");
		Element menuroot = new Element("ul");
		menuroot.setAttribute("class", "navmenu");

		CategoryVO[]categories = ServiceLocator.instance().getCategoryService().getAllCategory();
		for(CategoryVO categoryVO: categories)
		{
			Element child = new Element("category");
			child.addContent(new Element("id").setText(replaceBadCharacter(categoryVO.getId().toString())));
			child.addContent(new Element("name").setText(replaceBadCharacter(categoryVO.getName())));
			child.addContent(new Element("intro").setText(replaceBadCharacter(categoryVO.getDetails())));
			child.addContent(new Element("status").setText(replaceBadCharacter(categoryVO.getStatus()+"")));
			xmlroot.addContent(child);
			if(categoryVO.getStatus().equals(AccessStatus.ENABLE))
			{
				Element li = new Element("li");
				menuroot.addContent(li);
				Element a = new Element("a");
				a.setAttribute("href", replaceBadCharacter(property.getProperty("CATEGORY_MENU_HREF").replace("/##WEBROOT##/", APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL)).replaceAll("##HREFVALUE##", Utility.forcefullyURLEncoded(categoryVO.getName()))));
				a.setText(replaceBadCharacter(categoryVO.getName()));
				li.addContent(a);
			}
		}
		xmldocument.setContent(xmlroot);
		writeXMLDocument(xmldocument, xmlFile);

		menudocument.setContent(menuroot);
		writeXMLDocument(menudocument, menuFile);

		return categories;
	}
	
	public static PublicationVO[] resetContentPublication()
	{
		Properties property = HTSPortal.SERVLETCONTEXT;
		String rootPath = property.getProperty("APP_RROT");
		File xmlFile = new File(rootPath, property.getProperty("PUBLICATION_INTRO_XML"));
		deleteFileOnExit(xmlFile);
		
		Document xmldocument = new Document();

		Element xmlroot = new Element("publications");

		PublicationVO[]publications = ServiceLocator.instance().getPublicationService().getAllPublication();
		for(PublicationVO publication: publications)
		{
			Element child = new Element("publication");
			child.setAttribute("newsTicker", replaceBadCharacter(publication.getNewsTicker()));
			child.addContent(new Element("id").setText(replaceBadCharacter(publication.getId().toString())));
			child.addContent(new Element("name").setText(replaceBadCharacter(publication.getName())));
			child.addContent(new Element("intro").setText(replaceBadCharacter(publication.getDetails())));
			child.addContent(new Element("status").setText(replaceBadCharacter(publication.getStatus()+"")));
			xmlroot.addContent(child);
		}
		xmldocument.setContent(xmlroot);
		writeXMLDocument(xmldocument, xmlFile);
		return publications;
	}
	
	public static EventVO[] resetImageEventXML(Boolean createMenues)
	{
		Properties property = HTSPortal.SERVLETCONTEXT;
		String rootPath = property.getProperty("APP_RROT");
		File xmlFile = new File(rootPath, property.getProperty("EVENT_INTRO_XML"));
		deleteFileOnExit(xmlFile);
		
		Document xmldocument = new Document();

		Element xmlroot = new Element("events");

		EventVO[]eventVOs = ServiceLocator.instance().getEventService().getAllEvent();
		for(EventVO eventVO: eventVOs)
		{
			Element child = new Element("event");
			child.setAttribute("highlight", "1");
			if(eventVO.getWeight() != null && eventVO.getWeight().equals(""))
			{
				child.setAttribute("priority", eventVO.getWeight().toString());
			}
			child.addContent(new Element("id").setText(replaceBadCharacter(eventVO.getId().toString())));
			child.addContent(new Element("name").setText(replaceBadCharacter(eventVO.getName())));
			child.addContent(new Element("intro").setText(replaceBadCharacter(eventVO.getDetails())));
			child.addContent(new Element("status").setText(replaceBadCharacter(eventVO.getStatus()+"")));
			xmlroot.addContent(child);
		}
		xmldocument.setContent(xmlroot);
		writeXMLDocument(xmldocument, xmlFile);
		if(createMenues)
		{
			saveImageMenus(null, eventVOs);
		}
		return eventVOs;
	}
	
	public static List<ImagetagsFullVO> resetImageTagsXML(Boolean createMenues)
	{
		Properties property = HTSPortal.SERVLETCONTEXT;
		String rootPath = property.getProperty("APP_RROT");
		File xmlFile = new File(rootPath, property.getProperty("IMAGECATEGORY_INTRO_XML"));
		deleteFileOnExit(xmlFile);
		
		Document xmldocument = new Document();

		Element xmlroot = new Element("tags");

		List<ImagetagsFullVO>fullImageTags = ServiceLocator.instance().getImagetagsService().getAllHierarchyImagetags();
		for(ImagetagsFullVO fullImageTag: fullImageTags)
		{
			getImageCategoriesXMLFiles(fullImageTag, xmlroot);
		}
		xmldocument.setContent(xmlroot);
		writeXMLDocument(xmldocument, xmlFile);
		if(createMenues)
		{
			saveImageMenus(fullImageTags, null);
		}
		/*for(ImagetagsFullVO fullImageTag: fullImageTags)
		{
			createImageCategoriesFolders(fullImageTag);
		}*/
		return fullImageTags;
	}
	
	private static void getAllPathsFromTags(List<ImagetagsFullVO> tagVOs, final List<String>paths, String parentPath)
	{
		for(ImagetagsFullVO tagVO: tagVOs)
		{
			paths.add(parentPath + "/" + tagVO.getName());
			if(tagVO.getChilds() != null)
			{
				getAllPathsFromTags(tagVO.getChilds(), paths, parentPath + "/" + tagVO.getName());
			}
		}
	}

	public static void createImageFolderOnFTP(EventVO[]eventVOs, List<ImagetagsFullVO> fullImageTags)
	{
		try
		{
			List<String>dirPaths = new ArrayList<String>();
			
			if(fullImageTags == null)
			{
				fullImageTags = ServiceLocator.instance().getImagetagsService().getAllHierarchyImagetags();
			}
			if(eventVOs == null)
			{
				eventVOs = ServiceLocator.instance().getEventService().getAllEvent();
			}
			List<String>tagsPaths = new ArrayList<String>();
			getAllPathsFromTags(fullImageTags, tagsPaths, "");
			
			String imageRoot = FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.ROOT_PATH);
			
			dirPaths.add(imageRoot);
			dirPaths.add(imageRoot + HTSPortal.FTP.Image.CATEGORYROOT);
			dirPaths.add(imageRoot + HTSPortal.FTP.Image.EVENTROOT);
			
			for(String tagsPath: tagsPaths)
			{
				dirPaths.add(imageRoot + HTSPortal.FTP.Image.CATEGORYROOT + tagsPath);
			}
			
			for(EventVO eventVO: eventVOs)
			{
				String eventPath = imageRoot + HTSPortal.FTP.Image.EVENTROOT + "/" + eventVO.getName();
				dirPaths.add(eventPath);
				
				for(String tagsPath: tagsPaths)
				{
					dirPaths.add(eventPath + tagsPath);
				}
			}
			FTPUtility.createFolders(dirPaths, FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.URL), FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.USERNAME) , FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.PASSWORD));
		} catch(Exception e)
		{
			LOGGER.error("FTP ERROR:: Error on ftp folder creation: " + e.getMessage());
		}
	}

	public static void getImageCategoriesXMLFiles(ImagetagsFullVO fullImageTag, Element xmlroot)
	{
		Element child = new Element("category");
		child.setAttribute("highlight", "0");
		child.setAttribute("priority", fullImageTag.getWeight().toString());
		child.addContent(new Element("id").setText(replaceBadCharacter(fullImageTag.getId().toString())));
		child.addContent(new Element("name").setText(replaceBadCharacter(fullImageTag.getName())));
		child.addContent(new Element("intro").setText(replaceBadCharacter(fullImageTag.getDetails())));
		child.addContent(new Element("type").setText(replaceBadCharacter(fullImageTag.getType().toString())));
		child.addContent(new Element("status").setText(replaceBadCharacter(fullImageTag.getStatus().toString())));
		List<ImagetagsFullVO> childsFullImageTags = fullImageTag.getChilds();
		if(childsFullImageTags.size() > 0)
		{
			Element childXML = new Element("childs");
			for(ImagetagsFullVO childVO: childsFullImageTags)
			{
				getImageCategoriesXMLFiles(childVO, childXML);
			}
			child.addContent(childXML);
		}
		xmlroot.addContent(child);
	}
	
	public static Boolean saveImageMenus(List<ImagetagsFullVO> fullImageTags, EventVO[]eventVOs)
	{
		Properties property = HTSPortal.SERVLETCONTEXT;
		String rootPath = property.getProperty("APP_RROT");
		if(eventVOs == null)
		{
			eventVOs = ServiceLocator.instance().getEventService().getAllEvent();
		}
		
		if(fullImageTags == null)
		{
			fullImageTags = ServiceLocator.instance().getImagetagsService().getAllHierarchyImagetags();
		}

		File menuFile = new File(rootPath, property.getProperty("IMAGECATEGORY_MENU"));
		deleteFileOnExit(menuFile);
		
		Document menudocument = new Document();

		Element menuroot = new Element("ul");
		menuroot.setAttribute("class", "navmenu");
		
		Element eventli = new Element("li");
		Element eventa = new Element("a");
		eventa.setAttribute("class", "highlightmenu");
		eventa.setAttribute("href", "#");
		eventa.setText("Latest Events");
		eventli.addContent(eventa);

		if(eventVOs.length > 0)
		{
			Element eventul = new Element("ul");
			for(EventVO eventVO: eventVOs)
			{
				if(eventVO.getStatus().equals(AccessStatus.ENABLE))
				{
					Element li = new Element("li");
					eventul.addContent(li);
					Element a = new Element("a");
					a.setAttribute("href", replaceBadCharacter(property.getProperty("IMAGEEVENT_MENU_HREF").replace("/##WEBROOT##/", APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL)).replaceAll("##HREFVALUE##", Utility.forcefullyURLEncoded(eventVO.getName()))));
					a.setText(replaceBadCharacter(eventVO.getName()));
					li.addContent(a);
				}
			}
			if(eventul.getChildren("li").size() > 0)
			{
				eventli.addContent(eventul);
			}
		}
		if(eventli.getChildren("ul").size() > 0)
		{
			menuroot.addContent(eventli);
		}

		for(ImagetagsFullVO fullImageTag: fullImageTags)
		{
			saveImageMenus(fullImageTag, menuroot);
		}
		menudocument.setContent(menuroot);
		writeXMLDocument(menudocument, menuFile);
		return Boolean.TRUE;
	}
	
	public static void saveImageMenus(ImagetagsFullVO fullImageTag, Element menuroot)
	{
		if(fullImageTag.getStatus().equals(AccessStatus.ENABLE) && fullImageTag.getType().equals(ImagetagsType.NORMAL))
		{
			Properties property = HTSPortal.SERVLETCONTEXT;
			Element li = new Element("li");
			Element a = new Element("a");
			a.setAttribute("priority", fullImageTag.getWeight().toString());
			a.setAttribute("href", replaceBadCharacter(property.getProperty("IMAGECATEGORY_MENU_HREF").replace("/##WEBROOT##/", APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL)).replaceAll("##HREFVALUE##", Utility.forcefullyURLEncoded(fullImageTag.getName()))));
			a.setText(replaceBadCharacter(fullImageTag.getName()));
			li.addContent(a);
	
			List<ImagetagsFullVO> childsFullImageTags = fullImageTag.getChilds();
			if(childsFullImageTags.size() > 0)
			{
				Element ul = new Element("ul");
				for(ImagetagsFullVO childVO: childsFullImageTags)
				{
					saveImageMenus(childVO, ul);
				}
				if(ul.getChildren("li").size() > 0)
				{
					li.addContent(ul);
				}
			}
			menuroot.addContent(li);
		}
	}

	
	public static Boolean saveIntroductionXMLStartup()
	{
		resetContentSource();
		resetContentCategory();
		resetContentPublication();
		EventVO[]events = resetImageEventXML(Boolean.FALSE);
		List<ImagetagsFullVO>tags = resetImageTagsXML(Boolean.FALSE);
		saveImageMenus(tags, events);
		createStartupFolders();
		createImageFolderOnFTP(events, tags);
//		System.out.println("XML and Menues are reset");
		LOGGER.info("XML and Menues are reset");
		return Boolean.TRUE;
	}
	
	public static void createStartupFolders()
	{
		File tempFolder = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), HTSPortal.IMAGE.MEDIUM);
		if(!tempFolder.exists())
		{
			try
			{
				tempFolder.mkdirs();
			}catch(Exception e)
			{
				LOGGER.error("FAILED:: Create Folder '" + tempFolder.getName() + "' on application Startup\n\t\t" + e.getMessage());
			}
		}
		
		tempFolder = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), HTSPortal.IMAGE.THUMB);
		if(!tempFolder.exists())
		{
			try
			{
				tempFolder.mkdirs();
			}catch(Exception e)
			{
				LOGGER.error("FAILED:: Create Folder '" + tempFolder.getName() + "' on application Startup\n\t\t" + e.getMessage());
			}
		}
		
		tempFolder = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), HTSPortal.IMAGE.MEDIUM_450_350);
		if(!tempFolder.exists())
		{
			try
			{
				tempFolder.mkdirs();
			}catch(Exception e)
			{
				LOGGER.error("FAILED:: Create Folder '" + tempFolder.getName() + "' on application Startup\n\t\t" + e.getMessage());
			}
		}
		tempFolder = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.ERRORDIRECTORY));
//		tempFolder = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.ERRORDIRECTORY));
		if(!tempFolder.exists())
		{
			try
			{
				tempFolder.mkdirs();
			}catch(Exception e)
			{
				LOGGER.error("FAILED:: Create Folder '" + tempFolder.getName() + "' on application Startup\n\t\t" + e.getMessage());
			}
		}
		
		tempFolder = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.ORIGINALIMAGEDIRECTORY));
		if(!tempFolder.exists())
		{
			try
			{
				tempFolder.mkdirs();
			}catch(Exception e)
			{
				LOGGER.error("FAILED:: Create Folder '" + tempFolder.getName() + "' on application Startup\n\t\t" + e.getMessage());
			}
		}
	}
	
	public static void createImageCategoriesFolders(ImagetagsFullVO fullImageTag)
	{
		File imageCategory = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), fullImageTag.getName());
		if(!imageCategory.exists())
		{
			File childImageCategory = new File(imageCategory, HTSPortal.IMAGE.MEDIUM);
			try
			{
				if(!childImageCategory.exists())
					childImageCategory.mkdirs();
				childImageCategory = new File(imageCategory, HTSPortal.IMAGE.THUMB);
				if(!childImageCategory.exists())
					childImageCategory.mkdirs();
			}catch(Exception e)
			{
				LOGGER.error("FAILED:: Create Image Category '" + fullImageTag.getName() + "' on application Startup\n\t\t" + e.getMessage());
			}
		}
		List<ImagetagsFullVO> childsFullImageTags = fullImageTag.getChilds();
		for(ImagetagsFullVO child: childsFullImageTags)
		{
			createImageCategoriesFolders(child);
		}
	}

	private static Boolean writeXMLDocument(Document document, File xmlFile)
	{
		try {
			if(document!=null)
			{
				OutputStream outStream = new FileOutputStream(xmlFile);
				Writer writer = new OutputStreamWriter(outStream, "UTF-8");
				XMLOutputter outputter = new XMLOutputter();
				outputter.setFormat(Format.getPrettyFormat());
				outputter.output(document, writer);
			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	private static Boolean deleteFileOnExit(File file)
	{
		try
		{
			if(file.exists())
			{
				file.delete();
			}
			file.getParentFile().mkdirs();
		}catch(Exception e){}
		return Boolean.TRUE;
	}



	public static String replaceBadCharacter(String line)
	{
		try 
		{
			if(line != null) {
				line = line.replaceAll("â€“ ", "- ");
				line = line.replaceAll("ï¿½", "'");
				line = line.replaceAll("ï¿½", "\"");
				line = line.replaceAll("â€�", "\"");
				line = line.replaceAll("â€œ", "\"");
				line = line.replaceAll("â€˜", "'");
				line = line.replaceAll("â€™", "'");
				line = line.replaceAll("â€™", "'");
				line = line.replaceAll("â€”", "-");
				//line = line.replaceAll("Â©","(c)");
				line = line.replaceAll("â—�","*");
				line = line.replaceAll("â€¢","*");
				line = line.replaceAll("Ã©", "e");
				line = line.replaceAll("â€™", "'");
				line = line.replaceAll("â€™", "'");
				line = line.replaceAll("â€˜", "'");
				line = line.replaceAll("â€“", "-");
				line = line.replaceAll("Â£","&#163;");
				line = line.replaceAll("â€¦", ".");
				line = line.replaceAll("â‚¬","&#8364;");
				line = line.replaceAll("Â¥","&#x00A5");
				line = line.replaceAll("'", "'");
				line = line.replaceAll("Ã¢", "a");
				line = line.replaceAll("Ãƒ", "A");
				line = line.replaceAll("Ã¡", "a");
				line = line.replaceAll("Ã—", "x");
				line = line.replaceAll("Â´", "'");
				line = line.replaceAll("Ãª", "e");
				line = line.replaceAll("Ã¨", "e");
				line = line.replaceAll("Â§", "*");
				line = line.replaceAll("Ã¶", "o");
				line = line.replaceAll("Ã§", "c");
				line = line.replaceAll("Ã´", "o");
				line = line.replaceAll("Â°", "deg");
				line = line.replaceAll("Ã¤", "a");
				line = line.replaceAll("Ãº", "u");
				line = line.replaceAll("Â¥", "Euro");
				line = line.replaceAll("Ã¯", "i");
				line = line.replaceAll("Ã«", "e");
				line = line.replaceAll("Ã ", "a");
				line = line.replaceAll("Ã‚", "A");
				line = line.replaceAll("Â®", "(R)");
				line = line.replaceAll("_", "");
				line = line.replaceAll("Ù€", " ");
				line = line.replaceAll("Â©", "&#x00A9;");
				line = line.replace("Â¬", "");
				line= line.replace("Ä�", "a");
				line = line.replace("Â¯", "");
				line = line.replace("Âº", "&#186");
			}

		}
		catch (Exception e) 
		{
			LOGGER.error("Problem with replace special character [ "+line+" ]");
		}

		return line;

	}




	public static StringBuffer getFileContent(File file)
	{
		StringBuffer fileContent = new StringBuffer();
		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream(file);
			int ch;
			while((ch=fis.read())!=-1)
				fileContent.append((char)ch);
			fis.close();
		}catch(Exception e){
			LOGGER.error(e.getMessage());
			return null;
		}finally
		{
			try
			{
				if(fis!=null)
					fis.close();
			}catch(Exception e){/*e.printStackTrace();*/}
		}
		return fileContent;
	}

	public static boolean writeFile(String srcContent, File desFile){
		FileChannel desChannel = null;
		try{
			if(desFile.exists())
				desFile.delete();
			desChannel = new java.io.RandomAccessFile(desFile, "rw").getChannel();
			byte[] bytes = srcContent.getBytes();   
			java.nio.MappedByteBuffer mbb = desChannel.map(FileChannel.MapMode.READ_WRITE,0, bytes.length);
			mbb.put(ByteBuffer.wrap(bytes));
			desChannel.close();
			return true;
		}catch(Exception e){
			LOGGER.error(e.getMessage());
			return false;
		}finally {
			try{
				if(desChannel != null) {
					desChannel.close();
				}
			}catch(Exception e){/*e.printStackTrace();*/}
		}
	}

	/**
	 * 
	 * @param email
	 * @return
	 */
	public static Boolean isValidEmailAddress(String email)
	{
		Boolean isValid = Boolean.FALSE;
		try 
		{
			new InternetAddress(email, true);
			isValid = Boolean.TRUE;
		} 
		catch (AddressException e) 
		{
		}
		return isValid;
	}

	public static Boolean isNumeric(String num)
	{
		Boolean isValid = Boolean.FALSE;
		try{
			Integer.parseInt(num);
			isValid = Boolean.TRUE;
		}catch(NumberFormatException nfe)
		{
		}
		catch(NullPointerException npe)
		{
		}
		return isValid;
	}

	public static Boolean isDouble(String num)
	{
		Boolean isValid = Boolean.FALSE;
		try{
			Double.parseDouble(num);
			isValid = Boolean.TRUE;
		}catch(NumberFormatException nfe)
		{
		}
		return isValid;
	}
	
	public static Integer convertToInteger(String number, Integer defaultNumber)
	{
		Integer result = defaultNumber;
		try
		{
			if(number != null)
			{
				result = Integer.parseInt(number);
			}
		}
		catch(Exception e)
		{			
		}
		return result;
	}
	
	public static Integer convertToIntegerWithMinimum(String number, Integer defaultNumber)
	{
		Integer result = Utility.convertToInteger(number, defaultNumber);
		if(result < defaultNumber) {
			result = defaultNumber;
		}
		return result;
	}

	public static String getRequestedURLWithParameter(HttpServletRequest request, String[]excludeparameters)
	{
		StringBuffer requestedURL = new StringBuffer();
		requestedURL = request.getRequestURL();
		requestedURL.append("?");
		Enumeration pnames = request.getParameterNames();
		while(pnames.hasMoreElements()){
			String key = pnames.nextElement().toString();
			Boolean paramMatch = Boolean.FALSE;
			for(int i=0; i<excludeparameters.length; i++)
			{
				if(key.equalsIgnoreCase(excludeparameters[i]))
				{
					paramMatch = Boolean.TRUE;
					break;
				}
			}
			if(!paramMatch){
				if(!requestedURL.toString().endsWith("?")){
					requestedURL.append("&");
				}
				try{
					requestedURL.append(URLEncoder.encode(key, "UTF-8")+"="+URLEncoder.encode(request.getParameter(key), "UTF-8"));
				}
				catch(Exception e)
				{
					requestedURL.append(URLEncoder.encode(key)+"="+URLEncoder.encode(request.getParameter(key)));
				}
			}
		}
		return requestedURL.toString();
	}
	
	public static List<ArticleVO> getArticlesFromIterator(Iterator iterator, String pubStatus)
	{
		List<ArticleVO> articles = new ArrayList<ArticleVO>();
		while(iterator.hasNext())
		{
			Element doc = (Element)iterator.next();
			ArticleVO article = new ArticleVO();
			List<Element>fieldList = doc.getChildren("arr");
			for(Element tempEle: fieldList)
			{
				String fieldName = tempEle.getAttributeValue("name");
				List<String> tempList = new ArrayList<String>();
				List<Element> tempArrEle = tempEle.getChildren();
				if(fieldName.equals("category"))
				{
					tempList.clear();
					for(Element tempArrRecord: tempArrEle)
					{
						tempList.add(tempArrRecord.getTextNormalize());
					}
					article.setCategory(tempList);
				}
				else if(fieldName.equals("news"))
				{
					tempList.clear();
					for(Element tempArrRecord: tempArrEle)
					{
						String[]tempStr = tempArrRecord.getText().split("((\n\r)|(\r)|(\n))+");
						if(tempStr.length>0)
						{
							if(tempStr[0].length()<370)
							{
								tempList.add(tempStr[0]+"...");
							}
							else
							{
								tempList.add(tempStr[0].substring(0, tempStr[0].lastIndexOf(" ", 370))+"...");
							}
						}
					}
					article.setNews(tempList);
				}
			}
			fieldList = doc.getChildren("str");
			for(Element tempEle: fieldList)
			{
				String fieldName = tempEle.getAttributeValue("name");
				if(fieldName.equals("copyright"))
				{
					article.setCopyright(tempEle.getTextNormalize());
				}
				else if(fieldName.equals("exclusive"))
				{
					if(tempEle.getTextNormalize().equalsIgnoreCase("yes"))
					{
						article.setExclusive(Boolean.TRUE);
					}
					else
					{
						article.setExclusive(Boolean.FALSE);
					}
				}
				else if(fieldName.equals("headline"))
				{
					article.setHeadline(tempEle.getTextNormalize().replaceAll("\n", " "));
				}
				else if(fieldName.equals("location"))
				{
					article.setLocation(tempEle.getTextNormalize());
				}
				else if(fieldName.equals("publication"))
				{
					article.setPublication(tempEle.getTextNormalize());
				}
				else if(fieldName.equals("source"))
				{
					article.setSource(tempEle.getTextNormalize());
				}
				else if(fieldName.equals("id"))
				{
					article.setId(Utility.convertToInteger(tempEle.getTextNormalize(), -1));
				}
			}
			fieldList = doc.getChildren("date");
			for(Element tempEle: fieldList)
			{
				String fieldName = tempEle.getAttributeValue("name");
				if(fieldName.equals("contentdate"))
				{
					article.setContentDate(tempEle.getTextNormalize().split("T")[0]);
				}
			}
			article.setAccessStatus(pubStatus);
			articles.add(article);
		}
		return articles;
	}

	public static Boolean deleteImageIndex(String paramName, String paramValue)
	{
		Boolean result = Boolean.FALSE;
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.URL));
			solrServer.deleteByQuery(paramName+":" + HTSPortal.PERA + paramValue + HTSPortal.PERA);
			solrServer.commit();
			result = Boolean.TRUE;
		}
		catch(Exception e)
		{
			LOGGER.error(e.getMessage());
		}

		return result;
	}
	
	public static Boolean deleteArticleIndex(String paramName, String paramValue)
	{
		Boolean result = Boolean.FALSE;
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.URL));
			solrServer.deleteByQuery(paramName+":" + HTSPortal.PERA + paramValue + HTSPortal.PERA);
			solrServer.commit();
			result = Boolean.TRUE;
		}
		catch(Exception e)
		{
			LOGGER.error(e.getMessage());
		}

		return result;
	}

	public static StringBuffer printValues(Object[]objs)
	{
		StringBuffer result = new StringBuffer();
		if(objs != null)
		{
			for(Object obj: objs)
			{
				result.append(obj + ", ");
			}
		}
		return result;
	}

	
	public static String forcefullyURLEncoded(String url)
	{
		try
		{
			url = URLEncoder.encode(url, "utf-8");
		}catch(Exception e){
			LOGGER.error("Unable to encode '"+url+"' in utf-8 format");
		}
		return url;
	}

	/**
	 * 
	 * @param image
	 * @return
	 */
	@SuppressWarnings("static-access")
	public static String getImageCaption(File image)
	{
		String caption = "";
		try
		{
			Metadata metadata = ImageMetadataReader.readMetadata(image);
			IptcDirectory iptcDirectory = metadata.getDirectory(IptcDirectory.class);
			caption = replaceBadCharacter(iptcDirectory.getDescription(iptcDirectory.TAG_CAPTION));

		}
		catch(Exception e)
		{
			LOGGER.error(e.getMessage()+ "["+ image.getName()+"]");
		}
		return caption;
	}

	public static ImageVO getImageMetadata(File sourceFile)
	{
		ImageVO imageVO = new ImageVO();
		try
		{
			Metadata metadata = ImageMetadataReader.readMetadata(sourceFile);
			IptcDirectory iptcDirectory = metadata.getDirectory(IptcDirectory.class);
			String value = iptcDirectory.getDescription(iptcDirectory.TAG_HEADLINE);
			if(value != null && value.length() > 0 && !value.equalsIgnoreCase("null"))
			{
				imageVO.setTitle(value);
			}
			
			value = iptcDirectory.getDescription(iptcDirectory.TAG_CAPTION);
			if(value != null && value.length() > 0 && !value.equalsIgnoreCase("null"))
			{
				imageVO.setDetails(value);
			}
			
			value = iptcDirectory.getDescription(iptcDirectory.TAG_BY_LINE);
			if(value != null && value.length() > 0 && !value.equalsIgnoreCase("null"))
			{
				imageVO.setAuthor(value);
			}
//			imageVO.setAuthor(iptcDirectory.getDescription(iptcDirectory.TAG_BY_LINE)+": "+iptcDirectory.getDescription(iptcDirectory.TAG_BY_LINE_TITLE));
			
			value = iptcDirectory.getDescription(iptcDirectory.TAG_COPYRIGHT_NOTICE);
			if(value != null && value.length() > 0 && !value.equalsIgnoreCase("null"))
			{
				imageVO.setCopyright(value);
			}
			
			value = iptcDirectory.getDescription(iptcDirectory.TAG_KEYWORDS);
			if(value != null && value.length() > 0 && !value.equalsIgnoreCase("null"))
			{
				imageVO.setKeywords(value);
			}
			value = iptcDirectory.getDescription(iptcDirectory.TAG_IMAGE_ORIENTATION);
			if(value != null && value.length() > 0 && !value.equalsIgnoreCase("null"))
			{
				imageVO.setOrientation(value);
			}
			//			iptcDirectory.TAG_DATE_CREATED: Sun Jan 06 00:00:00 IST 2013
			value = iptcDirectory.getDescription(iptcDirectory.TAG_DATE_CREATED);
//			System.out.println(value);
			if(value != null && value.length() > 0 && !value.equalsIgnoreCase("null"))
			{
				imageVO.setCapturedate(stringToDate(value, 8));
			}
		}
		catch(Exception e)
		{
			LOGGER.error(e.getMessage()+ "["+ sourceFile.getName()+"]");
		}
		return imageVO;
	}

	public static String getChecksum(File inputFile)
	{
		String checksum = null;
		try{
			MessageDigest md = MessageDigest.getInstance("SHA1");
			FileInputStream fis = new FileInputStream(inputFile);
			byte[] dataBytes = new byte[1024];
			int nread = 0;   
			while ((nread = fis.read(dataBytes)) != -1) {  
				md.update(dataBytes, 0, nread);  
			};  
			byte[] mdbytes = md.digest();  
			//convert the byte to hex format  
			StringBuffer sb = new StringBuffer("");  
			for (int i = 0; i < mdbytes.length; i++) {  
				sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));  
			}  
//			System.out.println("Digest(in hex format):: " + sb.toString());
			checksum = sb.toString();
		}catch(Exception e)
		{
			LOGGER.error(e.getMessage()+ "[Checksum Error Generator]");
		}
		return checksum;
	}
	/**
	 * 
	 * @param to
	 * @param subject
	 * @param messageTxt
	 */
	public static void sendMail(String to, String subject, String messageTxt) 
	{
		Session mailsession = null;
		Properties props = new Properties();
		props.put(HTSPortal.MAIL.MAILSMTPHOST, APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.MAIL.MAILSMTPHOST));
		props.put(HTSPortal.MAIL.MAILSMTPPORT, APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.MAIL.MAILSMTPPORT));
		props.put(HTSPortal.MAIL.MAILSMTPAUTH, APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.MAIL.MAILSMTPAUTH));
		Transport transport = null;
		try 
		{
			mailsession = Session.getInstance(props, null);
			MimeMessage message = new MimeMessage(mailsession);
			message.setFrom(new InternetAddress(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.MAIL.MAILSMTPADMIN)));
			message.addRecipients(javax.mail.Message.RecipientType.TO, to);
			message.setSubject(subject);
			message.setSentDate(new Date());
			message.setContent(messageTxt, "text/html");
			message.removeHeader("X-AntiAbuse");
			message.saveChanges();

			transport = mailsession.getTransport("smtp");
			transport.connect();
			transport.sendMessage(message, message.getAllRecipients());
		} 
		catch (Exception e) 
		{
			LOGGER.error("MAIL: " + e.getMessage());
		}
		finally
		{
			try
			{
				transport.close();
			}
			catch (MessagingException e)
			{
			}
		}

	}

	public static Boolean moveFile(File srcFile, File desFile)
	{
		Boolean result = Boolean.FALSE;
		if(srcFile.exists())
		{
			if(desFile.exists())
			{
				desFile.delete();
			}
			if(srcFile.renameTo(desFile))
			{
				result = Boolean.TRUE;
			}
		}
		return result;
	}

	public static synchronized Boolean resizeImage(File inputImage, File outputImage, Boolean forcedSize, Boolean tiles, Integer width, Integer height, File watermarkFile, Float opeque)
	{
		Boolean result = Boolean.FALSE;
		LOGGER.info("Before Resize Image Heap Size in MB: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024));
		try{
			Thumbnails.Builder builder = Thumbnails.of(inputImage);
			if(forcedSize)
			{
				builder.forceSize(width, height);
			}
			else
			{
				builder.size(width, height);
			}
			builder.outputFormat("jpg")
			.watermark(Positions.CENTER, ImageIO.read(watermarkFile), opeque);
			if(tiles)
			{
				builder.watermark(Positions.BOTTOM_CENTER, ImageIO.read(watermarkFile), opeque)
		        .watermark(Positions.BOTTOM_LEFT, ImageIO.read(watermarkFile), opeque)
		        .watermark(Positions.BOTTOM_RIGHT, ImageIO.read(watermarkFile), opeque)
		        .watermark(Positions.CENTER_LEFT, ImageIO.read(watermarkFile), opeque)
		        .watermark(Positions.CENTER_RIGHT, ImageIO.read(watermarkFile), opeque)
		        .watermark(Positions.TOP_CENTER, ImageIO.read(watermarkFile), opeque)
		        .watermark(Positions.TOP_LEFT, ImageIO.read(watermarkFile), opeque)
		        .watermark(Positions.TOP_RIGHT, ImageIO.read(watermarkFile), opeque);
			}
			builder.outputQuality(1.0f)
			.toFile(outputImage);
			result = Boolean.TRUE;
		}catch(Exception e){
//			e.printStackTrace();
			LOGGER.error("Image resize error:: " + e.getMessage());
		}
		LOGGER.info("After Resize Image Heap Size in MB: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024));
		try{
			if((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024) > 150)
			{
				System.gc();
				LOGGER.info("System Garbage Collector Initiated");
			}
		}catch(Exception e){}
		return result;
	}
	
	public static Boolean resizeImage(File inputImage, File outputImage, Boolean tiles, Integer width, Integer height, File watermarkFile, Float opeque)
	{
		return resizeImage(inputImage, outputImage, Boolean.FALSE, tiles, width, height, watermarkFile, opeque);
	}
	
	public static Boolean resizeImage(File inputImage, File outputImage, Integer width, Integer height, File watermarkFile, Float opeque)
	{
		return resizeImage(inputImage, outputImage, Boolean.FALSE, Boolean.FALSE, width, height, watermarkFile, opeque);
	}
	
	public static Boolean resizeImage(String inputImage, String outputImage, Boolean forcedSize, Boolean tiles, Integer width, Integer height, String watermarkFile, Float opeque)
	{
		return resizeImage(new File(inputImage), new File(outputImage), forcedSize, tiles, width, height, new File(watermarkFile), opeque);
	}
	
	/*public static synchronized Boolean resizeImage(String inputImage, String outputImage, Integer width, Integer height, String watermarkFile, Double brightness)
	{	Boolean result = Boolean.FALSE;
		LOGGER.info("IMAGE Resize Input:  " + inputImage);
		LOGGER.info("IMAGE Resize Output: " + outputImage);
		ProcessStarter.setGlobalSearchPath(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.ENVIRONMENTPATH));
		IMOperation op = new IMOperation();
		op.addImage();
		op.resize(width, height);
		op.gravity("center");
		op.addImage();
		ConvertCmd convert = new ConvertCmd();

		try {
			convert.run(op, inputImage, outputImage);
			result = Boolean.TRUE;
		} catch (CommandException ce) {
			LOGGER.error("IMAGE Resize: " + ce.getMessage());
			ArrayList<String> cmdError = ce.getErrorText();
			for (String line:cmdError) {
				LOGGER.error("IMAGE Resize Error: "+line);
			}
		} catch (Exception e) {
			LOGGER.error("IMAGE Resize: " + e.getMessage());
			e.printStackTrace();
		}
		if(result && watermarkFile!=null)
		{
			result = Boolean.FALSE;
			op = new IMOperation();
			op.watermark(brightness);
			op.tile();
			op.addImage();
			op.addImage();
			op.addImage();
			CompositeCmd composite = new CompositeCmd();
			try {
				composite.run(op, watermarkFile, outputImage, outputImage);
				result = Boolean.TRUE;
			} catch (CommandException ce) {
				LOGGER.error("IMAGE Resize: " + ce.getMessage());
				ce.printStackTrace();
				ArrayList<String> cmdError = ce.getErrorText();
				for (String line:cmdError) {
					LOGGER.error("IMAGE Resize Error: "+line);
				}
			} catch (Exception e) {
				LOGGER.error("IMAGE Resize: " + e.getMessage());
				e.printStackTrace();
			}
		}
		return result;
	}*/

	public static String getImageSolrSearchURL(final String RESULT_PER_REQUEST)
	{
		StringBuffer url = new StringBuffer();
		//contentdate:[NOW-1MONTH/DAY TO NOW/DAY+1DAY]
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.URL));
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.SEARCH));
		url.append(HTSPortal.PATHSEPERATER);
		url.append(HTSPortal.Solr.PARAMETER_SEPRATER);
		url.append(HTSPortal.Solr.XML_VERSION);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.XML_VERSION));
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.ROWS_PER_PAGE);
		url.append(HTSPortal.EQUAL);
		url.append(RESULT_PER_REQUEST);
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.INDENT);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.INDENT));
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.FACET);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.FACET));
		for(String name : SOLR_PROFILE_CONFIGURATION_READER.getList(HTSPortal.Solr.Image.FACET_FIELD_VALUE))
		{
			url.append(HTSPortal.Solr.FIELD_SEPRATER);
			url.append(HTSPortal.Solr.FACET_FIELD);
			url.append(HTSPortal.EQUAL);
			url.append(name);
		}
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.SORT);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.SORT_FIELD));
		url.append(HTSPortal.URL_BLANK);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.SORT_ORDER));
		return url.toString();

	}
	
	/**
	 * 
	 * @return
	 */
	public static String getArticleSolrSearchURL(final String RESULT_PER_REQUEST)
	{
		StringBuffer url = new StringBuffer();
		//contentdate:[NOW-1MONTH/DAY TO NOW/DAY+1DAY]
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.URL));
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.SEARCH));
		url.append(HTSPortal.PATHSEPERATER);
		url.append(HTSPortal.Solr.PARAMETER_SEPRATER);
		url.append(HTSPortal.Solr.XML_VERSION);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.XML_VERSION));
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.ROWS_PER_PAGE);
		url.append(HTSPortal.EQUAL);
		url.append(RESULT_PER_REQUEST);
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.INDENT);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.INDENT));
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.FACET);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.FACET));
		for(String name : SOLR_PROFILE_CONFIGURATION_READER.getList(HTSPortal.Solr.Article.FACET_FIELD_VALUE))
		{
			url.append(HTSPortal.Solr.FIELD_SEPRATER);
			url.append(HTSPortal.Solr.FACET_FIELD);
			url.append(HTSPortal.EQUAL);
			url.append(name);
		}
		url.append(HTSPortal.Solr.FIELD_SEPRATER);
		url.append(HTSPortal.Solr.SORT);
		url.append(HTSPortal.EQUAL);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.SORT_FIELD));
		url.append(HTSPortal.URL_BLANK);
		url.append(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.SORT_ORDER));
		return url.toString();
	}
	
	public static Map<Short, String> getImagetagsTypes()
	{
		Map<Short, String> typeList = new HashMap<Short, String>();
		typeList.put(ImagetagsType.NORMAL, ImagetagsType.typeName[ImagetagsType.NORMAL]);
		typeList.put(ImagetagsType.SECTION, ImagetagsType.typeName[ImagetagsType.SECTION]);
		return typeList;
	}
	
	public static Map<Short, String> getAllPublicationStatus()
	{
		Map<Short, String> statusList = new HashMap<Short, String>();
		statusList.put(AccessStatus.DISABLE, "Disable");
		statusList.put(AccessStatus.DISABLE, "Disable");
		statusList.put(AccessStatus.SHORT_ACCESS, "Short Access");
		statusList.put(AccessStatus.FULL_ACCESS, "Full Access");
		statusList.put(AccessStatus.FULL_RESTRICTED, "Full Restricted");
		return statusList;
	}
	
	public static Map<Short, String> getAllUserStatus()
	{
		Map<Short, String> statusList = new HashMap<Short, String>();
		statusList.put(AccessStatus.ENABLE, "Enable");
		statusList.put(AccessStatus.DISABLE, "Disable");
		return statusList;
	}
	
	public static Map<Short, String> getAllUserRoleStatus(Short role)
	{
		Map<Short, String> roleList = new HashMap<Short, String>();
		if(role.equals(RoleStatus.SITE_ADMIN))
		{
			roleList.put(RoleStatus.SITE_ADMIN, RoleStatus.roleName[RoleStatus.SITE_ADMIN]);
			roleList.put(RoleStatus.GRAPHICS_ADMIN, RoleStatus.roleName[RoleStatus.GRAPHICS_ADMIN]);
			roleList.put(RoleStatus.CONTENT_ADMIN, RoleStatus.roleName[RoleStatus.CONTENT_ADMIN]);
			roleList.put(RoleStatus.REVENUEADMIN, RoleStatus.roleName[RoleStatus.REVENUEADMIN]);
			roleList.put(RoleStatus.VENDOR, RoleStatus.roleName[RoleStatus.VENDOR]);
			roleList.put(RoleStatus.CLIENT, RoleStatus.roleName[RoleStatus.CLIENT]);
			roleList.put(RoleStatus.VISITORS, RoleStatus.roleName[RoleStatus.VISITORS]);
		}
		else if(role.equals(RoleStatus.CONTENT_ADMIN))
		{
			roleList.put(RoleStatus.CONTENT_ADMIN, RoleStatus.roleName[RoleStatus.CONTENT_ADMIN]);
			roleList.put(RoleStatus.VENDOR, RoleStatus.roleName[RoleStatus.VENDOR]);
			roleList.put(RoleStatus.CLIENT, RoleStatus.roleName[RoleStatus.CLIENT]);
		}
		else if(role.equals(RoleStatus.GRAPHICS_ADMIN))
		{
			roleList.put(RoleStatus.GRAPHICS_ADMIN, RoleStatus.roleName[RoleStatus.GRAPHICS_ADMIN]);
		}
		else if(role.equals(RoleStatus.REVENUEADMIN))
		{
			roleList.put(RoleStatus.REVENUEADMIN, RoleStatus.roleName[RoleStatus.REVENUEADMIN]);
		}
		return roleList;
	}
	
	public static Map<Short, String> getAllTimeInterval()
	{
		Map<Short, String> intervalList = new HashMap<Short, String>();
		intervalList.put(TimeInterval.MONTHLY, TimeInterval.intervalName[TimeInterval.MONTHLY]);
		intervalList.put(TimeInterval.QUARTERLY, TimeInterval.intervalName[TimeInterval.QUARTERLY]);
		intervalList.put(TimeInterval.THRICE_YEARLY, TimeInterval.intervalName[TimeInterval.THRICE_YEARLY]);
		intervalList.put(TimeInterval.HALF_YEARLY, TimeInterval.intervalName[TimeInterval.HALF_YEARLY]);
		intervalList.put(TimeInterval.YEARLY, TimeInterval.intervalName[TimeInterval.YEARLY]);
		return intervalList;
	}
	
	public static List<Short> getAllUserRoles(Short role)
	{
		List<Short> roles = new ArrayList<Short>();
		if(role.equals(RoleStatus.SITE_ADMIN))
		{
			roles.add(RoleStatus.SITE_ADMIN);
			roles.add(RoleStatus.GRAPHICS_ADMIN);
			roles.add(RoleStatus.CONTENT_ADMIN);
			roles.add(RoleStatus.REVENUEADMIN);
			roles.add(RoleStatus.VENDOR);
			roles.add(RoleStatus.CLIENT);
			roles.add(RoleStatus.VISITORS);
		}
		else if(role.equals(RoleStatus.CONTENT_ADMIN))
		{
			roles.add(RoleStatus.CONTENT_ADMIN);
			roles.add(RoleStatus.VENDOR);
			roles.add(RoleStatus.CLIENT);
		}
		else if(role.equals(RoleStatus.GRAPHICS_ADMIN))
		{
			roles.add(RoleStatus.GRAPHICS_ADMIN);
		}
		else if(role.equals(RoleStatus.REVENUEADMIN))
		{
			roles.add(RoleStatus.REVENUEADMIN);
		} 
		return roles;
	}

	public static Object getExcelCellValue(Cell cell, Workbook wb)
	{
		Object result = null;
		FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
		if (cell != null) {
		    switch (evaluator.evaluateFormulaCell(cell)) {
		        case Cell.CELL_TYPE_BOOLEAN:
		        	result = cell.getBooleanCellValue();
		            break;
		        case Cell.CELL_TYPE_NUMERIC:
		        	result = cell.getNumericCellValue();
		            break;
		        case Cell.CELL_TYPE_STRING:
		        	result = cell.getStringCellValue();
		            break;
		        case Cell.CELL_TYPE_BLANK:
		        	result = "";
		            break;
		        case Cell.CELL_TYPE_ERROR:
		        	result = cell.getErrorCellValue();
		            break;
		        // CELL_TYPE_FORMULA will never occur
		        case Cell.CELL_TYPE_FORMULA:
		            break;
		        case -1:
		        	result = cell.toString();
		            break;
		    }
		}
		return result;
	}
	
	
	public static Date getFirstDayOfYear(int year)
	{
//		System.out.println(year);
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, 0);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		return cal.getTime();
	}
	
	public static Date getLastDayOfYear(int year)
	{
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, 11);
		cal.set(Calendar.DAY_OF_MONTH, 31);
		return cal.getTime();
	}
	
	public static Calendar dateToCalendar(Date date){ 
	  Calendar cal = Calendar.getInstance();
	  cal.setTime(date);
	  return cal;
	}
	
	public static void getZipFiles(String sourceFile, String destinationFolder) {
	    try {
	        String destinationname = destinationFolder;
	        byte[] buf = new byte[1024];
	        ZipInputStream zipinputstream = null;
	        ZipEntry zipentry;
	        zipinputstream = new ZipInputStream(new FileInputStream(sourceFile));

	        zipentry = zipinputstream.getNextEntry();
	        while (zipentry != null) {
	            //for each entry to be extracted
	            String entryName = destinationname + zipentry.getName();
	            entryName = entryName.replace('/', File.separatorChar);
	            entryName = entryName.replace('\\', File.separatorChar);
//	            System.out.println("entryname " + entryName);
	            int n;
	            FileOutputStream fileoutputstream;
	            File newFile = new File(entryName);
	            if (zipentry.isDirectory()) {
	                if (!newFile.mkdirs()) {
	                    break;
	                }
	                zipentry = zipinputstream.getNextEntry();
	                continue;
	            }

	            fileoutputstream = new FileOutputStream(entryName);

	            while ((n = zipinputstream.read(buf, 0, 1024)) > -1) {
	                fileoutputstream.write(buf, 0, n);
	            }

	            fileoutputstream.close();
	            zipinputstream.closeEntry();
	            zipentry = zipinputstream.getNextEntry();

	        }//while

	        zipinputstream.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static void main(String[] args)
	{
		/*try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.URL));
			solrServer.deleteByQuery("*:*");
			solrServer.commit();
		}
		catch(Exception e)
		{
			LOGGER.error(e.getMessage());
		}*/
		/*
		try {
	//		HttpSolrServer solr = new HttpSolrServer("http://localhost:8983/solr");
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.URL));
			SolrQuery query = new SolrQuery();
		    query.setQuery("*:*");
		    query.setFacet(true);
		    query.setFacetMinCount(1);
		    query.addFacetField("category");
		    query.addFacetField("publication").setFacetLimit(2);
		    query.setFacetLimit(2);
		    query.addFacetField("source");
		    query.addFilterQuery("category:Business & Finance","publication:*");
//		    query.setFields("id","price","merchant","cat","store");
		    query.setStart(0);
//		    query.set("defType", "edismax");
		    query.setRows(5000);
		    QueryResponse response = solrServer.query(query);
		    SolrDocumentList results = response.getResults();
		    System.out.println(response.getFieldStatsInfo());
		    for (int i = 0; i < results.size(); ++i) {
//		    	System.out.println(results.get(i));
		    	System.out.println(results.get(i).getFieldValue("headline"));
		    	System.out.println(results.get(i).getFieldValue("publication"));
		    	System.out.println(results.get(i).getFieldValue("source"));
		    	System.out.println("\n");
		    }
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
	}
}