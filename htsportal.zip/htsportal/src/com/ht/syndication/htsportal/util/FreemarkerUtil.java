package com.ht.syndication.htsportal.util;

import org.apache.commons.httpclient.util.URIUtil;

public class FreemarkerUtil {
	public FreemarkerUtil() {}

	public String getEncodeParameter(String str, Boolean replaceForSlug) {
		String result = str;
		if(replaceForSlug && result != null) {
			result = result.replaceAll("( |\t)+", "-");
			result = result.replace("&", "and");
			result = result.replace("%", "percent");
		}
		try {
			result = URIUtil.encodeWithinQuery(result);
		} catch(Exception e) {
		}
		return result;
		
	}
	
	public String getEncodeParameter(String str) {
		return getEncodeParameter(str, Boolean.FALSE);
	}
}
