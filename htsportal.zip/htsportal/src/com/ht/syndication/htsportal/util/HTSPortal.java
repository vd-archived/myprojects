package com.ht.syndication.htsportal.util;

import java.util.Properties;

public final class HTSPortal 
{
	private HTSPortal(){}
	public static final String UserConst = "htsbond007";
	
	public static final String PATHSEPERATER = "/";
	
	public static final String ADMIN = "Admin";
	
	public static final String FTP_PROFILE              = "ftpProfile.xml";
	
	public static final String SOLR_PROFILE             = "solrProfile.xml";
	
	public static final String APPLICATION_PROFILE      = "appProfile.xml";
	
	public static final String EQUAL            		= "=";
	
	public static final String URL_BLANK            	= "%20";
	
	public static Properties SERVLETCONTEXT     		= null;
	
	public static final String URL               		= "url";
	
	public static final String LINKURL               		= "linkurl";
	
	/**
     * Contains names of configuration properties for the Application.
     */
    public static final class QUARTZ
    {
        /**
         * Made private to prevent instances from being created.
         */
        private QUARTZ()
        {
        }

        public static final String CONTENTINTERVAL     			= "quartz.content.interval";
    	public static final String IMAGEINTERVAL     			= "quartz.image.interval";

    }
    
	public static final String ADMIN_EMAIL_ADDRESS 		= "adminEmailAddress";
	
	public static final String SUBJECT     				= "defaultSubject";
	
	public static final String PERA               		= "\"";
	
	public static final String YES               		= "YES";
	
	public static final String NO               		= "NO";
	
	
	/**
     * Contains names of configuration properties for the Application.
     */
    public static final class APP
    {
        /**
         * Made private to prevent instances from being created.
         */
        private APP()
        {
        }

        public static final String MAILTOSUBSCRIPTIONADMIN = "subscriptionmailadmin";
        public static final String MAXPROCESS = "maxprocess";

    }
    
    /**
     * Contains names of configuration properties for the Application.
     */
    public static final class MAIL
    {
        /**
         * Made private to prevent instances from being created.
         */
        private MAIL()
        {
        }
        public static final String MAILSMTPHOST = "mail.smtp.host";
        public static final String MAILSMTPPORT = "mail.smtp.port";
        public static final String MAILSMTPAUTH = "mail.smtp.auth";
        public static final String MAILSMTPUSER = "mail.smtp.user";
        public static final String MAILSMTPPASS = "mail.smtp.pass";
        public static final String MAILSMTPADMIN = "mail.smtp.admin";
    }
	
	/**
     * Contains names of configuration properties for the Image.
     */
    public static final class IMAGE
    {
        /**
         * Made private to prevent instances from being created.
         */
        private IMAGE()
        {
        }
        
        public static final String TEMPDIRECTORY          = "image.path.temp";
    	public static final String ERRORDIRECTORY         = "image.path.error";

        public static final String IMAGEDIRECTORY         = "image.path.processed";
    	public static final String IMAGEPERPAGE           = "image.count.perpage";
    	public static final String ORIGINALIMAGEDIRECTORY = "image.path.original";
    	public static final String WATERMARKBRIGHTNESS	  = "image.path.watermark.brightness";
    	public static final String WATERMARKTILES 		  = "image.path.watermark.tiles";
    	
    	public static final String MEDIUM                 = "MEDIUM";
    	public static final String THUMB                  = "THUMB";
    	public static final String MEDIUM_450_350         = "MEDIUM_450_350";
    }
    
    /**
     * Contains names of configuration properties for the Image.
     */
    public static final class ARTICLE
    {
        /**
         * Made private to prevent instances from being created.
         */
        private ARTICLE()
        {
        }
        
        public static final String TEMPDIRECTORY          = "article.path.temp";
    	public static final String ERRORDIRECTORY         = "article.path.error";
    }
	
    /**
     * Contains names of configuration properties for the ftp.
     */
    public static final class FTP
    {
        /**
         * Made private to prevent instances from being created.
         */
        private FTP() {
        }
        
        public static final class Image
        {
        	private Image() {
            }
        	
        	public static final String URL          = "image.url";
            
            public static final String USERNAME     = "image.username";

            public static final String PASSWORD     = "image.password";

            public static final String ROOT_PATH 	= "image.rootpath";
            
            public static final String EVENTROOT    = "EVENTS";
            
            public static final String CATEGORYROOT = "CATEGORIES";
        }
        
        public static final class Article
        {
        	private Article() {
            }
        	
        	public static final String URL          = "article.url";
            
            public static final String USERNAME     = "article.username";

            public static final String PASSWORD     = "article.password";

            public static final String ROOT_PATH 	= "article.rootpath";
        }

        
    }

    /**
     * Contains names of configuration properties for the solr.
     */
    public static final class Solr
    {
        /**
         * Made private to prevent instances from being created.
         */
        private Solr()
        {
        }
        
        public static final String PARAMETER_SEPRATER	= "?";
        
        public static final String XML_VERSION			= "version";
        
        public static final String FIELD_SEPRATER		= "&";
        
        public static final String ROWS_PER_PAGE		= "rows";
        
        public static final String RESULT_PER_REQUEST	= "resultPerRequest";
        
        public static final String INDENT				= "indent";
        
        public static final String FACET				= "facet";
        
        public static final String FACET_FIELD			= "facet.field";
        
        public static final String SORT					= "sort";
        
        public static final class Image
        {
        	private Image()
            {
            }
        	
        	public static final String SORT_FIELD			= "image.sort.field";
            
            public static final String SORT_ORDER			= "image.sort.order";
        	
        	public static final String URL          		= "image.url";
        	
        	public static final String DISPLAY_CONTENT 		= "image.displayContent";
            
            public static final String SEARCH          		= "image.search";
            
            public static final String XML_VERSION			= "image.version";
            
            public static final String ROWS_PER_PAGE		= "image.rows";
            
            public static final String RESULT_PER_REQUEST	= "image.resultPerRequest";

            public static final String INDENT				= "image.indent";
            
            public static final String FACET				= "image.facet";
            
            public static final String FACET_FIELD_VALUE	= "image.facetField";
            
            public static final String EVENT				= "event";

            public static final String TAGS					= "tags";
            
            public static final String CONTENT				= "id";
        	
        }
        
        public static final class Article
        {
        	private Article()
            {
            }
        	
        	public static final String SORT_FIELD			= "article.sort.field";
            
            public static final String SORT_ORDER			= "article.sort.order";
        	
        	public static final String URL          		= "article.url";
        	
        	public static final String DISPLAY_CONTENT 		= "article.displayContent";
        	
            public static final String SEARCH          		= "article.search";
            
            public static final String XML_VERSION			= "article.version";
            
            public static final String ROWS_PER_PAGE		= "article.rows";
            
            public static final String RESULT_PER_REQUEST	= "article.resultPerRequest";

            public static final String INDENT				= "article.indent";
            
            public static final String FACET				= "article.facet";
            
            public static final String FACET_FIELD_VALUE	= "article.facetField";
            
            public static final String PUBLICATION			= "publication";

            public static final String SOURCE				= "source";
            
            public static final String CATEGORY				= "category";
            
            public static final String CONTENT				= "id";
        }
    }

    /**
     * Contains names of configuration properties for the xml file.
     */
    public static final class XMLFile
    {
        /**
         * Made private to prevent instances from being created.
         */
        private XMLFile()
        {
        }

    	public static final String BYLINE 		= "ByLine";
    	
    	public static final String CONTENTDATE 	= "ContentDate";
    	
    	public static final String HEADLINE 	= "Headline";
    	
    	public static final String CONTENT 		= "BodyContent";
    	
    	public static final String SECTION 		= "Section";
    	
    	public static final String LOCATION 	= "Location";
    	
    	public static final String CONTENTID 	= "UniqID";
    	
    	public static final String COPYRIGHT 	= "Copyright";
        
    	public static final String SOURCE 		= "Source";
    	
    	public static final String CATEGORY 	= "Category";
    	
    	public static final String PUBLICATION 	= "PublicationName";
    	
    	public static final String IMAGE 	    = "Image";
    	
    }
    
    public static final class Astro
    {
    	private Astro()
    	{
    	}
    	public static final String GANESHA = "astro.ganesha"; 
    }

    /**
     * Contains names of configuration properties for the xml file.
     */
    public static final class SECTIONS
    {
        /**
         * Made private to prevent instances from being created.
         */
        private SECTIONS()
        {
        }

        public static final String HOMESECTIONSIZE1 		= "sections.homesection1.size";
    }
    
    public static final class DOWNLOADTYPE
    {
    	private DOWNLOADTYPE() {
    	}
    	
    	public static final String[]ARTICLEENDSWITH = new String[]{".xml"};
    	public static final String[]IMAGEENDSWITH = new String[]{".jpg", ".jpeg", ".png"};
    }
}