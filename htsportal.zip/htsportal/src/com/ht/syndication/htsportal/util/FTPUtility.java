package com.ht.syndication.htsportal.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.opensymphony.xwork2.util.logging.Logger;

public final class FTPUtility {

	private static final Log LOGGER = LogFactory.getLog(FTPUtility.class);
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

	private FTPUtility(){}

	/**
	 * 
	 * @param ftpUrl
	 * @param ftpUserName
	 * @param ftpPassword
	 * @return
	 */
	public static FTPClient getFtpConnection(String ftpUrl,String ftpUserName,String ftpPassword) {
		FTPClient client = new FTPClient();
		try {
			LOGGER.info("FTP Connection Request Start: url ["+ftpUrl+"] using username ["+ftpUserName+"] and password " + ftpPassword);
			client.connect(ftpUrl);
			int reply = client.getReplyCode(); 
			if(!FTPReply.isPositiveCompletion(reply)) {
				try {
					client.disconnect();
				} catch (Exception e) { 
					LOGGER.error("FTP server  ["+ftpUrl+"] refused connection.");
					throw new Exception ("FTP server  ["+ftpUrl+"] refused connection.");
				}
			}
			if (!client.login(ftpUserName, ftpPassword)) {
				LOGGER.error("Unable to login to FTP server ["+ftpUrl+"] using username ["+ftpUserName+"] and password ");
				throw new Exception ("Unable to login to FTP server ["+ftpUrl+"] using username ["+ftpUserName+"] and password ");  
			}
			LOGGER.info("FTP Connection request end with reply code: " + client.getReplyCode());
		} catch(Exception e) {
			LOGGER.error(e.getMessage());
		}
		return client;
	}

	public static void closeFtpConnection(FTPClient client) throws IOException {
		client.disconnect();
	}


	/**
	 * 
	 * @param rootpath
	 * @param client
	 * @throws IOException
	 */
	public static Boolean downloadFiles(String rootpath, FTPClient client, String[]articleEndsWith, String tempDirectory) throws IOException {
		return downloadFiles(rootpath, client, null, articleEndsWith, tempDirectory);
	}

	/**
	 * 
	 * @param rootpath
	 * @param client
	 * @throws IOException
	 */
	
	public static Boolean createFolders(List<String>dirPaths, String ftpUrl, String ftpUserName, String ftpPassword) throws IOException {
		LOGGER.info("Start Create Folder Batch");
		Boolean result = Boolean.FALSE;
		FTPClient ftpClient = getFtpConnection(ftpUrl, ftpUserName , ftpPassword);
		if(ftpClient.getReplyCode() == 230)
		{
			for(String dir: dirPaths)
			{
//				LOGGER.info("Going to create FTP Directory: " + ftpClient.printWorkingDirectory() + "/" + dir);
				if(!isDirectoryExists(ftpClient, dir))
				{
					ftpClient.mkd(dir);
				}
			}
			FTPUtility.closeFtpConnection(ftpClient);
			result = Boolean.TRUE;
		}
		else
		{
			LOGGER.error("Unable to connect ftp serrver");
		}
		LOGGER.info("END Create Folder");
		return result;
	}
	
	public static Boolean isDirectoryExists(FTPClient ftpClient, String directoryPath)
	{
		Boolean result = Boolean.TRUE;
		try{
			String basePath = ftpClient.printWorkingDirectory();
			ftpClient.changeWorkingDirectory(directoryPath);
	        Integer returnCode = ftpClient.getReplyCode();
	        if (returnCode == 550) {
	        	result = Boolean.FALSE;
	        }
	        ftpClient.changeWorkingDirectory(basePath);
		}catch(Exception e)
		{
			LOGGER.error("Unable to change ftp directory");
		}
		return result;
	}
	
	public static Boolean downloadFiles(String rootpath, FTPClient client, Integer maxDownload, String[]articleEndsWith, String tempDirectory) throws IOException {
		LOGGER.info("Downloading Started..................");
		Boolean result = Boolean.TRUE;
		client.setFileType(FTP.BINARY_FILE_TYPE);
//		LOGGER.info("Going to : " + client.printWorkingDirectory() +"/"+ rootpath);
		client.changeWorkingDirectory(client.printWorkingDirectory() +"/"+ rootpath);
//		LOGGER.info("Right Now at : " + client.printWorkingDirectory());
		File dir = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(tempDirectory));
		Integer downloadCounter = 0;
		downloadCounter = downloadFiles(client, null, dir, maxDownload, downloadCounter, articleEndsWith);
		if(downloadCounter < maxDownload) {
			result = Boolean.FALSE;
		}
//		LOGGER.info("Downloading Completed: " + result);
		return result;
	}

	public static Integer downloadFiles(FTPClient client, FTPFile ftpFile, File dir, Integer maxDownload, Integer downloadCounter, String[]articleEndsWith) throws IOException {
		if (ftpFile != null && ftpFile.isFile()) {
			if(isFileEndWith(ftpFile.getName(), articleEndsWith))
			{
//				LOGGER.info("FTP File Detected");
				dir.mkdirs();
				dir = new File(dir, ftpFile.getName());
				Boolean success = Boolean.FALSE;
				if (!(dir.exists() && ftpFile.getSize() != dir.length() )) {
					FileOutputStream fos = new FileOutputStream(dir);
					success = client.retrieveFile(ftpFile.getName(), fos);
					fos.close();
//					LOGGER.info("FTP File (" + dir.getAbsolutePath() + ") copied successfully...");
				}
				if(success) {
//					LOGGER.info("FTP File (" + ftpFile.getName() + ") deleted successfully...");
					client.deleteFile(ftpFile.getName());
					downloadCounter++;
				}
			}
		} else if(ftpFile == null || ftpFile.isDirectory() && !ftpFile.getName().equals(".") && !ftpFile.getName().equals("..")) {
//			LOGGER.info("FTP Folder Detected");
			if(ftpFile != null)
			{
				dir = new File(dir, ftpFile.getName());
			}
			dir.mkdirs();
			FTPFile[] listFile = client.listFiles();
			for (FTPFile tempFtpFile: listFile) {
				try {
					if (tempFtpFile.isFile()) {
						downloadCounter = downloadFiles(client, tempFtpFile, dir, maxDownload, downloadCounter, articleEndsWith);
					} else if(tempFtpFile.isDirectory()) {
						String currentPath = client.printWorkingDirectory();
	//					LOGGER.info("Next FTP Folder To Deep In: " + tempFtpFile.getName());
	//					LOGGER.info("Current Path: " + currentPath +"/"+ tempFtpFile.getName());
						client.changeWorkingDirectory(currentPath +"/"+ tempFtpFile.getName());
	//					LOGGER.info("After Path Changed: " + client.printWorkingDirectory());
						downloadCounter = downloadFiles(client, tempFtpFile, dir, maxDownload, downloadCounter, articleEndsWith);
						client.changeWorkingDirectory(currentPath);
					}
				} catch(Exception e) {
					e.printStackTrace();
					LOGGER.error("Unable to download the file [ " + tempFtpFile.getName() + " ] " + e.getMessage());
				}
				if(maxDownload!=null && downloadCounter >= maxDownload) {
					break;
				}
			}
		}
		return downloadCounter;
	}
	
	public static Boolean isFileEndWith(String name, String[]articleEndsWith)
	{
		Boolean result = Boolean.FALSE;
		for(String endStr: articleEndsWith)
		{
			if(name.toLowerCase().endsWith(endStr.toLowerCase()))
			{
				result = Boolean.TRUE;
				break;
			}
		}
		return result;
	}
	
	public static void getAllFilesFromDirectory(File directory, final List<File>fileList, Integer fetchLevel, String[]articleEndsWith)
	{
		getAllFilesFromDirectory(directory, fileList, fetchLevel, 0, articleEndsWith);
	}
	
	public static void getAllFilesFromDirectory(File directory, final List<File>fileList, Integer fetchLevel, Integer currentLevel, String[]articleEndsWith)
	{
		if(currentLevel == fetchLevel && directory.isFile() && FTPUtility.isFileEndWith(directory.getName(), articleEndsWith))
		{
			fileList.add(directory);
		}
		else if(directory.isDirectory() && currentLevel < fetchLevel)
		{
			currentLevel++;
			for(File file: directory.listFiles())
			{
				getAllFilesFromDirectory(file, fileList, fetchLevel, currentLevel, articleEndsWith);
			}
		}
	}
	
	public static void getAllFilesAndDirectory(File directory, final List<File>directoryList, final List<File>fileList, String[]articleEndsWith)
	{
		for(File file: directory.listFiles())
		{
			if(file.isFile() && isFileEndWith(file.getName(), articleEndsWith))
			{
				fileList.add(file);
			}
			else if(file.isDirectory())
			{
				directoryList.add(file);
			}
		}
	}
}