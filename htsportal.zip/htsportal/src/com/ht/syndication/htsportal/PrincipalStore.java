
package com.ht.syndication.htsportal;

/**
 * Stores the currently logged in Principal. The principal is passed
 * from another tier of the application (i.e. the web application).
 */
public final class PrincipalStore
{
    private static final ThreadLocal store = new ThreadLocal();

    /**
     * Get the user <code>principal</code>
     * for the currently executing thread.
     *
     * @return the current principal.
     */
    public static java.security.Principal get()
    {
        return (java.security.Principal)store.get();
    }

    /**
     * Set the <code>principal</code> for the currently
     * executing thread.
     *
     * @param name the user principal
     */
    @SuppressWarnings("unchecked")
	public static void set(final java.security.Principal principal)
    {
        store.set(principal);
    }
}
