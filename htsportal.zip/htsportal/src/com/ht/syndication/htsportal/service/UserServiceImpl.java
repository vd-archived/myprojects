package com.ht.syndication.htsportal.service;


import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ht.syndication.htsportal.domain.Publication;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.domain.RoleStatus;
import com.ht.syndication.htsportal.domain.User;
import com.ht.syndication.htsportal.domain.UserDao;
import com.ht.syndication.htsportal.transfer.LoginVO;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.Utility;


public class UserServiceImpl extends UserServiceBase
{
	private static final Log LOGGER = LogFactory.getLog(UserServiceImpl.class);
   
    
   @Override
    protected LoginVO handleAuthenticate(final String username, final String password) throws Exception
    {
        LoginVO result = new LoginVO();
        UserDao userDataAccessor = super.getUserDao();
        User user = (User)userDataAccessor.load(UserDao.TRANSFORM_NONE, username);
        String message = null;
		if(user==null)
		{
			message = "User name does not exists....";
			result.setUser(null);
		}
		else if(!user.getPassword().equals(password))
		{
			message = ("Password incorrect....");
			result.setUser(null);
		}
		else if(user.getStatus()!=1)
		{
			message = ("User ID is disabled....");
			result.setUser(null);
		}
		else{
			message = ("Login Successfully....");
			LOGGER.info(username + " logged in successfully" );
			result.setUser(userDataAccessor.toUserVO(user));
		}
		result.setMessage(message);
		
		return result;


    }

	@Override
	protected void handleDeleteUser(String username) throws Exception 
	{
		// TODO Auto-generated method stub
		
	}
	
	@Override
	protected UserVO handleGetUser(String username) throws Exception 
	{
		return (UserVO) super.getUserDao().load(UserDao.TRANSFORM_USERVO, username);
	}
	
	@Override
	protected List<UserVO> handleGetAllUsers(Short role) throws Exception 
	{
		UserDao userDataAccessor = super.getUserDao();
		List<Short> roles = Utility.getAllUserRoles(role);
		if(roles.size() == 0)
		{
			return null;
		}
		return Arrays.asList((UserVO[])userDataAccessor.loadAllByRoles(UserDao.TRANSFORM_USERVO, roles).toArray(new UserVO[0]));
	}

	@Override
	protected UserVO handleSaveUser(UserVO userVO, String userName) throws Exception 
	{
		UserVO resultVO = null;
		UserDao userDataAccessor = super.getUserDao();
		PublicationDao pubDataAccessor = super.getPublicationDao();
		User user = userDataAccessor.userVOToEntity(userVO);
		if(userVO.getPublication() != null)
		{
			Collection<Publication> publications = new HashSet<Publication>();
			Set<String> pubs = new HashSet<String>(userVO.getPublication());
			for(String pub: pubs)
			{
				if(pub.trim().length() > 0)
				{
					publications.add(pubDataAccessor.load(Integer.parseInt(pub)));
				}
			}
			user.setPublication(publications);
		}
		user.setUpdateBy(userName);
		resultVO = (UserVO)userDataAccessor.create(UserDao.TRANSFORM_USERVO, user);
		return resultVO;
	}
	
	@Override
	protected List<PublicationShortVO> handleGetAllPublication(String userName) throws Exception
	{
		UserDao userDataAccessor = super.getUserDao();
		PublicationDao pubDataAccessor = super.getPublicationDao();
        User user = (User)userDataAccessor.load(UserDao.TRANSFORM_NONE, userName);
        List<PublicationShortVO> result = null;
        if(user.getRole().equals(RoleStatus.SITE_ADMIN) || user.getRole().equals(RoleStatus.REVENUEADMIN))
        {
        	result = Arrays.asList((PublicationShortVO[])pubDataAccessor.loadAll(pubDataAccessor.TRANSFORM_PUBLISHER_SHORTVO).toArray(new PublicationShortVO[0]));
        }
        else
        {
        	result = Arrays.asList((PublicationShortVO[])pubDataAccessor.loadAllByUser(pubDataAccessor.TRANSFORM_PUBLISHER_SHORTVO, user).toArray(new PublicationShortVO[0]));
        }
        return result;
	}
}