package com.ht.syndication.htsportal.service;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.CategoryDao;
import com.ht.syndication.htsportal.domain.ContentDao;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.domain.SourceDao;
import com.ht.syndication.htsportal.transfer.ContentVO;

/**
 * <p>
 * Spring Service base class for <code>com.ht.syndication.htsportal.service.ContentService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see com.ht.syndication.htsportal.service.ContentService
 */
public abstract class ContentServiceBase implements ContentService
{

    private ContentDao contentDao;
    private PublicationDao publicationDao;
    private CategoryDao categoryDao;
    private SourceDao sourceDao;

    /**
	 * @return the contentDao
	 */
	public ContentDao getContentDao() 
	{
		return contentDao;
	}

	/**
	 * @param contentDao the contentDao to set
	 */
	public void setContentDao(ContentDao contentDao) 
	{
		this.contentDao = contentDao;
	}

	/**
	 * @return the publicationDao
	 */
	public PublicationDao getPublicationDao() 
	{
		return publicationDao;
	}

	/**
	 * @param publicationDao the publicationDao to set
	 */
	public void setPublicationDao(PublicationDao publicationDao) 
	{
		this.publicationDao = publicationDao;
	}

	/**
	 * @return the categoryDao
	 */
	public CategoryDao getCategoryDao() 
	{
		return categoryDao;
	}

	/**
	 * @param categoryDao the categoryDao to set
	 */
	public void setCategoryDao(CategoryDao categoryDao) 
	{
		this.categoryDao = categoryDao;
	}

	/**
	 * @return the sourceDao
	 */
	public SourceDao getSourceDao() 
	{
		return sourceDao;
	}

	/**
	 * @param sourceDao the sourceDao to set
	 */
	public void setSourceDao(SourceDao sourceDao) 
	{
		this.sourceDao = sourceDao;
	}

	/**
     * @see ContentService#deleteContent(String)
     */
    public ContentVO getContent(Integer id)
    {
        if (id == null)
        {
            throw new IllegalArgumentException("ContentService.getContent(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetContent(id);
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ContentService.getContent(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteContent(String)}
      */
    protected abstract ContentVO handleGetContent(Integer id) throws Exception;

    /**
     * @see ContentService#deleteContent(String)
     */
    public void deleteContent(Integer id)
    {
        if (id == null)
        {
            throw new IllegalArgumentException("ContentService.deleteContent(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteContent(id);
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ContentService.deleteContent(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteContent(int)}
      */
    protected abstract void handleDeleteContent(Integer id) throws Exception;

    /**
     * 
     */
    
    public Boolean indexContent()
    {
    	try
        {
            return this.handleIndexContent();
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ContentService.indexedContent()' --> " + th, th);
        }
    }
    
    
    public Boolean indexContent(Set<String> uniqueIds)
    {
    	try
        {
            return this.handleIndexContent(uniqueIds);
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ContentService.indexedContent()' --> " + th, th);
        }
    }

    
    /**
     * 
     */
    protected abstract Boolean handleIndexContent() throws Exception;
    
    protected abstract Boolean handleIndexContent(Set<String> uniqueIds) throws Exception;
    
    /**
     * @see ContentService#getAllContents()
     */
    public ContentVO[] getAllContent()
    {
        try
        {
            return this.handleGetAllContent();
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ContentService.getAllContent()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllContents()}
      */
    protected abstract ContentVO[] handleGetAllContent() throws Exception;

    public void saveBatchContent(String userName)
    {
    	try
        {
    		handleSaveBatchContent(userName);
        }
        catch (Throwable th)
        {
        	th.printStackTrace();
            throw new ContentServiceException("Error performing 'ContentService.saveBatchContent(List<ContentVO> content, String userName)' --> " + th, th);
        }
    }
    
    protected abstract void handleSaveBatchContent(String userName) throws Exception;
    
    
    /**
     * @see ContentService#saveContent(ContentVO)
     */
    public String saveContent(ContentVO content, String userName)
    {
    	List<String>errors = validateContentVO(content);
        if (userName == null || userName.trim().length() < 1 || userName.trim().length() > 30)
        {
        	errors.add("'userName' can not be null or empty or greater than 30 characters");
        }
        if(errors!=null && errors.size()>0)
    	{
    		StringBuffer errorsStr = new StringBuffer();
    		Integer count = 1;
    		for(String error : errors) 
    		{
    			errorsStr.append(count++).append(": ").append(error).append("\n");
    	    }
    		throw new IllegalArgumentException("ContentService.saveContent(ContentVO content, String userName):-\n"+errorsStr);
    	}
        try
        {
            return this.handleSaveContent(content, userName);
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ContentService.saveContent(ContentVO content, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveContent(ContentVO)}
      */
    protected abstract String handleSaveContent(ContentVO content, String userName) throws Exception;
    
    /**
     * @see ContentService#saveContent(ContentVO)
     */
    public String updateContent(ContentVO content, String updatedBy)
    {
    	List<String>errors = validateContentVO(content);
    	if (content.getId() == null)
        {
    		errors.add("'content.id' can not be null or empty");
        }
    	if (updatedBy == null || updatedBy.trim().length() < 1 || updatedBy.trim().length() > 30)
        {
    		errors.add("'updatedBy' can not be null or empty or greater than 30 characters");
        }
        if(errors!=null && errors.size()>0)
    	{
    		StringBuffer errorsStr = new StringBuffer();
    		Integer count = 1;
    		for(String error : errors) {
    			errorsStr.append(count++).append(": ").append(error).append("\n");
    	    }
    		throw new IllegalArgumentException("ContentService.updateContent(ContentVO content, String updatedBy):-\n"+errorsStr);
    	}
        try
        {
            return this.handleUpdateContent(content, updatedBy);
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ContentService.saveContent(ContentVO content)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #updateContent(int id, ContentVO)}
      */
    protected abstract String handleUpdateContent(ContentVO content, String updatedBy) throws Exception;

    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
    
    protected List<String> validateContentVO(ContentVO content)
    {
    	List<String>result = new ArrayList<String>();
    	if (content == null)
        {
    		result.add("'content' can not be null");
        }
    	else
    	{
    		if (content.getHeadline() == null || content.getHeadline().trim().length() < 1 || content.getHeadline().trim().length() > 1000)
            {
        		result.add("'content.headline' can not be null or empty or greater than 1000 characters");
            }
            if (content.getNews() == null || content.getNews().trim().length() < 1 || content.getNews().trim().length() > 20000)
            {
                result.add("'content.news' can not be null or empty or greater than 20000 characters");
            }
            if (content.getByline() != null && content.getByline().trim().length() > 200)
            {
                result.add("'content.byline' can not be null or empty or greater than 200 characters");
            }
            if (content.getSection() != null && content.getSection().trim().length() > 40)
            {
                result.add("'content.section' can not be null or empty or greater than 40 characters");
            }
            if (content.getLocation() == null || content.getLocation().trim().length() < 1 || content.getLocation().trim().length() > 60)
            {
                result.add("'content.location' can not be null or empty or greater than 60 characters");
            }
            if (content.getCopyright() != null && content.getCopyright().trim().length() > 200)
            {
                result.add("'content.copyright' can not be null or empty or greater than 200 characters");
            }
            if (content.getPublication() == null)
            {
                result.add("'content.publication' can not be null");
            }
            if (content.getSource() == null)
            {
                result.add("'content.source' can not be null");
            }
            if (content.getStatus() == null)
            {
                result.add("'content.status' can not be null");
            }
            if (content.getUniqueid() != null && content.getUniqueid().trim().length() > 20)
            {
            	result.add("'content.uniqueid' should be null or less than 21 characters");
            }
    	}
    	return result;
    }
}