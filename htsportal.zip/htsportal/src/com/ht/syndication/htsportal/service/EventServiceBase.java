package com.ht.syndication.htsportal.service;

import java.security.Principal;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.EventDao;
import com.ht.syndication.htsportal.transfer.EventVO;

/**
 * <p>
 * Spring Service base class for <code>EventService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see EventService
 */
public abstract class EventServiceBase implements EventService
{
    private EventDao eventDao;

    /**
     * Sets the reference to <code>event</code>'s DAO.
     */
    public void setEventDao(EventDao eventDao)
    {
        this.eventDao = eventDao;
    }

    /**
     * Gets the reference to <code>event</code>'s DAO.
     */
    protected EventDao getEventDao()
    {
        return this.eventDao;
    }

    /**
     * @see EventService#deleteEvent(java.lang.String)
     */
    public EventVO getEvent(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("EventService.getEvent(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetEvent(id);
        }
        catch (Throwable th)
        {
            throw new EventServiceException("Error performing 'EventService.getEvent(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteEvent(java.lang.String)}
      */
    protected abstract EventVO handleGetEvent(int id) throws Exception;

    /**
     * @see EventService#deleteEvent(java.lang.String)
     */
    public void deleteEvent(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("EventService.deleteEvent(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteEvent(id);
        }
        catch (Throwable th)
        {
            throw new EventServiceException("Error performing 'EventService.deleteEvent(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteEvent(int)}
      */
    protected abstract void handleDeleteEvent(int id) throws Exception;
    
    /**
     * @see EventService#deleteEvent(java.lang.String)
     */
    public EventVO disableEvent(int id, String updateBy)
    {
        if (id < 1 || updateBy==null || updateBy.trim().equals(""))
        {
            throw new IllegalArgumentException("EventService.disableEvent(int id, String updateBy) - 'id' or 'updateBy' can not be null or empty");
        }
        try
        {
            return this.handleDisableEvent(id, updateBy);
        }
        catch (Throwable th)
        {
            throw new EventServiceException("Error performing 'EventService.disableEvent(int id, String updateBy)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #disableEvent(int, String)}
      */
    protected abstract EventVO handleDisableEvent(int id, String updateBy) throws Exception;


    /**
     * @see EventService#getAllEvents()
     */
    public EventVO[] getAllEvent()
    {
        try
        {
            return this.handleGetAllEvent();
        }
        catch (Throwable th)
        {
            throw new EventServiceException("Error performing 'EventService.getAllEvents()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllEvents()}
      */
    protected abstract EventVO[] handleGetAllEvent() throws Exception;
    
    /**
     * @see EventService#getAllEvents()
     */
    public EventVO[] getAllActiveEvent()
    {
        try
        {
            return this.handleGetAllActiveEvent();
        }
        catch (Throwable th)
        {
            throw new EventServiceException("Error performing 'EventService.getAllActiveEvent()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllEvents()}
      */
    protected abstract EventVO[] handleGetAllActiveEvent() throws Exception;

    
    
    /**
     * @see EventService#saveEvent(com.ht.syndication.htsportal.transfer.EventVO)
     */
    public EventVO saveEvent(EventVO event, String userName)
    {
        if (event == null)
        {
            throw new IllegalArgumentException("EventService.saveEvent(com.ht.syndication.htsportal.transfer.EventVO event, String userName) - 'event' can not be null");
        }
        if (event.getName() == null || event.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("EventService.saveEvent(com.ht.syndication.htsportal.transfer.EventVO event, String userName) - 'event.name' can not be null or empty");
        }
        if (event.getStatus() == null)
        {
            throw new IllegalArgumentException("EventService.saveEvent(com.ht.syndication.htsportal.transfer.EventVO event, String userName) - 'event.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("EventService.saveEvent(com.ht.syndication.htsportal.transfer.EventVO event, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveEvent(event, userName);
        }
        catch (Throwable th)
        {
            th.printStackTrace();
            throw new EventServiceException("Error performing 'EventService.saveEvent(com.ht.syndication.htsportal.transfer.EventVO event, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveEvent(com.ht.syndication.htsportal.transfer.EventVO)}
      */
    protected abstract EventVO handleSaveEvent(EventVO event, String userName) throws Exception;
    
    /**
     * 
     * @return
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}