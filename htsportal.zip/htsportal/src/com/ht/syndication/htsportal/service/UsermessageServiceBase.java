package com.ht.syndication.htsportal.service;

import java.security.Principal;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.SubscriptionDao;
import com.ht.syndication.htsportal.domain.UsermessageDao;
import com.ht.syndication.htsportal.transfer.SubscriptionVO;
import com.ht.syndication.htsportal.transfer.UsermessageVO;

/**
 * <p>
 * Spring Service base class for <code>com.ht.syndication.htsportal.service.UsermessageService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see com.ht.syndication.htsportal.service.UsermessageService
 */
public abstract class UsermessageServiceBase implements UsermessageService
{

    private UsermessageDao usermessageDao;
    private SubscriptionDao subscriptionDao;

    /**
     * Sets the reference to <code>usermessage</code>'s DAO.
     */
    public void setUsermessageDao(UsermessageDao usermessageDao)
    {
        this.usermessageDao = usermessageDao;
    }

    /**
     * Gets the reference to <code>usermessage</code>'s DAO.
     */
    protected UsermessageDao getUsermessageDao()
    {
        return this.usermessageDao;
    }
    
    /**
     * Sets the reference to <code>SubscriptionMSG</code>'s DAO.
     */
    public void setSubscriptionDao(SubscriptionDao subscriptionDao)
    {
        this.subscriptionDao = subscriptionDao;
    }

    /**
     * Gets the reference to <code>SubscriptionMSG</code>'s DAO.
     */
    protected SubscriptionDao getSubscriptionDao()
    {
        return this.subscriptionDao;
    }

    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#deleteUsermessage(java.lang.Integer)
     */
    public UsermessageVO getUsermessage(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.getUsermessage(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetUsermessage(id);
        }
        catch (Throwable th)
        {
            throw new UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.getUsermessage(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteUsermessage(java.lang.Integer)}
      */
    protected abstract UsermessageVO handleGetUsermessage(Integer id) throws Exception;
    
    
    
    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#getSubscriptionMsg(java.lang.Integer)
     */
    public SubscriptionVO getSubscriptionMsg(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.getSubscriptionMsg(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetSubscriptionMsg(id);
        }
        catch (Throwable th)
        {
            throw new UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.getSubscriptionMsg(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getSubscriptionMsg(java.lang.Integer)}
      */
    protected abstract SubscriptionVO handleGetSubscriptionMsg(Integer id) throws Exception;
    
    
    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#deleteUsermessage(java.lang.Integer)
     */
    public void deleteUsermessage(Integer id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.deleteUsermessage(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteUsermessage(id);
        }
        catch (Throwable th)
        {
            throw new com.ht.syndication.htsportal.service.UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.deleteUsermessage(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteUsermessage(Integer)}
      */
    protected abstract void handleDeleteUsermessage(Integer id) throws java.lang.Exception;
    
    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#deleteSubscriptionMsg(java.lang.Integer)
     */
    public void deleteSubscriptionMsg(Integer id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.deleteSubscriptionMsg(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteSubscriptionMsg(id);
        }
        catch (Throwable th)
        {
            throw new com.ht.syndication.htsportal.service.UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.deleteSubscriptionMsg(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteSubscriptionMsg(Integer)}
      */
    protected abstract void handleDeleteSubscriptionMsg(Integer id) throws java.lang.Exception;

    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#getAllUsermessages()
     */
    public UsermessageVO[] getAllUsermessage()
    {
        try
        {
            return this.handleGetAllUsermessage();
        }
        catch (Throwable th)
        {
            throw new UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.getAllUsermessage()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllUsermessages()}
      */
    protected abstract UsermessageVO[] handleGetAllUsermessage() throws Exception;
    
    
    
    
    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#getAllSubscriptionMsg()
     */
    public SubscriptionVO[] getAllSubscriptionMsg()
    {
        try
        {
            return this.handleGetAllSubscriptionMsg();
        }
        catch (Throwable th)
        {
            throw new UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.getAllSubscriptionMsg' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllUsermessages()}
      */
    protected abstract SubscriptionVO[] handleGetAllSubscriptionMsg() throws Exception;
    
    
    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO)
     */
    public UsermessageVO saveUsermessage(UsermessageVO usermessage, String userName)
    {
        if (usermessage == null)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'usermessage' can not be null");
        }
        if (usermessage.getEmail() == null || usermessage.getEmail().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'usermessage.email' can not be null or empty");
        }
        if (usermessage.getFirstname() == null || usermessage.getFirstname().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'usermessage.firstname' can not be null or empty");
        }
        if (usermessage.getMessage() == null || usermessage.getMessage().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'usermessage.message' can not be null or empty");
        }
        if (usermessage.getTo() == null || usermessage.getTo().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'usermessage.to' can not be null or empty");
        }
        if (usermessage.getSubject() == null || usermessage.getSubject().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'usermessage.subject' can not be null or empty");
        }
        if (usermessage.getStatus() == null )
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'usermessage.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveUsermessage(usermessage, userName);
        }
        catch (Throwable th)
        {
            throw new com.ht.syndication.htsportal.service.UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO usermessage, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO)}
      */
    protected abstract UsermessageVO handleSaveUsermessage(UsermessageVO usermessage, String userName) throws Exception;
    
    
    /**
     * @see com.ht.syndication.htsportal.service.UsermessageService#saveSubscriptionMsg(SubscriptionVO, String)
     */
    public SubscriptionVO saveSubscriptionMsg(SubscriptionVO subscriptionMsg, String userName)
    {
        if (subscriptionMsg == null)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg' can not be null");
        }
        if (subscriptionMsg.getArticlecount() == null || subscriptionMsg.getArticlecount() < 1)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.articlecount' can not be null or less than 1");
        }
        if (subscriptionMsg.getReproduced() == null || subscriptionMsg.getReproduced().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.reproduced' can not be null or empty");
        }
        if (subscriptionMsg.getPublicationname() == null || subscriptionMsg.getPublicationname().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.Publicationname' can not be null or empty");
        }
        if (subscriptionMsg.getPublicationcirculation() == null || subscriptionMsg.getPublicationcirculation() < 1)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.Publicationcirculation' can not be null or less than 1");
        }
        if (subscriptionMsg.getOtherdetails() == null || subscriptionMsg.getOtherdetails().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.otherdetails' can not be null or empty");
        }
        if (subscriptionMsg.getCompanyname() == null || subscriptionMsg.getCompanyname().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.Companyname' can not be null or empty");
        }
        if (subscriptionMsg.getAddress() == null || subscriptionMsg.getAddress().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.address' can not be null or empty");
        }
        if (subscriptionMsg.getEmail() == null || subscriptionMsg.getEmail().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.email' can not be null or empty");
        }
        if (subscriptionMsg.getPhone() == null || subscriptionMsg.getPhone().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.phone' can not be null or empty");
        }
        if (subscriptionMsg.getCountry() == null || subscriptionMsg.getCountry().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.country' can not be null or empty");
        }
        if (subscriptionMsg.getMessage() == null || subscriptionMsg.getMessage().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.message' can not be null or empty");
        }
        if (subscriptionMsg.getEmailto() == null || subscriptionMsg.getEmailto().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.emailto' can not be null or empty");
        }
        if (subscriptionMsg.getEmailsubject() == null || subscriptionMsg.getEmailsubject().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.emailsubject' can not be null or empty");
        }
        if (subscriptionMsg.getStatus() == null )
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'subscriptionMsg.status' can not be null or empty");
        }
        
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveSubscriptionMsg(subscriptionMsg, userName);
        }
        catch (Throwable th)
        {
            throw new com.ht.syndication.htsportal.service.UsermessageServiceException("Error performing 'com.ht.syndication.htsportal.service.UsermessageService.saveSubscriptionMsg(com.ht.syndication.htsportal.transfer.SubscriptionVO subscriptionMsg, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveUsermessage(com.ht.syndication.htsportal.transfer.UsermessageVO)}
      */
    protected abstract SubscriptionVO handleSaveSubscriptionMsg(SubscriptionVO subscriptionMsg, String userName) throws Exception;
    
    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}