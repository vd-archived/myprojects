package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.transfer.EventVO;

/**
 * 
 */
public interface EventService
{
    /**
     * 
     */
	public EventVO getEvent(int id);
    /**
     * 
     */
	public void deleteEvent(int id);
	
	/**
     * 
     */
	public EventVO disableEvent(int id, String updateBy);

    /**
     * 
     */
    public EventVO[] getAllEvent();
    
    /**
     * 
     */
    public EventVO[] getAllActiveEvent();

    /**
     * 
     */
    public EventVO saveEvent(EventVO source, String updateBy);
    
}
