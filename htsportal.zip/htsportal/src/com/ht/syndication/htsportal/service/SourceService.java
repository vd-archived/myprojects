package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.transfer.SourceVO;

/**
 * 
 */
public interface SourceService
{
    /**
     * 
     */
	public SourceVO getSource(int id);
    /**
     * 
     */
	public void deleteSource(int id);

    /**
     * 
     */
    public SourceVO[] getAllSource();
    
    /**
     * 
     */
    public SourceVO[] getAllActiveSource();

    /**
     * 
     */
    public SourceVO saveSource(SourceVO source, String updateBy);
    
}
