package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.Publication;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.PublicationVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;

public class PublicationServiceImpl extends PublicationServiceBase
{
    
	@Override
	protected void handleDeletePublication(Integer id) throws Exception 
	{
		PublicationDao publicationDataAccessor = super.getPublicationDao();
		PublicationVO publicationVO = publicationDataAccessor.toPublicationVO(publicationDataAccessor.load(id));
		publicationDataAccessor.remove(id);
		Utility.deleteArticleIndex(HTSPortal.Solr.Article.PUBLICATION, publicationVO.getName());
	}
	/**
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected PublicationVO[] handleGetAllPublication() throws Exception 
	{
		return (PublicationVO[]) super.getPublicationDao().loadAll(PublicationDao.TRANSFORM_PUBLISHERVO).toArray(new PublicationVO[0]);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected PublicationVO[] handleGetAllActivePublication() throws Exception 
	{
		return (PublicationVO[]) super.getPublicationDao().loadAllActive(PublicationDao.TRANSFORM_PUBLISHERVO).toArray(new PublicationVO[0]);
	}
	
	@Override
	protected PublicationShortVO[] handleGetAllPublicationShort() throws Exception
	{
		return (PublicationShortVO[]) super.getPublicationDao().loadAll(PublicationDao.TRANSFORM_PUBLISHER_SHORTVO).toArray(new PublicationShortVO[0]);
	}

	@Override
	protected PublicationVO handleGetPublication(Integer id) throws Exception 
	{
	    return super.getPublicationDao().toPublicationVO(this.getPublicationDao().load(id));
	}
	
	@Override
	protected PublicationVO handleSavePublication(PublicationVO publicationVO, String userName) throws Exception 
	{
	    PublicationDao publicationDataAccessor = super.getPublicationDao();
		Publication publication = publicationDataAccessor.publicationVOToEntity(publicationVO);
		publication.setUpdatedby(userName);
		if(publicationVO.getOwner() != null)
		{
			publication.setOwner(super.getUserDao().load(publicationVO.getOwner()));
		}
		PublicationVO result  = (PublicationVO) publicationDataAccessor.create(PublicationDao.TRANSFORM_PUBLISHERVO, publication);
		if(publicationVO.getStatus().equals(AccessStatus.DISABLE))
		{
			Utility.deleteArticleIndex(HTSPortal.Solr.Article.PUBLICATION, publicationVO.getName());
		}

		return result;
	}
	@Override
	protected PublicationVO handleGetPublication(String name) throws Exception 
	{
	    return super.getPublicationDao().toPublicationVO(this.getPublicationDao().load(name));
	}
}