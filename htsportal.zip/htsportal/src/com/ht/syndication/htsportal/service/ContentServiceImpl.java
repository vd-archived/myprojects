package com.ht.syndication.htsportal.service;


import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.common.SolrInputDocument;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.Category;
import com.ht.syndication.htsportal.domain.CategoryDao;
import com.ht.syndication.htsportal.domain.Content;
import com.ht.syndication.htsportal.domain.ContentDao;
import com.ht.syndication.htsportal.domain.Publication;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.domain.Source;
import com.ht.syndication.htsportal.domain.SourceDao;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.transfer.ContentVO;
import com.ht.syndication.htsportal.util.FTPUtility;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ReadXML;
import com.ht.syndication.htsportal.util.Utility;


public class ContentServiceImpl extends ContentServiceBase
{
	private static final Log LOGGER = LogFactory.getLog(ContentServiceImpl.class);

	private static final ConfigurationReader FTP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.FTP_PROFILE);

	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);

	private static final ConfigurationReader APPLICATION_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

	@Override
	protected void handleDeleteContent(Integer id) throws Exception 
	{
		super.getContentDao().remove(id);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected ContentVO[] handleGetAllContent() throws Exception 
	{
		return (ContentVO[]) super.getContentDao().loadAll(ContentDao.TRANSFORM_CONTENTVO).toArray(new ContentVO[0]);
	}

	@Override
	protected ContentVO handleGetContent(Integer id) throws Exception 
	{
		return super.getContentDao().toContentVO(this.getContentDao().load(id));
	}



	@Override
	protected String handleSaveContent(ContentVO contentVO, String userName) throws Exception 
	{
		ContentDao contentDataAccessor = super.getContentDao();
		Content content = contentDataAccessor.contentVOToEntity(contentVO);
		content.setSource(super.getSourceDao().load(Integer.parseInt(contentVO.getSource())));
		content.setPublication(super.getPublicationDao().load(Integer.parseInt(contentVO.getPublication())));
		Collection<Category> categories = new HashSet<Category>();
		Category category = super.getCategoryDao().load(Integer.parseInt(contentVO.getCategory()[0]));
		categories.add(category);
		content.setCategory(categories);
		content.setUpdatedby(userName);
		contentDataAccessor.create(content);
		if(contentVO.getStatus().equals(AccessStatus.DISABLE) && contentVO.getId()!=null)
		{
			Utility.deleteArticleIndex(HTSPortal.Solr.Article.CONTENT, content.getId().toString());
		}
		return "";
	}

	@Override
	protected String handleUpdateContent(ContentVO content, String updatedBy) throws Exception 
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void handleSaveBatchContent(String userName) throws Exception 
	{
		LOGGER.info("Save Batch Function");
		Integer maxprocess = Utility.convertToInteger(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAXPROCESS), 10000);
		Boolean continueBatch = Boolean.FALSE;
		do
		{
			FTPClient ftpClient = FTPUtility.getFtpConnection(FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Article.URL), FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Article.USERNAME) , FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Article.PASSWORD));
			if(ftpClient.getReplyCode() == 230)
			{
				continueBatch = FTPUtility.downloadFiles(FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Article.ROOT_PATH), ftpClient, maxprocess, HTSPortal.DOWNLOADTYPE.ARTICLEENDSWITH, HTSPortal.ARTICLE.TEMPDIRECTORY);
				File directory = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.ARTICLE.TEMPDIRECTORY));
				File errorDirectory = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.ARTICLE.ERRORDIRECTORY));
				if(!errorDirectory.exists() || !errorDirectory.isDirectory())
				{
					errorDirectory = new File(directory.getParentFile(), errorDirectory.getName());
				}
				if(!errorDirectory.exists())
				{
					errorDirectory.mkdirs();
				}
				
				List<File> listFile = new ArrayList<File>();
				FTPUtility.getAllFilesFromDirectory(directory, listFile, 1, HTSPortal.DOWNLOADTYPE.ARTICLEENDSWITH);
				if(listFile!=null)
				{
					try
					{
						LOGGER.info("Batch Article Reading Start");
						Map<String, File> successMap = new HashMap<String, File>();
						List<File>failedFiles = new ArrayList<File>();
						List<ContentVO> listContent = this.readXmlFile(listFile, successMap, failedFiles);
						if(failedFiles != null && failedFiles.size()>0)
						{
							for(File errorFile: failedFiles)
							{
								if(!Utility.moveFile(errorFile, new File(errorDirectory, errorFile.getName())))
								{
									LOGGER.error("File not moved to error directory named: " + errorFile.getName());
								}
							}
						}
						if(listContent != null && listContent.size()>0)
						{
							Set<String> success = this.saveBatchContent(listContent, userName);
							
							LOGGER.info("Batch Article Reading End");
							
							LOGGER.info("Batch Article Index Start");
							if(success.size() > 0)
							{
								handleIndexContent(success);
							}
							else
							{
								handleIndexContent();
							}
							LOGGER.info("Batch Article Index End");

							Set<Entry<String, File>> entries = successMap.entrySet();
							for(Entry<String, File> entry: entries)
							{
								if(success.contains(entry.getKey()))
								{
									entry.getValue().delete();
								}
								else
								{
									File errorFile = entry.getValue();
									if(!Utility.moveFile(errorFile, new File(errorDirectory, errorFile.getName())))
									{
										LOGGER.error("File not moved to error directory named: " + errorFile.getName());
									}
								}
							}
						}
					}
					catch(Exception e)
					{
						LOGGER.error("Batch Failed (when try to read xml and save to database)");
						LOGGER.error("Technical Error");
						LOGGER.error(e.getMessage());
						e.printStackTrace();
					}
				}
				FTPUtility.closeFtpConnection(ftpClient);
			}
			else
			{
				LOGGER.error("Unable to connect ftp serrver");
				continueBatch = Boolean.FALSE;
			}
		}while(continueBatch);
		LOGGER.info("Save Batch Function END");
	}
	
	@SuppressWarnings("unchecked")
	@Override
	
	protected Boolean handleIndexContent() throws Exception 
	{
		LOGGER.info("Index Function Start");
		Boolean result = Boolean.FALSE;
		try
		{
			List<Content> listContent =  null;
			Integer count = 1;
			Integer MAXPROCESS = Utility.convertToInteger(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAXPROCESS), null);
			List<SolrInputDocument> solrInputDocuments = new ArrayList<SolrInputDocument>();
			do
			{
				LOGGER.info("Load Content..................");
				listContent =  (List<Content>) getContentDao().indexedContent(ContentDao.TRANSFORM_NONE, MAXPROCESS);
				LOGGER.info("Load Content Completed");
				for(Content entity: listContent)
				{
					SolrInputDocument doc = new SolrInputDocument();
					ContentVO content = getContentDao().toContentVO(entity);
					doc.addField( "id", content.getId());
					doc.addField( "headline", content.getHeadline());
					doc.addField( "contentdate", Utility.toSolrDate(content.getContentdate()) );
					doc.addField( "location", content.getLocation());
					doc.addField( "publication", content.getPublication());
					doc.addField( "news", content.getNews());
					doc.addField( "copyright", content.getCopyright());
					doc.addField( "source", content.getSource());
					doc.addField( "exclusive", content.getExclusive());
					doc.addField( "category", content.getCategory());
					doc.addField( "byline", content.getByline());
					solrInputDocuments.add(doc);
					entity.setIndexdate(new Date());
				}
				LOGGER.info("Indexed Content..................");
				if(saveIndex(solrInputDocuments))
				{
					LOGGER.info("Indexed Content Completed");
					getContentDao().update(listContent);
					//				    this.saveBatchContent(listContent, "htadmin");
					LOGGER.info("Updated Content :: "+listContent.size()*count++);
					result = Boolean.TRUE;
				}
			}while(listContent.size() >= MAXPROCESS);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Problem with indexing [ "+ e.getMessage() +" ]");
		}
		LOGGER.info("Index Function END");
		return result;
	}
	
	protected Boolean handleIndexContent(Set<String> uniqueIds) throws Exception 
	{
		LOGGER.info("Index Function Start");
		Boolean result = Boolean.FALSE;
		try
		{
			List<Content> listContent =  null;
			Integer count = 1;
			Integer MAXPROCESS = Utility.convertToInteger(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAXPROCESS), null);
			List<SolrInputDocument> solrInputDocuments = new ArrayList<SolrInputDocument>();
/*			do
			{
*/				LOGGER.info("Load Content..................");
				listContent =  (List<Content>) getContentDao().indexedContent(ContentDao.TRANSFORM_NONE, MAXPROCESS, uniqueIds);
				LOGGER.info("Load Content Completed");
				for(Content entity: listContent)
				{
					SolrInputDocument doc = new SolrInputDocument();
					ContentVO content = getContentDao().toContentVO(entity);
					doc.addField( "id", content.getId());
					doc.addField( "headline", content.getHeadline());
					doc.addField( "contentdate", Utility.toSolrDate(content.getContentdate()) );
					doc.addField( "location", content.getLocation());
					doc.addField( "publication", content.getPublication());
					doc.addField( "news", content.getNews());
					doc.addField( "copyright", content.getCopyright());
					doc.addField( "source", content.getSource());
					doc.addField( "exclusive", content.getExclusive());
					doc.addField( "category", content.getCategory());
					doc.addField( "byline", content.getByline());
					solrInputDocuments.add(doc);
					entity.setIndexdate(new Date());
				}
				LOGGER.info("Indexed Content..................");
				if(saveIndex(solrInputDocuments))
				{
					LOGGER.info("Indexed Content Completed");
					getContentDao().update(listContent);
					//				    this.saveBatchContent(listContent, "htadmin");
					LOGGER.info("Updated Content :: "+listContent.size()*count++);
					result = Boolean.TRUE;
				}
//			}while(listContent.size() >= MAXPROCESS);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.error("Problem with indexing [ "+ e.getMessage() +" ]");
		}
		LOGGER.info("Index Function END");
		return result;
	}


	/**
	 * 
	 * @param solrInputDocuments
	 * @return
	 */
	private Boolean saveIndex(List<SolrInputDocument>solrInputDocuments)
	{
		Boolean result = Boolean.FALSE;
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.URL));
			if(solrInputDocuments != null && solrInputDocuments.size()>0)
			{
				solrServer.add(solrInputDocuments);
				solrServer.commit();
			}
			result = Boolean.TRUE;
		}
		catch(Exception e)
		{
			LOGGER.error(e.getMessage());
		}
		return result;
	}

	/**
	 * 
	 * @param path
	 * @return
	 */
	private List<ContentVO> readXmlFile(List<File> splitedFiles, Map<String, File> successMap, List<File>failedFiles) 
	{
		List<ContentVO> listContent = new ArrayList<ContentVO>();
		if (splitedFiles != null && splitedFiles.size() > 0) 
		{
			for (File file : splitedFiles) 
			{
				if (file.getName().endsWith(".xml")) 
				{
					try
					{
						ReadXML readXml =  new ReadXML();
						readXml.setRoot(file);
						Element rootElement = readXml.root;
						Element byLineElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.BYLINE);
						Element contentDateElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.CONTENTDATE);
						Element headlineElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.HEADLINE);
						Element bodyContentElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.CONTENT);
						Element sectionElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.SECTION);
						Element sourceElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.SOURCE);
						Element categoryElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.CATEGORY);
						Element locationElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.LOCATION);
						Element publicationNameElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.PUBLICATION);
						Element uniqIDElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.CONTENTID);
						Element copyrightElem = readXml.getChildByName(rootElement, HTSPortal.XMLFile.COPYRIGHT);
						String[]usedcategories = categoryElem.getText().split("<<>>");

						ContentVO contentVO = new ContentVO();
						contentVO.setHeadline(headlineElem.getText());
						contentVO.setNews(bodyContentElem.getText());
						contentVO.setLocation(locationElem.getText());
						contentVO.setSource(sourceElem.getText());
						contentVO.setPublication(publicationNameElem.getText());
						contentVO.setCategory(usedcategories);
						contentVO.setStatus(new Short("1"));
						contentVO.setByline(byLineElem.getText());
						contentVO.setSection(sectionElem.getText());
						contentVO.setCopyright(copyrightElem.getText());
						contentVO.setUniqueid(uniqIDElem.getText());
						contentVO.setContentdate(Utility.stringToDate(contentDateElem.getText(), 2));
						listContent.add(contentVO);
						successMap.put(uniqIDElem.getText(), file);
					}
					catch(Exception ex)
					{
						LOGGER.error("Unable to read file [" + file.getName() + "]:: " + ex.getMessage());
						failedFiles.add(file);
					}
				}

			}
		}
		return listContent;
	}

	/**
	 * 
	 * @param contentList
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private Set<String> saveBatchContent(List<ContentVO> contentList, String userName) throws Exception
	{
		ContentDao contentDataAccessor = super.getContentDao();
		Map<String, Publication> publicationMap = this.getAllPublication();
		Map<String, Source> sourceMap = this.getAllSource();
		Map<String, Category> categoryMap = this.getAllCategory();
		Collection<Content> entityList = new ArrayList<Content>();
		Set<String> success = new HashSet<String>();
		Publication temppublication = null;
		Collection<Category> tempcategories = null;
		Source tempsource = null;
		LOGGER.info("Going create contentList");
		for(ContentVO contentVO: contentList)
		{
			try
			{
			Boolean errorFound = Boolean.FALSE;
			List<String> errors = validateContentVO(contentVO);
			if(errors!=null && errors.size()>0)
			{
				errorFound = Boolean.TRUE;
				LOGGER.error("Error Found For [" + contentVO.getHeadline() + "]");
				Integer count = 1;
				for(String error : errors) 
				{
					LOGGER.error("\t" + (count++) + ": " + error);
				}
			}
			if(!errorFound)
			{
				Content content = contentDataAccessor.contentVOToEntity(contentVO);
				tempcategories = new HashSet<Category>();
				for(String categoryName: contentVO.getCategory())
				{
					Category category = categoryMap.get(categoryName);
					if(category != null)
					{
						tempcategories.add(category);
					}
				}
				temppublication = publicationMap.get(contentVO.getPublication());
				tempsource = sourceMap.get(contentVO.getSource());

				content.setUpdatedby(userName);
				if(temppublication == null || tempsource == null || tempcategories == null || tempcategories.size() < 1)
				{
					LOGGER.error("Error:: Error found for headline: ["+contentVO.getHeadline()+"]");
					if(temppublication == null)
					{
						errorFound = Boolean.TRUE;
						LOGGER.error("Publication '"+contentVO.getPublication()+"' not found");
					}
					if(tempsource == null)
					{
						errorFound = Boolean.TRUE;
						LOGGER.error("	Source '"+contentVO.getSource()+"' not found");
					}
					if(tempcategories == null || tempcategories.size() < 1)
					{
						errorFound = Boolean.TRUE;
						LOGGER.error("	Category '" + Utility.printValues(contentVO.getCategory()) + "' not found");
					}
				}
				else
				{
					content.setPublication(temppublication);
					content.setSource(tempsource);
					content.setCategory(tempcategories);
				}
				if(!errorFound)
				{
					entityList.add(content);
					success.add(contentVO.getUniqueid());
				}
			}
			}
			catch(Exception ex)
			{
				LOGGER.error("Error:: Error found for headline: ["+contentVO.getHeadline()+"]");
			}
		}
		if(entityList.size()>0 )
		{
			LOGGER.info("Going add/update Content");
			contentDataAccessor.create(entityList);
			LOGGER.info("Adding/updating Content Completed");
		}
		return success;
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Publication> getAllPublication()
	{
		Map<String, Publication> publicationMap = new HashMap<String, Publication>();
		Collection<Publication> listPublication = super.getPublicationDao().loadAll(PublicationDao.TRANSFORM_NONE);
		for(Publication publication:listPublication)
		{
			publicationMap.put(publication.getName(), publication);
		}
		return publicationMap;
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Source> getAllSource()
	{
		Map<String, Source> sourceMap = new HashMap<String, Source>();
		Collection<Source> listSource = super.getSourceDao().loadAll(SourceDao.TRANSFORM_NONE);
		for(Source source:listSource)
		{
			sourceMap.put(source.getName(), source);
		}
		return sourceMap;
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Category> getAllCategory()
	{
		Map<String, Category> categoryMap = new HashMap<String, Category>();
		Collection<Category> listCategory = super.getCategoryDao().loadAll(CategoryDao.TRANSFORM_NONE);
		for(Category category:listCategory)
		{
			categoryMap.put(category.getName(), category);
		}
		return categoryMap;
	}


}