package com.ht.syndication.htsportal.service;


import com.ht.syndication.htsportal.domain.Subscription;
import com.ht.syndication.htsportal.domain.SubscriptionDao;
import com.ht.syndication.htsportal.domain.Usermessage;
import com.ht.syndication.htsportal.domain.UsermessageDao;
import com.ht.syndication.htsportal.transfer.SubscriptionVO;
import com.ht.syndication.htsportal.transfer.UsermessageVO;


public class UsermessageServiceImpl extends UsermessageServiceBase
{

	@Override
	protected void handleDeleteUsermessage(Integer id) throws Exception 
	{
		super.getUsermessageDao().remove(id);
	}

	@SuppressWarnings("unchecked")
    @Override
	protected UsermessageVO[] handleGetAllUsermessage() throws Exception 
	{
        return (UsermessageVO[]) super.getUsermessageDao().loadAll(UsermessageDao.TRANSFORM_USERMESSAGEVO).toArray(new UsermessageVO[0]);
	}
	
	@Override
	protected UsermessageVO handleGetUsermessage(Integer id) throws Exception 
	{
        return super.getUsermessageDao().toUsermessageVO(this.getUsermessageDao().load(id));
	}

	@Override
	protected UsermessageVO handleSaveUsermessage(UsermessageVO usermessageVO, String userName) throws Exception 
	{
		UsermessageDao usermessageDataAccessor = super.getUsermessageDao();
		Usermessage usermessage = usermessageDataAccessor.usermessageVOToEntity(usermessageVO);
		usermessage.setUpdatedby(userName);
		UsermessageVO result = (UsermessageVO) usermessageDataAccessor.create(UsermessageDao.TRANSFORM_USERMESSAGEVO,usermessage);
		return result;
	}

	@Override
	protected SubscriptionVO handleGetSubscriptionMsg(Integer id)
			throws Exception {
		return super.getSubscriptionDao().toSubscriptionVO(this.getSubscriptionDao().load(id));
	}

	@Override
	protected void handleDeleteSubscriptionMsg(Integer id) throws Exception {
		super.getSubscriptionDao().remove(id);
	}

	@Override
	protected SubscriptionVO[] handleGetAllSubscriptionMsg() throws Exception {
		return (SubscriptionVO[]) super.getSubscriptionDao().loadAll(SubscriptionDao.TRANSFORM_SUBSCRIPTIONVO).toArray(new SubscriptionVO[0]);
	}

	@Override
	protected SubscriptionVO handleSaveSubscriptionMsg(SubscriptionVO subscriptionMsg, String userName) throws Exception {
		SubscriptionDao subscriptionDataAccessor = super.getSubscriptionDao();
		Subscription subscription = subscriptionDataAccessor.subscriptionVOToEntity(subscriptionMsg);
		subscription.setUpdatedby(userName);
		SubscriptionVO result = (SubscriptionVO) subscriptionDataAccessor.create(SubscriptionDao.TRANSFORM_SUBSCRIPTIONVO, subscription);
		return result;
	}
}