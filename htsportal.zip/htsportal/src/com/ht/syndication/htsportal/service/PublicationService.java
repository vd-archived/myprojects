package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.PublicationVO;

/**
 * 
 */
public interface PublicationService
{
    /**
     * 
     */
	public PublicationVO getPublication(Integer id);
	/**
	 * 
	 * @param id
	 * @return
	 */
	public PublicationVO getPublication(String name);
    /**
     * 
     */
	public void deletePublication(Integer id);

    /**
     * 
     */
    public PublicationVO[] getAllPublication();

    /**
     * 
     */
    public PublicationVO[] getAllActivePublication();
    
    /**
     * 
     */
    public PublicationShortVO[] getAllPublicationShort();

    /**
     * 
     */
    public PublicationVO savePublication(PublicationVO publication, String updateBy);
}
