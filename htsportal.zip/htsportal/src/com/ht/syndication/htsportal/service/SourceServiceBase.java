package com.ht.syndication.htsportal.service;

import java.security.Principal;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.SourceDao;
import com.ht.syndication.htsportal.transfer.SourceVO;

/**
 * <p>
 * Spring Service base class for <code>SourceService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see SourceService
 */
public abstract class SourceServiceBase implements SourceService
{
    private SourceDao sourceDao;

    /**
     * Sets the reference to <code>source</code>'s DAO.
     */
    public void setSourceDao(SourceDao sourceDao)
    {
        this.sourceDao = sourceDao;
    }

    /**
     * Gets the reference to <code>source</code>'s DAO.
     */
    protected SourceDao getSourceDao()
    {
        return this.sourceDao;
    }

    /**
     * @see SourceService#deleteSource(java.lang.String)
     */
    public SourceVO getSource(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("SourceService.getSource(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetSource(id);
        }
        catch (Throwable th)
        {
            throw new SourceServiceException("Error performing 'SourceService.getSource(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteSource(java.lang.String)}
      */
    protected abstract SourceVO handleGetSource(int id) throws Exception;

    /**
     * @see SourceService#deleteSource(java.lang.String)
     */
    public void deleteSource(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("SourceService.deleteSource(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteSource(id);
        }
        catch (Throwable th)
        {
            throw new SourceServiceException("Error performing 'SourceService.deleteSource(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteSource(int)}
      */
    protected abstract void handleDeleteSource(int id) throws Exception;

    /**
     * @see SourceService#getAllSources()
     */
    public SourceVO[] getAllSource()
    {
        try
        {
            return this.handleGetAllSource();
        }
        catch (Throwable th)
        {
            throw new SourceServiceException("Error performing 'SourceService.getAllSources()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllSources()}
      */
    protected abstract SourceVO[] handleGetAllSource() throws Exception;
    
    public SourceVO[] getAllActiveSource()
    {
        try
        {
            return this.handleGetAllActiveSource();
        }
        catch (Throwable th)
        {
            throw new SourceServiceException("Error performing 'SourceService.getAllActiveSources()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllSources()}
      */
    protected abstract SourceVO[] handleGetAllActiveSource() throws Exception;

    /**
     * @see SourceService#saveSource(com.ht.syndication.htsportal.transfer.SourceVO)
     */
    public SourceVO saveSource(SourceVO source, String userName)
    {
        if (source == null)
        {
            throw new IllegalArgumentException("SourceService.saveSource(com.ht.syndication.htsportal.transfer.SourceVO source, String userName) - 'source' can not be null");
        }
        if (source.getName() == null || source.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("SourceService.saveSource(com.ht.syndication.htsportal.transfer.SourceVO source, String userName) - 'source.name' can not be null or empty");
        }
        if (source.getStatus() == null)
        {
            throw new IllegalArgumentException("SourceService.saveSource(com.ht.syndication.htsportal.transfer.SourceVO source, String userName) - 'source.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("SourceService.saveSource(com.ht.syndication.htsportal.transfer.SourceVO source, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveSource(source, userName);
        }
        catch (Throwable th)
        {
            th.printStackTrace();
            throw new SourceServiceException("Error performing 'SourceService.saveSource(com.ht.syndication.htsportal.transfer.SourceVO source, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveSource(com.ht.syndication.htsportal.transfer.SourceVO)}
      */
    protected abstract SourceVO handleSaveSource(SourceVO source, String userName) throws Exception;
    
    /**
     * 
     * @return
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}