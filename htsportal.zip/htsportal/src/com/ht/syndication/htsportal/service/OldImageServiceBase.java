package com.ht.syndication.htsportal.service;

import java.security.Principal;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.OldImagecategoryDao;
import com.ht.syndication.htsportal.transfer.ImageFileVO;
import com.ht.syndication.htsportal.transfer.ImagecategoryVO;

/**
 * <p>
 * Spring Service base class for <code>com.ht.syndication.htsportal.service.CategoryService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see com.ht.syndication.htsportal.service.CategoryService
 */
public abstract class OldImageServiceBase implements OldImageService
{
	private OldImagecategoryDao oldImagecategoryDao;

	/**
     * Setter and Getter the reference to <code>imagecategory</code>'s DAO.
     */
    public OldImagecategoryDao getImagecategoryDao() {
		return oldImagecategoryDao;
	}

	public void setImagecategoryDao(OldImagecategoryDao oldImagecategoryDao) {
		this.oldImagecategoryDao = oldImagecategoryDao;
	}
	
	public ImagecategoryVO getImagecategory(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.getImagecategory(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetImagecategory(id);
        }
        catch (Throwable th)
        {
            throw new OldImageServiceException("Error performing 'com.ht.syndication.htsportal.service.ImageService.getImagecategory(int id)' --> " + th, th);
        }
    }
	
    protected abstract ImagecategoryVO handleGetImagecategory(Integer id) throws Exception;
    
    public ImagecategoryVO deleteImagecategory(Integer id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.deleteImagecategory(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleDeleteImagecategory(id);
        }
        catch (Throwable th)
        {
            throw new OldImageServiceException("Error performing 'com.ht.syndication.htsportal.service.ImageService.deleteImagecategory(int id)' --> " + th, th);
        }
    }
    
    protected abstract ImagecategoryVO handleDeleteImagecategory(Integer id) throws java.lang.Exception;
	
    public ImagecategoryVO[] getAllActiveImagecategory()
    {
        try
        {
            return this.handleGetAllActiveImagecategory();
        }
        catch (Throwable th)
        {
            throw new OldImageServiceException("Error performing 'com.ht.syndication.htsportal.service.ImageService.getAllImagecategory()' --> " + th, th);
        }
    }

    protected abstract ImagecategoryVO[] handleGetAllActiveImagecategory() throws Exception;
    
    
    public ImagecategoryVO[] getAllImagecategory()
    {
        try
        {
            return this.handleGetAllImagecategory();
        }
        catch (Throwable th)
        {
            throw new OldImageServiceException("Error performing 'com.ht.syndication.htsportal.service.ImageService.getAllImagecategory()' --> " + th, th);
        }
    }

    protected abstract ImagecategoryVO[] handleGetAllImagecategory() throws Exception;
    
    
    
    public ImagecategoryVO saveImagecategory(ImagecategoryVO imagecategory, String userName)
    {
        if (imagecategory == null)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.saveImagecategoryategory(com.ht.syndication.htsportal.transfer.ImagecategoryVO imagecategory, String userName) - 'imagecategory' can not be null");
        }
        if (imagecategory.getName() == null || imagecategory.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.saveImagecategory(com.ht.syndication.htsportal.transfer.ImagecategoryVO imagecategory, String userName) - 'imagecategory.name' can not be null or empty");
        }
        if (imagecategory.getStatus() == null )
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.saveImagecategoryategory(com.ht.syndication.htsportal.transfer.ImagecategoryVO imagecategory, String userName) - 'imagecategory.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.saveImagecategoryategory(com.ht.syndication.htsportal.transfer.ImagecategoryVO imagecategory, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveImagecategory(imagecategory, userName);
        }
        catch (Throwable th)
        {
            throw new OldImageServiceException("Error performing 'com.ht.syndication.htsportal.service.ImageService.saveImagecategory(com.ht.syndication.htsportal.transfer.ImagecategoryVO imagecategory, String userName)' --> " + th, th);
        }
    }
    
    protected abstract ImagecategoryVO handleSaveImagecategory(ImagecategoryVO imagecategory, String userName) throws Exception;
    
	public ImageFileVO loadImage(String basePath, String cat, String subcat, String filename)
    {
    	if(basePath == null)
    	{
    		throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.loadImage(String basePath, String cat, String subcat, String filename) - 'basePath' can not be null or empty");
    	}
    	if(cat == null)
    	{
    		throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.loadImage(String basePath, String cat, String subcat, String filename) - 'cat' can not be null or empty");
    	}
    	if(filename == null)
    	{
    		throw new IllegalArgumentException("com.ht.syndication.htsportal.service.ImageService.loadImage(String basePath, String cat, String subcat, String filename) - 'filename' can not be null or empty");
    	}
        try
        {
            return this.handleLoadImage(basePath, cat, subcat, filename);
        }
        catch (Throwable th)
        {
            throw new OldImageServiceException("Error performing 'com.ht.syndication.htsportal.service.ImageService.loadImage(String basePath, String cat, String subcat, String filename)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #loadImage(java.lang.String, java.lang.String, java.lang.String, java.lang.String)}
      */
    protected abstract ImageFileVO handleLoadImage(String basePath, String cat, String subcat, String filename) throws Exception;

    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}