package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.transfer.CategoryVO;

/**
 * 
 */
public interface CategoryService
{
    /**
     * 
     */
	public CategoryVO getCategory(Integer id);
    /**
     * 
     */
	public void deleteCategory(Integer id);

    /**
     * 
     */
    public CategoryVO[] getAllCategory();

    /**
     * 
     */
    public CategoryVO saveCategory(CategoryVO category, String updateBy);
    /**
     * 
     */
}
