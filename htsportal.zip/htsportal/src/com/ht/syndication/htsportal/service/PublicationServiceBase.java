package com.ht.syndication.htsportal.service;

import java.security.Principal;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.domain.UserDao;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.PublicationVO;

/**
 * <p>
 * Spring Service base class for <code>com.ht.syndication.htsportal.service.PublicationService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see com.ht.syndication.htsportal.service.PublicationService
 */
public abstract class PublicationServiceBase implements PublicationService
{

    private PublicationDao publicationDao;
    private UserDao userDao;

    /**
     * Sets the reference to <code>publication</code>'s DAO.
     */
    public void setPublicationDao(PublicationDao publicationDao)
    {
        this.publicationDao = publicationDao;
    }

    /**
     * Gets the reference to <code>publication</code>'s DAO.
     */
    protected PublicationDao getPublicationDao()
    {
        return this.publicationDao;
    }
    
    public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	/**
     * @see com.ht.syndication.htsportal.service.PublicationService#deletePublication(java.lang.String)
     */
    public PublicationVO getPublication(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.getPublication(Integer id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetPublication(id);
        }
        catch (Throwable th)
        {
            throw new PublicationServiceException("Error performing 'com.ht.syndication.htsportal.service.PublicationService.getPublication(Integer id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deletePublication(java.lang.String)}
      */
    protected abstract PublicationVO handleGetPublication(Integer id) throws Exception;
    
    /**
     * 
     */
    public PublicationVO getPublication(String name)
    {
        if (name == null || name.equals(""))
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.getPublication(Integer id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetPublication(name);
        }
        catch (Throwable th)
        {
            throw new PublicationServiceException("Error performing 'com.ht.syndication.htsportal.service.PublicationService.getPublication(Integer id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getPublication(java.lang.String)}
      */
    protected abstract PublicationVO handleGetPublication(String name) throws Exception;


    /**
     * @see com.ht.syndication.htsportal.service.PublicationService#deletePublication(java.lang.String)
     */
    public void deletePublication(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.deletePublication(java.lang.String nickName) - 'nickName' can not be null or empty");
        }
        try
        {
            this.handleDeletePublication(id);
        }
        catch (Throwable th)
        {
            throw new PublicationServiceException("Error performing 'com.ht.syndication.htsportal.service.PublicationService.deletePublication(java.lang.String nickName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deletePublication(java.lang.String)}
      */
    protected abstract void handleDeletePublication(Integer id) throws Exception;

    /**
     * @see com.ht.syndication.htsportal.service.PublicationService#getAllPublications()
     */
    public PublicationVO[] getAllPublication()
    {
        try
        {
            return this.handleGetAllPublication();
        }
        catch (Throwable th)
        {
            throw new PublicationServiceException("Error performing 'com.ht.syndication.htsportal.service.PublicationService.getAllPublications()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllPublications()}
      */
    protected abstract PublicationVO[] handleGetAllPublication() throws Exception;
    
    
    
    /**
     * @see com.ht.syndication.htsportal.service.PublicationService#getAllActivePublication()
     */
    public PublicationVO[] getAllActivePublication()
    {
        try
        {
            return this.handleGetAllActivePublication();
        }
        catch (Throwable th)
        {
            throw new PublicationServiceException("Error performing 'com.ht.syndication.htsportal.service.PublicationService.getAllActivePublication()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllActivePublication()}
      */
    protected abstract PublicationVO[] handleGetAllActivePublication() throws Exception;
    
    /**
     * @see com.ht.syndication.htsportal.service.PublicationService#getAllActivePublication()
     */
    public PublicationShortVO[] getAllPublicationShort()
    {
        try
        {
            return this.handleGetAllPublicationShort();
        }
        catch (Throwable th)
        {
            throw new PublicationServiceException("Error performing 'com.ht.syndication.htsportal.service.PublicationService.getAllPublicationShort()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllActivePublication()}
      */
    protected abstract PublicationShortVO[] handleGetAllPublicationShort() throws Exception;
    

    /**
     * @see com.ht.syndication.htsportal.service.PublicationService#savePublication(com.ht.syndication.htsportal.transfer.PublicationVO)
     */
    public PublicationVO savePublication(PublicationVO publication, String userName)
    {
        if (publication == null)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.savePublication(com.ht.syndication.htsportal.transfer.PublicationVO publication, String userName) - 'publication' can not be null");
        }
        if (publication.getShortname() == null || publication.getShortname().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.savePublication(com.ht.syndication.htsportal.transfer.PublicationVO publication, String userName) - 'publication.shortname' can not be null or empty");
        }

        if (publication.getName() == null || publication.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.savePublication(com.ht.syndication.htsportal.transfer.PublicationVO publication, String userName) - 'publication.name' can not be null or empty");
        }
        if (publication.getStatus() == null )
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.savePublication(com.ht.syndication.htsportal.transfer.PublicationVO publication, String userName) - 'publication.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.PublicationService.savePublication(com.ht.syndication.htsportal.transfer.PublicationVO publication, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSavePublication(publication, userName);
        }
        catch (Throwable th)
        {
            throw new PublicationServiceException("Error performing 'com.ht.syndication.htsportal.service.PublicationService.savePublication(com.ht.syndication.htsportal.transfer.PublicationVO publication, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #savePublication(com.ht.syndication.htsportal.transfer.PublicationVO)}
      */
    protected abstract PublicationVO handleSavePublication(PublicationVO publication, String userName) throws Exception;
    
    /**
     * @see com.ht.syndication.htsportal.service.PublicationService#savePublication(com.ht.syndication.htsportal.transfer.PublicationVO)
     */
    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}