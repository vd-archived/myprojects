package com.ht.syndication.htsportal.service;

import java.util.List;

import com.ht.syndication.htsportal.transfer.ClientVO;

/**
 * 
 */
public interface ClientService
{
    /**
     * 
     */
	public ClientVO getClient(Integer id);
	/**
     * 
     */
	public List<ClientVO> getClientsByPublication(Integer id);
    /**
     * 
     */
	public ClientVO deleteClient(Integer id);

    /**
     * 
     */
    public ClientVO[] getAllClient();

    /**
     * 
     */
    public ClientVO saveClient(ClientVO client, String updateBy);
    /**
     * 
     */
}
