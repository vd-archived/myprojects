package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.Category;
import com.ht.syndication.htsportal.domain.CategoryDao;
import com.ht.syndication.htsportal.transfer.CategoryVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;


public class CategoryServiceImpl extends CategoryServiceBase
{

	@Override
	protected void handleDeleteCategory(Integer id) throws Exception 
	{
		CategoryDao categoryDataAccessor = super.getCategoryDao();
		CategoryVO categoryVO = categoryDataAccessor.toCategoryVO(categoryDataAccessor.load(id));
		categoryDataAccessor.remove(id);
		Utility.deleteArticleIndex(HTSPortal.Solr.Article.CATEGORY, categoryVO.getName());
	}

	@SuppressWarnings("unchecked")
    @Override
	protected CategoryVO[] handleGetAllCategory() throws Exception 
	{
        return (CategoryVO[]) super.getCategoryDao().loadAll(CategoryDao.TRANSFORM_CATEGORYVO).toArray(new CategoryVO[0]);
	}
	
	@Override
	protected CategoryVO handleGetCategory(Integer id) throws Exception 
	{
        return super.getCategoryDao().toCategoryVO(this.getCategoryDao().load(id));
	}

	@Override
	protected CategoryVO handleSaveCategory(CategoryVO categoryVO, String userName) throws Exception 
	{
		CategoryDao categoryDataAccessor = super.getCategoryDao();
		Category category = categoryDataAccessor.categoryVOToEntity(categoryVO);
		category.setUpdatedby(userName);
		CategoryVO result = (CategoryVO) categoryDataAccessor.create(CategoryDao.TRANSFORM_CATEGORYVO, category);
		if(categoryVO.getStatus().equals(AccessStatus.DISABLE))
		{
			Utility.deleteArticleIndex(HTSPortal.Solr.Article.CATEGORY, categoryVO.getName());
		}

		return result;
	}
}