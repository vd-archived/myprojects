package com.ht.syndication.htsportal.service;

import java.util.Set;

import com.ht.syndication.htsportal.transfer.ContentVO;

/**
 * 
 */
public interface ContentService
{
    /**
     * 
     */
	public ContentVO getContent(Integer id);
    /**
     * 
     */
	public void deleteContent(Integer id);

    /**
     * 
     */
    public ContentVO[] getAllContent();
    
    /**
     * 
     */
    
    public Boolean indexContent();
    
    public Boolean indexContent(Set<String> uniqueIds);

    /**
     * 
     */
    public String saveContent(ContentVO content, String updateBy);
    /**
     * 
     * @param content
     * @param updateBy
     * @return
     */
    public void saveBatchContent(String updateBy);
    /**
     * 
     */
    public String updateContent(ContentVO content, String updateBy);
}
