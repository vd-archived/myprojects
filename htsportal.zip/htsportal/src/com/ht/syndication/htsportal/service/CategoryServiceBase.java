package com.ht.syndication.htsportal.service;

import java.security.Principal;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.CategoryDao;
import com.ht.syndication.htsportal.transfer.CategoryVO;

/**
 * <p>
 * Spring Service base class for <code>com.ht.syndication.htsportal.service.CategoryService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see com.ht.syndication.htsportal.service.CategoryService
 */
public abstract class CategoryServiceBase implements CategoryService
{

    private CategoryDao categoryDao;

    /**
     * Sets the reference to <code>category</code>'s DAO.
     */
    public void setCategoryDao(CategoryDao categoryDao)
    {
        this.categoryDao = categoryDao;
    }

    /**
     * Gets the reference to <code>category</code>'s DAO.
     */
    protected CategoryDao getCategoryDao()
    {
        return this.categoryDao;
    }

    /**
     * @see com.ht.syndication.htsportal.service.CategoryService#deleteCategory(java.lang.String)
     */
    public CategoryVO getCategory(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.CategoryService.getCategory(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetCategory(id);
        }
        catch (Throwable th)
        {
            throw new CategoryServiceException("Error performing 'com.ht.syndication.htsportal.service.CategoryService.getCategory(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteCategory(java.lang.String)}
      */
    protected abstract CategoryVO handleGetCategory(Integer id) throws Exception;

    /**
     * @see com.ht.syndication.htsportal.service.CategoryService#deleteCategory(java.lang.String)
     */
    public void deleteCategory(Integer id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.CategoryService.deleteCategory(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteCategory(id);
        }
        catch (Throwable th)
        {
            throw new CategoryServiceException("Error performing 'com.ht.syndication.htsportal.service.CategoryService.deleteCategory(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteCategory(int)}
      */
    protected abstract void handleDeleteCategory(Integer id) throws java.lang.Exception;

    /**
     * @see com.ht.syndication.htsportal.service.CategoryService#getAllCategorys()
     */
    public CategoryVO[] getAllCategory()
    {
        try
        {
            return this.handleGetAllCategory();
        }
        catch (Throwable th)
        {
            throw new CategoryServiceException("Error performing 'com.ht.syndication.htsportal.service.CategoryService.getAllCategory()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllCategorys()}
      */
    protected abstract CategoryVO[] handleGetAllCategory() throws Exception;

    /**
     * @see com.ht.syndication.htsportal.service.CategoryService#saveCategory(com.ht.syndication.htsportal.transfer.CategoryVO)
     */
    public CategoryVO saveCategory(CategoryVO category, String userName)
    {
        if (category == null)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.CategoryService.saveCategory(com.ht.syndication.htsportal.transfer.CategoryVO category, String userName) - 'category' can not be null");
        }
        if (category.getName() == null || category.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.CategoryService.saveCategory(com.ht.syndication.htsportal.transfer.CategoryVO category, String userName) - 'category.name' can not be null or empty");
        }
        if (category.getStatus() == null )
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.CategoryService.saveCategory(com.ht.syndication.htsportal.transfer.CategoryVO category, String userName) - 'category.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("com.ht.syndication.htsportal.service.CategoryService.saveCategory(com.ht.syndication.htsportal.transfer.CategoryVO category, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveCategory(category, userName);
        }
        catch (Throwable th)
        {
            throw new CategoryServiceException("Error performing 'com.ht.syndication.htsportal.service.CategoryService.saveCategory(com.ht.syndication.htsportal.transfer.CategoryVO category, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveCategory(com.ht.syndication.htsportal.transfer.CategoryVO)}
      */
    protected abstract CategoryVO handleSaveCategory(CategoryVO category, String userName) throws Exception;
    
    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}