package com.ht.syndication.htsportal.service;

import java.util.List;

import com.ht.syndication.htsportal.transfer.LoginVO;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.UserVO;

/**
 * 
 */
public interface UserService
{

    /**
     * 
     */
    public LoginVO authenticate(String username, String password);

    /**
     * 
     */
    public void deleteUser(String username);

    /**
     * 
     */
    public UserVO getUser(String username);
    
    /**
     * 
     */
    public List<UserVO> getAllUsers(Short role);

    /**
     * 
     */
    public UserVO saveUser(UserVO user, String userName);
    
    /**
     * 
     */
    public UserVO updateUser(UserVO user, String userName);
    
    /**
     * 
     */
    public List<PublicationShortVO> getAllPublication(String userName);
}
