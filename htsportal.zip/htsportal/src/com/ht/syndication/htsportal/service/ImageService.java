package com.ht.syndication.htsportal.service;

import java.io.File;
import java.util.List;

import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;

/**
 * 
 */
public interface ImageService
{
    /**
     * 
    */
	public ImageVO getImage(int id);
	
	/**
     * 
    */
	public ImageFullVO getFullImage(int id);
    
	/**
     * 
     */
	public void deleteImage(int id);
	
	/**
     * 
     */
	public ImageVO disableImage(int id, String updateBy);

    /**
     * 
     */
    public List<ImageVO> getAllImage();
    
    /**
     * 
     */
    public List<ImageFullVO> getAllFullImage();
    
    /**
     * 
     */
    public List<ImageFullVO> getAllInactiveImage();
    
    /**
     * 
     */
    public ImageVO saveImage(ImageVO source, String updateBy);
    
    /**
     * 
     */
    public ImageVO uploadImage(ImageVO source, String updateBy);
    
    /**
     * 
     */
    public List<String> uploadImage(List<File> uploads, List<String> uploadFileNames, List<String> uploadContentTypes, String keywords, String copyright, Integer event, List<Integer>tags, String updateBy);
    
    
    /**
     * 
     */
    public void saveBatchImages(String username);
    
    /**
     * 
     */
    public Boolean indexImage();
}
