package com.ht.syndication.htsportal.service;

import java.util.ArrayList;
import java.util.List;

import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.Imagetags;
import com.ht.syndication.htsportal.domain.ImagetagsDao;
import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;


public class ImagetagsServiceImpl extends ImagetagsServiceBase
{

	@Override
	protected void handleDeleteImagetags(int id) throws Exception 
	{
		ImagetagsDao imagetagsDataAccessor = super.getImagetagsDao();
		ImagetagsVO imagetagsVO = imagetagsDataAccessor.toImagetagsVO(imagetagsDataAccessor.load(id));
		imagetagsDataAccessor.remove(id);
		Utility.deleteImageIndex(HTSPortal.Solr.Image.TAGS, imagetagsVO.getName());
	}
	
	@Override
	protected ImagetagsVO handleDisableImagetags(int id, String userName) throws Exception 
	{
		ImagetagsDao imagetagsDataAccessor = super.getImagetagsDao();
		Imagetags imagetags = imagetagsDataAccessor.load(id);
		imagetags.setStatus(AccessStatus.DISABLE);
		imagetags.setUpdateby(userName);
		ImagetagsVO result = (ImagetagsVO) imagetagsDataAccessor.create(ImagetagsDao.TRANSFORM_IMAGETAGSVO, imagetags);
		Utility.deleteImageIndex(HTSPortal.Solr.Image.TAGS, result.getName());
		return result;
	}
	
	@Override
	protected List<ImagetagsVO> handleGetAllImagetags() throws Exception 
	{
        return new ArrayList(super.getImagetagsDao().loadAll(ImagetagsDao.TRANSFORM_IMAGETAGSVO));
	}
	
	@Override
	protected List<ImagetagsFullVO> handleGetAllHierarchyImagetags() throws Exception 
	{
		List<ImagetagsFullVO> resultCategories = new ArrayList<ImagetagsFullVO>();
		resultCategories = new ArrayList(super.getImagetagsDao().loadAllActiveByParent(ImagetagsDao.TRANSFORM_IMAGETAGSFULLVO, null));
        return resultCategories;
	}

	@Override
	protected ImagetagsVO handleGetImagetags(int id) throws Exception 
	{
        return super.getImagetagsDao().toImagetagsVO(this.getImagetagsDao().load(id));
	}

	@Override
	protected ImagetagsVO handleSaveImagetags(ImagetagsVO imagetagsVO, String userName) throws Exception 
	{
	    ImagetagsDao imagetagsDataAccessor = super.getImagetagsDao();
		Imagetags imagetags = imagetagsDataAccessor.imagetagsVOToEntity(imagetagsVO);
		imagetags.setUpdateby(userName);
		if(imagetagsVO.getParent()!=null)
		{
			imagetags.setParent(imagetagsDataAccessor.load(imagetagsVO.getParent()));
		}
		else
		{
			imagetags.setParent(null);
		}
		ImagetagsVO result = (ImagetagsVO) imagetagsDataAccessor.create(ImagetagsDao.TRANSFORM_IMAGETAGSVO, imagetags);
		if(!imagetagsVO.getStatus().equals(AccessStatus.ENABLE))
		{
			Utility.deleteImageIndex(HTSPortal.Solr.Image.TAGS, imagetagsVO.getName());
		}
		return result;
	}
}