package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.transfer.SubscriptionVO;
import com.ht.syndication.htsportal.transfer.UsermessageVO;

/**
 * 
 */
public interface UsermessageService
{
    /**
     * 
     */
	public UsermessageVO getUsermessage(Integer id);
    /**
     * 
     */
	public void deleteUsermessage(Integer id);

    /**
     * 
     */
    public UsermessageVO[] getAllUsermessage();

    /**
     * 
     */
    public UsermessageVO saveUsermessage(UsermessageVO usermessage, String updateBy);
    /**
     * 
     */
    
    
    
    /**
     * 
     */
	public SubscriptionVO getSubscriptionMsg(Integer id);
    /**
     * 
     */
	public void deleteSubscriptionMsg(Integer id);

    /**
     * 
     */
    public SubscriptionVO[] getAllSubscriptionMsg();

    /**
     * 
     */
    public SubscriptionVO saveSubscriptionMsg(SubscriptionVO subscriptionMsg, String updateBy);
}