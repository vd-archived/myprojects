package com.ht.syndication.htsportal.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import com.ht.syndication.htsportal.domain.Client;
import com.ht.syndication.htsportal.domain.ClientDao;
import com.ht.syndication.htsportal.domain.Publication;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.transfer.ClientVO;


public class ClientServiceImpl extends ClientServiceBase
{

	@Override
	protected ClientVO handleDeleteClient(Integer id) throws Exception 
	{
		ClientDao clientDataAccessor = super.getClientDao();
		ClientVO clientVO = clientDataAccessor.toClientVO(clientDataAccessor.load(id));
		clientDataAccessor.remove(id);
		return clientVO;
	}

	@SuppressWarnings("unchecked")
    @Override
	protected ClientVO[] handleGetAllClient() throws Exception 
	{
        return (ClientVO[]) super.getClientDao().loadAll(ClientDao.TRANSFORM_CLIENTVO).toArray(new ClientVO[0]);
	}
	
	@SuppressWarnings("unchecked")
    @Override
	protected List<ClientVO> handleGetClientsByPublication(Integer id) throws Exception 
	{
		List<ClientVO> result = null;
		Publication publication = super.getPublicationDao().load(id);
		if(publication != null)
		{
			Collection entities = publication.getClient();
			super.getClientDao().toClientVOCollection(entities);
			result = new ArrayList<ClientVO>(entities);
		}
		return result;
	}

	@Override
	protected ClientVO handleGetClient(Integer id) throws Exception 
	{
        return super.getClientDao().toClientVO(this.getClientDao().load(id));
	}

	@Override
	protected ClientVO handleSaveClient(ClientVO clientVO, String userName) throws Exception 
	{
		ClientDao clientDataAccessor = super.getClientDao();
		Client client = clientDataAccessor.clientVOToEntity(clientVO);
		if(clientVO.getPublications() !=null && clientVO.getPublications().size() > 0)
		{
			PublicationDao publicationDataAccessor = super.getPublicationDao();
			Collection<Publication> publications = new HashSet<Publication>();
			for(String publication: clientVO.getPublications())
			{
				if(!publication.trim().equals(""))
				{
					publications.add(publicationDataAccessor.load(Integer.parseInt(publication)));
				}
			}
			client.setPublication(publications);
		}
		client.setUpdatedby(userName);
		ClientVO result = (ClientVO) clientDataAccessor.create(ClientDao.TRANSFORM_CLIENTVO, client);
		return result;
	}
}