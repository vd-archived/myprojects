package com.ht.syndication.htsportal.service;

import java.util.Date;
import java.util.List;

import com.ht.syndication.htsportal.transfer.PublicationRevenueVO;
import com.ht.syndication.htsportal.transfer.RevenueVO;

/**
 * 
 */
public interface RevenueService
{
    /**
     * 
     */
	public RevenueVO getRevenue(Integer id);
    /**
     * 
     */
	public RevenueVO deleteRevenue(Integer id);

    /**
     * 
     */
    public RevenueVO[] getAllRevenue();

    /**
     * 
     */
    public RevenueVO saveRevenue(RevenueVO revenue, String updateBy);
    
    /**
     * 
     */
    public List<RevenueVO> saveBatchRevenue(List<RevenueVO> revenue, String updateBy);
    
    /**
     * 
     */
    public List<PublicationRevenueVO> getRevenueByPublicationDate(List<Integer> publication, final Date date);
    
    public PublicationRevenueVO getRevenueByPublicationDate(Integer publication, final Date date);
    
    public List<PublicationRevenueVO> getRevenueByPublicationDateRange(List<Integer> publication, final Date startDate, final Date endDate);
    
    public PublicationRevenueVO getRevenueByPublicationDateRange(Integer publication, final Date startDate, final Date endDate);
}
