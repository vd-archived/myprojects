package com.ht.syndication.htsportal.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.common.SolrInputDocument;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.EventDao;
import com.ht.syndication.htsportal.domain.Image;
import com.ht.syndication.htsportal.domain.ImageDao;
import com.ht.syndication.htsportal.domain.Imagetags;
import com.ht.syndication.htsportal.domain.ImagetagsDao;
import com.ht.syndication.htsportal.domain.ImagetagsType;
import com.ht.syndication.htsportal.transfer.EventVO;
import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;
import com.ht.syndication.htsportal.util.FTPUtility;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;


public class ImageServiceImpl extends ImageServiceBase
{
	private static final Log LOGGER = LogFactory.getLog(ImageServiceImpl.class);
	private static final ConfigurationReader FTP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.FTP_PROFILE);
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APPLICATION_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

	@Override
	protected void handleDeleteImage(int id) throws Exception 
	{
		ImageDao imageDataAccessor = super.getImageDao();
		ImageVO imageVO = imageDataAccessor.toImageVO(imageDataAccessor.load(id));
		imageDataAccessor.remove(id);
		Utility.deleteImageIndex(HTSPortal.Solr.Image.CONTENT, imageVO.getId().toString());
	}
	
	@Override
	protected ImageVO handleDisableImage(int id, String userName) throws Exception 
	{
		ImageDao imageDataAccessor = super.getImageDao();
		Image image = imageDataAccessor.load(id);
		image.setStatus(AccessStatus.DISABLE);
		image.setUpdateby(userName);
		ImageVO result = (ImageVO) imageDataAccessor.create(ImageDao.TRANSFORM_IMAGEVO, image);
		Utility.deleteImageIndex(HTSPortal.Solr.Image.CONTENT, result.getId().toString());
		return result;
	}
	
	@Override
	protected List<ImageVO> handleGetAllImage() throws Exception 
	{
        return new ArrayList(super.getImageDao().loadAll(ImageDao.TRANSFORM_IMAGEVO));
	}
	
	@Override
	protected List<ImageFullVO> handleGetAllInactiveImage() throws Exception {
		return new ArrayList<ImageFullVO>(super.getImageDao().loadAllInactiveImages(ImageDao.TRANSFORM_SOLRIMAGEVO));
	}
	
	@Override
	protected List<ImageFullVO> handleGetAllFullImage() throws Exception 
	{
        return new ArrayList(super.getImageDao().loadAll(ImageDao.TRANSFORM_SOLRIMAGEVO));
	}

	@Override
	protected ImageVO handleGetImage(int id) throws Exception 
	{
        return super.getImageDao().toImageVO(this.getImageDao().load(id));
	}
	
	@Override
	protected ImageFullVO handleGetFullImage(int id) throws Exception 
	{
		return super.getImageDao().toImageFullVO(this.getImageDao().load(id));
	}

	@Override
	protected ImageVO handleSaveImage(ImageVO imageVO, String userName) throws Exception 
	{
		Boolean isCreateOperation = (imageVO.getId() == null);
	    ImageDao imageDataAccessor = super.getImageDao();
	    Image image = imageDataAccessor.imageVOToEntity(imageVO);
		if(imageVO.getEvent() != null && !imageVO.getEvent().equals(""))
		{
			image.setEvent(super.getEventDao().load(imageVO.getEvent()));
		}
		Collection<Imagetags> imagetags = new HashSet<Imagetags>();
		if(imageVO.getTags() != null && imageVO.getTags().size() > 0)
		{
			for(Integer tagid: imageVO.getTags())
			{
				if(!tagid.equals(""))
				{
					imagetags.add(super.getImagetagsDao().load(tagid));
				}
			}
		}
		image.setImagetags(imagetags);
		image.setIndexdate(null);
		image.setUpdateby(userName);
		ImageVO result = (ImageVO) imageDataAccessor.create(ImageDao.TRANSFORM_IMAGEVO, image);
		if(isCreateOperation)
		{
			image.setName(image.getName() + image.getId().toString());
			result.setName(image.getName());
		}
		if(!imageVO.getStatus().equals(AccessStatus.ENABLE))
		{
			Utility.deleteImageIndex(HTSPortal.Solr.Image.CONTENT, imageVO.getId().toString());
		}
		return result;
	}
	
	private Map<String, Integer> getEventMap(List<EventVO>eventVOs)
	{
		Map<String, Integer>events = new HashMap<String, Integer>();
		if(eventVOs != null)
		{
			for(EventVO event: eventVOs)
			{
				events.put(event.getName(), event.getId());
			}
		}
		return events;
	}
	
	private Map<String, Integer> getTagsMap(List<ImagetagsVO>tagsVOs)
	{
		Map<String, Integer>tags = new HashMap<String, Integer>();
		if(tagsVOs != null)
		{
			for(ImagetagsVO tag: tagsVOs)
			{
				tags.put(tag.getName(), tag.getId());
			}
		}
		return tags;
	}
	
	@Override
	protected List<String> handleUploadImage(List<File> uploads, List<String> uploadFileNames, List<String> uploadContentTypes, String keywords, String copyright, Integer event, List<Integer> tags, String updateBy) {
		Properties property = HTSPortal.SERVLETCONTEXT;
		File watermarkFile = new File(property.getProperty("APP_RROT") + APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.WATERMARKTILES));
		Float opeque = Float.parseFloat(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.WATERMARKBRIGHTNESS));
		File originalFolder = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.ORIGINALIMAGEDIRECTORY));
		File errorFolder = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.ERRORDIRECTORY));
		File processFolder = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY));
		
		if(!watermarkFile.exists()) {
			System.out.println("No Watermark file found..." + watermarkFile.getAbsolutePath());
		}
		
		Boolean isHomeImage = Boolean.FALSE;

		List<ImagetagsVO> imagetagsVOs = new ArrayList(super.getImagetagsDao().loadAllByType(ImagetagsDao.TRANSFORM_IMAGETAGSVO, ImagetagsType.SECTION));
		for(ImagetagsVO tag: imagetagsVOs)
		{
			if(tag.getType().equals(ImagetagsType.SECTION))
			{
				isHomeImage = Boolean.TRUE;
				break;
			}
		}
		Integer counter = 0;
		List<String> status = new ArrayList<String>();
		if(uploads.size()>0)
		{
			Iterator<File> uploadFileIte = uploads.iterator();
			Iterator<String> uploadTypeIte = uploadContentTypes.iterator();
			Iterator<String> uploadNameIte = uploadFileNames.iterator();
		    while (uploadTypeIte.hasNext())
		    {
		    	Boolean success = Boolean.FALSE;
		        File uploadFile = uploadFileIte.next();
		        String uploadType = uploadTypeIte.next();
		        String uploadName = uploadNameIte.next();
		        if(uploadType.startsWith("image") || (uploadType.contains("application/octet-stream")))
		        {
	        		try
		        	{
	        			String checksum = Utility.getChecksum(uploadFile);
			        	String imageUploadName = "HTSI" + new Date().getTime() + (counter++);
			        	String extension = uploadName.substring(uploadName.lastIndexOf("."));
			        	
			        	ImageVO imageVO = Utility.getImageMetadata(uploadFile);
			        	imageVO.setName(imageUploadName);
			        	imageVO.setExtension(extension);
			        	imageVO.setChecksum(checksum);
			        	imageVO.setStatus(AccessStatus.IMAGE_UPLOADED);
			        	if(keywords != null)
			        	{
			        		if(imageVO.getKeywords() != null)
			        		{
			        			keywords += imageVO.getKeywords();
			        		}
			        		imageVO.setKeywords(keywords);
			        	}
			        	if(copyright != null)
			        	{
			        		if(imageVO.getCopyright() != null)
			        		{
			        			copyright += imageVO.getCopyright();
			        		}
			        		imageVO.setCopyright(copyright);
			        	}
			        	if(event != null)
			        	{
			        		imageVO.setEvent(event);
			        	}
			        	if(tags != null)
			        	{
			        		imageVO.setTags(tags);
			        	}
			        	
			        	File originalFile = new File(originalFolder, imageVO.getName() + imageVO.getExtension());
						File mediumFile = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.MEDIUM + File.separator + imageVO.getName() + ".jpg");
						File errorFile = new File(errorFolder, uploadName);
						File thumbFile  = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.THUMB  + File.separator + imageVO.getName() + ".jpg");
						File homeFile   = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.MEDIUM_450_350  + File.separator + imageVO.getName() + ".jpg");
//						FileUtils.copyFile(uploadFile, originalFile, Boolean.TRUE);
						success = Utility.resizeImage(uploadFile, mediumFile, Boolean.TRUE, 500, 500, watermarkFile, opeque);
						if(success){
							success = Utility.resizeImage(uploadFile, thumbFile, 160, 160, watermarkFile, opeque);
							if(isHomeImage && success)
							{
								success = Utility.resizeImage(uploadFile, homeFile, Boolean.TRUE, Boolean.TRUE, 450, 350, watermarkFile, opeque);
							}
							if(success) {
								try {
									imageVO = uploadImage(imageVO, updateBy);
									if(imageVO != null) {
										status.add("File '"+uploadName+"' uploaded successfully with name: " + imageVO.getName());
									}
								} catch(Exception e){
									success = Boolean.FALSE;
									LOGGER.error("Failed thumbnail generation on original image file: " + uploadFile.getName() + " and Error Message [" + e.getMessage() + "]");
								}
							}
						}
						if(!success)
						{
							Utility.moveFile(uploadFile, errorFile);
							LOGGER.error("Failed thumbnail generation on original image file: " + originalFile.getAbsolutePath() + " and moved to error folder...");
							status.add("File '"+uploadName+"' uploaded failed");
						}
						else
						{
							LOGGER.info("File '"+uploadName+"' uploaded successfully with name: " + imageVO.getName());
						}
		        	}
	        		catch(ImageServiceException e)
	        		{
	        			status.add("File '"+uploadName+"' is failed: " + e.getMessage());
	        			LOGGER.error("IMAGE ERROR::File '"+uploadName+"' is failed: " + e.getMessage());
	        		}
		        	catch(Exception e)
		        	{
		        		status.add("File '"+uploadName+"' copy failed: " + e.getMessage());
		        		LOGGER.error("IMAGE ERROR::File '"+uploadName+"' copy failed...\n"+e.getMessage());
		        		e.printStackTrace();
		        	}
		        }
		        else
		        {
		        	status.add("File '"+uploadName+"' copy failed, not a type of image ("+uploadType+")...");
		        	LOGGER.error("IMAGE ERROR::File '"+uploadName+"' copy failed, not a type of image...");
		        }
		    }
		}
		return status;
	}

	
	@Override
	protected void handleSaveBatchImages(String userName) throws Exception 
	{
		LOGGER.info("Save Batch Function");
		Integer maxprocess = Utility.convertToInteger(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAXPROCESS), 100);
		Boolean continueBatch = Boolean.FALSE;
		Map<String, Integer>events = getEventMap(new ArrayList(super.getEventDao().loadAll(EventDao.TRANSFORM_EVENTVO)));
		Map<String, Integer>tags = getTagsMap(new ArrayList(super.getImagetagsDao().loadAll(ImagetagsDao.TRANSFORM_IMAGETAGSVO)));
		do
		{
			FTPClient ftpClient = FTPUtility.getFtpConnection(FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.URL), FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.USERNAME) , FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.PASSWORD));
			if(ftpClient.getReplyCode() == 230)
			{
				continueBatch = FTPUtility.downloadFiles(FTP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.FTP.Image.ROOT_PATH), ftpClient, maxprocess, HTSPortal.DOWNLOADTYPE.IMAGEENDSWITH, HTSPortal.IMAGE.TEMPDIRECTORY);
				LOGGER.info("Batch Image Reading Start");

				File directory = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.TEMPDIRECTORY));
				File eventDirectory = new File(directory, HTSPortal.FTP.Image.EVENTROOT);
				File tagDirectory = new File(directory, HTSPortal.FTP.Image.CATEGORYROOT);
				if(!eventDirectory.exists() || !tagDirectory.exists())
				{
					eventDirectory.mkdirs();
					tagDirectory.mkdirs();
				}
				if(eventDirectory.exists())
				{
					List<File>rootFiles = new ArrayList<File>();
					List<File>eventDirectories = new ArrayList<File>();
					FTPUtility.getAllFilesAndDirectory(eventDirectory, eventDirectories, rootFiles, HTSPortal.DOWNLOADTYPE.IMAGEENDSWITH);
					if(rootFiles.size() > 0)
					{
						for(File file: rootFiles)
						{
							LOGGER.error("Image have not event and category to map ['" + file.getAbsolutePath() + "']'");
						}
					}
					if(eventDirectories.size() > 0)
					{
						for(File file: eventDirectories)
						{
							Integer eventID = events.get(file.getName());
							if(eventID == null)
							{
								LOGGER.error("Event ['" + file.getName() + "'] not found...");
							}
							else
							{
								rootFiles.clear();
								List<File>tagsDirectory = new ArrayList<File>();
								FTPUtility.getAllFilesAndDirectory(file, tagsDirectory, rootFiles, HTSPortal.DOWNLOADTYPE.IMAGEENDSWITH);
								
								this.processFileList(rootFiles, null, null, eventID, null, userName);
								
								if(tagsDirectory.size() > 0)
								{
									for(File tag: tagsDirectory)
									{
										this.processTagsFileList(tag, null, null, eventID, tags, userName);
									}
								}
							}
						}
					}
				}
				if(tagDirectory.exists())
				{
					List<File>rootFiles = new ArrayList<File>();
					List<File>tagDirectories = new ArrayList<File>();
					FTPUtility.getAllFilesAndDirectory(tagDirectory, tagDirectories, rootFiles, HTSPortal.DOWNLOADTYPE.IMAGEENDSWITH);
					if(rootFiles.size() > 0)
					{
						for(File file: rootFiles)
						{
							LOGGER.error("Image have not event and category to map ['" + file.getAbsolutePath() + "']'");
						}
					}
					if(tagDirectories.size() > 0)
					{
						rootFiles.clear();
						if(tagDirectories.size() > 0)
						{
							for(File tag: tagDirectories)
							{
								this.processTagsFileList(tag, null, null, null, tags, userName);
							}
						}
					}
				}
				LOGGER.info("Batch Image Reading End");
				FTPUtility.closeFtpConnection(ftpClient);
			}
			else
			{
				LOGGER.error("Unable to connect ftp server");
				continueBatch = Boolean.FALSE;
			}
		}while(continueBatch);
		LOGGER.info("Save Batch Function END");
	}
	
	private void processTagsFileList(File tagFolder, String keyword, String copyright, Integer event, Map<String, Integer>tags, String updateBy)
	{
		if(tagFolder.exists() && tagFolder.isDirectory())
		{
			List<Integer>tagIDs = new ArrayList<Integer>();
			if(tags.get(tagFolder.getName()) != null)
			{
				tagIDs.add(tags.get(tagFolder.getName()));
				List<File>directories = new ArrayList<File>();
				List<File>files = new ArrayList<File>();
				FTPUtility.getAllFilesAndDirectory(tagFolder, directories, files, HTSPortal.DOWNLOADTYPE.IMAGEENDSWITH);
				
				this.processFileList(files, null, null, event, tagIDs, updateBy);
				
				if(directories.size() > 0)
				{
					for(File tag: directories)
					{
						this.processTagsFileList(tag, null, null, event, tags, updateBy);
					}
				}
			}
			else
			{
				LOGGER.error("Image Tags ['" + tagFolder.getName() + "'] not found...");
			}
		}
	}

	private void processFileList(List<File>files, String keyword, String copyright, Integer event, List<Integer>tags, String updateBy)
	{
		List<String> uploadFileNames = new ArrayList<String>();
		List<String> uploadContentTypes = new ArrayList<String>();
		if(files !=null && files.size() > 0)
		{
			for(File file: files)
			{
				uploadFileNames.add(file.getName());
				uploadContentTypes.add("image/jpeg");
			}
			List<String> status = this.handleUploadImage(files, uploadFileNames, uploadContentTypes, keyword, copyright, event, tags, updateBy);
			printErrorLogs(status);
			deleteAll(files);
		}
	}
	
	private void printErrorLogs(List<String>errors){
		if(errors != null)
		{
			for(String error: errors)
			{
				LOGGER.error(error);
			}
		}
	}
	
	private void deleteAll(List<File>files)
	{
		if(files !=null && files.size() > 0)
		{
			for(File file: files)
			{
				if(file.exists()) {
					file.delete();
					LOGGER.info(file.getAbsolutePath() + " is deleted");
				}
			}
		}
	}

	@Override
	protected ImageVO handleUploadImage(ImageVO imageVO, String updateBy) throws Exception {
		ImageDao imageDataAccessor = super.getImageDao();
	    if(imageVO.getId() == null)
	    {
		    ImageVO temp = (ImageVO)imageDataAccessor.loadByChecksum(ImageDao.TRANSFORM_IMAGEVO, imageVO.getChecksum());
		    if(temp != null)
		    {
		    	throw new ImageServiceException("Image already exists with name = " + temp.getName());
		    }
	    }
		Image image = imageDataAccessor.imageVOToEntity(imageVO);
		if(imageVO.getEvent() != null && !imageVO.getEvent().equals(""))
		{
			image.setEvent(super.getEventDao().load(imageVO.getEvent()));
		}
		if(imageVO.getTags() != null && imageVO.getTags().size() > 0)
		{
			Collection<Imagetags> imagetags = new HashSet<Imagetags>();
			for(Integer tagid: imageVO.getTags())
			{
				if(tagid != null)
				{
					imagetags.add(super.getImagetagsDao().load(tagid));
				}
			}
			image.setImagetags(imagetags);
		}
		image.setUpdateby(updateBy);
		ImageVO result = (ImageVO) imageDataAccessor.create(ImageDao.TRANSFORM_IMAGEVO, image);
/*		image.setName(image.getName() + image.getId().toString());
		result.setName(image.getName());*/
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected Boolean handleIndexImage() throws Exception 
	{
		LOGGER.info("Image Index Function Start");
		Boolean result = Boolean.FALSE;
		try
		{
			Properties property = HTSPortal.SERVLETCONTEXT;
			File watermarkFile = new File(property.getProperty("APP_RROT") + APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.WATERMARKTILES));
			Float opeque = Float.parseFloat(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.WATERMARKBRIGHTNESS));
			
			File processFolder = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY));
			
			List<Image> listImage =  null;
			Integer count = 1;
			Integer MAXPROCESS = Utility.convertToInteger(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAXPROCESS), null);
			List<SolrInputDocument> solrInputDocuments = new ArrayList<SolrInputDocument>();
			do
			{
				LOGGER.info("Load Image List..................");
				listImage =  (List<Image>) getImageDao().loadAllNotIndexed(ImageDao.TRANSFORM_NONE, MAXPROCESS);
				for(Image entity: listImage)
				{
					LOGGER.info("Image ID Processing: " + entity.getId());
					Boolean isHomeImage = Boolean.FALSE;
					Boolean success = Boolean.FALSE;
					for(Imagetags tag: entity.getImagetags())
					{
						if(tag.getType().equals(ImagetagsType.SECTION))
						{
							isHomeImage = Boolean.TRUE;
							break;
						}
					}
					File mediumFile = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.MEDIUM + File.separator + entity.getName() + ".jpg");
					File homeFile   = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.MEDIUM_450_350  + File.separator + entity.getName() + ".jpg"); 
					if(isHomeImage)
					{
						if(homeFile.exists())
						{
							success = Boolean.TRUE;
						}
						else if(mediumFile.exists())
						{
							success = Utility.resizeImage(mediumFile, homeFile, Boolean.TRUE, Boolean.TRUE, 450, 350, watermarkFile, opeque);
						}
						else
						{
							LOGGER.error("Medium image file not found for home image: " + mediumFile.getName());
						}
					}
					else
					{
						success = Boolean.TRUE;
					}
					if(success)
					{
						SolrInputDocument doc = new SolrInputDocument();
						ImageFullVO image = getImageDao().toImageFullVO(entity);
	
						doc.addField( "id", image.getId());
						doc.addField( "name", image.getName());
						doc.addField( "extension", image.getExtension());
						doc.addField( "title", image.getTitle());
						doc.addField( "author", image.getAuthor());
						doc.addField( "details", image.getDetails());
						doc.addField( "type", image.getType());
						doc.addField( "orientation", image.getOrientation());
						doc.addField( "editorial", image.getOrientation());
						doc.addField( "keywords", image.getKeywords());
						doc.addField( "copyright", image.getCopyright());
	/*					doc.addField( "width", image.getWidth());
						doc.addField( "height", image.getHeight());
						doc.addField( "resolution", image.getResolution());*/
						doc.addField( "checksum", image.getChecksum());
						if(image.getCapturedate() != null)
						{
							doc.addField( "capturedate", Utility.toSolrDate(image.getCapturedate()));
						}
						doc.addField( "updatedate", Utility.toSolrDate(new Date()));
						doc.addField( "event", image.getEventName());
						doc.addField( "tags", image.getTagsNames());
						solrInputDocuments.add(doc);
						if(success && mediumFile.exists())
						{
							entity.setIndexdate(new Date());
							entity.setStatus(AccessStatus.ENABLE);
						}
					}
				}
				LOGGER.info("Indexed Image..................");
				if(saveIndex(solrInputDocuments))
				{
					LOGGER.info("Indexed Image Completed");
					getImageDao().update(listImage);
					LOGGER.info("Updated Image :: "+listImage.size()*count++);
					result = Boolean.TRUE;
				}
			}while(listImage.size() >= MAXPROCESS);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			LOGGER.info("Problem with indexing [ "+ e.getMessage() +" ]");
		}
		LOGGER.info("Image Index Function END");
		return result;
	}

	/**
	 * 
	 * @param solrInputDocuments
	 * @return
	 */
	private Boolean saveIndex(List<SolrInputDocument>solrInputDocuments)
	{
		Boolean result = Boolean.FALSE;
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.URL));
			if(solrInputDocuments != null && solrInputDocuments.size()>0)
			{
				solrServer.add(solrInputDocuments);
				solrServer.commit();
			}
			result = Boolean.TRUE;
		}
		catch(Exception e)
		{
			LOGGER.error(e.getMessage());
		}
		return result;
	}

}




































/*
@Override
	protected void handleSaveBatchImageThumbnail() throws Exception {
		LOGGER.info("Image Batch Function");
		Integer maxprocess = Utility.convertToInteger(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAXPROCESS), 10000);
		File originalFolder = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.ORIGINALIMAGEDIRECTORY));
		File processFolder = new File(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY));
		Boolean continueBatch = Boolean.TRUE;
		do
		{
			List<Image> images = new ArrayList(super.getImageDao().loadAllNotIndexed(ImageDao.TRANSFORM_NONE, maxprocess));
			if(images.size()>0)
			{
				Properties property = HTSPortal.SERVLETCONTEXT;
				File watermarkFile = new File(property.getProperty("APP_RROT") + APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.WATERMARKTILES));
				Float opeque = Float.parseFloat(APPLICATION_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.WATERMARKBRIGHTNESS));
				for(Image image: images)
				{
					LOGGER.info("Image ID Processing: " + image.getId());
					Boolean isHomeImage = Boolean.FALSE;
					for(Imagetags tag: image.getImagetags())
					{
						if(tag.getType().equals(ImagetagsType.SECTION))
						{
							isHomeImage = Boolean.TRUE;
							break;
						}
					}
					File originalFile = new File(originalFolder, image.getName() + image.getExtension());
					File mediumFile = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.MEDIUM + File.separator + image.getName() + ".jpg");
					File thumbFile  = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.THUMB  + File.separator + image.getName() + ".jpg");
					File homeFile   = new File(processFolder.getAbsolutePath() + File.separator + HTSPortal.IMAGE.MEDIUM_450_350  + File.separator + image.getName() + ".jpg"); 
					if(originalFile.exists())
					{
						Boolean success = Utility.resizeImage(originalFile, mediumFile, Boolean.TRUE, 500, 500, watermarkFile, opeque);
						if(success)
						{
							success = Utility.resizeImage(originalFile, thumbFile, 160, 160, watermarkFile, opeque);
						}
						if(isHomeImage && success)
						{
							success = Utility.resizeImage(originalFile, homeFile, Boolean.TRUE, Boolean.TRUE, 450, 350, watermarkFile, opeque);
						}
						ImageVO imageVO = Utility.getImageMetadata(originalFile);
						super.getImageDao().imageVOToEntity(imageVO, image, Boolean.FALSE);
						try{
							if(success)
								originalFile.delete();
						}catch(Exception e){
							LOGGER.error("Failed to delete original image file: " + originalFile.getAbsolutePath());
						}
					}
					else if(isHomeImage)
					{
						if(mediumFile.exists())
						{
							Utility.resizeImage(mediumFile, homeFile, Boolean.TRUE, Boolean.TRUE, 450, 350, watermarkFile, opeque);
						}
						else
						{
							LOGGER.error("Medium image file not found: " + mediumFile.getAbsolutePath());
						}
					}
				}
			}
			else
			{
				continueBatch = Boolean.FALSE;
			}
		}while(continueBatch);
		LOGGER.info("Save Batch Function END");
	}

*/