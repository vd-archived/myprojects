package com.ht.syndication.htsportal.service;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.ClientDao;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.domain.RevenueDao;
import com.ht.syndication.htsportal.transfer.PublicationRevenueVO;
import com.ht.syndication.htsportal.transfer.RevenueVO;

public abstract class RevenueServiceBase implements RevenueService
{

    private RevenueDao revenueDao;
    private PublicationDao publicationDao;
    private ClientDao clientDao;

    /**
     * Sets the reference to <code>revenue</code>'s DAO.
     */
    public void setRevenueDao(RevenueDao revenueDao)
    {
        this.revenueDao = revenueDao;
    }


    protected RevenueDao getRevenueDao()
    {
        return this.revenueDao;
    }
    
    protected PublicationDao getPublicationDao() {
		return publicationDao;
	}

	public void setPublicationDao(PublicationDao publicationDao) {
		this.publicationDao = publicationDao;
	}
	
	public ClientDao getClientDao() {
		return clientDao;
	}

	public void setClientDao(ClientDao clientDao) {
		this.clientDao = clientDao;
	}


	public RevenueVO getRevenue(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("RevenueService.getRevenue(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetRevenue(id);
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.getRevenue(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteRevenue(java.lang.String)}
      */
    protected abstract RevenueVO handleGetRevenue(Integer id) throws Exception;

    /**
     * @see RevenueService#deleteRevenue(java.lang.String)
     */
    public RevenueVO deleteRevenue(Integer id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("RevenueService.deleteRevenue(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleDeleteRevenue(id);
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.deleteRevenue(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteRevenue(int)}
      */
    protected abstract RevenueVO handleDeleteRevenue(Integer id) throws java.lang.Exception;

    /**
     * @see RevenueService#getAllRevenues()
     */
    public RevenueVO[] getAllRevenue()
    {
        try
        {
            return this.handleGetAllRevenue();
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.getAllRevenue()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllRevenues()}
      */
    protected abstract RevenueVO[] handleGetAllRevenue() throws Exception;
    
    public PublicationRevenueVO getRevenueByPublicationDate(Integer publication, final Date date)
    {
    	if (publication == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDate(Integer publication, Date date) - 'publication' can not be null");
        }
    	if (date == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDate(Integer publication, Date date) - 'date' can not be null");
        }
        try
        {
        	PublicationRevenueVO result = null;
        	List<Integer>pubs = new ArrayList<Integer>();
        	pubs.add(publication);
        	List<PublicationRevenueVO>fetchResult = this.handleGetRevenueByPublicationDate(pubs, date);
        	if(fetchResult != null && fetchResult.size() > 0)
        	{
        		result = fetchResult.get(0);
        	}
        	return result;
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.getRevenueByPublicationDate(Integer Publication, Date date)' --> " + th, th);
        }
    }
    
    /**
     * @see RevenueService#getAllRevenues()
     */
    public List<PublicationRevenueVO> getRevenueByPublicationDate(List<Integer> publication, final Date date)
    {
    	if (publication == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDate(List<Integer> publication, Date date) - 'publication' can not be null");
        }
    	if (date == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDate(List<Integer> publication, Date date) - 'date' can not be null");
        }
        try
        {
            return this.handleGetRevenueByPublicationDate(publication, date);
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.getRevenueByPublicationDate(List<Integer> Publication, Date date)' --> " + th, th);
        }
    }

    /**
     *  Performs the core logic for {@link #getRevenueByPublicationDate()}
     */
    protected abstract List<PublicationRevenueVO> handleGetRevenueByPublicationDate(List<Integer> publication, final Date date) throws Exception;

    
    public PublicationRevenueVO getRevenueByPublicationDateRange(Integer publication, final Date startDate, final Date endDate)
    {
    	if (publication == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDateRange(Integer publication, final Date startDate, final Date endDate) - 'publication' can not be null");
        }
    	if (startDate == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDateRange(Integer publication, final Date startDate, final Date endDate) - 'startDate' can not be null");
        }
    	if (endDate == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDateRange(Integer publication, final Date startDate, final Date endDate) - 'endDate' can not be null");
        }
        try
        {
        	PublicationRevenueVO result = null;
        	List<Integer>pubs = new ArrayList<Integer>();
        	pubs.add(publication);
        	List<PublicationRevenueVO>fetchResult = this.handleGetRevenueByPublicationDateRange(pubs, startDate, endDate);
        	if(fetchResult != null && fetchResult.size() > 0)
        	{
        		result = fetchResult.get(0);
        	}
        	return result;
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.getRevenueByPublicationDate(Integer Publication, Date date)' --> " + th, th);
        }
    }
    
    public List<PublicationRevenueVO> getRevenueByPublicationDateRange(List<Integer> publication, final Date startDate, final Date endDate)
    {
    	if (publication == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDateRange(List<Integer> publication, final Date startDate, final Date endDate) - 'publication' can not be null");
        }
    	if (startDate == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDateRange(List<Integer> publication, final Date startDate, final Date endDate) - 'startDate' can not be null");
        }
    	if (endDate == null)
        {
            throw new IllegalArgumentException("RevenueService.getRevenueByPublicationDateRange(List<Integer> publication, final Date startDate, final Date endDate) - 'endDate' can not be null");
        }
        try
        {
        	return this.handleGetRevenueByPublicationDateRange(publication, startDate, endDate);
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.getRevenueByPublicationDate(Integer Publication, Date date)' --> " + th, th);
        }
    }
    
    protected abstract List<PublicationRevenueVO> handleGetRevenueByPublicationDateRange(List<Integer> publication, final Date startDate, final Date endDate) throws Exception;
    
    
    /**
     * @see RevenueService#saveRevenue(RevenueVO)
     */
    public RevenueVO saveRevenue(RevenueVO revenue, String userName)
    {
        if (revenue == null)
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'revenue' can not be null");
        }
        if (revenue.getClient() == null || revenue.getClient().trim().length() == 0)
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'revenue.client' can not be null or empty");
        }
        if (revenue.getPublication() == null || revenue.getPublication().trim().length() == 0)
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'revenue.publication' can not be null or empty");
        }
        if (revenue.getDate() == null )
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'revenue.date' can not be null or empty");
        }
        if (revenue.getAmount() == null )
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'revenue.amount' can not be null or empty");
        }
        if (revenue.getStatus() == null )
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'revenue.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveRevenue(revenue, userName);
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.saveRevenue(RevenueVO revenue, String userName)' --> " + th, th);
        }
    }
    
     /**
      * Performs the core logic for {@link #saveRevenue(RevenueVO)}
      */
    protected abstract RevenueVO handleSaveRevenue(RevenueVO revenue, String userName) throws Exception;
    
    public List<RevenueVO> saveBatchRevenue(List<RevenueVO> revenues, String userName)
    {
        if (revenues == null)
        {
            throw new IllegalArgumentException("RevenueService.saveBatchRevenue(List<RevenueVO> revenues, String userName) - 'revenues' can not be null");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveBatchRevenue(revenues, userName);
        }
        catch (Throwable th)
        {
            throw new RevenueServiceException("Error performing 'RevenueService.handleSaveRevenue(RevenueVO revenue, String userName)' --> " + th, th);
        }
    }
    
     /**
      * Performs the core logic for {@link #saveRevenue(RevenueVO)}
      */
    protected abstract List<RevenueVO> handleSaveBatchRevenue(List<RevenueVO> revenues, String userName) throws Exception;
    
    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}