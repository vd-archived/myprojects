package com.ht.syndication.htsportal.service;

import java.io.File;
import java.io.FileInputStream;

import org.apache.commons.io.IOUtils;
import org.apache.struts2.ServletActionContext;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.domain.OldImagecategory;
import com.ht.syndication.htsportal.domain.OldImagecategoryDao;
import com.ht.syndication.htsportal.transfer.ImageFileVO;
import com.ht.syndication.htsportal.transfer.ImagecategoryVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;



public class OldImageServiceImpl extends OldImageServiceBase
{
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

	@Override
	protected ImagecategoryVO handleDeleteImagecategory(Integer id) throws Exception 
	{
		ImagecategoryVO imagecategoryVO = super.getImagecategoryDao().toImagecategoryVO(this.getImagecategoryDao().load(id));
		super.getImagecategoryDao().remove(id);
		Utility.deleteIntroductionXML(HTSPortal.XMLFile.IMAGE, imagecategoryVO.getId());
		Utility.deleteMenu(HTSPortal.XMLFile.IMAGE, imagecategoryVO.getName());
//		deleteImageCategoryFolder(imagecategoryVO.getName());
		return imagecategoryVO;
	}

	@SuppressWarnings("unchecked")
    @Override
	protected ImagecategoryVO[] handleGetAllActiveImagecategory() throws Exception 
	{
        return (ImagecategoryVO[]) super.getImagecategoryDao().loadAllActive(OldImagecategoryDao.TRANSFORM_IMAGECATEGORYVO).toArray(new ImagecategoryVO[0]);
	}

	@SuppressWarnings("unchecked")
    @Override
	protected ImagecategoryVO[] handleGetAllImagecategory() throws Exception 
	{
        return (ImagecategoryVO[]) super.getImagecategoryDao().loadAll(OldImagecategoryDao.TRANSFORM_IMAGECATEGORYVO).toArray(new ImagecategoryVO[0]);
	}
	
	@Override
	protected ImagecategoryVO handleGetImagecategory(Integer id) throws Exception 
	{
        return super.getImagecategoryDao().toImagecategoryVO(this.getImagecategoryDao().load(id));
	}

	@Override
	protected ImagecategoryVO handleSaveImagecategory(ImagecategoryVO imagecategoryVO, String userName) throws Exception 
	{
		OldImagecategoryDao imagecategoryDataAccessor = super.getImagecategoryDao();
		if(imagecategoryVO.getId()!=null)
		{
			imagecategoryVO.setOldName(super.getImagecategoryDao().toImagecategoryVO(this.getImagecategoryDao().load(imagecategoryVO.getId())).getName());
		}
		OldImagecategory oldImagecategory = imagecategoryDataAccessor.imagecategoryVOToEntity(imagecategoryVO);
		oldImagecategory.setUpdatedby(userName);
		ImagecategoryVO result = (ImagecategoryVO) imagecategoryDataAccessor.create(OldImagecategoryDao.TRANSFORM_IMAGECATEGORYVO, oldImagecategory);
		if(imagecategoryVO.getId()!=null)
		{
			result.setOldName(imagecategoryVO.getOldName());
		}
		if(imagecategoryVO.getId()==null)
		{
			createImageCategoryFolder(result.getName());
		}
		else if(!result.getName().equalsIgnoreCase(result.getOldName()))
		{
			renameImageCategoryFolder(result.getName(), result.getOldName());
		}
		Utility.saveIntroductionXML(HTSPortal.XMLFile.IMAGE, result.getId(), result.getName(), result.getDetails(), result.getStatus(), result.getHighlightStatusInString(), result.getPriority());
		Utility.saveMenu(HTSPortal.XMLFile.IMAGE, result.getOldName(), result.getName(), result.getStatus(), result.getHighlight(), result.getPriority());
		return result;
	}
	

	@Override
	protected ImageFileVO handleLoadImage(String basePath, String cat, String subcat, String filename) throws Exception {
		ImageFileVO result = null;
		if(!(basePath == null || cat == null || filename == null))
		{
			File imageFile = new File(basePath);
			imageFile = new File(imageFile, cat);
			if(subcat!=null)
			{
				imageFile = new File(imageFile, subcat);
			}
			imageFile = new File(imageFile, filename);
			if (!imageFile.exists())
			{
				imageFile = new File(imageFile.getParentFile(), "404.png");
			}
			if (!imageFile.exists())
			{
				imageFile = new File(ServletActionContext.getServletContext().getRealPath("/images/404.png"));
			}
			if (imageFile.exists())
			{
				FileInputStream fis = null;
				try
				{
					fis = new FileInputStream(imageFile);
					result = new ImageFileVO(filename, getContentType(filename), IOUtils.toByteArray(new FileInputStream(imageFile)));
					fis.close();
				}
				finally
				{
					if(fis!=null)
					{
						fis.close();
					}
				}
			}
		}
		return result;
	}
	
	private String getContentType(String imageExtension)
	{
		if(imageExtension.contains("."))
		{
			imageExtension = imageExtension.substring(imageExtension.lastIndexOf("."));
		}
		String result = "application/force-download";
		
		if(imageExtension.equalsIgnoreCase("pdf"))
		{
			result = "application/pdf";
		}
		else if(imageExtension.equalsIgnoreCase("exe"))
		{
			result = "application/octet-stream";
		}
		else if(imageExtension.equalsIgnoreCase("zip"))
		{
			result = "application/zip";
		}
		else if(imageExtension.equalsIgnoreCase("doc"))
		{
			result = "application/msword";
		}
		else if(imageExtension.equalsIgnoreCase("xls"))
		{
			result = "application/vnd.ms-excel";
		}
		else if(imageExtension.equalsIgnoreCase("ppt"))
		{
			result = "application/vnd.ms-powerpoint";
		}
		else if(imageExtension.equalsIgnoreCase("gif"))
		{
			result = "image/gif";
		}
		else if(imageExtension.equalsIgnoreCase("png"))
		{
			result = "image/png";
		}
		else if(imageExtension.equalsIgnoreCase("jpeg") || imageExtension.equalsIgnoreCase("jpg"))
		{
			result = "image/jpg";
		}
		return result;
	}
	
	private Boolean createImageCategoryFolder(String categoryName)
	{
		Boolean result = Boolean.FALSE;
		File imageCategory = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), categoryName);
		File childImageCategory = new File(imageCategory, HTSPortal.IMAGE.MEDIUM);
		try
		{
			childImageCategory.mkdirs();
			childImageCategory = new File(imageCategory, HTSPortal.IMAGE.THUMB);
			result = childImageCategory.mkdirs();
		}catch(Exception e)
		{
//			System.out.println("FAILED:: Create Image Category " + categoryName + "\n\t\t" + e.getMessage());
		}
		return result;
	}

	
	private Boolean renameImageCategoryFolder(String newCategoryName, String oldCategoryName)
	{
		Boolean result = Boolean.FALSE;
		File oldImageCategory = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), oldCategoryName);
		File newImageCategory = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), newCategoryName);
		try
		{
			result = oldImageCategory.renameTo(newImageCategory);
		}catch(Exception e)
		{
//			System.out.println("FAILED:: Rename Image Category From '" + oldCategoryName + "' To '" + newCategoryName + "'\n\t\t" + e.getMessage());
		}
		return result;
	}
	
	private Boolean deleteImageCategoryFolder(String categoryName)
	{
		Boolean result = Boolean.FALSE;
		File imageCategory = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), categoryName);
		try
		{
			result = deleteFolder(imageCategory);
		}catch(Exception e)
		{
//			System.out.println("FAILED:: Delete Image Category '" + categoryName + "'\n\t\t" + e.getMessage());
		}
		return result;
	}
	
	private Boolean deleteFolder(File file)
	{
		Boolean result = Boolean.FALSE;
		if(file.exists())
		{
			if(file.isDirectory()){
				File[]childs = file.listFiles();
				if(childs.length>0)
				{
					for(int i=0; i<childs.length; i++)
					{
						deleteFolder(childs[i]);
					}
				}
			}
			file.delete();
			result = Boolean.TRUE;
		}
		else
		{
			result = Boolean.TRUE;
		}
		return result;
	}
}