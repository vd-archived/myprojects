package com.ht.syndication.htsportal.service;

import java.security.Principal;
import java.util.List;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.ClientDao;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.transfer.ClientVO;

public abstract class ClientServiceBase implements ClientService
{

    private ClientDao clientDao;
    private PublicationDao publicationDao;

    /**
     * Sets the reference to <code>client</code>'s DAO.
     */
    public void setClientDao(ClientDao clientDao)
    {
        this.clientDao = clientDao;
    }


    protected ClientDao getClientDao()
    {
        return this.clientDao;
    }
    
    protected PublicationDao getPublicationDao() {
		return publicationDao;
	}

	public void setPublicationDao(PublicationDao publicationDao) {
		this.publicationDao = publicationDao;
	}

	public ClientVO getClient(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("ClientService.getClient(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetClient(id);
        }
        catch (Throwable th)
        {
            throw new ClientServiceException("Error performing 'ClientService.getClient(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteClient(java.lang.String)}
      */
    protected abstract ClientVO handleGetClient(Integer id) throws Exception;
    
	public List<ClientVO> getClientsByPublication(Integer id)
    {
        if (id == null || id == 0)
        {
            throw new IllegalArgumentException("ClientService.getClientsByPublication(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetClientsByPublication(id);
        }
        catch (Throwable th)
        {
            throw new ClientServiceException("Error performing 'ClientService.getClientsByPublication(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getClientsByPublication(java.lang.Integer)}
      */
    protected abstract List<ClientVO> handleGetClientsByPublication(Integer id) throws Exception;
    
    /**
     * @see ClientService#deleteClient(java.lang.String)
     */
    public ClientVO deleteClient(Integer id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("ClientService.deleteClient(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleDeleteClient(id);
        }
        catch (Throwable th)
        {
            throw new ClientServiceException("Error performing 'ClientService.deleteClient(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteClient(int)}
      */
    protected abstract ClientVO handleDeleteClient(Integer id) throws java.lang.Exception;

    /**
     * @see ClientService#getAllClients()
     */
    public ClientVO[] getAllClient()
    {
        try
        {
            return this.handleGetAllClient();
        }
        catch (Throwable th)
        {
            throw new ClientServiceException("Error performing 'ClientService.getAllClient()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllClients()}
      */
    protected abstract ClientVO[] handleGetAllClient() throws Exception;

    /**
     * @see ClientService#saveClient(ClientVO)
     */
    public ClientVO saveClient(ClientVO client, String userName)
    {
        if (client == null)
        {
            throw new IllegalArgumentException("ClientService.saveClient(ClientVO client, String userName) - 'client' can not be null");
        }
        if (client.getName() == null || client.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("ClientService.saveClient(ClientVO client, String userName) - 'client.name' can not be null or empty");
        }
        if (client.getStatus() == null )
        {
            throw new IllegalArgumentException("ClientService.saveClient(ClientVO client, String userName) - 'client.status' can not be null or empty");
        }
        if (client.getRevenueinterval() == null )
        {
            throw new IllegalArgumentException("ClientService.saveClient(ClientVO client, String userName) - 'client.revenueinterval' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("ClientService.saveClient(ClientVO client, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveClient(client, userName);
        }
        catch (Throwable th)
        {
            throw new ClientServiceException("Error performing 'ClientService.saveClient(ClientVO client, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveClient(ClientVO)}
      */
    protected abstract ClientVO handleSaveClient(ClientVO client, String userName) throws Exception;
    
    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}