package com.ht.syndication.htsportal.service;

import java.io.File;
import java.security.Principal;
import java.util.List;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.EventDao;
import com.ht.syndication.htsportal.domain.ImageDao;
import com.ht.syndication.htsportal.domain.ImagetagsDao;
import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;

/**
 * <p>
 * Spring Service base class for <code>ImageService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see ImageService
 */
public abstract class ImageServiceBase implements ImageService
{
	private ImagetagsDao imagetagsDao;
    private ImageDao imageDao;
    private EventDao eventDao;
    
    public void setImagetagsDao(ImagetagsDao imagetagsDao)
    {
        this.imagetagsDao = imagetagsDao;
    }

    public ImagetagsDao getImagetagsDao()
    {
        return this.imagetagsDao;
    }
    
    public ImageDao getImageDao() {
		return this.imageDao;
	}

    public void setImageDao(ImageDao imageDao) {
		this.imageDao = imageDao;
	}

    public EventDao getEventDao() {
		return this.eventDao;
	}

    public void setEventDao(EventDao eventDao) {
		this.eventDao = eventDao;
	}

    /**
     * @see ImageService#deleteImage(java.lang.String)
     */
    public ImageVO getImage(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("ImageService.getImage(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetImage(id);
        }
        catch (Throwable th)
        {
            throw new ImageServiceException("Error performing 'ImageService.getImage(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteImage(java.lang.String)}
      */
    protected abstract ImageVO handleGetImage(int id) throws Exception;
    
    /**
     * @see ImageService#deleteImage(java.lang.String)
     */
    public ImageFullVO getFullImage(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("ImageService.getFullImage(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetFullImage(id);
        }
        catch (Throwable th)
        {
            throw new ImageServiceException("Error performing 'ImageService.getFullImage(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteImage(java.lang.String)}
      */
    protected abstract ImageFullVO handleGetFullImage(int id) throws Exception;

    /**
     * @see ImageService#deleteImage(java.lang.String)
     */
    public void deleteImage(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("ImageService.deleteImage(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteImage(id);
        }
        catch (Throwable th)
        {
            throw new ImageServiceException("Error performing 'ImageService.deleteImage(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteImage(int)}
      */
    protected abstract void handleDeleteImage(int id) throws Exception;
    
    /**
     * @see ImageService#deleteImage(java.lang.String)
     */
    public ImageVO disableImage(int id, String updateBy)
    {
        if (id < 1 || updateBy==null || updateBy.trim().equals(""))
        {
            throw new IllegalArgumentException("ImageService.disableImage(int id, String updateBy) - 'id' or 'updateBy' can not be null or empty");
        }
        try
        {
            return this.handleDisableImage(id, updateBy);
        }
        catch (Throwable th)
        {
            throw new ImageServiceException("Error performing 'ImageService.disableImage(int id, String updateBy)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #disableImage(int, String)}
      */
    protected abstract ImageVO handleDisableImage(int id, String updateBy) throws Exception;
    
    /**
     * @see ImageService#getAllFullImage()
     */
    public List<ImageFullVO> getAllFullImage()
    {
        try
        {
            return this.handleGetAllFullImage();
        }
        catch (Throwable th)
        {
            throw new ImageServiceException("Error performing 'ImageService.getAllFullImage()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllImages()}
      */
    protected abstract List<ImageFullVO> handleGetAllFullImage() throws Exception;
    
    /**
     * @see ImageService#getAllFullImage()
     */
    public List<ImageFullVO> getAllInactiveImage()
    {
        try
        {
            return this.handleGetAllInactiveImage();
        }
        catch (Throwable th)
        {
            throw new ImageServiceException("Error performing 'ImageService.getAllInactiveImage()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllImages()}
      */
    protected abstract List<ImageFullVO> handleGetAllInactiveImage() throws Exception;

    /**
     * @see ImageService#getAllImage()
     */
    public List<ImageVO> getAllImage()
    {
        try
        {
            return this.handleGetAllImage();
        }
        catch (Throwable th)
        {
            throw new ImageServiceException("Error performing 'ImageService.getAllImages()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllImages()}
      */
    protected abstract List<ImageVO> handleGetAllImage() throws Exception;

    
    /**
     * @see ImageService#saveImage(com.ht.syndication.htsportal.transfer.ImageVO)
     */
    public ImageVO saveImage(ImageVO image, String userName)
    {
        if (image == null)
        {
            throw new IllegalArgumentException("ImageService.saveImage(com.ht.syndication.htsportal.transfer.ImageVO image, String userName) - 'image' can not be null");
        }
        if (userName == null || userName.length() == 0)
        {
            throw new IllegalArgumentException("ImageService.saveImage(com.ht.syndication.htsportal.transfer.ImageVO image, String userName) - 'userName' can not be null or empty");
        }
        if (image.getName() == null || image.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("ImageService.saveImage(com.ht.syndication.htsportal.transfer.ImageVO image, String userName) - 'image.name' can not be null or empty");
        }
        if (image.getStatus() == null)
        {
            throw new IllegalArgumentException("ImageService.saveImage(com.ht.syndication.htsportal.transfer.ImageVO image, String userName) - 'image.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("ImageService.saveImage(com.ht.syndication.htsportal.transfer.ImageVO image, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveImage(image, userName);
        }
        catch (Throwable th)
        {
            th.printStackTrace();
            throw new ImageServiceException("Error performing 'ImageService.saveImage(com.ht.syndication.htsportal.transfer.ImageVO image, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveImage(com.ht.syndication.htsportal.transfer.ImageVO)}
      */
    protected abstract ImageVO handleSaveImage(ImageVO image, String userName) throws Exception;
    
    
    public ImageVO uploadImage(ImageVO source, String updateBy)
    {
    	if (source == null)
        {
            throw new IllegalArgumentException("ImageService.uploadImage(ImageVO source, String updateBy)' --> 'source' can not be null");
        }
    	if (updateBy == null)
        {
            throw new IllegalArgumentException("ImageService.uploadImage(ImageVO source, String updateBy)' --> 'updateBy' can not be null");
        }
    	try
    	{
    		return this.handleUploadImage(source, updateBy);
    	}
    	catch(ImageServiceException e)
    	{
    		throw new ImageServiceException(e.getMessage());
    	}
    	catch (Throwable th)
        {
            th.printStackTrace();
            throw new ImageServiceException("Error performing 'ImageService.handleUploadImage(ImageVO source, String updateBy)' --> " + th, th);
        }
    }
    
    /**
     * Performs the core logic for {@link #uploadImage(com.ht.syndication.htsportal.transfer.ImageVO, String)}
     */
    protected abstract ImageVO handleUploadImage(ImageVO source, String updateBy) throws Exception;
    
    public List<String> uploadImage(List<File> uploads, List<String> uploadFileNames, List<String> uploadContentTypes, String keywords, String copyright, Integer event, List<Integer>tags, String updateBy)
    {
    	if (uploads == null)
        {
            throw new IllegalArgumentException("ImageService.uploadImage(List<File> uploads, ----, String updateBy)' --> 'uploads' can not be null");
        }
    	if (updateBy == null)
        {
            throw new IllegalArgumentException("ImageService.uploadImage(List<File> uploads, ----, String updateBy)' --> 'updateBy' can not be null");
        }
    	try
    	{
    		return this.handleUploadImage(uploads, uploadFileNames, uploadContentTypes, keywords, copyright, event, tags, updateBy);
    	}
    	catch(ImageServiceException e)
    	{
    		throw new ImageServiceException(e.getMessage());
    	}
    	catch (Throwable th)
        {
            th.printStackTrace();
            throw new ImageServiceException("Error performing 'ImageService.uploadImage(List<File> uploads, ----, String updateBy)' --> " + th, th);
        }
    }
    
    /**
     * Performs the core logic for {@link #uploadImage(List<File> uploads, List<String> uploadFileNames, List<String> uploadContentTypes, String keywords, String copyright, Integer event, List<Integer>tags, String updateBy)}
     */
    protected abstract List<String> handleUploadImage(List<File> uploads, List<String> uploadFileNames, List<String> uploadContentTypes, String keywords, String copyright, Integer event, List<Integer>tags, String updateBy);
    
  
    public void saveBatchImages(String username)
    {
    	try
    	{
    		this.handleSaveBatchImages(username);
    	}
    	catch (Throwable th)
        {
            th.printStackTrace();
            throw new ImageServiceException("Error performing 'ImageService.saveBatchImages(String username)' --> " + th, th);
        }
    }
    
    /**
     * Performs the core logic for {@link #saveImage(com.ht.syndication.htsportal.transfer.ImageVO)}
     */
    protected abstract void handleSaveBatchImages(String username) throws Exception;
    
    
    public Boolean indexImage()
    {
    	try
        {
            return this.handleIndexImage();
        }
        catch (Throwable th)
        {
            throw new ContentServiceException("Error performing 'ImageService.indexImage()' --> " + th, th);
        }
    }
    
    /**
     * 
     */
    protected abstract Boolean handleIndexImage() throws Exception;
    
    
    /**
     * 
     * @return
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}