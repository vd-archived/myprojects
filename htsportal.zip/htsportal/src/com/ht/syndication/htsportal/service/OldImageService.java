package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.transfer.ImageFileVO;
import com.ht.syndication.htsportal.transfer.ImagecategoryVO;


/**
 * 
 */
public interface OldImageService
{
    /**
     * 
     */
	public ImageFileVO loadImage(String basePath, String cat, String subcat, String filename);
	
	/**
     * 
     */
	public ImagecategoryVO getImagecategory(Integer id);
    /**
     * 
     */
	public ImagecategoryVO deleteImagecategory(Integer id);

    /**
     * 
     */
    public ImagecategoryVO[] getAllImagecategory();
    
    /**
     * 
     */
    public ImagecategoryVO[] getAllActiveImagecategory();

    /**
     * 
     */
    public ImagecategoryVO saveImagecategory(ImagecategoryVO imagecategory, String updateBy);
}
