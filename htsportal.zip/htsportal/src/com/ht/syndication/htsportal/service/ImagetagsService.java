package com.ht.syndication.htsportal.service;

import java.util.List;

import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;

/**
 * 
 */
public interface ImagetagsService
{
    /**
     * 
     */
	public ImagetagsVO getImagetags(int id);
    /**
     * 
     */
	public void deleteImagetags(int id);
	
	/**
     * 
     */
	public ImagetagsVO disableImagetags(int id, String updateBy);

    /**
     * 
     */
    public List<ImagetagsVO> getAllImagetags();
    
    /**
     * 
     */
    public List<ImagetagsFullVO> getAllHierarchyImagetags();


    /**
     * 
     */
    public ImagetagsVO saveImagetags(ImagetagsVO source, String updateBy);
}
