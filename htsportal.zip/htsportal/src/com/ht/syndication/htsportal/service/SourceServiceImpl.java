package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.Source;
import com.ht.syndication.htsportal.domain.SourceDao;
import com.ht.syndication.htsportal.transfer.SourceVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;


public class SourceServiceImpl extends SourceServiceBase
{

	@Override
	protected void handleDeleteSource(int id) throws Exception 
	{
		SourceDao sourceDataAccessor = super.getSourceDao();
		SourceVO sourceVO = sourceDataAccessor.toSourceVO(sourceDataAccessor.load(id));
		sourceDataAccessor.remove(id);
		Utility.deleteArticleIndex(HTSPortal.Solr.Article.SOURCE, sourceVO.getName());
	}

	@SuppressWarnings("unchecked")
    @Override
	protected SourceVO[] handleGetAllSource() throws Exception 
	{
        return (SourceVO[]) super.getSourceDao().loadAll(SourceDao.TRANSFORM_SOURCEVO).toArray(new SourceVO[0]);
	}
	
	@SuppressWarnings("unchecked")
    @Override
	protected SourceVO[] handleGetAllActiveSource() throws Exception 
	{
        return (SourceVO[]) super.getSourceDao().loadAllActive(SourceDao.TRANSFORM_SOURCEVO).toArray(new SourceVO[0]);
	}
	
	@Override
	protected SourceVO handleGetSource(int id) throws Exception 
	{
        return super.getSourceDao().toSourceVO(this.getSourceDao().load(id));
	}

	@Override
	protected SourceVO handleSaveSource(SourceVO sourceVO, String userName) throws Exception 
	{
	    SourceDao sourceDataAccessor = super.getSourceDao();
		Source source = sourceDataAccessor.sourceVOToEntity(sourceVO);
		source.setUpdatedby(userName);
		SourceVO result = (SourceVO) sourceDataAccessor.create(SourceDao.TRANSFORM_SOURCEVO, source);
		if(sourceVO.getStatus().equals(AccessStatus.DISABLE))
		{
			Utility.deleteArticleIndex(HTSPortal.Solr.Article.SOURCE, sourceVO.getName());
		}

		return result;
	}
}