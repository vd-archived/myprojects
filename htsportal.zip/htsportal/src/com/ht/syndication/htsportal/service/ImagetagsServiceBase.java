package com.ht.syndication.htsportal.service;

import java.security.Principal;
import java.util.List;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.ImagetagsDao;
import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;

/**
 * <p>
 * Spring Service base class for <code>ImagetagsService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see ImagetagsService
 */
public abstract class ImagetagsServiceBase implements ImagetagsService
{
    private ImagetagsDao imagetagsDao;
    
    /**
     * Sets the reference to <code>imagetags</code>'s DAO.
     */
    public void setImagetagsDao(ImagetagsDao imagetagsDao)
    {
        this.imagetagsDao = imagetagsDao;
    }

    /**
     * Gets the reference to <code>imagetags</code>'s DAO.
     */
    protected ImagetagsDao getImagetagsDao()
    {
        return this.imagetagsDao;
    }

    /**
     * @see ImagetagsService#deleteImagetags(java.lang.String)
     */
    public ImagetagsVO getImagetags(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("ImagetagsService.getImagetags(int id) - 'id' can not be null or empty");
        }
        try
        {
            return this.handleGetImagetags(id);
        }
        catch (Throwable th)
        {
            throw new ImagetagsServiceException("Error performing 'ImagetagsService.getImagetags(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteImagetags(java.lang.String)}
      */
    protected abstract ImagetagsVO handleGetImagetags(int id) throws Exception;

    /**
     * @see ImagetagsService#deleteImagetags(java.lang.String)
     */
    public void deleteImagetags(int id)
    {
        if (id < 1)
        {
            throw new IllegalArgumentException("ImagetagsService.deleteImagetags(int id) - 'id' can not be null or empty");
        }
        try
        {
            this.handleDeleteImagetags(id);
        }
        catch (Throwable th)
        {
            throw new ImagetagsServiceException("Error performing 'ImagetagsService.deleteImagetags(int id)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteImagetags(int)}
      */
    protected abstract void handleDeleteImagetags(int id) throws Exception;
    
    /**
     * @see ImagetagsService#deleteImagetags(java.lang.String)
     */
    public ImagetagsVO disableImagetags(int id, String updateBy)
    {
        if (id < 1 || updateBy==null || updateBy.trim().equals(""))
        {
            throw new IllegalArgumentException("ImagetagsService.disableImagetags(int id, String updateBy) - 'id' or 'updateBy' can not be null or empty");
        }
        try
        {
            return this.handleDisableImagetags(id, updateBy);
        }
        catch (Throwable th)
        {
            throw new ImagetagsServiceException("Error performing 'ImagetagsService.disableImagetags(int id, String updateBy)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #disableImagetags(int, String)}
      */
    protected abstract ImagetagsVO handleDisableImagetags(int id, String updateBy) throws Exception;

    /**
     * @see ImagetagsService#getAllImagetags()
     */
    public List<ImagetagsVO> getAllImagetags()
    {
        try
        {
            return this.handleGetAllImagetags();
        }
        catch (Throwable th)
        {
            throw new ImagetagsServiceException("Error performing 'ImagetagsService.getAllImagetagss()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllImagetagss()}
      */
    protected abstract List<ImagetagsVO> handleGetAllImagetags() throws Exception;

    /**
     * @see ImagetagsService#getAllHierarchyImagetags()
     */
    public List<ImagetagsFullVO> getAllHierarchyImagetags()
    {
        try
        {
            return this.handleGetAllHierarchyImagetags();
        }
        catch (Throwable th)
        {
            throw new ImagetagsServiceException("Error performing 'ImagetagsService.getAllHierarchyImagetags()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllHierarchyImagetags()}
      */
    protected abstract List<ImagetagsFullVO> handleGetAllHierarchyImagetags() throws Exception;

    /**
     * @see ImagetagsService#saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO)
     */
    public ImagetagsVO saveImagetags(ImagetagsVO imagetags, String userName)
    {
        if (imagetags == null)
        {
            throw new IllegalArgumentException("ImagetagsService.saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO imagetags, String userName) - 'imagetags' can not be null");
        }
        if (imagetags.getName() == null || imagetags.getName().trim().length() == 0)
        {
            throw new IllegalArgumentException("ImagetagsService.saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO imagetags, String userName) - 'imagetags.name' can not be null or empty");
        }
        if (imagetags.getType() == null)
        {
            throw new IllegalArgumentException("ImagetagsService.saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO imagetags, String userName) - 'imagetags.Type' can not be null or empty");
        }
        if (imagetags.getStatus() == null)
        {
            throw new IllegalArgumentException("ImagetagsService.saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO imagetags, String userName) - 'imagetags.status' can not be null or empty");
        }
        if (userName == null || userName.trim().length() == 0)
        {
            throw new IllegalArgumentException("ImagetagsService.saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO imagetags, String userName) - 'userName' can not be null or empty");
        }
        try
        {
            return this.handleSaveImagetags(imagetags, userName);
        }
        catch (Throwable th)
        {
            th.printStackTrace();
            throw new ImagetagsServiceException("Error performing 'ImagetagsService.saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO imagetags, String userName)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #saveImagetags(com.ht.syndication.htsportal.transfer.ImagetagsVO)}
      */
    protected abstract ImagetagsVO handleSaveImagetags(ImagetagsVO imagetags, String userName) throws Exception;
    
    /**
     * 
     * @return
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}