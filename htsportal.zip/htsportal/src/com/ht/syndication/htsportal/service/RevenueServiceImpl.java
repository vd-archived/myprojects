package com.ht.syndication.htsportal.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ht.syndication.htsportal.domain.Client;
import com.ht.syndication.htsportal.domain.ClientDao;
import com.ht.syndication.htsportal.domain.Publication;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.domain.Revenue;
import com.ht.syndication.htsportal.domain.RevenueDao;
import com.ht.syndication.htsportal.transfer.ClientRevenuesVO;
import com.ht.syndication.htsportal.transfer.PublicationRevenueVO;
import com.ht.syndication.htsportal.transfer.RevenueVO;
import com.ht.syndication.htsportal.util.Utility;


public class RevenueServiceImpl extends RevenueServiceBase
{

	@Override
	protected RevenueVO handleDeleteRevenue(Integer id) throws Exception 
	{
		RevenueDao revenueDataAccessor = super.getRevenueDao();
		RevenueVO revenueVO = revenueDataAccessor.toRevenueVO(revenueDataAccessor.load(id));
		revenueDataAccessor.remove(id);
		return revenueVO;
	}

	@SuppressWarnings("unchecked")
    @Override
	protected RevenueVO[] handleGetAllRevenue() throws Exception 
	{
        return (RevenueVO[]) super.getRevenueDao().loadAll(RevenueDao.TRANSFORM_REVENUEVO).toArray(new RevenueVO[0]);
	}
	
	@Override
	protected RevenueVO handleGetRevenue(Integer id) throws Exception 
	{
        return super.getRevenueDao().toRevenueVO(this.getRevenueDao().load(id));
	}
	
	@Override
	protected List<PublicationRevenueVO> handleGetRevenueByPublicationDate(List<Integer> publications, final Date date) throws Exception
	{
		List<PublicationRevenueVO> result = new ArrayList<PublicationRevenueVO>();
		try{
		RevenueDao revenueDataAccessor = super.getRevenueDao();
		ClientDao clientDataAccessor = super.getClientDao();
		PublicationDao publicationDataAccessor = super.getPublicationDao();
		for(Integer pub: publications)
		{
			Publication publication = publicationDataAccessor.load(pub);
			List<ClientRevenuesVO>clientRevenuesVOs = new ArrayList<ClientRevenuesVO>();
			for(Client client: publication.getClient())
			{
				ClientRevenuesVO clientRevenuesVO = new ClientRevenuesVO(clientDataAccessor.toClientVO(client));
				RevenueVO revenue = (RevenueVO) super.getRevenueDao().loadByPublicationClientDate(RevenueDao.TRANSFORM_REVENUEVO, publication, client, date);
				if(revenue != null)
				{
					clientRevenuesVO.addRevenue(revenue.getDate(), revenue.getAmount());
				}
				clientRevenuesVOs.add(clientRevenuesVO);
			}
			PublicationRevenueVO temp = new PublicationRevenueVO(publicationDataAccessor.toPublicationShortVO(publication), clientRevenuesVOs);
			result.add(temp);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	protected List<PublicationRevenueVO> handleGetRevenueByPublicationDateRange(List<Integer> publications, Date startDate, Date endDate) throws Exception {
		List<PublicationRevenueVO> result = new ArrayList<PublicationRevenueVO>();
		try{
		RevenueDao revenueDataAccessor = super.getRevenueDao();
		ClientDao clientDataAccessor = super.getClientDao();
		PublicationDao publicationDataAccessor = super.getPublicationDao();
		for(Integer pub: publications)
		{
			Publication publication = publicationDataAccessor.load(pub);
			List<ClientRevenuesVO>clientRevenuesVOs = new ArrayList<ClientRevenuesVO>();
			for(Client client: publication.getClient())
			{
				ClientRevenuesVO clientRevenuesVO = new ClientRevenuesVO(clientDataAccessor.toClientVO(client));
				RevenueVO[]revenues = (RevenueVO[]) super.getRevenueDao().loadByPublicationClientDateRange(RevenueDao.TRANSFORM_REVENUEVO, publication, client, startDate, endDate).toArray(new RevenueVO[0]);
				if(revenues != null)
				{
					for(RevenueVO revenue: revenues)
					{
						clientRevenuesVO.addRevenue(revenue.getDate(), revenue.getAmount());
					}
				}
				clientRevenuesVOs.add(clientRevenuesVO);
			}
			PublicationRevenueVO temp = new PublicationRevenueVO(publicationDataAccessor.toPublicationShortVO(publication), clientRevenuesVOs);
			result.add(temp);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}

	@Override
	protected RevenueVO handleSaveRevenue(RevenueVO revenueVO, String userName) throws Exception 
	{
		RevenueVO result = null;
		Publication publication = null;
		Client client = null;
		if(Utility.isNumeric(revenueVO.getClient()) && Utility.isNumeric(revenueVO.getPublication()))
		{
			publication = super.getPublicationDao().load(Integer.parseInt(revenueVO.getPublication()));
			if(publication == null)
			{
				throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - Publication with id='" + revenueVO.getPublication() + "' not found");
			}
			client = super.getClientDao().load(Integer.parseInt(revenueVO.getClient()));
			if(client == null)
			{
				throw new IllegalArgumentException("RevenueService.saveRevenue(RevenueVO revenue, String userName) - Client with id='" + revenueVO.getClient() + "' not found");
			}
			RevenueDao revenueDao = super.getRevenueDao();
			Revenue revenue = revenueDao.revenueVOToEntity(publication,client,revenueVO);
			revenue.setUpdatedby(userName);
			result = (RevenueVO) revenueDao.create(RevenueDao.TRANSFORM_REVENUEVO, revenue);
		}
		return result;
	}

	@Override
	protected List<RevenueVO> handleSaveBatchRevenue(List<RevenueVO> revenues, String userName) throws Exception {
		List<RevenueVO> failedRevenue = new ArrayList<RevenueVO>();
		PublicationDao publicationDao = this.getPublicationDao();
		ClientDao clientDao = this.getClientDao();
		RevenueDao revenueDao = super.getRevenueDao();
		
		Map<String, Publication> publicationMap = this.getAllPublication();
		Map<String, Client> clientMap = this.getAllClients();
		
		for(RevenueVO revenueVO: revenues)
		{
			Publication publication = publicationMap.get(revenueVO.getPublication());
			Client client = clientMap.get(revenueVO.getClient());
			if(publication == null || client == null)
			{
				failedRevenue.add(revenueVO);
				continue;
			}
			
			Revenue revenue = revenueDao.revenueVOToEntity(publication, client, revenueVO);
			revenue.setUpdatedby(userName);
			revenueDao.create(RevenueDao.TRANSFORM_NONE, revenue);
			
		}
		return failedRevenue;
	}

	@SuppressWarnings("unchecked")
	private Map<String, Publication> getAllPublication()
	{
		Map<String, Publication> publicationMap = new HashMap<String, Publication>();
		Collection<Publication> listPublication = super.getPublicationDao().loadAll(PublicationDao.TRANSFORM_NONE);
		for(Publication publication:listPublication)
		{
			publicationMap.put(publication.getName(), publication);
		}
		return publicationMap;
	}
	
	@SuppressWarnings("unchecked")
	private Map<String, Client> getAllClients()
	{
		Map<String, Client> clientMap = new HashMap<String, Client>();
		Collection<Client> listClient = super.getClientDao().loadAll(ClientDao.TRANSFORM_NONE);
		for(Client client: listClient)
		{
			clientMap.put(client.getName(), client);
		}
		return clientMap;
	}
}