package com.ht.syndication.htsportal.service;

import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.domain.Event;
import com.ht.syndication.htsportal.domain.EventDao;
import com.ht.syndication.htsportal.transfer.EventVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;


public class EventServiceImpl extends EventServiceBase
{

	@Override
	protected void handleDeleteEvent(int id) throws Exception 
	{
		EventDao eventDataAccessor = super.getEventDao();
		EventVO eventVO = eventDataAccessor.toEventVO(eventDataAccessor.load(id));
		eventDataAccessor.remove(id);
		Utility.deleteImageIndex(HTSPortal.Solr.Image.EVENT, eventVO.getName());
	}
	
	@Override
	protected EventVO handleDisableEvent(int id, String userName) throws Exception 
	{
		EventDao eventDataAccessor = super.getEventDao();
		Event event = eventDataAccessor.load(id);
		event.setStatus(AccessStatus.DISABLE);
		event.setUpdateby(userName);
		EventVO result = (EventVO) eventDataAccessor.create(EventDao.TRANSFORM_EVENTVO, event);
		Utility.deleteImageIndex(HTSPortal.Solr.Image.EVENT, result.getName());
		return result;
	}
	
	@Override
	protected EventVO[] handleGetAllEvent() throws Exception 
	{
        return (EventVO[]) super.getEventDao().loadAll(EventDao.TRANSFORM_EVENTVO).toArray(new EventVO[0]);
	}
	
	@Override
	protected EventVO[] handleGetAllActiveEvent() throws Exception 
	{
        return (EventVO[]) super.getEventDao().loadAllActive(EventDao.TRANSFORM_EVENTVO).toArray(new EventVO[0]);
	}
	
	@Override
	protected EventVO handleGetEvent(int id) throws Exception 
	{
        return super.getEventDao().toEventVO(this.getEventDao().load(id));
	}

	@Override
	protected EventVO handleSaveEvent(EventVO eventVO, String userName) throws Exception 
	{
	    EventDao eventDataAccessor = super.getEventDao();
		Event event = eventDataAccessor.eventVOToEntity(eventVO);
		event.setUpdateby(userName);
		EventVO result = (EventVO) eventDataAccessor.create(EventDao.TRANSFORM_EVENTVO, event);
		if(!eventVO.getStatus().equals(AccessStatus.ENABLE))
		{
			Utility.deleteImageIndex(HTSPortal.Solr.Image.EVENT, eventVO.getName());
		}
		return result;
	}
}