package com.ht.syndication.htsportal.service;

import java.security.Principal;
import java.util.List;

import com.ht.syndication.htsportal.PrincipalStore;
import com.ht.syndication.htsportal.domain.PublicationDao;
import com.ht.syndication.htsportal.domain.UserDao;
import com.ht.syndication.htsportal.transfer.LoginVO;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.UserVO;

/**
 * <p>
 * Spring Service base class for <code>UserService</code>,
 * provides access to all services and entities referenced by this service.
 * </p>
 *
 * @see UserService
 */
public abstract class UserServiceBase implements UserService
{

    private UserDao userDao;
    private PublicationDao publicationDao;

    public void setUserDao(UserDao userDao)
    {
        this.userDao = userDao;
    }

    protected UserDao getUserDao()
    {
        return this.userDao;
    }
    
    public void setPublicationDao(PublicationDao publicationDao)
    {
        this.publicationDao = publicationDao;
    }

    protected PublicationDao getPublicationDao()
    {
        return this.publicationDao;
    }

    /**
     * @see UserService#authenticate(String, String)
     */
    public LoginVO authenticate(String username, String password)
    {
    	if (username == null || username.trim().length() == 0)
        {
            throw new IllegalArgumentException("UserService.authenticate(String username, String password) - 'username' can not be null or empty");
        }
        if (password == null || password.trim().length() == 0)
        {
            throw new IllegalArgumentException("UserService.authenticate(String username, String password) - 'password' can not be null or empty");
        }
        try
        {
            return this.handleAuthenticate(username, password);
        }
        catch (Throwable th)
        {
            throw new UserServiceException("Error performing 'UserService.authenticate(String username, String password)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #authenticate(String, String)}
      */
    protected abstract LoginVO handleAuthenticate(String username, String password) throws Exception;

    /**
     * @see UserService#deleteUser(String)
     */
    public void deleteUser(String username)
    {
        if (username == null || username.trim().length() == 0)
        {
            throw new IllegalArgumentException("UserService.deleteUser(String username) - 'username' can not be null or empty");
        }
        try
        {
            this.handleDeleteUser(username);
        }
        catch (Throwable th)
        {
            throw new UserServiceException("Error performing 'UserService.deleteUser(String username)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #deleteUser(String)}
      */
    protected abstract void handleDeleteUser(String username) throws Exception;

    /**
     * @see UserService#getUser(String username)
     */
    public UserVO getUser(String username)
    {
        try
        {
            return this.handleGetUser(username);
        }
        catch (Throwable th)
        {
            throw new UserServiceException("Error performing 'UserService.getUser()' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getUser(String)}
      */
    protected abstract UserVO handleGetUser(String username) throws Exception;

    
    /**
     * @see UserService#getAllUsers()
     */
    public List<UserVO> getAllUsers(Short role)
    {
        try
        {
            return this.handleGetAllUsers(role);
        }
        catch (Throwable th)
        {
            throw new UserServiceException("Error performing 'UserService.getAllUsers(Short role)' --> " + th, th);
        }
    }

     /**
      * Performs the core logic for {@link #getAllUsers(String)}
      */
    protected abstract List<UserVO> handleGetAllUsers(Short role) throws Exception;

    /**
     * @see UserService#saveUser(UserVO)
     */
    public UserVO saveUser(UserVO user, String userName)
    {
    	validateUser(user, "UserService.saveUser(UserVO user, String userName)");
        if (user.getPassword() == null || user.getPassword().trim().length() == 0)
        {
            throw new IllegalArgumentException("UserService.saveUser(UserVO user, String userName) - 'user.password' can not be null or empty");
        }
        try
        {
            return this.handleSaveUser(user, userName);
        }
        catch (Throwable th)
        {
            throw new UserServiceException("Error performing 'UserService.saveUser(UserVO user)' --> " + th, th);
        }
    }
    
    public UserVO updateUser(UserVO user, String userName)
    {
    	validateUser(user, "UserService.updateUser(UserVO user, String userName)");
        try
        {
            return this.handleSaveUser(user, userName);
        }
        catch (Throwable th)
        {
            throw new UserServiceException("Error performing 'UserService.updateUser(UserVO user)' --> " + th, th);
        }
    }
    
	/**
	 * Performs the core logic for {@link #saveUser(UserVO)}
	 */
	protected abstract UserVO handleSaveUser(UserVO user, String userName) throws Exception;
	   
	public List<PublicationShortVO> getAllPublication(String userName)
	{
		if (userName == null || userName.equals(""))
        {
            throw new IllegalArgumentException("UserService.getAllPublication(String userName) - 'userName' can not be null or empty");
        }
	    try
	    {
	       return this.handleGetAllPublication(userName);
	    }
	    catch (Throwable th)
	    {
	       throw new UserServiceException("Error performing 'UserService.updateUser(UserVO user)' --> " + th, th);
	    }
	}
	   
	protected abstract List<PublicationShortVO> handleGetAllPublication(String userName) throws Exception;


    private void validateUser(UserVO user, String errorStr)
    {
    	if (user == null)
        {
            throw new IllegalArgumentException(errorStr + " - 'user' can not be null");
        }
        if (user.getUsername() == null || user.getUsername().trim().length() == 0)
        {
            throw new IllegalArgumentException(errorStr + " - 'user.username' can not be null or empty");
        }
        if (user.getFirstName() == null || user.getFirstName().trim().length() == 0)
        {
            throw new IllegalArgumentException(errorStr + " - 'user.firstName' can not be null or empty");
        }
        if (user.getLastName() == null || user.getLastName().trim().length() == 0)
        {
            throw new IllegalArgumentException(errorStr + " - 'user.lastName' can not be null or empty");
        }
        if (user.getRole() == null)
        {
            throw new IllegalArgumentException(errorStr + " - 'user.role' can not be null");
        }
        if (user.getStatus() == null)
        {
            throw new IllegalArgumentException(errorStr + " - 'user.status' can not be null");
        }
    }

    /**
     * Gets the current <code>principal</code> if one has been set,
     * otherwise returns <code>null</code>.
     *
     * @return the current principal
     */
    protected Principal getPrincipal()
    {
        return PrincipalStore.get();
    }
}