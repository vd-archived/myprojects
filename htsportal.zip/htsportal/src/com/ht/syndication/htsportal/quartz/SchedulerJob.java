package com.ht.syndication.htsportal.quartz;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;

import com.ht.syndication.htsportal.util.ContentUtility;

public class SchedulerJob implements Job
{
	private static final Log LOGGER = LogFactory.getLog(SchedulerJob.class);
	
	public void execute(JobExecutionContext context) throws JobExecutionException {
		List<JobExecutionContext> jobs = null;
		Boolean result = Boolean.TRUE;
		try {
			jobs = context.getScheduler().getCurrentlyExecutingJobs();
		} catch (SchedulerException e1) {
			LOGGER.error("Faild to get currently executing content jobs: " + e1.getMessage());
		}
		try {
			if(jobs != null && jobs.size() >0 ) {
				for(JobExecutionContext job: jobs)
				{
					if(job.getTrigger().equals(context.getTrigger()) && !job.getJobInstance().equals(this))
					{
						result = Boolean.FALSE;
						break;
					}
				}
			}
		} catch(Exception e) {
			LOGGER.error("Faild to compare current executing content jobs: " + e.getMessage());
		}
		try {
			if(result)
			{
				LOGGER.info("Content Job is running started: " + this);
				Map dataMap = context.getJobDetail().getJobDataMap();
				ContentUtility task = (ContentUtility)dataMap.get("contentUtility");
				LOGGER.info("Save content job started");
				task.saveContent();
				LOGGER.info("Save content job ended");
				LOGGER.info("Index content job started");
				task.indexContent();
				LOGGER.info("Index content job ended");
				LOGGER.info("Content Job is running ended: " + this);
			}
			else
			{
				LOGGER.info("There's another instance of content job is running, so leaving: " + this);
			}
		} catch(Exception e) {
			LOGGER.error("Faild to run Content Job successfully: " + e.getMessage());
		}
	}
}