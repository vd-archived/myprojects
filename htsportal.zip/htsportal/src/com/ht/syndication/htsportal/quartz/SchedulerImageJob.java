package com.ht.syndication.htsportal.quartz;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;

import com.ht.syndication.htsportal.util.ImageUtility;

public class SchedulerImageJob implements Job
{
	private static final Log LOGGER = LogFactory.getLog(SchedulerImageJob.class);
	public void execute(JobExecutionContext context) throws JobExecutionException {
		List<JobExecutionContext> jobs = null;
		Boolean result = Boolean.TRUE;
		try {
			jobs = context.getScheduler().getCurrentlyExecutingJobs();
		} catch (SchedulerException e1) {
			LOGGER.error("Faild to get currently executing image jobs: " + e1.getMessage());
		}
		try {
			for(JobExecutionContext job: jobs)
			{
				if(job.getTrigger().equals(context.getTrigger()) && !job.getJobInstance().equals(this))
				{
					result = Boolean.FALSE;
					break;
				}
			}
		} catch(Exception e) {
			LOGGER.error("Faild to compare current executing image jobs: " + e.getMessage());
		}
		try {
			if(result)
			{
				LOGGER.info("Image Job is running started: " + this);
				Map dataMap = context.getJobDetail().getJobDataMap();
				ImageUtility task = (ImageUtility)dataMap.get("imageUtility");
				
				LOGGER.info("Upload image from ftp job started");
				task.saveImage();
				LOGGER.info("Upload image from ftp job ended");
				
				LOGGER.info("Generate image index job started");
				task.indexImage();
				LOGGER.info("Generate image index job ended");
	
				LOGGER.info("Image Job is running ended: " + this);
			}
			else
			{
				LOGGER.info("There's another instance of image job is running, so leaving: " + this);
			}
		} catch(Exception e) {
			LOGGER.error("Faild to run Image Job successfully: " + e.getMessage());
		}
	}
}