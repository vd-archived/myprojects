package com.ht.syndication.htsportal.quartz;

import java.util.Date;
import java.util.Map;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.util.ContentUtility;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ImageUtility;

public class QuartzSchedulerListener implements ServletContextListener
{
	private static final Log LOGGER = LogFactory.getLog(QuartzSchedulerListener.class);
	
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void contextInitialized(ServletContextEvent arg0) 
	{
		LOGGER.info("Initialize Quartz Scheduler Listener");
		ContentUtility contentTask = new ContentUtility();
		ImageUtility imageTask = new ImageUtility();

		try {
			SchedulerFactory factory = new StdSchedulerFactory();
			Scheduler scheduler = factory.getScheduler();
			scheduler.start();
			JobDetail jd = new JobDetail("saveIndexContent", Scheduler.DEFAULT_GROUP, SchedulerJob.class);
			Map dataMap = jd.getJobDataMap();
			dataMap.put("contentUtility", contentTask);
			SimpleTrigger st = new SimpleTrigger("saveIndexContent", Scheduler.DEFAULT_GROUP, new Date(), null, SimpleTrigger.REPEAT_INDEFINITELY, 60L*1000L*APP_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.QUARTZ.CONTENTINTERVAL));
			LOGGER.info("*** Quartz Started for Content***");
			scheduler.scheduleJob(jd, st);
			
			jd = new JobDetail("thumbImage", Scheduler.DEFAULT_GROUP, SchedulerImageJob.class);
			dataMap = jd.getJobDataMap();
			dataMap.put("imageUtility", imageTask);
			st = new SimpleTrigger("thumbImage", Scheduler.DEFAULT_GROUP, new Date(), null, SimpleTrigger.REPEAT_INDEFINITELY, 60L*1000L*APP_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.QUARTZ.IMAGEINTERVAL));
			LOGGER.info("*** Quartz Started for Image***");
			scheduler.scheduleJob(jd, st);
		} 
		catch (SchedulerException e) 
		{
			LOGGER.error("Failed to execute quartz jobs:" + e.getMessage());
		}
	}

	public void contextDestroyed(ServletContextEvent arg0) 
	{
		LOGGER.info("Destroy Quartz Scheduler Listener");
	}
}