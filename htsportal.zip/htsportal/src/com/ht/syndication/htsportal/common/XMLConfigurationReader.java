package com.ht.syndication.htsportal.common;

import java.util.List;

/**
 * to be used to read properties from configurtion file
 * 
 * 
 */
public final class XMLConfigurationReader extends ConfigurationReader
{
    /**
     * Made private so that instances cannot be created directly.
     * 
     */
    public XMLConfigurationReader(final String configFileName)
    {
        super(configFileName);
    }

    /**
     * Reads a boolean property from a data source, provided a string key to locate the property.
     * 
     * @param key Key to locate the property.
     * @return A boolean value.
     */
    public boolean getBooleanProperty(String name)
    {
        return _config == null ? null : _config.getBoolean(name);
    }

    /**
     * Reads an integer property from a data source, provided a string key to locate the property.
     * 
     * @param key Key to locate the property.
     * @return An integer value.
     */
    public int getIntegerProperty(String name)
    {
        return _config == null ? null : _config.getInt(name);
    }

    /**
     * Returns a list of value corresponding to a repeating property in the configuration file.
     * 
     * @param name A {@link java.lang.String} containing property name.
     * @return A {@link java.util.List} of {@link java.lang.String} values containing all values available for the property.
     */
    @SuppressWarnings("unchecked")
    public List<String> getList(String name)
    {
        return _config == null ? null : _config.getList(name);
    }

    /**
     * Reads a property from the configuration and returns its value to the caller.
     * 
     * @param name A {@link java.lang.String} specifying the name of the property to be fetched.
     * @return A {@link java.lang.String} containing property name.
     */
    public String getProperty(String name)
    {
        return _config == null ? null : _config.getString(name);
    }

    public String[] getPropertyArray(String name)
    {
        return _config == null ? null : _config.getStringArray(name);
    }
}
