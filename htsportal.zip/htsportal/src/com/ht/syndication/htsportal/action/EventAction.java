package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.EventVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class EventAction extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3985768615685228060L;

	public String showAll()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setEventVOs(Arrays.asList(ServiceLocator.instance().getEventService().getAllEvent()));
		return SUCCESS;
	}
	
	public String deleteAll()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getIds()!=null)
		{
			for(Integer id: getIds())
			{
				ServiceLocator.instance().getEventService().disableEvent(id, getUser().getUsername());
			}
		}
		Utility.resetImageEventXML(Boolean.TRUE);
		return SUCCESS;
	}
	
	public String save()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getId() != null && getName() != null)
		{
			if(validation())
			{
				try
				{
					EventVO eventVO = ServiceLocator.instance().getEventService().saveEvent(new EventVO(getId(), getName(), getDetails(), Short.parseShort(getStatus())), getUser().getUsername());
					addActionError("Event '"+getName()+"' updated successfully...");
					setEventVO(eventVO);
					EventVO[]events = Utility.resetImageEventXML(Boolean.TRUE);
					Utility.createImageFolderOnFTP(events, null);
				}
				catch(Exception e)
				{
					addActionError(e.getMessage());
				}
			}
		}
		else if (getName() != null) 
		{
			if(validation())
			{
				try
				{
					EventVO eventVO = ServiceLocator.instance().getEventService().saveEvent(new EventVO(getName(), getDetails(), Short.parseShort(getStatus())), getUser().getUsername());
					addActionError("Event '"+getName()+"' created successfully...");
					setEventVO(eventVO);
					EventVO[]events = Utility.resetImageEventXML(Boolean.TRUE);
					Utility.createImageFolderOnFTP(events, null);
				}
				catch(Exception e)
				{
					addActionError(e.getMessage());
				}
			}
		}
		if(getEventVO()==null && getId() != null)
		{
			setEventVO(ServiceLocator.instance().getEventService().getEvent(getId()));
			if(getEventVO() == null)
			{
				addActionError("No event found with id '"+getId()+"'...");
			}
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	private Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getName().equals(""))
		{
			addActionError("Name can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getStatus().equals(""))
		{
			addActionError("Status can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getName().length()>50)
		{
			addActionError("Name can not exceed 50 character");
			isValid = Boolean.FALSE;
		}
		if(getDetails().length()>5000)
		{
			addActionError("Details can not exceed 5000 character");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
	
	private Map session;
	private UserVO user;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	private List<EventVO> eventVOs;
	private EventVO eventVO;
	private Integer id;
	private Integer[] ids;
	private String name;
	private String details;
	private String status;

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public EventVO getEventVO() {
		return eventVO;
	}

	public void setEventVO(EventVO eventVO) {
		this.eventVO = eventVO;
	}

	public List<EventVO> getEventVOs() {
		return eventVOs;
	}

	public void setEventVOs(List<EventVO> eventVOs) {
		this.eventVOs = eventVOs;
	}

	public Integer[] getIds() {
		return ids;
	}

	public void setIds(Integer[] ids) {
		this.ids = ids;
	}
}