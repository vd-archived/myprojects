package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.JDOMException;
import com.ht.syndication.htsportal.org.jdom.filter.ElementFilter;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;
import com.ht.syndication.htsportal.service.UsermessageService;
import com.ht.syndication.htsportal.transfer.ArticleVO;
import com.ht.syndication.htsportal.transfer.ContentVO;
import com.ht.syndication.htsportal.transfer.ImageSectionVO;
import com.ht.syndication.htsportal.transfer.SubscriptionVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.transfer.UsermessageVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ListObject;
import com.ht.syndication.htsportal.util.Utility;
import com.ht.syndication.htsportal.util.XML_Utility;
import com.opensymphony.xwork2.ActionSupport;

import freemarker.ext.dom.NodeModel;

public class ShowPortalPage extends ActionSupport implements SessionAware, Serializable
{
	private static final long serialVersionUID = -2941522682877153237L;
	/**
	 * 
	 */
	private static final Log LOGGER = LogFactory.getLog(ShowPortalPage.class);
	private Map session;
	private UserVO user;
	private String webroot;
	private String cat, src, pub, arid, page, byline, homeSection1Intro;
	private StringBuffer bodycontent;
	private ListObject shortTypeDetails;
	private String email, firstname, lastname, organisationName, message, contactno, articlecount, contentreproduced, publicationname, publicationcirculation, otherdetails, companyname, address, phonenumber, country;
	private List<ImageSectionVO> imageList = new ArrayList<ImageSectionVO>();
	private List<ArticleVO> articles;
	private List<ListObject>publicationsInfo;
	private List<ListObject>categoriesInfo;
	private List<ListObject>sourcesInfo;
	private List<ListObject>bylineInfo;
	private List<ListObject> pageNumberList;
	private NodeModel exclusiveDoc;

//	private static final String defaultarticleboost = "{!boost b=recip(ms(NOW,contentdate),3.16e-11,1,1)}";
//	private static final String defaultimageboost = "{!boost b=recip(ms(NOW,updatedate),3.16e-11,1,1)}";
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	List<ContentVO> contentList = new ArrayList<ContentVO>();
	Properties property = HTSPortal.SERVLETCONTEXT;


	public NodeModel getExclusiveDoc() {
		return exclusiveDoc;
	}


	public void setExclusiveDoc(NodeModel exclusiveDoc) {
		this.exclusiveDoc = exclusiveDoc;
	}

	public String getHomeSection1Intro() {
		return homeSection1Intro;
	}

	public void setHomeSection1Intro(String homeSection1Intro) {
		this.homeSection1Intro = homeSection1Intro;
	}


	public List<ContentVO> getContentList() 
	{
		return contentList;
	}

	public String getWebroot() {
		return webroot;
	}


	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}


	public String getArticlecount() {
		return articlecount;
	}


	public void setArticlecount(String articlecount) {
		this.articlecount = articlecount;
	}


	public String getContentreproduced() {
		return contentreproduced;
	}


	public void setContentreproduced(String contentreproduced) {
		this.contentreproduced = contentreproduced;
	}


	public String getPublicationname() {
		return publicationname;
	}


	public void setPublicationname(String publicationname) {
		this.publicationname = publicationname;
	}

	public String getPublicationcirculation() {
		return publicationcirculation;
	}

	public void setPublicationcirculation(String publicationcirculation) {
		this.publicationcirculation = publicationcirculation;
	}

	public String getOtherdetails() {
		return otherdetails;
	}


	public void setOtherdetails(String otherdetails) {
		this.otherdetails = otherdetails;
	}


	public String getCompanyname() {
		return companyname;
	}


	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPhonenumber() {
		return phonenumber;
	}


	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public void setContentList(List<ContentVO> contentList) 
	{
		this.contentList = contentList;
	}


	/*
	 * return images for Home Page
	 */
	public List<ImageSectionVO> getImageList() 
	{
		return imageList;
	}


	public void setImageList(List<ImageSectionVO> imageList) 
	{
		this.imageList = imageList;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the firstname
	 */
	public String getFirstname() {
		return firstname;
	}

	private String url = Utility.getArticleSolrSearchURL(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE));
	/**
	 * @param firstname the firstname to set
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * 
	 * @return the contactno
	 */
	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	/**
	 * @param the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the shortTypeDetails
	 */
	public ListObject getShortTypeDetails() {
		return shortTypeDetails;
	}

	/**
	 * @param shortTypeDetails the shortTypeDetails to set
	 */
	public void setShortTypeDetails(ListObject shortTypeDetails) {
		this.shortTypeDetails = shortTypeDetails;
	}

	/**
	 * @return the pub
	 */
	public String getPub() {
		return pub;
	}

	/**
	 * @param pub the pub to set
	 */
	public void setPub(String pub) {
		this.pub = pub;
	}

	/**
	 * @return the arid
	 */
	public String getArid() {
		return arid;
	}

	/**
	 * @param arid the arid to set
	 */
	public void setArid(String arid) {
		this.arid = arid;
	}

	/**
	 * @return the bodycontent
	 */
	public StringBuffer getBodycontent() {
		return bodycontent;
	}

	/**
	 * @param bodycontent the bodycontent to set
	 */
	public void setBodycontent(StringBuffer bodycontent) {
		this.bodycontent = bodycontent;
	}

	/**
	 * @return the cat
	 */
	public String getCat() {
		return cat;
	}

	/**
	 * @param cat the cat to set
	 */
	public void setCat(String cat) {
		this.cat = cat;
	}

	/**
	 * @return the src
	 */
	public String getSrc() {
		return src;
	}

	/**
	 * @param src the src to set
	 */
	public void setSrc(String src) {
		this.src = src;
	}

	/**
	 * @return the page
	 */
	public String getPage() {
		return page;
	}

	/**
	 * @param page the page to set
	 */
	public void setPage(String page) {
		this.page = page;
	}
	
	public String getByline() {
		return byline;
	}


	public void setByline(String byline) {
		this.byline = byline;
	}


	/**
	 * @return
	 */
	/*public String index() {
		// TODO Auto-generated method stub

		return SUCCESS;
	}*/

	public String aboutus() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		return SUCCESS;
	}

	public String publications() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		try
		{
			File publicationFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("PUBLICATION_INTRO_XML")));
			Document document = null;
			if(publicationFile.exists())
			{
				StringBuffer siteContent = new StringBuffer();
				SAXBuilder builder = new SAXBuilder();
				try
				{
					document = builder.build(publicationFile);
					Element root = document.getRootElement();
					List publications = root.getChildren("publication");
					int i = 0;
					for (i = 0; i < publications.size(); i++) 
					{
						Element row = (Element) publications.get(i);
						if(row.getAttribute("newsTicker").getValue().equalsIgnoreCase("true") && !(row.getChild("status").getText().equalsIgnoreCase("0")))
						{
							if(i%2 == 1)
							{
								siteContent.append("<tr class=\"oddrow\">");
							}
							else
							{
								siteContent.append("<tr class=\"evenrow\">");
							}
							siteContent.append("<td><a style=\"text-decoration: none;font-weight:bold;\" href=\"publication?pub="+URLEncoder.encode("\""+row.getChild("name").getText()+"\"","UTF-8")+"\">"+row.getChild("name").getText()+"</a></td>");
							siteContent.append("<td>"+row.getChild("intro").getText()+"</td>");
							siteContent.append("</tr>");
						}
					}
					Boolean hiddenPublication = Boolean.FALSE;
					for (i = 0; i < publications.size(); i++) 
					{
						Element row = (Element) publications.get(i);
						if(row.getAttribute("newsTicker").getValue().equalsIgnoreCase("false") && !(row.getChild("status").getText().equalsIgnoreCase("0")))
						{
							hiddenPublication = Boolean.TRUE;
							if(i%2 == 1)
							{
								siteContent.append("<tr class=\"oddrow\" toggletr=\"toggletr\" style=\"display:none;\">");
							}
							else
							{
								siteContent.append("<tr class=\"evenrow\" toggletr=\"toggletr\" style=\"display:none;\">");
							}
							siteContent.append("<td><a style=\"text-decoration: none;font-weight:bold;\" href=\"publication?pub="+URLEncoder.encode("\""+row.getChild("name").getText()+"\"","UTF-8")+"\">"+row.getChild("name").getText()+"</a></td>");
							siteContent.append("<td>"+row.getChild("intro").getText()+"</td>");
							siteContent.append("</tr>");
						}
					}
					if(hiddenPublication)
					{
						siteContent.append("<tr>");
						siteContent.append("<td colspan=\"2\"><div style=\"padding-top:25px;\"><img src=\"images/morepublication.png\" id=\"togglepublicationview\" style=\"cursor: pointer\" /></div></td>");
						siteContent.append("</tr>");
					}
				} catch (JDOMException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				} catch (IOException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				}
				if(siteContent.length()>0)
				{
					setBodycontent(siteContent);
				}
			}
		}
		catch(Exception e)
		{
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}
	
	private List<ImageSectionVO> getHomeImageSection1()
	{
		File sourceFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_INTRO_XML")));
		try
		{
			Document document = null;
			if(sourceFile.exists())
			{
				SAXBuilder builder = new SAXBuilder();
				try
				{
					document = builder.build(sourceFile);
					Element root = document.getRootElement();
					Iterator<Element>sourceNames = root.getDescendants(new ElementFilter("name"));
					while(sourceNames.hasNext())
					{
						Element source = sourceNames.next(); 
						if(source.getValue().equals("HOMESECTION1"))
						{
							setHomeSection1Intro(source.getParentElement().getChild("intro").getTextNormalize());
							break;
						}
					}
				} catch (JDOMException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				} catch (IOException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		List<ImageSectionVO>tempImageList = new ArrayList<ImageSectionVO>();
		Integer imagePerPage = Utility.convertToInteger(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.SECTIONS.HOMESECTIONSIZE1), 10);
		String imageUrl = Utility.getImageSolrSearchURL(imagePerPage.toString());
		XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
		String parameter = "&q=*:*";
		parameter = "&q="+Utility.forcefullyURLEncoded("tags:\"HOME_SECTION_1\"");
		parameter+="&start=0";
		HttpServletRequest request = ServletActionContext.getRequest();
		StringBuffer requestPage = getCurrentURLWithParam(request, Boolean.FALSE);
		try
		{
			Document document = xmlUtility.getXMLDocument(new URL(imageUrl+parameter));
			Iterator iterator = document.getDescendants(new ElementFilter("doc"));
			while(iterator.hasNext())
			{
				Element doc = (Element)iterator.next();
				ImageSectionVO image = new ImageSectionVO();
				List<Element>fieldList = doc.getChildren("arr");
				for(Element tempEle: fieldList)
				{
					String fieldName = tempEle.getAttributeValue("name");
					List<ListObject> tempList = new ArrayList<ListObject>();
					List<Element> tempArrEle = tempEle.getChildren();
					if(fieldName.equals("tags"))
					{
						tempList.clear();
						for(Element tempArrRecord: tempArrEle)
						{
							tempList.add(ListObject.Factory.newInstance(null, tempArrRecord.getTextNormalize()));
						}
						image.setTagsDetails(tempList);
					}
				}
				fieldList = doc.getChildren("str");
				for(Element tempEle: fieldList)
				{
					String fieldName = tempEle.getAttributeValue("name");
					if(fieldName.equals("id"))
					{
						image.setId(Utility.convertToInteger(tempEle.getTextNormalize(), -1));
					}
					else if(fieldName.equals("name"))
					{
						image.setName(tempEle.getTextNormalize().replaceAll("\n", " "));
					}
					else if(fieldName.equals("title"))
					{
						image.setTitle(tempEle.getTextNormalize());
					}
					else if(fieldName.equals("details"))
					{
						image.setDetails(tempEle.getTextNormalize().replaceAll("\n", " "));
					}
					else if(fieldName.equals("copyright"))
					{
						image.setCopyright(tempEle.getTextNormalize());
					}
					else if(fieldName.equals("author"))
					{
						image.setAuthor(tempEle.getTextNormalize().replaceAll("\n", " "));
					}
					else if(fieldName.equals("event"))
					{
						image.setEventDetails(ListObject.Factory.newInstance(null, tempEle.getTextNormalize().replaceAll("\n", " ")));
					}
				}
				image.setTargetUrl(property.getProperty("IMAGECATEGORY_MENU_HREF").replace("/##WEBROOT##/", APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL)).replaceAll("##HREFVALUE##", Utility.forcefullyURLEncoded("HOME_SECTION_1")));
				if(image.getEventName() != null)
				{
					image.setTargetUrl(property.getProperty("IMAGEEVENT_MENU_HREF").replace("/##WEBROOT##/", APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL)).replaceAll("##HREFVALUE##", Utility.forcefullyURLEncoded(image.getEventName())));
				}
				else
				{
					for(ListObject tagObject: image.getTagsDetails())
					{
						if(!tagObject.getValue().toString().equals("HOME_SECTION_1")) {
							image.setTargetUrl(property.getProperty("IMAGECATEGORY_MENU_HREF").replace("/##WEBROOT##/", APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL)).replaceAll("##HREFVALUE##", Utility.forcefullyURLEncoded(tagObject.getValue().toString())));
						}
					}
				}
				tempImageList.add(image);
			}
		}
		catch(Exception e)
		{
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return tempImageList;
	}

	/**
	 * @return
	 */
	public String home()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		return SUCCESS;
	}
	
	public String contactus()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		Boolean error = Boolean.FALSE;
		if(getEmail()!=null)
		{
			if(getFirstname().trim().equals(""))
			{
				addFieldError("firstname", "First name is mandatory");
				error = Boolean.TRUE;
			}
			if(getLastname().trim().equals(""))
			{
				addFieldError("lastname", "Last name is mandatory");
				error = Boolean.TRUE;
			}
			if(getOrganisationName().trim().equals(""))
			{
				addFieldError("organisationName", "Organisation name is mandatory");
				error = Boolean.TRUE;
			}
			if(getContactno().trim().equals(""))
			{
				addFieldError("contactno", "Contact number is mandatory");
				error = Boolean.TRUE;
			}
			if(getEmail().trim().equals(""))
			{
				addFieldError("email", "Your email address is mandatory");
				error = Boolean.TRUE;
			}
			else if(!Utility.isValidEmailAddress(getEmail().trim()))
			{
				addFieldError("email", "Please enter valid email address");
				error = Boolean.TRUE;
			}
			if(getMessage().trim().equals(""))
			{
				addFieldError("message", "Please write message. It is mandatory");
				error = Boolean.TRUE;
			}
			if(error)
			{
				return SUCCESS;
			}
			UsermessageService usermessageService = ServiceLocator.instance().getUsermessageService();
			UsermessageVO usermessageVO = new UsermessageVO(getEmail(), getFirstname(), getLastname(), getOrganisationName(), getMessage(), getContactno(), Short.parseShort("1"));
			usermessageVO.setTo(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.ADMIN_EMAIL_ADDRESS));
			usermessageVO.setSubject(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.SUBJECT));
			usermessageVO = usermessageService.saveUsermessage(usermessageVO, getEmail());
			StringBuffer mailmsg = new StringBuffer("User Name: " + usermessageVO.getFirstname() + " " + usermessageVO.getLastname());
			mailmsg.append("<br />Organisation Name: " + usermessageVO.getOrganisationName());
			mailmsg.append("<br />E-Mail Address: " + usermessageVO.getEmail());
			mailmsg.append("<br />Contact Number: " + usermessageVO.getContactno());
			mailmsg.append("<br />Message: " + usermessageVO.getMessage());
			
			Utility.sendMail(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAILTOSUBSCRIPTIONADMIN), usermessageVO.getSubject(), mailmsg.toString());
			addActionError("Your query is submitted successfully...");
		}
		return SUCCESS;
	}

	public String subscription()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		Boolean error = Boolean.FALSE;
		if(getEmail()!=null)
		{
			if(getArticlecount().trim().equals("")||(!Utility.isNumeric(getArticlecount())))
			{
				addFieldError("articlecount", "Article count is mandatory and should be numeric...");
				error = Boolean.TRUE;
			}
			if(getContentreproduced()==null || getContentreproduced().trim().equals(""))
			{
				addFieldError("contentreproduced", "Content reproduced is mandatory...");
				error = Boolean.TRUE;
			}
			if(getPublicationname().trim().equals(""))
			{
				addFieldError("publicationname", "Publication name is mandatory...");
				error = Boolean.TRUE;
			}
			if(getPublicationcirculation().trim().equals("")||(!Utility.isNumeric(getPublicationcirculation())))
			{
				addFieldError("publicationcirculation", "Publication circulation is mandatory and should be numeric...");
				error = Boolean.TRUE;
			}
			if(getEmail().trim().equals(""))
			{
				addFieldError("email", "Your email address is mandatory...");
				error = Boolean.TRUE;
			}
			else if(!Utility.isValidEmailAddress(getEmail().trim()))
			{
				addFieldError("email", "Please enter valid email address...");
				error = Boolean.TRUE;
			}
			if(getOtherdetails().trim().equals(""))
			{
				addFieldError("otherdetails", "Other details is mandatory...");
				error = Boolean.TRUE;
			}
			if(getCompanyname().trim().equals(""))
			{
				addFieldError("companyname", "Company name is mandatory...");
				error = Boolean.TRUE;
			}
			if(getAddress().trim().equals(""))
			{
				addFieldError("address", "Address is mandatory...");
				error = Boolean.TRUE;
			}
			if(getPhonenumber().trim().equals(""))
			{
				addFieldError("phonenumber", "Phone number is mandatory...");
				error = Boolean.TRUE;
			}
			if(getCountry().trim().equals(""))
			{
				addFieldError("country", "Country is mandatory...");
				error = Boolean.TRUE;
			}
			if(getMessage().trim().equals(""))
			{
				addFieldError("message", "Please write message. It is mandatory...");
				error = Boolean.TRUE;
			}
			if(error)
			{
				return SUCCESS;
			}
			UsermessageService usermessageService = ServiceLocator.instance().getUsermessageService();
			SubscriptionVO subscriptionVO = new SubscriptionVO(Integer.parseInt(getArticlecount()), getContentreproduced(), getPublicationname(), Integer.parseInt(getPublicationcirculation()), getOtherdetails(), getCompanyname(), getAddress(), getEmail(), getPhonenumber(), getCountry(), getMessage());
			subscriptionVO.setEmailto(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.ADMIN_EMAIL_ADDRESS));
			subscriptionVO.setEmailsubject(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.SUBJECT));
			subscriptionVO.setStatus(Short.parseShort("1"));
			subscriptionVO = usermessageService.saveSubscriptionMsg(subscriptionVO, getEmail());
			
			StringBuffer mailmsg = new StringBuffer("Publication Name: " + subscriptionVO.getPublicationname());
			mailmsg.append("<br />Article Count: " + subscriptionVO.getArticlecount());
			mailmsg.append("<br />Content Reproduced: " + subscriptionVO.getReproduced());
			mailmsg.append("<br />Circulation: " + subscriptionVO.getPublicationcirculation());
			mailmsg.append("<br />Company Name: " + subscriptionVO.getCompanyname());
			mailmsg.append("<br />Address: " + subscriptionVO.getAddress());
			mailmsg.append("<br />E-Mail: " + subscriptionVO.getEmail());
			mailmsg.append("<br />Contact Number: " + subscriptionVO.getPhone());
			mailmsg.append("<br />Country: " + subscriptionVO.getCountry());
			mailmsg.append("<br />Other Details: " + subscriptionVO.getOtherdetails());
			mailmsg.append("<br />Message: " + subscriptionVO.getMessage());
			Utility.sendMail(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.APP.MAILTOSUBSCRIPTIONADMIN), subscriptionVO.getEmailsubject(), mailmsg.toString());
			addActionError("Your subscription query is submitted successfully...");
		}
		return SUCCESS;
	}

	/**
	 * @return
	 */
	public String source() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getPage()==null)
		{
			setPage("1");
		}
		articles = new ArrayList<ArticleVO>();
		String pubStatus = "SHORT_ACCESS";
		if(pubStatus.equalsIgnoreCase("FULL_ACCESS") || pubStatus.equalsIgnoreCase("SHORT_ACCESS"))
		{
			XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
			String parameter = "&q=*:*";
			if(getSrc()!= null && getSrc().trim().length() > 0)
			{
				parameter = "&q=" + Utility.forcefullyURLEncoded("source:" + getSrc());
			}
			if(getPage() != null && xmlUtility.isInteger(getPage()) && Integer.parseInt(getPage()) > 0 )
			{
				parameter+="&start="+((Integer.parseInt(getPage())-1) * SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE));
			}
			else
			{
				parameter+="&start=0";
			}
			parameter += setFilteration(xmlUtility, "publication", getPub());
			parameter += setFilteration(xmlUtility, "category", getCat());
			parameter += setFilteration(xmlUtility, "byline", getByline());
			HttpServletRequest request = ServletActionContext.getRequest();
			StringBuffer requestPage = getCurrentURLWithParam(request, Boolean.FALSE);
			try
			{
				Document document = xmlUtility.getXMLDocument(new URL(url+parameter));
				processShortPanel(document.getDescendants(new ElementFilter("lst")), requestPage);
				this.setArticles(Utility.getArticlesFromIterator(document.getDescendants(new ElementFilter("doc")), pubStatus));
				Integer currentPage = 1;
				if(getPage()!=null && !getPage().trim().equals(""))
				{
					currentPage = Utility.convertToInteger(getPage(), 1);
				}
				Iterator iterator = document.getDescendants(new ElementFilter("result"));
				while(iterator.hasNext())
				{
					Element ele = (Element)iterator.next();
					setPageNumberList(getPageNumberList(requestPage.toString(), currentPage, new Integer(SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE)), Utility.convertToInteger(ele.getAttributeValue("numFound"), 0)));
				}
			}
			catch(Exception e)
			{
				LOGGER.error("ERROR: "+e.getMessage());
			}
			if(getSrc()!=null)
			{
				setShortTypeDetails(xmlUtility.getTypeNameDetails("/WEB-INF/xml/source.xml", "source", getSrc()));
			}
		}
		return SUCCESS;
	}

	/**
	 * @return
	 */
	public String category()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getPage()==null)
		{
			setPage("1");
		}
		articles = new ArrayList<ArticleVO>();
		String pubStatus = "SHORT_ACCESS";
		if(pubStatus.equalsIgnoreCase("FULL_ACCESS") || pubStatus.equalsIgnoreCase("SHORT_ACCESS"))
		{
			XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
			String parameter = "&q=*:*";
			if(getCat()!= null && getCat().trim().length() > 0)
			{
				parameter = "&q=" + Utility.forcefullyURLEncoded("category:" + getCat());
			}
			if(getPage() != null && xmlUtility.isInteger(getPage()) && Integer.parseInt(getPage()) > 0 )
			{
				parameter+="&start="+((Integer.parseInt(getPage())-1) * SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE));
			}
			else
			{
				parameter+="&start=0";
			}
			parameter += setFilteration(xmlUtility, "publication", getPub());
			parameter += setFilteration(xmlUtility, "source", getSrc());
			parameter += setFilteration(xmlUtility, "byline", getByline());
			HttpServletRequest request = ServletActionContext.getRequest();
			StringBuffer requestPage = getCurrentURLWithParam(request, Boolean.FALSE);
			try
			{
				Document document = xmlUtility.getXMLDocument(new URL(url+parameter));
				processShortPanel(document.getDescendants(new ElementFilter("lst")), requestPage);
				this.setArticles(Utility.getArticlesFromIterator(document.getDescendants(new ElementFilter("doc")), pubStatus));
				Integer currentPage = 1;
				if(getPage()!=null && !getPage().trim().equals(""))
				{
					currentPage = Utility.convertToInteger(getPage(), 1);
				}
				Iterator iterator = document.getDescendants(new ElementFilter("result"));
				while(iterator.hasNext())
				{
					Element ele = (Element)iterator.next();
					setPageNumberList(getPageNumberList(requestPage.toString(), currentPage, new Integer(SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE)), Utility.convertToInteger(ele.getAttributeValue("numFound"), 0)));
				}
			}
			catch(Exception e)
			{
				LOGGER.error("ERROR: "+e.getMessage());
				LOGGER.error("ERROR: SOLR URL: " + url+parameter);
			}
			if(getCat()!=null)
			{
				setShortTypeDetails(xmlUtility.getTypeNameDetails("/WEB-INF/xml/category.xml", "category", getCat()));
			}
		}
		return SUCCESS;
	}


	public String publication() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getPage()==null)
		{
			setPage("1");
		}
		articles = new ArrayList<ArticleVO>();
		String pubStatus = "FULL_RESTRICTED";
		if(getPub()!=null)
		{
			String temp = getPub();
			if(temp.startsWith("\""))
			{
				temp = temp.substring(1);
			}
			if(temp.endsWith("\""))
			{
				temp = temp.substring(0, temp.length()-1);
			}
			pubStatus = Utility.getPublicationAccessStatus(temp);
		}
		if(pubStatus.equalsIgnoreCase("FULL_ACCESS") || pubStatus.equalsIgnoreCase("SHORT_ACCESS"))
		{
			XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
			String parameter = "&q=*:*";
			if(getPub()!= null && getPub().trim().length() > 0)
			{
				parameter = "&q=" + Utility.forcefullyURLEncoded("publication:" + getPub());
			}

			if(getPage() != null && xmlUtility.isInteger(getPage()) && Integer.parseInt(getPage()) > 0 )
			{
				parameter+="&start="+((Integer.parseInt(getPage())-1) * SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE));
			}
			else
			{
				parameter+="&start=0";
			}
			parameter += setFilteration(xmlUtility, "source", getSrc());
			parameter += setFilteration(xmlUtility, "category", getCat());
			parameter += setFilteration(xmlUtility, "byline", getByline());
			HttpServletRequest request = ServletActionContext.getRequest();
			StringBuffer requestPage = getCurrentURLWithParam(request, Boolean.FALSE);
			try
			{
				Document document = xmlUtility.getXMLDocument(new URL(url+parameter));
				processShortPanel(document.getDescendants(new ElementFilter("lst")), requestPage);
				this.setArticles(Utility.getArticlesFromIterator(document.getDescendants(new ElementFilter("doc")), pubStatus));
				Integer currentPage = 1;
				if(getPage()!=null && !getPage().trim().equals(""))
				{
					currentPage = Utility.convertToInteger(getPage(), 1);
				}
				Iterator iterator = document.getDescendants(new ElementFilter("result"));
				while(iterator.hasNext())
				{
					Element ele = (Element)iterator.next();
					setPageNumberList(getPageNumberList(requestPage.toString(), currentPage, new Integer(SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE)), Utility.convertToInteger(ele.getAttributeValue("numFound"), 0)));
				}
			}
			catch(Exception e)
			{
				LOGGER.error("ERROR: "+e.getMessage());
			}
			if(getPub()!=null)
			{
				setShortTypeDetails(null);
		//		setShortTypeDetails(xmlUtility.getTypeNameDetails("/WEB-INF/xml/publication.xml", "publication", getPub()));
			}
		}
		else
		{
			setShortTypeDetails(ListObject.Factory.newInstance(getPub(), "You have not authorized to view this publication"));
		}
		return SUCCESS;
	}

	private List<ListObject> getPanelInfoCount(List<Element>countFields, String requestPage, String type)
	{
		List<ListObject>tempInfo = new ArrayList<ListObject>();
		for(Element countField: countFields)
		{
			StringBuffer tempRequestPage = new StringBuffer(requestPage);
			String name = countField.getAttributeValue("name");
			String printname = name.trim(); 
			if(printname.equals(""))
			{
				printname = "Others";
			}
			if(!countField.getValue().equalsIgnoreCase("0"))
			{
				if(type.equalsIgnoreCase("publication") && (getPub()==null||getPub().equalsIgnoreCase("")))
				{
					tempRequestPage.append("&pub=").append(Utility.forcefullyURLEncoded("\""+name+"\""));
				}
				else if(type.equalsIgnoreCase("category") && (getCat()==null||getCat().equalsIgnoreCase("")))
				{
					tempRequestPage.append("&cat=").append(Utility.forcefullyURLEncoded("\""+name+"\""));
				}
				else if(type.equalsIgnoreCase("source") && (getSrc()==null||getSrc().equalsIgnoreCase("")))
				{
					tempRequestPage.append("&src=").append(Utility.forcefullyURLEncoded("\""+name+"\""));
				}
				else if(type.equalsIgnoreCase("byline") && (getByline()==null||getByline().equalsIgnoreCase("")))
				{
					tempRequestPage.append("&byline=").append(Utility.forcefullyURLEncoded("\""+name+"\""));
				}
				tempInfo.add(ListObject.Factory.newInstance(printname, ListObject.Factory.newInstance(tempRequestPage, countField.getValue())));
			}
		}
		return tempInfo;
	}
	
	
	
	private void processShortPanel(Iterator iterator, StringBuffer requestPage)
	{
		while(iterator.hasNext())
		{
			Element ele = (Element)iterator.next();
			if(ele.getAttributeValue("name").equalsIgnoreCase("facet_fields"))
			{
				List<Element>fieldsEle = ele.getChildren("lst");
				for(Element field: fieldsEle)
				{
					if(field.getAttributeValue("name").equalsIgnoreCase("publication"))
					{
						this.setPublicationsInfo(getPanelInfoCount(field.getChildren("int"), requestPage.toString(), "publication"));
					}
					else if(field.getAttributeValue("name").equalsIgnoreCase("category"))
					{
						this.setCategoriesInfo(getPanelInfoCount(field.getChildren("int"), requestPage.toString(), "category"));
					}
					else if(field.getAttributeValue("name").equalsIgnoreCase("source"))
					{
						this.setSourcesInfo(getPanelInfoCount(field.getChildren("int"), requestPage.toString(), "source"));
					}
					else if(field.getAttributeValue("name").equalsIgnoreCase("byline"))
					{
						this.setBylineInfo(getPanelInfoCount(field.getChildren("int"), requestPage.toString(), "byline"));
					}
				}
			}
		}
	}
	
	private List<ListObject> getPageNumberList(String requestedURL, Integer currentPage, Integer recordPerPage, Integer recordSize)
	{
		List<ListObject> tempList = new ArrayList<ListObject>();
		Integer pageCount = (int)Math.ceil(recordSize/(float)(recordPerPage));
		if (pageCount > 0)
		{
			currentPage = currentPage - 5;
			if(currentPage>1)
			{
				if((currentPage + 9)>=pageCount)
				{
					currentPage = pageCount - 10;
				}
				tempList.add(ListObject.Factory.newInstance(requestedURL+"&page="+currentPage, "Previous"));
			}
			else
			{
				currentPage = 0;
			}
			int i = 0;
			for (i = (currentPage+1); i < (currentPage + 11) && i <= pageCount; i++)
			{
				tempList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "" + i));
			}
			if ( i <= pageCount )
			{
				tempList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "Next"));
			}
		}
		return tempList;
	}

	public String article()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		articles = new ArrayList<ArticleVO>();
		String pubStatus = "FULL_RESTRICTED";
		if(getPub()!=null)
		{
			String temp = getPub();
			if(temp.startsWith("\""))
			{
				temp = temp.substring(1);
			}
			if(temp.endsWith("\""))
			{
				temp = temp.substring(0, temp.length()-1);
			}
			pubStatus = Utility.getPublicationAccessStatus(temp);
		}
		XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
		//	String url = ServletActionContext.getServletContext().getInitParameter("solrsearchurl");
		if(getArid()==null){
			url+="&q=*%3A*";
		}else{
			url+="&q=id%3A"+Utility.forcefullyURLEncoded(getArid());
		}
		if(getPage()==null||!xmlUtility.isInteger(getPage())||Integer.parseInt(getPage())<1){
			url+="&start=0";
		}else if(getPage()==null){
			url+="&start=0";
		}else{
			url+="&start="+((Integer.parseInt(getPage())-1)*10);
		}
		url = url.replace(" ", "+");

		try
		{
			Document document = xmlUtility.getXMLDocument(new URL(url));
			Iterator iterator = document.getDescendants(new ElementFilter("doc"));
			while(iterator.hasNext())
			{
				Element doc = (Element)iterator.next();
				ArticleVO article = new ArticleVO();
				List<Element>fieldList = doc.getChildren("arr");
				for(Element tempEle: fieldList)
				{
					String fieldName = tempEle.getAttributeValue("name");
					List<String> tempList = new ArrayList<String>();
					List<Element> tempArrEle = tempEle.getChildren();
					if(fieldName.equals("category"))
					{
						tempList.clear();
						for(Element tempArrRecord: tempArrEle)
						{
							tempList.add(tempArrRecord.getTextNormalize());
						}
						article.setCategory(tempList);
					}
					else if(fieldName.equals("news"))
					{
						tempList.clear();
						for(Element tempArrRecord: tempArrEle)
						{
							String[] tempStr = tempArrRecord.getText().replaceAll("(?m)^\\s+$", "").split("((\n\r)+)|(\n+)");
							Integer loop_count = tempStr.length;
							if(tempStr.length > 2 && pubStatus.equalsIgnoreCase("SHORT_ACCESS"))
							{
								loop_count = 2;
							}

							for(int i=0; i < loop_count; i++) {
								tempList.add(tempStr[i]);
							}
							if(pubStatus.equalsIgnoreCase("SHORT_ACCESS"))
								tempList.set(tempList.size()-1, tempList.get(tempList.size()-1) + "...");
						}
						article.setNews(tempList);
					}
				}
				fieldList = doc.getChildren("str");
				for(Element tempEle: fieldList)
				{
					String fieldName = tempEle.getAttributeValue("name");
					if(fieldName.equals("copyright"))
					{
						article.setCopyright(tempEle.getTextNormalize());
					}
					else if(fieldName.equals("exclusive"))
					{
						if(tempEle.getTextNormalize().equalsIgnoreCase("yes"))
						{
							article.setExclusive(Boolean.TRUE);
						}
						else
						{
							article.setExclusive(Boolean.FALSE);
						}
					}
					else if(fieldName.equals("headline"))
					{
						article.setHeadline(tempEle.getTextNormalize().replaceAll("\n", " "));
					}
					else if(fieldName.equals("location"))
					{
						article.setLocation(tempEle.getTextNormalize());
					}
					else if(fieldName.equals("publication"))
					{
						article.setPublication(tempEle.getTextNormalize());
					}
					else if(fieldName.equals("source"))
					{
						article.setSource(tempEle.getTextNormalize());
					}
					else if(fieldName.equals("id"))
					{
						article.setId(Utility.convertToInteger(tempEle.getTextNormalize(), -1));
					}
				}
				fieldList = doc.getChildren("date");
				for(Element tempEle: fieldList)
				{
					String fieldName = tempEle.getAttributeValue("name");
					if(fieldName.equals("contentdate"))
					{
						article.setContentDate(tempEle.getTextNormalize().split("T")[0]);
					}
				}
				article.setAccessStatus(pubStatus);
				articles.add(article);
			}
		}
		catch(Exception e)
		{
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}

	public String exclusive() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getPage()==null)
		{
			setPage("1");
		}
		articles = new ArrayList<ArticleVO>();
		String pubStatus = "SHORT_ACCESS";
		if(pubStatus.equalsIgnoreCase("FULL_ACCESS") || pubStatus.equalsIgnoreCase("SHORT_ACCESS"))
		{
			XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
			String parameter = "&q=" + Utility.forcefullyURLEncoded("exclusive:" + HTSPortal.YES);
			if(getPage() != null && xmlUtility.isInteger(getPage()) && Integer.parseInt(getPage()) > 0 )
			{
				parameter+="&start="+((Integer.parseInt(getPage())-1) * SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE));
			}
			else
			{
				parameter+="&start=0";
			}
			parameter += setFilteration(xmlUtility, "source", getSrc());
			parameter += setFilteration(xmlUtility, "publication", getPub());
			parameter += setFilteration(xmlUtility, "category", getCat());
			parameter += setFilteration(xmlUtility, "byline", getByline());
			
			HttpServletRequest request = ServletActionContext.getRequest();
			StringBuffer requestPage = getCurrentURLWithParam(request, Boolean.FALSE);
			try
			{
				Document document = xmlUtility.getXMLDocument(new URL(url+parameter));
				processShortPanel(document.getDescendants(new ElementFilter("lst")), requestPage);
				this.setArticles(Utility.getArticlesFromIterator(document.getDescendants(new ElementFilter("doc")), pubStatus));
				Integer currentPage = 1;
				if(getPage()!=null && !getPage().trim().equals(""))
				{
					currentPage = Utility.convertToInteger(getPage(), 1);
				}
				Iterator iterator = document.getDescendants(new ElementFilter("result"));
				while(iterator.hasNext())
				{
					Element ele = (Element)iterator.next();
					setPageNumberList(getPageNumberList(requestPage.toString(), currentPage, new Integer(SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE)), Utility.convertToInteger(ele.getAttributeValue("numFound"), 0)));
				}
			}
			catch(Exception e)
			{
				LOGGER.error("ERROR: "+e.getMessage());
			}
			setShortTypeDetails(ListObject.Factory.newInstance("HT Syndication Exclusive","Latest stories from HT Syndication’s own publications – Government Content, NGO News and Daily Health Digest. Keep yourself abreast with important developments in government sectors around the world, social sector news, and most recent drug launch and research in the health industry"));
		}
		else
		{
			setShortTypeDetails(ListObject.Factory.newInstance(getPub(), "You have not authorized to view this publication"));
		}
		return SUCCESS;
	}

	private StringBuffer getCurrentURLWithParam(HttpServletRequest request, Boolean deleteTypeParameter)
	{
		StringBuffer urlPage = request.getRequestURL();
		urlPage.append("?");
		Enumeration pnames = request.getParameterNames();
		while(pnames.hasMoreElements()){
			String key = pnames.nextElement().toString();
			if(!key.equalsIgnoreCase("page")){
				if(!urlPage.toString().endsWith("?")){
					urlPage.append("&");
				}
				if((!deleteTypeParameter==Boolean.TRUE&&(key.equalsIgnoreCase("pub")||key.equalsIgnoreCase("cat")||key.equalsIgnoreCase("src")||key.equalsIgnoreCase("byline"))))
				{
					try
					{
						urlPage.append(key+"="+URLEncoder.encode(request.getParameter(key), "UTF-8"));
					}catch(Exception e){
						LOGGER.error("ERROR: "+e.getMessage());
					}
				}
			}
		}
		return urlPage;
	}

	private String setFilteration(XML_Utility xmlUtility, String name, String value)
	{
		String result = "";
		if(value!=null)
		{
			try
			{
				xmlUtility.addXsltParameters(name, URLEncoder.encode(value,"UTF-8"));
				result = "&fq="+URLEncoder.encode(name+":"+value,"UTF-8");
			}
			catch(UnsupportedEncodingException e)
			{
				LOGGER.error("ERROR: "+e.getMessage());
			}
		}
		return result;
	}


	public List<ArticleVO> getArticles() {
		return articles;
	}


	public void setArticles(List<ArticleVO> articles) {
		this.articles = articles;
	}


	public String getOrganisationName()
	{
		return organisationName;
	}


	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public List<ListObject> getPublicationsInfo() {
		return publicationsInfo;
	}


	public void setPublicationsInfo(List<ListObject> publicationsInfo) {
		this.publicationsInfo = publicationsInfo;
	}


	public List<ListObject> getCategoriesInfo() {
		return categoriesInfo;
	}


	public void setCategoriesInfo(List<ListObject> categoriesInfo) {
		this.categoriesInfo = categoriesInfo;
	}


	public List<ListObject> getSourcesInfo() {
		return sourcesInfo;
	}


	public void setSourcesInfo(List<ListObject> sourcesInfo) {
		this.sourcesInfo = sourcesInfo;
	}
	
	
	public List<ListObject> getBylineInfo() {
		return bylineInfo;
	}


	public void setBylineInfo(List<ListObject> bylineInfo) {
		this.bylineInfo = bylineInfo;
	}


	public List<ListObject> getPageNumberList() {
		return pageNumberList;
	}

	public void setPageNumberList(List<ListObject> pageNumberList) {
		this.pageNumberList = pageNumberList;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
}
