package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.ContentService;
import com.ht.syndication.htsportal.service.ImageService;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class IndexAction extends ActionSupport implements SessionAware, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -444506092139392203L;
	
	private Map session;
	private UserVO user;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	
	
	/**
	 * @return the session
	 */
	public Map getSession() {
		return session;
	}


	/**
	 * @param session the session to set
	 */
	public void setSession(Map session) {
		this.session = session;
	}


	/**
	 * @return the user
	 */
	public UserVO getUser() {
		return user;
	}


	/**
	 * @param user the user to set
	 */
	public void setUser(UserVO user) {
		this.user = user;
	}

	public String createall() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		
		ContentService contentService = ServiceLocator.instance().getContentService();
		addActionError("All Content Indexes created successfully ["+contentService.indexContent()+"]");
		
		ImageService imageService = ServiceLocator.instance().getImageService();
		addActionError("All Image Indexes created successfully ["+imageService.indexImage()+"]");
		return SUCCESS;
	}
	 
	public String deleteall() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		addActionError("Index deletion service disable permanently");
		/*if(getUser()==null)
		{
			addActionError("Need Administrator Privilage For Index Creation");
			return SUCCESS;
		}
		IndexService indexService = ServiceLocator.instance().getIndexService();
		addActionError("All Indexes deleted successfully ["+indexService.deleteAllIndexes()+"]");*/
		return SUCCESS;
	}
	
	public String resetMenusXML()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		Utility.saveIntroductionXMLStartup();
		addActionError("Reset Done");
		return SUCCESS;
	}
}