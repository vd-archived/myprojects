package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ImagetagsAction extends ActionSupport implements SessionAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -792643275857276821L;

	public String showAll()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setImagetagsVOs(ServiceLocator.instance().getImagetagsService().getAllImagetags());
		setTypeList(Utility.getImagetagsTypes());
		return SUCCESS;
	}
	
	public String deleteAll()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getIds()!=null)
		{
			for(Integer id: getIds())
			{
				ServiceLocator.instance().getImagetagsService().disableImagetags(id, getUser().getUsername());
			}
			Utility.resetImageTagsXML(Boolean.TRUE);
		}
		return SUCCESS;
	}
	
	public String save()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		Integer parentCatetory = null;
		if(getParent() != null && Utility.isNumeric(getParent()))
		{
			parentCatetory = Integer.parseInt(getParent());
		}
		if(getId() != null && getName() != null)
		{
			if(validation())
			{
				try
				{
					ImagetagsVO imagetagsVO = ServiceLocator.instance().getImagetagsService().saveImagetags(new ImagetagsVO(getId(), getName(), getDetails(), getWeight(), getType(), getStatus(), parentCatetory), getUser().getUsername());
					addActionError("Imagetags '"+getName()+"' updated successfully...");
					setImagetagsVO(imagetagsVO);
					List<ImagetagsFullVO>tags = Utility.resetImageTagsXML(Boolean.TRUE);
					Utility.createImageFolderOnFTP(null, tags);
				}
				catch(Exception e)
				{
					addActionError(e.getCause().getMessage());
				}
			}
		}
		else if (getName() != null) 
		{
			if(validation())
			{
				try
				{
					ImagetagsVO imagetagsVO = ServiceLocator.instance().getImagetagsService().saveImagetags(new ImagetagsVO(getName(), getDetails(), getWeight(), getType(), getStatus(), parentCatetory), getUser().getUsername());
					addActionError("Imagetags '"+getName()+"' created successfully...");
					setImagetagsVO(imagetagsVO);
					List<ImagetagsFullVO>tags = Utility.resetImageTagsXML(Boolean.TRUE);
					Utility.createImageFolderOnFTP(null, tags);
				}
				catch(Exception e)
				{
					addActionError(e.getCause().getMessage());
				}
			}
		}
		if(getImagetagsVO()==null && getId() != null)
		{
			setImagetagsVO(ServiceLocator.instance().getImagetagsService().getImagetags(getId()));
			if(getImagetagsVO() == null)
			{
				addActionError("No imagetags found with id '"+getId()+"'...");
			}
		}
		Integer level = 0;
		List<ImagetagsFullVO> tempHirarchyImagetagsVOs = ServiceLocator.instance().getImagetagsService().getAllHierarchyImagetags();
		hirarchyImagetagsVOs = new ArrayList<ImagetagsVO>();
		hirarchyImagetagsVOs.add(new ImagetagsVO(null, "SET AS ROOT CATEGORY"));
		for(ImagetagsFullVO temp: tempHirarchyImagetagsVOs)
		{
			if(getId() != null && getId().equals(temp.getId()))
				continue;
			hirarchyImagetagsVOs.add(new ImagetagsVO(temp.getId(), setHiphenOnLevel(level) + temp.getName()));
			processChilds(temp, hirarchyImagetagsVOs, level, getId());
		}
		setTypeList(Utility.getImagetagsTypes());
		return SUCCESS;
	}

	private void processChilds(ImagetagsFullVO rootVO, List<ImagetagsVO> hirarchyImagetagsVOs, Integer level, Integer ignoreID)
	{
		level++;
		for(ImagetagsFullVO temp: rootVO.getChilds())
		{
			if(ignoreID != null && ignoreID.equals(temp.getId()))
				continue;
			hirarchyImagetagsVOs.add(new ImagetagsVO(temp.getId(), setHiphenOnLevel(level) + temp.getName()));
			processChilds(temp, hirarchyImagetagsVOs, level, ignoreID);
		}
	}
	
	private String setHiphenOnLevel(Integer level)
	{
		StringBuffer levelHiphen = new StringBuffer();
		for(int i=0; i< level; i++)
		{
			levelHiphen.append("----");
		}
		return levelHiphen.toString();
	}

	/**
	 * 
	 * @return
	 */
	private Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getName().equals(""))
		{
			addActionError("Name can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getStatus() == null)
		{
			addActionError("Status can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getName().length()>50)
		{
			addActionError("Name can not exceed 50 character");
			isValid = Boolean.FALSE;
		}
		if(getDetails().length()>5000)
		{
			addActionError("Details can not exceed 5000 character");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
	
	private Map session;
	private UserVO user;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	private List<ImagetagsVO> imagetagsVOs;
	private List<ImagetagsVO> hirarchyImagetagsVOs;
	private ImagetagsVO imagetagsVO;
	private Integer id;
	private Integer[] ids;
	private String name;
	private String details;
	private Integer weight;
	private String parent;
	private Short type;
	private Short status;
	private Map<Short, String> typeList;

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public ImagetagsVO getImagetagsVO() {
		return imagetagsVO;
	}

	public void setImagetagsVO(ImagetagsVO imagetagsVO) {
		this.imagetagsVO = imagetagsVO;
	}

	public List<ImagetagsVO> getImagetagsVOs() {
		return imagetagsVOs;
	}

	public void setImagetagsVOs(List<ImagetagsVO> imagetagsVOs) {
		this.imagetagsVOs = imagetagsVOs;
	}

	public Integer[] getIds() {
		return ids;
	}

	public void setIds(Integer[] ids) {
		this.ids = ids;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}
	
	public Map<Short, String> getTypeList() {
		return typeList;
	}

	public void setTypeList(Map<Short, String> typeList) {
		this.typeList = typeList;
	}

	public List<ImagetagsVO> getHirarchyImagetagsVOs() {
		return hirarchyImagetagsVOs;
	}

	public void setHirarchyImagetagsVOs(List<ImagetagsVO> hirarchyImagetagsVOs) {
		this.hirarchyImagetagsVOs = hirarchyImagetagsVOs;
	}
}