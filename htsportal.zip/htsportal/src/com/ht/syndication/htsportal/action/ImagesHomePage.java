package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.JDOMException;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;
import com.ht.syndication.htsportal.transfer.ImageVO;
import com.ht.syndication.htsportal.transfer.ImageWidgetVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.FreemarkerUtil;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class ImagesHomePage extends ActionSupport implements SessionAware, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4460216022479290013L;

	private static final Log LOGGER = LogFactory.getLog(ImagesHomePage.class);
	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;
	
	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public String home()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.URL));
			File categoryFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_INTRO_XML")));
			Document document = null;
			if(categoryFile.exists())
			{
				SAXBuilder builder = new SAXBuilder();
				try
				{
					document = builder.build(categoryFile);
					Element root = document.getRootElement();
					List categories = root.getChildren("category");
					for (int i = 0; i < categories.size(); i++) 
					{
						Element row = (Element) categories.get(i);
						String categoryName = row.getChildText("name");
						String categoryDetails = row.getChildText("intro");
						String categoryStatus = row.getChildText("status");
						String categoryType = row.getChildText("type");
						if(categoryStatus.equals("1") && categoryType.equals("1")) {
							ImageWidgetVO imageWidget = new ImageWidgetVO();
							imageWidget.setName(categoryName);
							imageWidget.setDetails(categoryDetails);
	
							SolrQuery query = new SolrQuery();
						    query.setQuery("tags:\"" + categoryName.trim() + "\" AND updatedate:[NOW-5YEAR TO *]");
						    query.setStart(0);
						    query.setRows(16);
						    QueryResponse response = solrServer.query(query);
						    SolrDocumentList results = response.getResults();
						    if(results.size() > 0) {
						    	for(SolrDocument image: results) {
						    		ImageVO imageVO = new ImageVO();
						    		imageVO.setName(image.getFieldValue("name").toString());
						    		if(image.getFieldValue("title") != null) {
						    			imageVO.setTitle(image.getFieldValue("title").toString());
						    		}
						    		if(image.getFieldValue("details") != null) {
						    			imageVO.setDetails(image.getFieldValue("details").toString());
						    		}
						    		if(image.getFieldValue("author") != null) {
						    			imageVO.setAuthor(image.getFieldValue("author").toString());
						    		}
						    		imageWidget.getImages().add(imageVO);
						    	}
						    	getImageWidgets().add(imageWidget);
						    }
						}
					}
				} catch (JDOMException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				} catch (IOException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				}
			}
			else {
				LOGGER.error("ERROR: Image Category File Not Found [" + categoryFile.getAbsolutePath() + "]");
			}
		}
		catch(Exception e)
		{
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}
	
	private FreemarkerUtil freemarkerUtil = new FreemarkerUtil();
	private List<ImageWidgetVO>imageWidgets = new ArrayList<ImageWidgetVO>();
	
	public List<ImageWidgetVO> getImageWidgets() {
		return imageWidgets;
	}

	public void setImageWidgets(List<ImageWidgetVO> imageWidgets) {
		this.imageWidgets = imageWidgets;
	}

	public FreemarkerUtil getFreemarkerUtil() {
		return freemarkerUtil;
	}

	public void setFreemarkerUtil(FreemarkerUtil freemarkerUtil) {
		this.freemarkerUtil = freemarkerUtil;
	}
}