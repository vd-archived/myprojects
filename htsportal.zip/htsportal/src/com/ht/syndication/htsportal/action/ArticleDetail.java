package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.FreemarkerUtil;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class ArticleDetail extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8011627908743572466L;
	
	private static final Log LOGGER = LogFactory.getLog(ArticleDetail.class);
	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;
	
	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public String execute()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.URL));
			
			SolrQuery query = new SolrQuery();
			query.setQuery("id:"+articleId);
			
			query.setFacet(true);
			query.addFacetField("category");
			query.addFacetField("source");
			query.addFacetField("publication");
			query.addFacetField("byline");
			query.addFacetField("location");
		    QueryResponse response = solrServer.query(query);
		    setDocuments(response.getResults());
		    setFacetFields(response.getFacetFields());
		} catch (Exception e) {
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}
	
	private FreemarkerUtil freemarkerUtil = new FreemarkerUtil();
	private String articleId;
	private String title;
	private List<FacetField>facetFields = new ArrayList<FacetField>();
	private SolrDocumentList documents = new SolrDocumentList();
	private String filtertype = "article";
	
	
	public SolrDocumentList getDocuments() {
		return documents;
	}

	public void setDocuments(SolrDocumentList documents) {
		this.documents = documents;
	}
	
	public List<FacetField> getFacetFields() {
		return facetFields;
	}

	public void setFacetFields(List<FacetField> facetFields) {
		this.facetFields = facetFields;
	}

	public FreemarkerUtil getFreemarkerUtil() {
		return freemarkerUtil;
	}

	public void setFreemarkerUtil(FreemarkerUtil freemarkerUtil) {
		this.freemarkerUtil = freemarkerUtil;
	}

	public String getArticleId() {
		return articleId;
	}

	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}
}
