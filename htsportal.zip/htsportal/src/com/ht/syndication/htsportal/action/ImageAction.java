package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.ImageServiceException;
import com.ht.syndication.htsportal.transfer.EventVO;
import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;
import com.ht.syndication.htsportal.transfer.ImagetagsFullVO;
import com.ht.syndication.htsportal.transfer.ImagetagsVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ListObject;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;


public class ImageAction extends ActionSupport implements SessionAware, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3022183216070799706L;

	public String imageUpdate()
	{
		String RETURNSTR = "IMAGENOTFOUND";
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getId() != null && getStatus() != null)
		{
			if(this.validation())
			{
				imageVO = new ImageVO(Integer.parseInt(getId()), getName(), getTitle(), Short.parseShort(getStatus()));
				imageVO.setAuthor(getAuthor());
				imageVO.setDetails(getDetails());
				imageVO.setType(getType());
				imageVO.setOrientation(getOrientation());
				imageVO.setEditorial(getEditorial());
				imageVO.setKeywords(getKeywords());
				imageVO.setCopyright(getCopyright());
				imageVO.setWidth(getWidth());
				imageVO.setHeight(getHeight());
				imageVO.setResolution(getResolution());
				imageVO.setEvent(getEventid());
				if(getTagids() != null)
				{
					imageVO.setTags(Arrays.asList(getTagids()));
				}
				else{
					imageVO.setTags(null);
				}
				imageVO = ServiceLocator.instance().getImageService().saveImage(imageVO, getUser().getUsername());
				addActionError("Image '" + getName() + "' updated successfully");
			}
		}
		
		if(getId() != null || imageVO != null)
		{
			try{
				if(imageVO == null)
				{
					imageFullVO = ServiceLocator.instance().getImageService().getFullImage(Integer.parseInt(getId()));
				}
				else
				{
					imageFullVO = ServiceLocator.instance().getImageService().getFullImage(imageVO.getId());
				}
			}
			catch(ImageServiceException e){}
			catch(NullPointerException e){}
			catch(NumberFormatException e){}
			if(imageFullVO != null)
			{
				events = new ArrayList<EventVO>(Arrays.asList(ServiceLocator.instance().getEventService().getAllEvent()));
				events.add(0, new EventVO(null, "Nothing", null, null));

				Integer level = 0;
				List<ImagetagsFullVO> fullImageTags = ServiceLocator.instance().getImagetagsService().getAllHierarchyImagetags();
				imageTags = new ArrayList<ImagetagsVO>();
//				imageTags.add(new ImagetagsVO(null, "Select Image Category"));
				for(ImagetagsFullVO temp: fullImageTags)
				{
					imageTags.add(new ImagetagsVO(temp.getId(), setHiphenOnLevel(level) + temp.getName()));
					processChilds(temp, imageTags, level);
				}
				RETURNSTR = SUCCESS;
			}
		}
		return RETURNSTR;
	}
	
	public String inactiveImages()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		Integer imagePerPage = Utility.convertToInteger(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE), 15);
		if(getPage()==null)
		{
			setPage("1");
		}
		else
		{
			setPage(Utility.convertToInteger(getPage(), 1).toString());
		}
		Integer currentPage = Integer.parseInt(getPage());
		images = ServiceLocator.instance().getImageService().getAllInactiveImage();
		Integer startIndex = ((currentPage-1) * imagePerPage);
		for(int i = startIndex; i<images.size() && i<(startIndex + imagePerPage); i++)
		{
			imageNameList.add(images.get(i));
		}
		this.setPageNumberBlock(ServletActionContext.getRequest(), currentPage, imagePerPage, images.size());
		return SUCCESS;
	}
	
	
	public String upload()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(uploads.size() > 0 )
		{
			List<String>allStatus = ServiceLocator.instance().getImageService().uploadImage(uploads, uploadFileNames, uploadContentTypes, getKeywords(), getCopyright(), getEventid(), Arrays.asList(getTagids()), getUser().getUsername());
			for(String status: allStatus)
			{
				addActionError(status);
			}
		}
		events = new ArrayList<EventVO>(Arrays.asList(ServiceLocator.instance().getEventService().getAllEvent()));
		events.add(0, new EventVO(null, "Select Event", null, null));

		Integer level = 0;
		List<ImagetagsFullVO> fullImageTags = ServiceLocator.instance().getImagetagsService().getAllHierarchyImagetags();
		imageTags = new ArrayList<ImagetagsVO>();
		imageTags.add(new ImagetagsVO(null, "Select Image Category"));
		for(ImagetagsFullVO temp: fullImageTags)
		{
			imageTags.add(new ImagetagsVO(temp.getId(), setHiphenOnLevel(level) + temp.getName()));
			processChilds(temp, imageTags, level);
		}
		return SUCCESS;
	}
	
	private void processChilds(ImagetagsFullVO rootVO, List<ImagetagsVO> hirarchyImagetagsVOs, Integer level)
	{
		level++;
		for(ImagetagsFullVO temp: rootVO.getChilds())
		{
			hirarchyImagetagsVOs.add(new ImagetagsVO(temp.getId(), setHiphenOnLevel(level) + temp.getName()));
			processChilds(temp, hirarchyImagetagsVOs, level);
		}
	}
	
	private String setHiphenOnLevel(Integer level)
	{
		StringBuffer levelHiphen = new StringBuffer();
		for(int i=0; i< level; i++)
		{
			levelHiphen.append("----");
		}
		return levelHiphen.toString();
	}
	
	/**
	 * 
	 * @return
	 */
	private Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		try
		{
			if(getName().equals("") || getName().length() > 100)
			{
				addActionError("Name can not be empty and can not exceed 100 characters");
				isValid = Boolean.FALSE;
			}
			if(!getTitle().equals("") && getTitle().length() > 2000)
			{
				addActionError("Title can not exceed 2000 characters");
				isValid = Boolean.FALSE;
			}
			if(!getAuthor().equals("") && getAuthor().length() > 100)
			{
				addActionError("Author can not exceed 100 characters");
				isValid = Boolean.FALSE;
			}
			if(!getDetails().equals("") && getDetails().length() > 5000)
			{
				addActionError("Details can not exceed 5000 characters");
				isValid = Boolean.FALSE;
			}
			if(!getType().equals("") && getType().length() > 25)
			{
				addActionError("Type can not exceed 25 characters");
				isValid = Boolean.FALSE;
			}
			if(!getOrientation().equals("") && getOrientation().length() > 25)
			{
				addActionError("Orientation can not exceed 25 characters");
				isValid = Boolean.FALSE;
			}
			if(!getEditorial().equals("") && getEditorial().length() > 25)
			{
				addActionError("Editorial can not exceed 25 characters");
				isValid = Boolean.FALSE;
			}
			if(!getKeywords().equals("") && getKeywords().length() > 2000)
			{
				addActionError("Keywords can not exceed 2000 characters");
				isValid = Boolean.FALSE;
			}
			if(!getCopyright().equals("") && getCopyright().length() > 200)
			{
				addActionError("Copyright can not exceed 200 characters");
				isValid = Boolean.FALSE;
			}
			if(!getWidth().equals("") && (!Utility.isNumeric(getWidth()) || getWidth().length() > 6))
			{
				addActionError("Width should be numeric and can not exceed 6 characters");
				isValid = Boolean.FALSE;
			}
			if(!getHeight().equals("") && (!Utility.isNumeric(getHeight()) || getHeight().length() > 6))
			{
				addActionError("Height should be numeric and can not exceed 6 characters");
				isValid = Boolean.FALSE;
			}
			if(!getResolution().equals("") && (!Utility.isNumeric(getResolution()) || getResolution().length() > 6))
			{
				addActionError("Resolution should be numeric and can not exceed 6 characters");
				isValid = Boolean.FALSE;
			}
			if(getStatus().equals(""))
			{
				addActionError("Status can not be empty");
				isValid = Boolean.FALSE;
			}
		}
		catch(Exception e)
		{
			addActionError("Exception: " + e.getMessage());
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
	
	private void setPageNumberBlock(HttpServletRequest request, Integer currentPage, Integer imagePerPage, Integer imageSize)
	{
		String[]excludeParams = {"page"};
		String requestedURL = Utility.getRequestedURLWithParameter(ServletActionContext.getRequest(), excludeParams);
		Integer pageCount = (int)Math.ceil(imageSize/(float)(imagePerPage));
		if (pageCount > 0)
		{
			currentPage = currentPage - 5;
			if(currentPage>1)
			{
				if((currentPage + 9)>=pageCount)
				{
					currentPage = pageCount - 10;
				}
				if(currentPage < 1)
				{
					currentPage = 0;
				}
				else
				{
					pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+currentPage, "Previous"));
				}
			}
			else
			{
				currentPage = 0;
			}
			int i = 0;
			for (i = (currentPage+1); i < (currentPage + 11) && i <= pageCount; i++)
			{
				pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "" + i));
			}
			if ( i <= pageCount )
			{
				pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "Next"));
			}
		}
	}
	
	private List<ImageFullVO> images;
	
	public List<ImageFullVO> getImages() {
		return images;
	}
	
	public void setImages(List<ImageFullVO> images) {
		this.images = images;
	}

	private Integer[]ids;
	private String id;
	private String name;
	private String title;
	private String author;
	private String details;
	private String type;
	private String orientation;
	private String editorial;
	private String keywords;
	private String copyright;
	private String width;
	private String height;
	private String resolution;
	private String status;
	private String checksum;
	private Date indexdate;
	private Date createdate;
	private Date updatedate;
	private UserVO updateby;
	private List<EventVO> events;
	private List<ImagetagsVO> imageTags;
	private Integer eventid;
	private Integer[]tagids;
	
	private ImageVO imageVO;
	
	private ImageFullVO imageFullVO;
	
	public ImageFullVO getImageFullVO() {
		return imageFullVO;
	}

	public void setImageFullVO(ImageFullVO imageFullVO) {
		this.imageFullVO = imageFullVO;
	}

	public Integer[] getIds() {
		return ids;
	}

	public void setIds(Integer[] ids) {
		this.ids = ids;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOrientation() {
		return orientation;
	}

	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getCopyright() {
		return copyright;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getChecksum() {
		return checksum;
	}

	public void setChecksum(String checksum) {
		this.checksum = checksum;
	}

	public Date getIndexdate() {
		return indexdate;
	}

	public void setIndexdate(Date indexdate) {
		this.indexdate = indexdate;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Date getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(Date updatedate) {
		this.updatedate = updatedate;
	}

	public UserVO getUpdateby() {
		return updateby;
	}

	public void setUpdateby(UserVO updateby) {
		this.updateby = updateby;
	}

	public List<EventVO> getEvents() {
		return events;
	}

	public void setEvents(List<EventVO> events) {
		this.events = events;
	}

	public List<ImagetagsVO> getImageTags() {
		return imageTags;
	}

	public void setImageTags(List<ImagetagsVO> imageTags) {
		this.imageTags = imageTags;
	}

	public Integer getEventid() {
		return eventid;
	}

	public void setEventid(Integer eventid) {
		this.eventid = eventid;
	}

	public Integer[] getTagids() {
		return tagids;
	}

	public void setTagids(Integer[] tagids) {
		this.tagids = tagids;
	}

	
	
	
	private Map session;
	private UserVO user;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private String webroot;
	private static final Log LOGGER = LogFactory.getLog(ConfigurationReader.class);

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}
	
	public void setUser(UserVO user) {
		this.user = user;
	}

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	private List<File> uploads = new ArrayList<File>();
    private List<String> uploadFileNames = new ArrayList<String>();
    private List<String> uploadContentTypes = new ArrayList<String>();

	public List<File> getUpload() {
		return uploads;
	}

	public void setUpload(List<File> uploads) {
		this.uploads = uploads;
	}

	public List<String> getUploadFileName() {
		return uploadFileNames;
	}

	public void setUploadFileName(List<String> uploadFileNames) {
		this.uploadFileNames = uploadFileNames;
	}

	public List<String> getUploadContentType() {
		return uploadContentTypes;
	}

	public void setUploadContentType(List<String> uploadContentTypes) {
		this.uploadContentTypes = uploadContentTypes;
	}
	
	private List<ImageVO> imageNameList = new ArrayList<ImageVO>();
	private List<ListObject> pageNumberList = new ArrayList<ListObject>();
	private String page;

	public List<ImageVO> getImageNameList() {
		return imageNameList;
	}

	public void setImageNameList(List<ImageVO> imageNameList) {
		this.imageNameList = imageNameList;
	}

	public List<ListObject> getPageNumberList() {
		return pageNumberList;
	}

	public void setPageNumberList(List<ListObject> pageNumberList) {
		this.pageNumberList = pageNumberList;
	}


	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public ImageVO getImageVO() {
		return imageVO;
	}

	public void setImageVO(ImageVO imageVO) {
		this.imageVO = imageVO;
	}
}