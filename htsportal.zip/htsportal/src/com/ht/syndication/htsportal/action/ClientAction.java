package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.ClientService;
import com.ht.syndication.htsportal.transfer.ClientVO;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ClientAction extends ActionSupport implements SessionAware, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8545320732443223496L;

	public String create() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getName() != null && getStatus() != null)
		{
			if(this.validation())
			{
				try{
					ClientService clientService = ServiceLocator.instance().getClientService();
					ClientVO clientVO = new ClientVO(getName(), getDetails(), Short.parseShort("1"), getStatus(), getTimeinterval());
					clientVO.setPublications(getPubs());
					clientService.saveClient(clientVO, getUser().getUsername());
					addActionError("Client created successfully...");
					clearFields();
				}
				catch(Exception e)
				{
					addActionError("Error Found: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		setTimeIntervalList(Utility.getAllTimeInterval());
		setStatusList(Utility.getAllUserStatus());
		pubList = new ArrayList<PublicationShortVO>();
		pubList.add(new PublicationShortVO(null, null, "Select Publication", null));
		pubList.addAll(Arrays.asList(ServiceLocator.instance().getPublicationService().getAllPublicationShort()));
		return SUCCESS;
	}
	
	public String update() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		ClientVO clientVO = null;
		setTimeIntervalList(Utility.getAllTimeInterval());
		setStatusList(Utility.getAllUserStatus());
		pubList = new ArrayList<PublicationShortVO>();
		pubList.add(new PublicationShortVO(null, null, "Select Publication", null));
		pubList.addAll(Arrays.asList(ServiceLocator.instance().getPublicationService().getAllPublicationShort()));
		if (getId() != null && getStatus() != null)
		{
			if(this.validation())
			{
				try{
					ClientService clientService = ServiceLocator.instance().getClientService();
					clientVO = new ClientVO(getId(), getName(), getDetails(), Short.parseShort("1"), getStatus(), getTimeinterval());
					clientVO.setPublications(getPubs());
					clientService.saveClient(clientVO, getUser().getUsername());
					addActionError("Client updated successfully...");
				}
				catch(Exception e)
				{
					addActionError("Error Found: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		if(clientVO == null && getId() != null)
		{
			clientVO = ServiceLocator.instance().getClientService().getClient(getId());
			setId(clientVO.getId());
			setName(clientVO.getName());
			setDetails(clientVO.getDetails());
			setStatus(clientVO.getStatus());
			setTimeinterval(clientVO.getRevenueinterval());
		}
		currentPubList = new HashMap<String, String>();
		for(String pubKey: clientVO.getPublications())
		{
			for(PublicationShortVO temp: pubList)
			{
				if(temp.getId() != null && temp.getId().toString().equals(pubKey))
				{
					currentPubList.put(pubKey, temp.getName());
					break;
				}
			}
		}
		return SUCCESS;
	}
	
	public String show() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setClients(Arrays.asList(ServiceLocator.instance().getClientService().getAllClient()));
		setTimeIntervalList(Utility.getAllTimeInterval());
		setStatusList(Utility.getAllUserStatus());
		return SUCCESS;
	}

	private Integer id;
	private String name;
	private String details;
	private Short status;
	private Short timeinterval;
	private Short type;
	private Map<Short, String> statusList;
	private Map<Short, String> timeIntervalList;
	private List<PublicationShortVO> pubList;
	private List<String>pubs;
	private List<ClientVO>clients;
	private Map<String, String> currentPubList;
	
	public Map<String, String> getCurrentPubList() {
		return currentPubList;
	}

	public void setCurrentPubList(Map<String, String> currentPubList) {
		this.currentPubList = currentPubList;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}
	
	public Short getTimeinterval() {
		return timeinterval;
	}

	public void setTimeinterval(Short timeinterval) {
		this.timeinterval = timeinterval;
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public Map<Short, String> getStatusList() {
		return statusList;
	}

	public void setStatusList(Map<Short, String> statusList) {
		this.statusList = statusList;
	}

	public Map<Short, String> getTimeIntervalList() {
		return timeIntervalList;
	}

	public void setTimeIntervalList(Map<Short, String> timeIntervalList) {
		this.timeIntervalList = timeIntervalList;
	}

	public List<PublicationShortVO> getPubList() {
		return pubList;
	}

	public void setPubList(List<PublicationShortVO> pubList) {
		this.pubList = pubList;
	}

	public List<String> getPubs() {
		return pubs;
	}

	public void setPubs(List<String> pubs) {
		this.pubs = pubs;
	}
	
	public List<ClientVO> getClients() {
		return clients;
	}

	public void setClients(List<ClientVO> clients) {
		this.clients = clients;
	}

	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	public Map getSession() {
		return session;
	}
	public void setSession(Map session) {
		this.session = session;
	}
	public UserVO getUser() {
		return user;
	}
	public void setUser(UserVO user) {
		this.user = user;
	}
	
	private void clearFields()
	{
		this.id = null;
		this.name = null;
		this.details = null;
		this.status = null;
		this.type = null;
	}
	
	public Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getName() == null || getName().length() > 30)
		{
			addActionError("Name can not blank and can't exceed 85 character");
			isValid = Boolean.FALSE;
		}
		if(getTimeinterval() == null)
		{
			addActionError("Revenue interval can not blank");
			isValid = Boolean.FALSE;
		}
		if(getStatus() == null)
		{
			addActionError("Status can not blank");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
}
