package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.JDOMException;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;
import com.ht.syndication.htsportal.transfer.PublicationVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.FreemarkerUtil;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class ArticlePublication extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8011627908743572466L;
	
	private static final Log LOGGER = LogFactory.getLog(ArticlePublication.class);
	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;
	
	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public String execute() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		try {
			File publicationFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("PUBLICATION_INTRO_XML")));
			Document document = null;
			if(publicationFile.exists()) {
				SAXBuilder builder = new SAXBuilder();
				try {
					document = builder.build(publicationFile);
					Element root = document.getRootElement();
					List publications = root.getChildren("publication");
					for (int i = 0; i < publications.size(); i++) {
						Element row = (Element) publications.get(i);
						if(row.getAttribute("newsTicker").getValue().equalsIgnoreCase("true") && !(row.getChild("status").getText().equalsIgnoreCase("0"))) {
							PublicationVO publication = new PublicationVO();
							publication.setName(row.getChild("name").getText());
							publication.setDetails(row.getChild("intro").getText());
							publication.setNewsTicker("yes");
							getPublications().add(publication);
						}
					}
					for (int i = 0; i < publications.size(); i++) {
						Element row = (Element) publications.get(i);
						if(row.getAttribute("newsTicker").getValue().equalsIgnoreCase("false") && !(row.getChild("status").getText().equalsIgnoreCase("0"))) {
							PublicationVO publication = new PublicationVO();
							publication.setName(row.getChild("name").getText());
							publication.setDetails(row.getChild("intro").getText());
							publication.setNewsTicker("no");
							getPublications().add(publication);
						}
					}
				} catch (JDOMException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				} catch (IOException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				}
			}
		}
		catch(Exception e)
		{
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}
	
	private List<PublicationVO>publications = new ArrayList<PublicationVO>();
	
	private FreemarkerUtil freemarkerUtil = new FreemarkerUtil();
	
	public FreemarkerUtil getFreemarkerUtil() {
		return freemarkerUtil;
	}

	public void setFreemarkerUtil(FreemarkerUtil freemarkerUtil) {
		this.freemarkerUtil = freemarkerUtil;
	}

	public List<PublicationVO> getPublications() {
		return publications;
	}

	public void setPublications(List<PublicationVO> publications) {
		this.publications = publications;
	}
}
