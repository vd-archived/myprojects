package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class ShowUserPage extends ActionSupport implements SessionAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -945948080547456836L;

	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	/**
	 * @return
	 */
	public String execute() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		return SUCCESS;
	}
}