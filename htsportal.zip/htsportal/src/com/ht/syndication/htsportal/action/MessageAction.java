package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.domain.AccessStatus;
import com.ht.syndication.htsportal.service.UsermessageService;
import com.ht.syndication.htsportal.transfer.SubscriptionVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.transfer.UsermessageVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class MessageAction extends ActionSupport implements SessionAware, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 9196013277741251180L;
	
	private Map<String, Object> session;
	private UsermessageVO[] messageList;
	private SubscriptionVO[] subscriptionVOList;
	private UserVO user;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	private String id;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	

	public String allmessage()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setMessageList(ServiceLocator.instance().getUsermessageService().getAllUsermessage());
		return SUCCESS;
	}
	
	public String allSubscriptionMessage()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setSubscriptionVOList(ServiceLocator.instance().getUsermessageService().getAllSubscriptionMsg());
		return SUCCESS;
	}
	
	public String deletemessage()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getId()!=null && Utility.isNumeric(getId()))
		{
			UsermessageService usermessageService = ServiceLocator.instance().getUsermessageService();
			UsermessageVO usermessageVO = usermessageService.getUsermessage(Integer.parseInt(getId()));
			usermessageVO.setStatus(AccessStatus.DISABLE);
			usermessageService.saveUsermessage(usermessageVO, getUser().getUsername());
		}
		return SUCCESS;
	}
	
	public String deletesubscription()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getId()!=null && Utility.isNumeric(getId()))
		{
			UsermessageService usermessageService = ServiceLocator.instance().getUsermessageService();
			SubscriptionVO subscriptionVO = usermessageService.getSubscriptionMsg(Integer.parseInt(getId()));
			subscriptionVO.setStatus(AccessStatus.DISABLE);
			usermessageService.saveSubscriptionMsg(subscriptionVO, getUser().getUsername());
		}
		return SUCCESS;
	}
	

	/**
	 * @return the user
	 */
	public UserVO getUser() {
		return user;
	}


	/**
	 * @param user the user to set
	 */
	public void setUser(UserVO user) {
		this.user = user;
	}


	/**
	 * @return the session
	 */
	public Map<String, Object> getSession() {
		return session;
	}


	/* (non-Javadoc)
	 * @see org.apache.struts2.interceptor.SessionAware#setSession(java.util.Map)
	 */
	/**
	 * @param session the session to set
	 */
	public void setSession(Map<String, Object> session) 
	{
		this.session = session;
	}
	
	
	/**
	 * @return the messageList
	 */
	public UsermessageVO[] getMessageList() {
		return messageList;
	}


	/**
	 * @param messageList the messageList to set
	 */
	public void setMessageList(UsermessageVO[] messageList) {
		this.messageList = messageList;
	}

	public SubscriptionVO[] getSubscriptionVOList() {
		return subscriptionVOList;
	}

	public void setSubscriptionVOList(SubscriptionVO[] subscriptionVOList) {
		this.subscriptionVOList = subscriptionVOList;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

}
