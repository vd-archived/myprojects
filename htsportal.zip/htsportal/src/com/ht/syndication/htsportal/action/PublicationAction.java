package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.PublicationService;
import com.ht.syndication.htsportal.transfer.PublicationVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class PublicationAction extends ActionSupport implements SessionAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5574113199949750108L;
	
	PublicationVO[] publications;
	private Map session;
	private UserVO user;
	private String pubShortname,pubName, pubDetails, pubWeburl, pubemail, pubaddress,
	pubphone, pubfax, pubcontactperson1, pubcontactperson2,
	pubcontactperson3, pubotherinfo, pubowner;
	private Short pubstatus;
	private Integer pubID;
	private Map<Short, String> statusList;
	private List<UserVO>users;
	private String pubExclusive;
	private String pubNewsTicker;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	/**
	 * @return the statusList
	 */
	public Map<Short, String> getStatusList() {
		return statusList;
	}

	/**
	 * @param statusList the statusList to set
	 */
	public void setStatusList(Map<Short, String> statusList) {
		this.statusList = statusList;
	}

	public String getPubowner() {
		return pubowner;
	}
	public void setPubowner(String pubowner) {
		this.pubowner = pubowner;
	}
	public Integer getPubID() {
		return pubID;
	}

	public void setPubID(Integer pubID) {
		this.pubID = pubID;
	}

	public String getPubName() {
		return pubName;
	}

	public void setPubName(String pubName) {
		this.pubName = pubName;
	}

	public String getPubDetails() {
		return pubDetails;
	}

	public void setPubDetails(String pubDetails) {
		this.pubDetails = pubDetails;
	}

	public String getPubWeburl() {
		return pubWeburl;
	}

	public void setPubWeburl(String pubWeburl) {
		this.pubWeburl = pubWeburl;
	}

	public String getPubemail() {
		return pubemail;
	}

	public void setPubemail(String pubemail) {
		this.pubemail = pubemail;
	}

	public String getPubaddress() {
		return pubaddress;
	}

	public void setPubaddress(String pubaddress) {
		this.pubaddress = pubaddress;
	}

	public String getPubphone() {
		return pubphone;
	}

	public void setPubphone(String pubphone) {
		this.pubphone = pubphone;
	}

	public String getPubfax() {
		return pubfax;
	}

	public void setPubfax(String pubfax) {
		this.pubfax = pubfax;
	}

	public String getPubcontactperson1() {
		return pubcontactperson1;
	}

	public void setPubcontactperson1(String pubcontactperson1) {
		this.pubcontactperson1 = pubcontactperson1;
	}

	public String getPubcontactperson2() {
		return pubcontactperson2;
	}

	public void setPubcontactperson2(String pubcontactperson2) {
		this.pubcontactperson2 = pubcontactperson2;
	}

	public String getPubcontactperson3() {
		return pubcontactperson3;
	}

	public void setPubcontactperson3(String pubcontactperson3) {
		this.pubcontactperson3 = pubcontactperson3;
	}

	public String getPubotherinfo() {
		return pubotherinfo;
	}

	public void setPubotherinfo(String pubotherinfo) {
		this.pubotherinfo = pubotherinfo;
	}

	public Short getPubstatus() {
		return pubstatus;
	}

	public void setPubstatus(Short pubstatus) {
		this.pubstatus = pubstatus;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public PublicationVO[] getPublications() {
		return publications;
	}

	public void setPublications(PublicationVO[] publications) {
		this.publications = publications;
	}
	

    public String getPubShortname()
    {
        return pubShortname;
    }

    public void setPubShortname(String pubShortname)
    {
        this.pubShortname = pubShortname;
    }
    
	public List<UserVO> getUsers() {
		return users;
	}
	
	public void setUsers(List<UserVO> users) {
		this.users = users;
	}
	
	/**
	 * @return
	 */

	public String create() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getPubShortname() != null) {
			if(this.validation())
			{
				PublicationService publicationService = ServiceLocator.instance().getPublicationService();
				PublicationVO publicationVO = new PublicationVO(getPubID(),getPubShortname(), getPubName(), getPubDetails(), getPubWeburl(), getPubemail(), getPubaddress(), getPubphone(), getPubfax(), getPubcontactperson1(), getPubcontactperson2(), getPubcontactperson3(), getPubotherinfo(), getPubstatus());
				publicationVO.setOwner(getPubowner());
				publicationVO.setExclusive(getPubExclusive());
				publicationVO.setNewsTicker(getPubNewsTicker());
				publicationVO = publicationService.savePublication(publicationVO, getUser().getUsername());
				addActionError("Publication '"+getPubShortname()+"' created successfully...");
				Utility.resetContentPublication();
				/*Utility.saveIntroductionXML(HTSPortal.XMLFile.PUBLICATION, publicationVO.getId(), publicationVO.getName(), publicationVO.getDetails(), publicationVO.getStatus(), publicationVO.getNewsTicker(), null);*/
			}
		}
		setUsers(ServiceLocator.instance().getUserService().getAllUsers(getUser().getRole()));
		setStatusList(Utility.getAllPublicationStatus());
		return SUCCESS;
	}

	public String show() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		PublicationService publicationService = ServiceLocator.instance().getPublicationService();
		setPublications(publicationService.getAllPublication());
		return SUCCESS;
	}

	public String update() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getPubstatus() != null) {
			if(this.validation())
			{
				PublicationVO publicationVO = new PublicationVO(getPubID(), getPubShortname(), getPubName(), getPubDetails(), getPubWeburl(), getPubemail(), getPubaddress(), getPubphone(), getPubfax(), getPubcontactperson1(), getPubcontactperson2(), getPubcontactperson3(), getPubotherinfo(), getPubstatus());
				publicationVO.setOwner(getPubowner());
				publicationVO.setExclusive(getPubExclusive());
				publicationVO.setNewsTicker(getPubNewsTicker());
				PublicationService publicationService = ServiceLocator.instance().getPublicationService();
				publicationVO = publicationService.savePublication(publicationVO, getUser().getUsername());
				addActionError("Publication '"+getPubName()+"' updated successfully...");
				Utility.resetContentPublication();
				/*Utility.saveIntroductionXML(HTSPortal.XMLFile.PUBLICATION, publicationVO.getId(), publicationVO.getName(), publicationVO.getDetails(), publicationVO.getStatus(), publicationVO.getNewsTicker(), null);*/
			}
		}
		if(getPubID()!=null)
		{
			PublicationService publicationService = ServiceLocator.instance().getPublicationService();
			PublicationVO publication = publicationService.getPublication(getPubID());
			if(publication==null){
				addActionError("No Publication found for '"+getPubShortname()+"'");
			}else{
				setPubID(publication.getId());
				setPubShortname(publication.getShortname());
				setPubName(publication.getName());
				setPubExclusive(publication.getExclusive());
				setPubNewsTicker(publication.getNewsTicker());
				setPubDetails(publication.getDetails());
				setPubWeburl(publication.getWeburl());
				setPubemail(publication.getEmail());
				setPubaddress(publication.getAddress());
				setPubphone(publication.getPhone());
				setPubfax(publication.getFax());
				setPubcontactperson1(publication.getContactperson1());
				setPubcontactperson2(publication.getContactperson2());
				setPubcontactperson3(publication.getContactperson3());
				setPubotherinfo(publication.getOtherinfo());
				setPubstatus(publication.getStatus());
				setPubowner(publication.getOwner());
				
				setStatusList(Utility.getAllPublicationStatus());
				setUsers(ServiceLocator.instance().getUserService().getAllUsers(getUser().getRole()));
			}
		}
		else
		{
			addActionError("No Publication found for updation");
		}
		return SUCCESS;
	}
	
	public String delete() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		Integer id = getPubID();
		PublicationService publicationService = ServiceLocator.instance().getPublicationService();
		publicationService.deletePublication(id);
		Utility.resetContentPublication();
		return show();
	}

	public String getPubExclusive() {
		return pubExclusive;
	}

	public void setPubExclusive(String pubExclusive) 
	{
		this.pubExclusive = pubExclusive;
	}

	public String getPubNewsTicker() {
		return pubNewsTicker;
	}

	public void setPubNewsTicker(String pubNewsTicker) {
		this.pubNewsTicker = pubNewsTicker;
	}
	
	/**
	 * 
	 * @return
	 */
	private Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getPubShortname().equals("")){
			addActionError("Nick name can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getPubName().equals("")){
			addActionError("Name can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getPubstatus().equals("")){
			addActionError("Status can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getPubShortname().length()>10){
			addActionError("Nick name can not exceed 10 character");
			isValid = Boolean.FALSE;
		}
		if(getPubName().length()>50){
			addActionError("Name can not exceed 50 character");
			isValid = Boolean.FALSE;
		}
		if(getPubDetails().length()>2000){
			addActionError("Details can not exceed 2000 character");
			isValid = Boolean.FALSE;
		}
		if(getPubWeburl().length()>100){
			addActionError("Web URL can not exceed 100 character");
			isValid = Boolean.FALSE;
		}
		if(getPubemail().length()>100){
			addActionError("E-Mail can not exceed 100 character");
			isValid = Boolean.FALSE;
		}
		if(getPubaddress().length()>200){
			addActionError("Address can not exceed 200 character");
			isValid = Boolean.FALSE;
		}
		if(getPubphone().length()>22){
			addActionError("Phone can not exceed 22 character");
			isValid = Boolean.FALSE;
		}
		if(getPubfax().length()>22){
			addActionError("Fax can not exceed 22 character");
			isValid = Boolean.FALSE;
		}
		if(getPubcontactperson1().length()>40){
			addActionError("Contact Person 1 can not exceed 40 character");
			isValid = Boolean.FALSE;
		}
		if(getPubcontactperson2().length()>40){
			addActionError("Contact Person 2 can not exceed 40 character");
			isValid = Boolean.FALSE;
		}
		if(getPubcontactperson3().length()>40){
			addActionError("Contact Person 3 can not exceed 40 character");
			isValid = Boolean.FALSE;
		}
		if(getPubotherinfo().length()>500){
			addActionError("Other information can not exceed 500 character");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
}