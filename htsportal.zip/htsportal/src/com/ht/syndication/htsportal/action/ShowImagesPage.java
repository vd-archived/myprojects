package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.JDOMException;
import com.ht.syndication.htsportal.org.jdom.filter.ElementFilter;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;
import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ListObject;
import com.ht.syndication.htsportal.util.Utility;
import com.ht.syndication.htsportal.util.XML_Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ShowImagesPage extends ActionSupport implements SessionAware, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5897386178820450941L;

	private static final Log LOGGER = LogFactory.getLog(ShowImagesPage.class);
	
//	private static final String defaultboost = "{!boost b=recip(ms(NOW,updatedate),3.16e-11,1,1)}";
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	
	private String cat;
	private String event;
	private String event_encoded;
	private String cat_encoded;
	private String webroot;
	private String page;
	private List<ImageVO> images = new ArrayList<ImageVO>();
	private List<ListObject>pageNumberList  = new ArrayList<ListObject>();
	private Map session;
	private UserVO user;
	private String url = Utility.getImageSolrSearchURL(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE));
	private String sourceName;
	private String sourceIntro;
	
	
	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public List<ImageVO> getImages() 
	{
		return images;
	}

	public void setImages(List<ImageVO> images) 
	{
		this.images = images;
	}

	/**
	 * 
	 * @return
	 */
	public String images() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		Boolean isEvent = Boolean.FALSE;
		if(getCat() == null && getEvent() == null)
		{
			setCat("News");
		}
		File sourceFile = null;
		if(getEvent() != null)
		{
			sourceFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("EVENT_INTRO_XML")));
			isEvent = Boolean.TRUE;
		}
		else
		{
			sourceFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("IMAGECATEGORY_INTRO_XML")));
		}
		try
		{
			Document document = null;
			if(sourceFile.exists())
			{
				SAXBuilder builder = new SAXBuilder();
				try
				{
					document = builder.build(sourceFile);
					Element root = document.getRootElement();
					Iterator<Element>sourceNames = root.getDescendants(new ElementFilter("name"));
					while(sourceNames.hasNext())
					{
						Element source = sourceNames.next(); 
						if(isEvent && source.getValue().equals(getEvent()))
						{
							setSourceName(source.getValue());
							setSourceIntro(source.getParentElement().getChild("intro").getTextNormalize());
							break;
						}
						else if(!isEvent && source.getValue().equals(getCat()))
						{
							setSourceName(source.getValue());
							setSourceIntro(source.getParentElement().getChild("intro").getTextNormalize());
							break;
						}
					}
				} catch (JDOMException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				} catch (IOException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(getPage()==null)
		{
			setPage("1");
		}
		Integer imagePerPage = Utility.convertToInteger(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE), 15);
		Integer currentPage = Utility.convertToInteger(getPage(), 1);
		if(currentPage==1)
		{
			setPage("1");
		}
		XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
		String parameter = "&q=*:*";
		if(getEvent()!= null && getEvent().trim().length() > 0)
		{
			parameter = "&q=" + Utility.forcefullyURLEncoded("event:\"" + getEvent()+"\"");
		}
		if(getCat()!= null && getCat().trim().length() > 0)
		{
			parameter = "&q=" + Utility.forcefullyURLEncoded("tags:\"" + getCat()+"\"");
		}

		if(getPage() != null && xmlUtility.isInteger(getPage()) && Integer.parseInt(getPage()) > 0 )
		{
			parameter+="&start="+((Integer.parseInt(getPage())-1) * SOLR_PROFILE_CONFIGURATION_READER.getIntegerProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE));
		}
		else
		{
			parameter+="&start=0";
		}
		HttpServletRequest request = ServletActionContext.getRequest();
		StringBuffer requestPage = getCurrentURLWithParam(request, Boolean.FALSE);
		try
		{
			Document document = xmlUtility.getXMLDocument(new URL(url+parameter));
			processBodyPanel(document.getDescendants(new ElementFilter("doc")));
			if(getPage()!=null && !getPage().trim().equals(""))
			{
				currentPage = Utility.convertToInteger(getPage(), 1);
			}
			Element ele = (Element)document.getDescendants(new ElementFilter("result")).next();
			this.setPageNumberBlock(currentPage, imagePerPage, Utility.convertToInteger(ele.getAttributeValue("numFound"), 0));
		}
		catch(Exception e)
		{
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}
	
	private void setPageNumberBlock(Integer currentPage, Integer imagePerPage, Integer imageSize)
	{
		String[]excludeParams = {"page"};
		String requestedURL = Utility.getRequestedURLWithParameter(ServletActionContext.getRequest(), excludeParams);
		Integer pageCount = (int)Math.ceil(imageSize/(float)(imagePerPage));
		if (pageCount > 1)
		{
			currentPage = currentPage - 5;
			if(currentPage>1)
			{
				if((currentPage + 9)>=pageCount)
				{
					currentPage = pageCount - 10;
				}
				if(currentPage < 1)
				{
					currentPage = 0;
				}
				else
				{
					pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+currentPage, "Previous"));
				}
			}
			else
			{
				currentPage = 0;
			}
			int i = 0;
			for (i = (currentPage+1); i < (currentPage + 11) && i <= pageCount; i++)
			{
				pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "" + i));
			}
			if ( i <= pageCount )
			{
				pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "Next"));
			}
		}
	}
	
	private StringBuffer getCurrentURLWithParam(HttpServletRequest request, Boolean deleteTypeParameter)
	{
		StringBuffer urlPage = request.getRequestURL();
		urlPage.append("?");
		Enumeration pnames = request.getParameterNames();
		while(pnames.hasMoreElements()){
			String key = pnames.nextElement().toString();
			if(!key.equalsIgnoreCase("page")){
				if(!urlPage.toString().endsWith("?")){
					urlPage.append("&");
				}
				if(!deleteTypeParameter==Boolean.TRUE&&(key.equalsIgnoreCase("cat")||key.equalsIgnoreCase("event")))
				{
					try
					{
						urlPage.append(key+"="+URLEncoder.encode(request.getParameter(key), "UTF-8"));
					}catch(Exception e){
						e.printStackTrace();
					}
				}
			}
		}
		return urlPage;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public String getCat() {
		return cat;
	}


	public void setCat(String cat) {
		this.cat = cat;
		try{
			this.cat_encoded = URLEncoder.encode(cat, "UTF-8");
		}
		catch(Exception e)
		{
			this.cat_encoded = URLEncoder.encode(cat);
		}
	}

	public String getCat_encoded() {
		return cat_encoded;
	}

	public List<ListObject> getPageNumberList()
	{
		return this.pageNumberList;
	}

	public void setPageNumberList(List<ListObject> pageNumberList) {
		this.pageNumberList = pageNumberList;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getEvent_encoded() {
		return event_encoded;
	}

	public void setEvent_encoded(String event_encoded) {
		this.event_encoded = event_encoded;
	}

	public void setCat_encoded(String cat_encoded) {
		this.cat_encoded = cat_encoded;
	}
	
	private void processBodyPanel(Iterator iterator)
	{
		while(iterator.hasNext())
		{
			Element doc = (Element)iterator.next();
			ImageFullVO image = new ImageFullVO();
			List<Element>fieldList = doc.getChildren("arr");
			for(Element tempEle: fieldList)
			{
				String fieldName = tempEle.getAttributeValue("name");
				List<ListObject> tempList = new ArrayList<ListObject>();
				List<Element> tempArrEle = tempEle.getChildren();
				if(fieldName.equals("tags"))
				{
					tempList.clear();
					for(Element tempArrRecord: tempArrEle)
					{
						tempList.add(ListObject.Factory.newInstance(null, tempArrRecord.getTextNormalize()));
					}
					image.setTagsDetails(tempList);
				}
			}
			fieldList = doc.getChildren("str");
			for(Element tempEle: fieldList)
			{
				String fieldName = tempEle.getAttributeValue("name");
				if(fieldName.equals("id"))
				{
					image.setId(Utility.convertToInteger(tempEle.getTextNormalize(), -1));
				}
				else if(fieldName.equals("name"))
				{
					image.setName(tempEle.getTextNormalize().replaceAll("\n", " "));
				}
				else if(fieldName.equals("title"))
				{
					image.setTitle(StringEscapeUtils.escapeHtml(tempEle.getTextNormalize()));
				}
				else if(fieldName.equals("details"))
				{
					image.setDetails(StringEscapeUtils.escapeHtml(tempEle.getTextNormalize().replaceAll("\n", " ")));
				}
				else if(fieldName.equals("copyright"))
				{
					image.setCopyright(tempEle.getTextNormalize());
				}
				else if(fieldName.equals("author"))
				{
					image.setAuthor(tempEle.getTextNormalize().replaceAll("\n", " "));
				}
				else if(fieldName.equals("event"))
				{
					image.setEventDetails(ListObject.Factory.newInstance(null, tempEle.getTextNormalize().replaceAll("\n", " ")));
				}
			}
			this.images.add(image);
		}
	}

	public String getSourceName() {
		return sourceName;
	}

	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	public String getSourceIntro() {
		return sourceIntro;
	}

	public void setSourceIntro(String sourceIntro) {
		this.sourceIntro = sourceIntro;
	}
}