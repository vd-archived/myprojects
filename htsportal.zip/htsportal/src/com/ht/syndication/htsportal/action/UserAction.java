package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.UserService;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5830682695919008132L;

	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public String create() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		if (getUname() != null) {
			if (this.validation(Boolean.TRUE)) {
				try {
					UserService userService = ServiceLocator.instance()
							.getUserService();
					UserVO userVO = new UserVO(getUname(), getUpassword(),
							getUfirstName(), getUlastName(), getUemail(),
							getUrole(), getUstatus(), getUpubs());
					userService.saveUser(userVO, getUser().getUsername());
					addActionError("User created successfully...");
				} catch (Exception e) {
					addActionError("Error Found: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		setStatusList(Utility.getAllUserStatus());
		setRoleList(Utility.getAllUserRoleStatus(getUser().getRole()));
		pubList = new ArrayList<PublicationShortVO>();
		pubList.add(new PublicationShortVO(null, null, "Select Publication",
				null));
		pubList.addAll(Arrays.asList(ServiceLocator.instance()
				.getPublicationService().getAllPublicationShort()));
		return SUCCESS;
	}

	public String update() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		UserVO userVO = null;
		if (getUname() != null && getUfirstName() != null) {
			if (this.validation(Boolean.FALSE)) {
				try {
					UserService userService = ServiceLocator.instance()
							.getUserService();
					userVO = new UserVO(getUname(), null, getUfirstName(),
							getUlastName(), getUemail(), getUrole(),
							getUstatus(), null);
					userService.updateUser(userVO, getUser().getUsername());
					addActionError("User updated successfully...");
				} catch (Exception e) {
					addActionError("Error Found: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		if (userVO == null && getUname() != null) {
			userVO = ServiceLocator.instance().getUserService()
					.getUser(getUname());
			setUname(userVO.getUsername());
			setUfirstName(userVO.getFirstName());
			setUlastName(userVO.getLastName());
			setUemail(userVO.getEmail());
			setUstatus(userVO.getStatus());
			setUrole(userVO.getRole());
		}
		setStatusList(Utility.getAllUserStatus());
		setRoleList(Utility.getAllUserRoleStatus(getUser().getRole()));
		pubList = new ArrayList<PublicationShortVO>();
		pubList.add(new PublicationShortVO(null, null, "Select Publication",
				null));
		pubList.addAll(Arrays.asList(ServiceLocator.instance()
				.getPublicationService().getAllPublicationShort()));
		return SUCCESS;
	}

	public String show() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		setUsers(ServiceLocator.instance().getUserService()
				.getAllUsers(getUser().getRole()));
		setStatusList(Utility.getAllUserStatus());
		setRoleList(Utility.getAllUserRoleStatus(getUser().getRole()));
		return SUCCESS;
	}

	private String uname;
	private String upassword;
	private String ufirstName;
	private String ulastName;
	private String uemail;
	private Short ustatus;
	private Short urole;
	private Map<Short, String> statusList;
	private Map<Short, String> roleList;
	private List<PublicationShortVO> pubList;
	private List<String> upubs;
	private List<UserVO> users;

	public List<UserVO> getUsers() {
		return users;
	}

	public void setUsers(List<UserVO> users) {
		this.users = users;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	public String getUfirstName() {
		return ufirstName;
	}

	public void setUfirstName(String ufirstName) {
		this.ufirstName = ufirstName;
	}

	public String getUlastName() {
		return ulastName;
	}

	public void setUlastName(String ulastName) {
		this.ulastName = ulastName;
	}

	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	public Short getUstatus() {
		return ustatus;
	}

	public void setUstatus(Short ustatus) {
		this.ustatus = ustatus;
	}

	public Short getUrole() {
		return urole;
	}

	public void setUrole(Short urole) {
		this.urole = urole;
	}

	public Map<Short, String> getStatusList() {
		return statusList;
	}

	public void setStatusList(Map<Short, String> statusList) {
		this.statusList = statusList;
	}

	public Map<Short, String> getRoleList() {
		return roleList;
	}

	public void setRoleList(Map<Short, String> roleList) {
		this.roleList = roleList;
	}

	public List<PublicationShortVO> getPubList() {
		return pubList;
	}

	public void setPubList(List<PublicationShortVO> pubList) {
		this.pubList = pubList;
	}

	public List<String> getUpubs() {
		return upubs;
	}

	public void setUpubs(List<String> upubs) {
		this.upubs = upubs;
	}

	public Boolean validation(Boolean validateAll) {
		Boolean isValid = Boolean.TRUE;
		if (getUname() == null || getUname().length() > 30) {
			addActionError("User name can not blank and can't exceed 30 character");
			isValid = Boolean.FALSE;
		} else if (getUname().indexOf(" ") != -1) {
			addActionError("User name can not contain space");
			isValid = Boolean.FALSE;
		}
		if (validateAll
				&& (getUpassword() == null || getUpassword().length() > 30)) {
			addActionError("Password can not blank and can't exceed 30 character");
			isValid = Boolean.FALSE;
		}
		if (getUfirstName() == null || getUfirstName().length() > 50) {
			addActionError("First name can not blank and can't exceed 50 character");
			isValid = Boolean.FALSE;
		}
		if (getUlastName() != null && getUlastName().length() > 50) {
			addActionError("Last name can not blank and can't exceed 50 character");
			isValid = Boolean.FALSE;
		}
		if (getUstatus() == null) {
			addActionError("Status can not blank");
			isValid = Boolean.FALSE;
		}
		if (getUrole() == null) {
			addActionError("Role can not blank");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
}
