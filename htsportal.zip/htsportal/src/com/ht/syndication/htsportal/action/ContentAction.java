package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.CategoryService;
import com.ht.syndication.htsportal.service.ContentService;
import com.ht.syndication.htsportal.service.PublicationService;
import com.ht.syndication.htsportal.service.SourceService;
import com.ht.syndication.htsportal.transfer.CategoryVO;
import com.ht.syndication.htsportal.transfer.ContentVO;
import com.ht.syndication.htsportal.transfer.PublicationVO;
import com.ht.syndication.htsportal.transfer.SourceVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ContentAction extends ActionSupport implements SessionAware, Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 6672254020987610405L;
	
	ContentVO[] contents;
	private Map session;
	private Map<String, String> publications, categories, sources;
	private UserVO user;
	private String id, section, headline, news, byline, location, copyright, publication_id, source_id, category_id, uniqueid, contentdate, status;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	
	/**
	 * @return the contents
	 */
	public ContentVO[] getContents() {
		return contents;
	}

	/**
	 * @param contents the contents to set
	 */
	public void setContents(ContentVO[] contents) {
		this.contents = contents;
	}

	/**
	 * @return the session
	 */
	public Map getSession() {
		return session;
	}

	/**
	 * @param session the session to set
	 */
	public void setSession(Map session) {
		this.session = session;
	}

	/**
	 * @return the publications
	 */
	public Map<String, String> getPublications() {
		return publications;
	}

	/**
	 * @param publications the publications to set
	 */
	public void setPublications(Map<String, String> publications) {
		this.publications = publications;
	}

	/**
	 * @return the categories
	 */
	public Map<String, String> getCategories() {
		return categories;
	}

	/**
	 * @param categories the categories to set
	 */
	public void setCategories(Map<String, String> categories) {
		this.categories = categories;
	}

	/**
	 * @return the sources
	 */
	public Map<String, String> getSources() {
		return sources;
	}

	/**
	 * @param sources the sources to set
	 */
	public void setSources(Map<String, String> sources) {
		this.sources = sources;
	}

	/**
	 * @return the user
	 */
	public UserVO getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(UserVO user) {
		this.user = user;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the section
	 */
	public String getSection() {
		return section;
	}

	/**
	 * @param section the section to set
	 */
	public void setSection(String section) {
		this.section = section;
	}

	/**
	 * @return the headline
	 */
	public String getHeadline() {
		return headline;
	}

	/**
	 * @param headline the headline to set
	 */
	public void setHeadline(String headline) {
		this.headline = headline;
	}

	/**
	 * @return the news
	 */
	public String getNews() {
		return news;
	}

	/**
	 * @param news the news to set
	 */
	public void setNews(String news) {
		this.news = news;
	}

	/**
	 * @return the byline
	 */
	public String getByline() {
		return byline;
	}

	/**
	 * @param byline the byline to set
	 */
	public void setByline(String byline) {
		this.byline = byline;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the copyright
	 */
	public String getCopyright() {
		return copyright;
	}

	/**
	 * @param copyright the copyright to set
	 */
	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	/**
	 * @return the publication_id
	 */
	public String getPublication_id() {
		return publication_id;
	}

	/**
	 * @param publication_id the publication_id to set
	 */
	public void setPublication_id(String publication_id) {
		this.publication_id = publication_id;
	}

	/**
	 * @return the source_id
	 */
	public String getSource_id() {
		return source_id;
	}

	/**
	 * @param source_id the source_id to set
	 */
	public void setSource_id(String source_id) {
		this.source_id = source_id;
	}

	/**
	 * @return the category_id
	 */
	public String getCategory_id() {
		return category_id;
	}

	/**
	 * @param category_id the category_id to set
	 */
	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}

	/**
	 * @return the uniqueid
	 */
	public String getUniqueid() {
		return uniqueid;
	}

	/**
	 * @param uniqueid the uniqueid to set
	 */
	public void setUniqueid(String uniqueid) {
		this.uniqueid = uniqueid;
	}

	/**
	 * @return the contentdate
	 */
	public String getContentdate() {
		return contentdate;
	}

	/**
	 * @param contentdate the contentdate to set
	 */
	public void setContentdate(String contentdate) {
		this.contentdate = contentdate;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public String create() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		boolean errorfound = false;
		if(getHeadline()!=null){
			if(getUser()==null){
				addActionError("User need to be login to insert the article");
				errorfound = true;
			}
			if(getHeadline().equals("")){
				addActionError("Headline can not be empty");
				errorfound = true;
			}
			if(getNews().equals("")){
				addActionError("Body text can not be empty");
				errorfound = true;
			}
			if(getLocation().equals("")){
				addActionError("Location can not be empty");
				errorfound = true;
			}
			if(getLocation().equals("")){
				addActionError("Location can not be empty");
				errorfound = true;
			}
			if(getPublication_id().equals("")){
				addActionError("Publication ID can not be empty");
				errorfound = true;
			}
			if(getCategory_id().equals("")){
				addActionError("Category ID can not be empty");
				errorfound = true;
			}
			if(getSource_id().equals("")){
				addActionError("Source ID can not be empty");
				errorfound = true;
			}
			if(getStatus().equals("")){
				addActionError("Status can not be empty");
				errorfound = true;
			}
			if(errorfound){
				return SUCCESS;
			}
			ContentService contentService = ServiceLocator.instance().getContentService();
			String[]cateroies = {getCategory_id()};
			ContentVO contentVO = new ContentVO(getHeadline(), getNews(), getLocation(), getSource_id(), getPublication_id(), cateroies, Short.parseShort(getStatus()));
			contentVO.setByline(getByline());
			contentVO.setSection(getSection());
			contentVO.setCopyright(getCopyright());
			contentVO.setUniqueid(getUniqueid());
			contentVO.setContentdate(Utility.stringToDate(getContentdate(), 0));/*1: for default jquery Date Format*/
			contentService.saveContent(contentVO, getUser().getUsername());
			addActionError("Article feed created successfully...");
		}
		PublicationService publicationsService = ServiceLocator.instance().getPublicationService();
		CategoryService categoryService = ServiceLocator.instance().getCategoryService();
		SourceService sourceService = ServiceLocator.instance().getSourceService();
		
		publications = new HashMap<String,String>();
		categories = new HashMap<String,String>();
		sources = new HashMap<String,String>();
		PublicationVO[]publicationsVO = publicationsService.getAllPublication();
		if(publicationsVO!=null){
			for(PublicationVO publicationVO: publicationsVO){
				publications.put(publicationVO.getId().toString(), publicationVO.getName()+" ["+publicationVO.getId().toString()+"]");
			}
		}
		CategoryVO[]categoriesVO = categoryService.getAllCategory();
		if(categoriesVO!=null){
			for(CategoryVO categoryVO: categoriesVO){
				categories.put(categoryVO.getId().toString(), categoryVO.getName());
			}
		}
		SourceVO[]sourcesVO = sourceService.getAllSource();
		if(sourcesVO!=null){
			for(SourceVO sourceVO: sourcesVO){
				sources.put(sourceVO.getId().toString(), sourceVO.getName());
			}
		}
		return SUCCESS;
	}

	public String show() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		ContentService contentService = ServiceLocator.instance().getContentService();
		setContents(contentService.getAllContent());
		return SUCCESS;
	}

	public String update() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getHeadline() != null) {
			boolean errorfound = false;
			if(getId().equals("")){
				addActionError("ID can not be empty");
				errorfound = true;
			}
			if(getHeadline().equals("")){
				addActionError("Headline can not be empty");
				errorfound = true;
			}
			if(getNews().equals("")){
				addActionError("News can not be empty");
				errorfound = true;
			}
			if(getLocation().equals("")){
				addActionError("Location can not be empty");
				errorfound = true;
			}
			if(getStatus().equals("")){
				addActionError("Status can not be empty");
				errorfound = true;
			}
			if(errorfound){
				return SUCCESS;
			}
			ContentService contentService = ServiceLocator.instance().getContentService();
			String[]cateroies = {getCategory_id()};
			ContentVO contentVO = new ContentVO(Integer.parseInt(getId()), getHeadline(), getNews(), getLocation(), getSource_id(), getPublication_id(), cateroies, Short.parseShort(getStatus()));
			contentVO.setByline(getByline());
			contentVO.setSection(getSection());
			contentVO.setCopyright(getCopyright());
			contentVO.setUniqueid(getUniqueid());
			contentVO.setContentdate(Utility.stringToDate(getContentdate(), 3));/*1: for default update text Date Format*/
			contentService.saveContent(contentVO, getUser().getUsername());
			addActionError("Content '"+getId()+"' updated successfully...");
		}else{
			ContentService contentService = ServiceLocator.instance().getContentService();
			ContentVO content = contentService.getContent(Integer.parseInt(getId()));
			if(content==null){
				addActionError("No Content found for '"+getId()+"'");
			}else{
				this.contents = new ContentVO[1];
				this.contents[0] = content;
			}
			PublicationService publicationsService = ServiceLocator.instance().getPublicationService();
			CategoryService categoryService = ServiceLocator.instance().getCategoryService();
			SourceService sourceService = ServiceLocator.instance().getSourceService();
			
			publications = new HashMap<String,String>();
			categories = new HashMap<String,String>();
			sources = new HashMap<String,String>();
			PublicationVO[]publicationsVO = publicationsService.getAllPublication();
			if(publicationsVO!=null)
			{
				for(PublicationVO publicationVO: publicationsVO)
				{
					publications.put(publicationVO.getId().toString(), publicationVO.getName());
				}
			}
			CategoryVO[]categoriesVO = categoryService.getAllCategory();
			if(categoriesVO!=null)
			{
				for(CategoryVO categoryVO: categoriesVO)
				{
					categories.put(categoryVO.getId().toString(), categoryVO.getName());
				}
			}
			SourceVO[]sourcesVO = sourceService.getAllSource();
			if(sourcesVO!=null)
			{
				for(SourceVO sourceVO: sourcesVO)
				{
					sources.put(sourceVO.getId().toString(), sourceVO.getName());
				}
			}
		}
		return SUCCESS;
	}

	public String delete() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		String[]ids = getId().split(", ");
		ContentService contentService = ServiceLocator.instance().getContentService();
		for(String id: ids){
			contentService.deleteContent(Integer.parseInt(id));
		}
		return show();
	}
}