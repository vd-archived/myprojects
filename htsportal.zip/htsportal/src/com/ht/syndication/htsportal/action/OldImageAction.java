
package com.ht.syndication.htsportal.action;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.OldImageService;
import com.ht.syndication.htsportal.transfer.ImageFileVO;
import com.ht.syndication.htsportal.transfer.ImagecategoryVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ListObject;
import com.opensymphony.xwork2.ActionSupport;

public class OldImageAction extends ActionSupport implements SessionAware, ServletRequestAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -984120650887762336L;
	
	private static final Log LOGGER = LogFactory.getLog(ConfigurationReader.class);
	private HttpServletRequest servletRequest;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot, imagecategory, imagesubcategory;
	private List<ListObject>imagecategories;
	private List<File> uploads = new ArrayList<File>();
    private List<String> uploadFileNames = new ArrayList<String>();
    private List<String> uploadContentTypes = new ArrayList<String>();
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	/**
	 * @return
	 */
	public String uploadimage()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(uploads.size()>0)
		{
			Iterator<File> uploadFileIte = uploads.iterator();
			Iterator<String> uploadTypeIte = uploadContentTypes.iterator();
			Iterator<String> uploadNameIte = uploadFileNames.iterator();
		    while (uploadTypeIte.hasNext()) {
		        File uploadFile = uploadFileIte.next();
		        String uploadType = uploadTypeIte.next();
		        String uploadName = uploadNameIte.next();
		        if(uploadType.startsWith("image"))
		        {
		        	File srcfile = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY));
		        	srcfile = new File(srcfile, imagecategory);
		        	try
		        	{
			        	if(getImagesubcategory()==null || getImagesubcategory().equals(""))
			        		FileUtils.copyFile(uploadFile, new File(srcfile, uploadName), Boolean.TRUE);
			        	else
			        		FileUtils.copyFile(uploadFile, new File(new File(srcfile, getImagesubcategory()), uploadName), Boolean.TRUE);
			        	addActionError("File '"+uploadName+"' copy success...");
		        	}
		        	catch(Exception e)
		        	{
		        		addActionError("File '"+uploadName+"' copy failed...");
		        		LOGGER.error("IMAGE ERROR::File '"+uploadName+"' copy failed...\n"+e.getMessage());
		        		e.printStackTrace();
		        	}
		        }
		        else
		        {
		        	addActionError("File '"+uploadName+"' copy failed, not a type of image...");
		        	LOGGER.error("IMAGE ERROR::File '"+uploadName+"' copy failed, not a type of image...");
		        	/*
		        	File srcfile = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY));
		        	srcfile = new File(srcfile, imagecategory);
		        	try
		        	{
			        	if(getImagesubcategory()==null || getImagesubcategory().equals(""))
			        		FileUtils.copyFile(uploadFile, new File(srcfile, uploadName), Boolean.TRUE);
			        	else
			        		FileUtils.copyFile(uploadFile, new File(new File(srcfile, getImagesubcategory()), uploadName), Boolean.TRUE);
			        	addActionError("File '"+uploadName+"' copy success...");
		        	}
		        	catch(Exception e)
		        	{
		        		LOGGER.error("File '"+uploadName+"' copy failed...\n"+e.getMessage());
		        		addActionError("File '"+uploadName+"' copy failed...");
		        		e.printStackTrace();
		        	}*/
		        }
		    }
		}
		OldImageService oldImageService = ServiceLocator.instance().getOldImageService();
		ImagecategoryVO[]imagecategoryVO = oldImageService.getAllImagecategory();
		setImagecategories(new ArrayList<ListObject>());
		for(ImagecategoryVO icatVO: imagecategoryVO)
		{
			this.imagecategories.add(ListObject.Factory.newInstance(icatVO.getName(), icatVO.getName()));
		}
		this.imagecategories.add(ListObject.Factory.newInstance("homePageCartoons", "Home Page Cartoons"));
		this.imagecategories.add(ListObject.Factory.newInstance("homePageImages", "Home Page Images"));
		return SUCCESS;
	}
	
	/**
	 * @return
	 */
	public String loadimage() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		return SUCCESS;
	}

	public byte[] getCustomImageInBytes(){
		OldImageService oldImageService = ServiceLocator.instance().getOldImageService();
		if(this.validation())
		{
			setImageFileVO(oldImageService.loadImage(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), getCat(), getSubcat(), getFilename()));
			setImageInByte(imageFileVO.getImageBytes());
		}
		return imageInByte;
	}

	public String getCustomContentType() {
		return getImageFileVO().getImageType();
	}

	public String getCustomContentDisposition() {
		return getImageFileVO().getImageName();
	}

	private Map<String, Object> session;
	private UserVO user;
	private String cat;
	private String subcat;
	private String filename;
	private ImageFileVO imageFileVO;
	byte[] imageInByte = null;
	
	public byte[] getImageInByte() {
		return imageInByte;
	}


	public void setImageInByte(byte[] imageInByte) {
		this.imageInByte = imageInByte;
	}


	public ImageFileVO getImageFileVO() {
		return imageFileVO;
	}

	public void setImageFileVO(ImageFileVO imageFileVO) {
		this.imageFileVO = imageFileVO;
	}

	public String getCat() {
		return cat;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}

	public String getSubcat() {
		return subcat;
	}

	public void setSubcat(String subcat) {
		this.subcat = subcat;
	}
	
	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public Map<String, Object> getSession() {
		return session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public List<ListObject> getImagecategories() {
		return imagecategories;
	}
	
	public void setImagecategories(List<ListObject> imagecategories) {
		this.imagecategories = imagecategories;
	}
	
	public String getImagecategory() {
		return imagecategory;
	}
	
	public void setImagecategory(String imagecategory) {
		this.imagecategory = imagecategory;
	}
	
	public List<File> getUpload() {
        return this.uploads;
    }
	
	public void setUpload(List<File> uploads) {
		this.uploads = uploads;
	}
	
	public List<String> getUploadFileName() {
		return uploadFileNames;
	}
	
	public void setUploadFileName(List<String> uploadFileNames) {
		this.uploadFileNames = uploadFileNames;
	}
	
	public List<String> getUploadContentType() {
		return uploadContentTypes;
	}
	
	public void setUploadContentType(List<String> uploadContentTypes) {
		this.uploadContentTypes = uploadContentTypes;
	}
	
	public String getImagesubcategory() {
		return imagesubcategory;
	}

	public void setImagesubcategory(String imagesubcategory) {
		this.imagesubcategory = imagesubcategory;
	}
	/**
	 * 
	 * @return
	 */
	private Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getCat().equals(""))
		{
			addActionError("Category can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getFilename().equals(""))
		{
			addActionError("File name can not be empty");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.servletRequest = request;
 
	}
}