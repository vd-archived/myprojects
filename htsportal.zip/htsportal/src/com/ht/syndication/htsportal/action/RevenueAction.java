package com.ht.syndication.htsportal.action;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.RevenueService;
import com.ht.syndication.htsportal.transfer.ClientVO;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.RevenueVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class RevenueAction extends ActionSupport implements SessionAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9171981498400488848L;

	private String fetchValue(Cell cell, Workbook wb)
	{
		String result = null;
		if(cell != null)
		{
			Object colVal = Utility.getExcelCellValue(cell, wb);
			if(colVal != null)
			{
				result = colVal.toString();
			}
		}
		return result;
	}

	public String monthlyTemplateUpload() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getDate() != null)
		{
			if(this.uploadValidation())
			{
				final Integer START_COLOMN = 2;
				List<RevenueVO>revenues = new ArrayList<RevenueVO>();
				try{
					List<String>columns = new ArrayList<String>();
					InputStream myxls = new FileInputStream(getFileUpload());
					Workbook wb     = new HSSFWorkbook(myxls);
					Sheet workingSheet = wb.getSheetAt(0);
					Row row = workingSheet.getRow(0);
					int i = START_COLOMN;
					String cellValue = null;
					do
					{
						cellValue = fetchValue(row.getCell(i++), wb);
						if(cellValue != null)
						{
							columns.add(cellValue);
						}
					}while(cellValue != null);

					i = 1;
					do
					{
						row = workingSheet.getRow(i++);
						if(row != null)
						{
							String pubName = fetchValue(row.getCell(1), wb);
							if(pubName == null || pubName.trim().equals(""))
							{
								break;
							}
							for(int j = 0; j < columns.size(); j++)
							{
								cellValue = fetchValue(row.getCell(j + START_COLOMN), wb);
								if(cellValue != null && !cellValue.trim().equals(""))
								{
									if(Utility.isDouble(cellValue))
									{
										RevenueVO revenueVO = new RevenueVO(pubName, columns.get(j), Utility.stringToDate(getDate(), 4), Double.parseDouble(cellValue), Short.parseShort("1"));
										revenues.add(revenueVO);
									}
									else
									{
										addActionError("Error invalid amount: pub: " + pubName + " and client: " + columns.get(j) + " on dated: " + getDate());
									}
								}
							}
						}
					}while(row != null);
					revenues = ServiceLocator.instance().getRevenueService().saveBatchRevenue(revenues, getUser().getUsername());
					for(RevenueVO revenueVO: revenues)
					{
						addActionError("Error pub: " + revenueVO.getPublication() + " and client: " + revenueVO.getClient() + " on dated: " +date);
					}

				}catch(Exception e)
				{
					e.printStackTrace();
					addActionError(e.getMessage());
				}
			}
		}
		return SUCCESS;
	}

	public String yearlyTemplateUpload() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getFileUpload() != null)
		{
			final Integer START_COLOMN = 2;
			List<RevenueVO>revenues = new ArrayList<RevenueVO>();
			try{
				List<String>columns = new ArrayList<String>();
				InputStream myxls = new FileInputStream(getFileUpload());
				Workbook wb     = new HSSFWorkbook(myxls);
				Sheet workingSheet = wb.getSheetAt(0);
				Row row = workingSheet.getRow(0);
				int i = START_COLOMN;
				String cellValue = null;
				do
				{
					cellValue = fetchValue(row.getCell(i++), wb);
					if(cellValue != null)
					{
						columns.add(cellValue);
					}
				}while(cellValue != null);

				i = 1;
				do
				{
					row = workingSheet.getRow(i++);
					if(row != null)
					{
						String dataport = fetchValue(row.getCell(0), wb);
						String pubName = fetchValue(row.getCell(1), wb);
						if(pubName == null || pubName.trim().equals("") || dataport == null || dataport.trim().equals(""))
						{
							continue;
						}
						for(int j = 0; j < columns.size(); j++)
						{
							cellValue = fetchValue(row.getCell(j + START_COLOMN), wb);
							if(cellValue != null && !cellValue.trim().equals(""))
							{
								if(Utility.isDouble(cellValue))
								{
									Date date = null;
									if(columns.get(j).indexOf("-") != -1)
									{
										date = Utility.stringToDate(columns.get(j), null);
									}
									else
									{
										date = Utility.stringToDate(columns.get(j), 6);
									}
									RevenueVO revenueVO = new RevenueVO(pubName, dataport, date, Double.parseDouble(cellValue), Short.parseShort("1"));
									revenues.add(revenueVO);
								}
								else
								{
									addActionError("Error invalid amount: pub: " + pubName + " and client: " + dataport + " on dated: " + columns.get(j));
								}
							}
						}
					}
				}while(row != null);
				revenues = ServiceLocator.instance().getRevenueService().saveBatchRevenue(revenues, getUser().getUsername());
				for(RevenueVO revenueVO: revenues)
				{
					addActionError("Error pub: " + revenueVO.getPublication() + " and client: " + revenueVO.getClient() + " on dated: " + revenueVO.getDate());
				}

			}catch(Exception e)
			{
				e.printStackTrace();
				addActionError(e.getMessage());
			}
		}
		return SUCCESS;
	}

	public String monthlyTemplateDownload()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));

		try{
			ClientVO[]clients = ServiceLocator.instance().getClientService().getAllClient();
			PublicationShortVO[]publications = ServiceLocator.instance().getPublicationService().getAllPublicationShort();
			Workbook wb = new HSSFWorkbook();

			CellStyle cellStyle = wb.createCellStyle();
			Font font = wb.createFont();
			font.setFontName(HSSFFont.FONT_ARIAL);
			font.setFontHeightInPoints((short) 11);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
			font.setColor(HSSFColor.BLACK.index);
			cellStyle.setFont(font);

			CellStyle cellStyle1 = wb.createCellStyle();
			Font font1 = wb.createFont();
			font1.setFontName(HSSFFont.FONT_ARIAL);
			font1.setFontHeightInPoints((short) 11);
			font1.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font1.setColor(HSSFColor.DARK_BLUE.index);
			cellStyle1.setFont(font1);
			cellStyle1.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
			cellStyle1.setAlignment(cellStyle1.ALIGN_CENTER);
			cellStyle1.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);


			Sheet workingSheet = wb.createSheet("Revenue");
			Integer rowIndex = 0;
			Integer coloumnIndex = 0;
			Row row = workingSheet.createRow(rowIndex++);
			Cell cell = row.createCell(coloumnIndex++);
			cell.setCellStyle(cellStyle1);
			cell.setCellValue("S.No");
			cell = row.createCell(coloumnIndex++);
			cell.setCellStyle(cellStyle1);
			cell.setCellValue("Publication");

			for(ClientVO client: clients)
			{
				cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle1);
				cell.setCellValue(client.getName());
			}
			for(PublicationShortVO publication: publications)
			{
				coloumnIndex = 0;
				row = workingSheet.createRow(rowIndex++);
				cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle);
				cell.setCellValue((rowIndex - 1));

				cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(publication.getName());
			}
			workingSheet.autoSizeColumn((short) 1);
			workingSheet.autoSizeColumn((short) 2);
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			wb.write(bos);
			downloadstream = new ByteArrayInputStream(bos.toByteArray());
		}catch(Exception e)
		{

		}
		return SUCCESS;
	}

	public String create() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getPublication() != null  && !getPublication().equals("") && getClients() != null)
		{
			if(this.validation())
			{
				try{
					setStatus(Short.parseShort("1"));
					RevenueService revenueService = ServiceLocator.instance().getRevenueService();
					for(int i=0; i<getClients().size(); i++)
					{
						Integer client = getClients().get(i);
						String amount  = getAmounts().get(i);
						if(!amount.equals(""))
						{
							RevenueVO revenueVO = new RevenueVO(getPublication().toString(), client.toString(), Utility.stringToDate(getDate(), 4), Double.parseDouble(amount), getStatus());
							revenueService.saveRevenue(revenueVO, getUser().getUsername());
						}
					}
					addActionError("Revenue create/update successfully...");
				}
				catch(Exception e)
				{
					addActionError("Error Found: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		pubList = new ArrayList<PublicationShortVO>();
		pubList.add(new PublicationShortVO(null, null, "Select Publication", null));
		pubList.addAll(Arrays.asList(ServiceLocator.instance().getPublicationService().getAllPublicationShort()));
		if(getPublication() != null && !getPublication().equals(""))
		{
			setClientList(ServiceLocator.instance().getClientService().getClientsByPublication(getPublication()));
		}
		return SUCCESS;
	}

	public String getclient()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getId() != null)
		{
			setClientList(ServiceLocator.instance().getClientService().getClientsByPublication(getId()));
		}
		return SUCCESS;
	}

	/*	public String show() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setRevenues(Arrays.asList(ServiceLocator.instance().getRevenueService().getAllRevenue()));
		setStatusList(Utility.getAllUserStatus());
		fillMaps(true, true);
		for(int i = 0; i < revenues.size(); i++)
		{
			revenues.get(i).setPublication(publicationMap.get(Integer.parseInt(revenues.get(i).getPublication())));
			revenues.get(i).setClient(clientMap.get(Integer.parseInt(revenues.get(i).getClient())));
		}
		return SUCCESS;
	}*/

	private void fillMaps(Boolean fillPublication, Boolean fillClient)
	{
		if(fillPublication)
		{
			publicationMap = new HashMap<Integer, String>();
			publicationMap.put(null, "Select Publication");
			for(PublicationShortVO temp: ServiceLocator.instance().getPublicationService().getAllPublicationShort())
			{
				publicationMap.put(temp.getId(), temp.getName());
			}
		}
		if(fillClient)
		{
			clientMap = new HashMap<Integer, String>();
			clientMap.put(null, "Select Client");
			for(ClientVO temp: ServiceLocator.instance().getClientService().getAllClient())
			{
				clientMap.put(temp.getId(), temp.getName());
			}
		}
	}

	private Integer id;
	private Integer publication;
	private List<Integer> clients;
	private String date;
	private List<String> amounts;
	private Short status;
	private InputStream downloadstream;

	private Map<Short, String> statusList;
	private Map<Integer, String> publicationMap;
	private Map<Integer, String> clientMap;
	private List<PublicationShortVO> pubList;
	private List<ClientVO> clientList;

	private File fileUpload;
	private String fileUploadContentType;
	private String fileUploadFileName;

	public File getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}

	public String getFileUploadContentType() {
		return fileUploadContentType;
	}

	public void setFileUploadContentType(String fileUploadContentType) {
		this.fileUploadContentType = fileUploadContentType;
	}

	public String getFileUploadFileName() {
		return fileUploadFileName;
	}

	public void setFileUploadFileName(String fileUploadFileName) {
		this.fileUploadFileName = fileUploadFileName;
	}

	public InputStream getDownloadstream() {
		return downloadstream;
	}

	public void setDownloadstream(InputStream downloadstream) {
		this.downloadstream = downloadstream;
	}

	private List<RevenueVO>revenues;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPublication() {
		return publication;
	}

	public void setPublication(Integer publication) {
		this.publication = publication;
	}

	public List<Integer> getClients() {
		return clients;
	}

	public void setClients(List<Integer> clients) {
		this.clients = clients;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<String> getAmounts() {
		return amounts;
	}

	public void setAmounts(List<String> amounts) {
		this.amounts = amounts;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Map<Short, String> getStatusList() {
		return statusList;
	}

	public void setStatusList(Map<Short, String> statusList) {
		this.statusList = statusList;
	}

	public List<PublicationShortVO> getPubList() {
		return pubList;
	}

	public void setPubList(List<PublicationShortVO> pubList) {
		this.pubList = pubList;
	}

	public List<ClientVO> getClientList() {
		return clientList;
	}

	public void setClientList(List<ClientVO> clientList) {
		this.clientList = clientList;
	}

	public List<RevenueVO> getRevenues() {
		return this.revenues;
	}

	public void setRevenues(List<RevenueVO> revenues) {
		this.revenues = revenues;
	}

	public Map<Integer, String> getPublicationMap() {
		return publicationMap;
	}

	public void setPublicationMap(Map<Integer, String> publicationMap) {
		this.publicationMap = publicationMap;
	}

	public Map<Integer, String> getClientMap() {
		return clientMap;
	}

	public void setClientMap(Map<Integer, String> clientMap) {
		this.clientMap = clientMap;
	}

	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	public Map getSession() {
		return session;
	}
	public void setSession(Map session) {
		this.session = session;
	}
	public UserVO getUser() {
		return user;
	}
	public void setUser(UserVO user) {
		this.user = user;
	}

	public Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getPublication() == null)
		{
			addActionError("Publication can not blank");
			isValid = Boolean.FALSE;
		}
		if(getClients() == null)
		{
			addActionError("Client can not blank and must be numeric");
			isValid = Boolean.FALSE;
		}
		if(getDate() == null || Utility.stringToDate(getDate(), 4, Boolean.TRUE) == null)
		{
			addActionError("Date can not blank and must be MMM yyyy");
			isValid = Boolean.FALSE;
		}
		if(getAmounts() == null)
		{
			addActionError("Amount can not blank and must be number");
			isValid = Boolean.FALSE;
		}
		if(getAmounts() != null)
		{
			for(String amount: getAmounts())
			{
				if(!amount.trim().equals("") && !Utility.isDouble(amount))
				{
					addActionError("Amount can not blank and must be number");
					isValid = Boolean.FALSE;
					break;
				}
			}
		}
		return isValid;
	}

	public Boolean uploadValidation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getFileUpload() == null)
		{
			addActionError("Excel file can not blank");
			isValid = Boolean.FALSE;
		}
		else if(!(getFileUploadContentType().equalsIgnoreCase(".csv") || getFileUploadContentType().equalsIgnoreCase("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") || getFileUploadContentType().equalsIgnoreCase("application/vnd.ms-excel")))
		{
			addActionError("File type must be a excel");
			isValid = Boolean.FALSE;
		}
		if(getDate() == null || getDate().isEmpty())
		{
			addActionError("Date can not blank");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
}