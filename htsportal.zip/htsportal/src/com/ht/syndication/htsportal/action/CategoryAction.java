package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.CategoryVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class CategoryAction extends ActionSupport implements SessionAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5764939261513976389L;

	CategoryVO[] categorys;
	private Map session;
	private UserVO user;
	private String  categoryName, categoryDetails, categorystatus,categoryOldName;
	Integer categoryID;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	

	
	
	/**
	 * @return the categoryID
	 */
	public Integer getCategoryID() {
		return categoryID;
	}

	/**
	 * @param categoryID the categoryID to set
	 */
	public void setCategoryID(Integer categoryID) {
		this.categoryID = categoryID;
	}

	/**
	 * @return the categoryName
	 */
	public String getCategoryName() {
		return categoryName;
	}

	/**
	 * @param categoryName the categoryName to set
	 */
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	/**
	 * @return the categoryDetails
	 */
	public String getCategoryDetails() {
		return categoryDetails;
	}

	/**
	 * @param categoryDetails the categoryDetails to set
	 */
	public void setCategoryDetails(String categoryDetails) {
		this.categoryDetails = categoryDetails;
	}

	/**
	 * @return the categorystatus
	 */
	public String getCategorystatus() {
		return categorystatus;
	}

	/**
	 * @param categorystatus the categorystatus to set
	 */
	public void setCategorystatus(String categorystatus) {
		this.categorystatus = categorystatus;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public CategoryVO[] getCategorys() {
		return categorys;
	}

	public void setCategorys(CategoryVO[] categorys) {
		this.categorys = categorys;
	}
	
	public String getCategoryOldName() 
	{
		return categoryOldName;
	}

	public void setCategoryOldName(String categoryOldName) 
	{
		this.categoryOldName = categoryOldName;
	}
	


	/**
	 * @return
	 */
	public String create() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getCategoryName() != null) 
		{
			if(this.validation())
			{
				CategoryVO categoryVO = ServiceLocator.instance().getCategoryService().saveCategory(new CategoryVO(getCategoryID(),getCategoryName(), getCategoryDetails(), Short.parseShort(getCategorystatus())), getUser().getUsername());
				addActionError("Category '"+getCategoryName()+"' created successfully...");
				Utility.resetContentCategory();
				/*Utility.saveIntroductionXML(HTSPortal.XMLFile.CATEGORY, categoryVO.getId(), categoryVO.getName(), categoryVO.getDetails(), categoryVO.getStatus(), null, null);
				Utility.saveMenu(HTSPortal.XMLFile.CATEGORY, "", categoryVO.getName(), categoryVO.getStatus(), null, null);*/
			}
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	public String show() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setCategorys(ServiceLocator.instance().getCategoryService().getAllCategory());
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	public String update() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		CategoryVO categoryVO = null;
		if (getCategoryID() != null)
		{
			categoryVO = ServiceLocator.instance().getCategoryService().getCategory(getCategoryID());
			if (getCategorystatus() != null) 
			{
				if(this.validation())
				{
					String oldName = categoryVO.getName();
					categoryVO.setName(getCategoryName());
					categoryVO.setDetails(getCategoryDetails());
					categoryVO.setStatus(Short.parseShort(getCategorystatus()));
					categoryVO = ServiceLocator.instance().getCategoryService().saveCategory(categoryVO, getUser().getUsername());
					categoryVO.setOldName(oldName);
					addActionError("Category '" + categoryVO.getName() + "' updated successfully...");
					Utility.resetContentCategory();
					/*Utility.saveIntroductionXML(HTSPortal.XMLFile.CATEGORY, categoryVO.getId(), categoryVO.getName(), categoryVO.getDetails(), categoryVO.getStatus(), null, null);
					Utility.saveMenu(HTSPortal.XMLFile.CATEGORY, categoryVO.getOldName(), categoryVO.getName(), categoryVO.getStatus(), null, null);*/
				}
			}
		}
		else
		{
			addActionError("No Category found for updation");
		}
		if(categoryVO==null)
		{
			addActionError("No Category found for '"+getCategoryName()+"'");
		}
		else
		{
			this.categorys = new CategoryVO[1];
			this.categorys[0] = categoryVO;
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	public String delete() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		ServiceLocator.instance().getCategoryService().deleteCategory(getCategoryID());
		Utility.resetContentCategory();
		return show();
	}


	/**
	 * 
	 * @return
	 */
	private Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getCategoryName().equals(""))
		{
			addActionError("Name can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getCategorystatus().equals(""))
		{
			addActionError("Status can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getCategoryName().length()>45)
		{
			addActionError("Name can not exceed 45 character");
			isValid = Boolean.FALSE;
		}
		if(getCategoryDetails().length()>1000)
		{
			addActionError("Details can not exceed 1000 character");
			isValid = Boolean.FALSE;
		}

		return isValid;
	}
}