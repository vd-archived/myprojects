package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class StaticPage extends ActionSupport implements SessionAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1406328550206149399L;

	private static final Log LOGGER = LogFactory.getLog(StaticPage.class);

	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public String home() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		try {
			File ftlFile = new File(ServletActionContext.getServletContext()
					.getRealPath(
							"/WEB-INF/free_marker/pages/" + getSlug() + ".ftl"));
			if (!ftlFile.exists()) {
				return ERROR;
			}
		} catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
		}
		return SUCCESS;
	}

	private String slug;

	public String getSlug() {
		return slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}
}
