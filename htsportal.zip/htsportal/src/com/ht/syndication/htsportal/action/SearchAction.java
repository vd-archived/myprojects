package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.ORDER;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.FreemarkerUtil;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class SearchAction extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8011627908743572466L;
	
	private static final Log LOGGER = LogFactory.getLog(SearchAction.class);
	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;
	
	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public String articleExclusive() {
		setExclusive("yes");
		setFiltertype("article");
		return search();
	}
	
	public String articleSearch() {
		setFiltertype("article");
		return search();
	}
	
	public String imageSearch() {
		setFiltertype("image");
		return search();
	}
	
	public String search()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(filtertype == null) {
			if(getTags().size() > 0) {
				filtertype = "image";
			}
			else {
				filtertype = "article";
			}
		}
		try
		{
			SolrServer solrServer = null;
			SolrQuery query = new SolrQuery();
			query.setFacet(true);
			StringBuffer queryStr = new StringBuffer();
			if(filtertype.equalsIgnoreCase("article")) {
				solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.URL));
				setRowPerPage(Utility.convertToIntegerWithMinimum(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE), 10));
				queryStr = insertQuery(queryStr, "contentdate:[NOW-" + SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.DISPLAY_CONTENT) + " TO *]");
				query.addFacetField("category");
				query.addFacetField("source");
				query.addFacetField("publication");
				query.addFacetField("byline");
				query.addFacetField("location");
				if(exclusive != null && exclusive.equalsIgnoreCase("yes")) {
					queryStr = insertQuery(queryStr, "exclusive:YES");
				}
				query.addSortField("contentdate", ORDER.desc);
			}
			else {
				solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.URL));
				setRowPerPage(Utility.convertToIntegerWithMinimum(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE), 10));
				queryStr = insertQuery(queryStr, "updatedate:[NOW-" + SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.DISPLAY_CONTENT) + " TO *]");
				query.addFacetField("tags");
				query.addFacetField("event");
				query.addSortField("updatedate", ORDER.desc);
			}
			setPageNumber(Utility.convertToIntegerWithMinimum(getPage(), 1));
			
			if(filterkeyword != null && filterkeyword.length() > 0) {
				queryStr = insertQuery(queryStr, freemarkerUtil.getEncodeParameter(filterkeyword));
/*				query.set("defType", "dismax");
				query.set("qf", "headline_nl^20 text_nl^1");*/
			}
			
			if(queryStr.length() > 0) {
				query.setQuery(queryStr.insert(0, "(").append(")").toString());
			}
			if(filtertype.equalsIgnoreCase("article")) {
				if(category != null && category.size() > 0) {
					StringBuffer categoryFilter = new StringBuffer();
					for(String cat: category) {
						if(!cat.trim().equals("")) {
							categoryFilter = insertOrQuery(categoryFilter, "category:\""+cat+"\"");
						}
					}
					if(categoryFilter.length() > 0)
						query.addFilterQuery(categoryFilter.insert(0, "(").append(")").toString());
				}
				if(publication != null && publication.size() > 0) {
					StringBuffer publicationFilter = new StringBuffer();
					for(String pub: publication) {
						if(!pub.trim().equals("")) {
							publicationFilter = insertOrQuery(publicationFilter, "publication:\""+pub+"\"");
						}
					}
					if(publicationFilter.length() > 0)
						query.addFilterQuery(publicationFilter.insert(0, "(").append(")").toString());
				}
				if(source != null && source.size() > 0) {
					StringBuffer sourceFilter = new StringBuffer();
					for(String src: source) {
						if(!src.trim().equals("")) {
							sourceFilter = insertOrQuery(sourceFilter, "source:\""+src+"\"");
						}
					}
					if(sourceFilter.length() > 0)
						query.addFilterQuery(sourceFilter.insert(0, "(").append(")").toString());
				}
				if(byline != null && byline.size() > 0) {
					StringBuffer bylineFilter = new StringBuffer();
					for(String author: byline) {
						bylineFilter = insertOrQuery(bylineFilter, "byline:\""+author+"\"");
					}
					if(bylineFilter.length() > 0)
						query.addFilterQuery(bylineFilter.insert(0, "(").append(")").toString());
				}
				if(location != null && location.size() > 0) {
					StringBuffer locationFilter = new StringBuffer();
					for(String loc: location) {
						if(!loc.trim().equals("")) {
							locationFilter = insertOrQuery(locationFilter, "location:\""+loc+"\"");
						}
					}
					if(locationFilter.length() > 0)
						query.addFilterQuery(locationFilter.insert(0, "(").append(")").toString());
				}
			} else {
				if(tags != null && tags.size() > 0) {
					StringBuffer tagsFilter = new StringBuffer();
					for(String tag: tags) {
						if(!tag.trim().equals("")) {
							tagsFilter = insertOrQuery(tagsFilter, "tags:\""+tag+"\"");
						}
					}
					if(tagsFilter.length() > 0)
						query.addFilterQuery(tagsFilter.insert(0, "(").append(")").toString());
				}
				if(event != null && event.size() > 0) {
					StringBuffer eventFilter = new StringBuffer();
					for(String eventName: event) {
						if(!eventName.trim().equals("")) {
							eventFilter = insertOrQuery(eventFilter, "event:\""+eventName+"\"");
						}
					}
					if(eventFilter.length() > 0)
						query.addFilterQuery(eventFilter.insert(0, "(").append(")").toString());
				}
			}
			
			query.setStart((getPageNumber()-1)*getRowPerPage());
		    query.setRows(getRowPerPage());
		    if(solrServer != null) {
			    QueryResponse response = solrServer.query(query);
			    setDocuments(response.getResults());
			    setFacetFields(response.getFacetFields());
			    setPagination();
		    }
		    
		} catch (Exception e) {
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return filtertype.toLowerCase();
	}
	
	private void setPagination() {
		List<String>paramList = new ArrayList<String>();
		Map<String, Object>params = ActionContext.getContext().getParameters();
		for(String key: params.keySet()) {
			if(!key.equalsIgnoreCase("page")) {
				Object value = params.get(key);
				if(value instanceof String[]) {
					for(String val: (String[])value) {
						paramList.add(key + "=" + freemarkerUtil.getEncodeParameter(val));
					}
				} else if(value instanceof List) {
					for(Object val: (ArrayList)value) {
						paramList.add(key + "=" + freemarkerUtil.getEncodeParameter(val.toString()));
					}
				} else {
					paramList.add(key + "=" + freemarkerUtil.getEncodeParameter(value.toString()));
				}
			}
		}
		StringBuffer paginationLink = new StringBuffer(getWebroot());
		paginationLink.append(ActionContext.getContext().getName()).append("?").append(StringUtils.join(paramList, "&"));
		
		String currentLink = paginationLink.toString();

		
		Long numberOfPage = (long) Math.ceil(getDocuments().getNumFound() / (double)getRowPerPage());
	    Integer startPage = getPageNumber() - 5;
	    if(startPage < 1) {
	    	startPage = 1;
	    }
	    if(startPage > 1) {
	    	pagination.put("&laquo;&laquo;", currentLink + "&page=1");
	    }
	    if((getPageNumber() - 1) > 0) {
	    	pagination.put("&laquo;", currentLink + "&page=" + (getPageNumber() - 1));
	    }
	    for(int i = startPage; i < (startPage + 10) && i <= numberOfPage; i++) {
	    	pagination.put(i + "", currentLink + "&page=" + i);
	    }
	    if((getPageNumber() + 1) <= numberOfPage) {
	    	pagination.put("&raquo;", currentLink + "&page=" + (getPageNumber() + 1));
	    }
	    if((startPage + 10) < numberOfPage) {
	    	pagination.put("&raquo;&raquo;", currentLink + "&page=" + numberOfPage.toString());
	    }
	}
	
	private StringBuffer insertQuery(StringBuffer query, String queryStr) {
		return insertQuery(query, queryStr, " AND ");
	}
	
	private StringBuffer insertOrQuery(StringBuffer query, String queryStr) {
		return insertQuery(query, queryStr, " OR ");
	}
	
	private StringBuffer insertQuery(StringBuffer query, String queryStr, String seperator) {
		if(query.length() > 0) {
			query.append(seperator);
		}
		query.append(queryStr);
		return query;
	}
	
	private List<String>category = new ArrayList<String>();
	private List<String>source = new ArrayList<String>();
	private List<String>publication = new ArrayList<String>();
	private List<String>byline = new ArrayList<String>();
	private List<String>location = new ArrayList<String>();
	private List<String>tags = new ArrayList<String>();
	private List<String>event = new ArrayList<String>();
	private Map<String, String>pagination = new LinkedHashMap<String, String>();  
	private String filterkeyword;
	private String exclusive;
	private String filtertype;
	private String page;
	private Integer rowPerPage;
	private Integer pageNumber;
	private FreemarkerUtil freemarkerUtil = new FreemarkerUtil();

	private List<FacetField>facetFields = new ArrayList<FacetField>();
	private SolrDocumentList documents = new SolrDocumentList();
	
	
	public SolrDocumentList getDocuments() {
		return documents;
	}

	public void setDocuments(SolrDocumentList documents) {
		this.documents = documents;
	}

	public Integer getRowPerPage() {
		return rowPerPage;
	}

	public void setRowPerPage(Integer rowPerPage) {
		this.rowPerPage = rowPerPage;
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public List<String> getPublication() {
		return publication;
	}

	public void setPublication(List<String> publication) {
		this.publication = publication;
	}

	public List<String> getTags() {
		return tags;
	}

	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	public String getFilterkeyword() {
		return filterkeyword;
	}

	public void setFilterkeyword(String filterkeyword) {
		this.filterkeyword = filterkeyword;
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}

	public List<FacetField> getFacetFields() {
		return facetFields;
	}

	public void setFacetFields(List<FacetField> facetFields) {
		this.facetFields = facetFields;
	}

	public List<String> getCategory() {
		return category;
	}

	public void setCategory(List<String> category) {
		this.category = category;
	}

	public List<String> getSource() {
		return source;
	}

	public void setSource(List<String> source) {
		this.source = source;
	}

	public List<String> getByline() {
		return byline;
	}

	public void setByline(List<String> byline) {
		this.byline = byline;
	}

	public List<String> getLocation() {
		return location;
	}

	public void setLocation(List<String> location) {
		this.location = location;
	}

	public Map<String, String> getPagination() {
		return pagination;
	}

	public void setPagination(Map<String, String> pagination) {
		this.pagination = pagination;
	}

	public FreemarkerUtil getFreemarkerUtil() {
		return freemarkerUtil;
	}

	public void setFreemarkerUtil(FreemarkerUtil freemarkerUtil) {
		this.freemarkerUtil = freemarkerUtil;
	}

	public List<String> getEvent() {
		return event;
	}

	public void setEvent(List<String> event) {
		this.event = event;
	}

	public String getExclusive() {
		return exclusive;
	}

	public void setExclusive(String exclusive) {
		this.exclusive = exclusive;
	}
}
