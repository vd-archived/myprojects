package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.FreemarkerUtil;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class ImageDetail extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8011627908743572466L;
	
	private static final Log LOGGER = LogFactory.getLog(ImageDetail.class);
	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;
	
	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public String execute()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.URL));
			SolrQuery query = new SolrQuery();
			query.setQuery("name:" + name);
			query.setFacet(true);
			query.addFacetField("tags");
			query.addFacetField("event");
		    QueryResponse response = solrServer.query(query);
		    setDocuments(response.getResults());
		    setFacetFields(response.getFacetFields());
		    
		    SolrQuery similar = new SolrQuery();
		    similar.setRows(12);
		    if(getDocuments().getNumFound() > 0) {
		    	SolrDocument doc = getDocuments().get(0);
		    	if(doc.getFieldValue("event") != null) {
		    		String event = "\"" + freemarkerUtil.getEncodeParameter(doc.getFieldValue("event").toString()) + "\"";
		    		setEventName(event);
		    		similar.setQuery("event:" + event);
			    	setSimilarByEvent(solrServer.query(similar).getResults());
		    	}
		    	if(doc.getFieldValue("title") != null) {
		    		String title = freemarkerUtil.getEncodeParameter(doc.getFieldValue("title").toString());
		    		similar.setQuery(title);
			    	setSimilarByTitle(solrServer.query(similar).getResults());
			    	setName(freemarkerUtil.getEncodeParameter(title));
		    	} else if(doc.getFieldValue("details") != null) {
		    		String title = freemarkerUtil.getEncodeParameter(doc.getFieldValue("details").toString());
		    		similar.setQuery(title);
			    	setSimilarByTitle(solrServer.query(similar).getResults());
			    	setName(freemarkerUtil.getEncodeParameter(title));
		    	}
		    }
		} catch (Exception e) {
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}
	
	private FreemarkerUtil freemarkerUtil = new FreemarkerUtil();
	private String name;
	private String title;
	private String eventName;
	private List<FacetField>facetFields = new ArrayList<FacetField>();
	private SolrDocumentList documents = new SolrDocumentList();
	private String filtertype = "image";
	private SolrDocumentList similarByEvent = new SolrDocumentList();
	private SolrDocumentList similarByTitle = new SolrDocumentList();
	
	public SolrDocumentList getDocuments() {
		return documents;
	}

	public void setDocuments(SolrDocumentList documents) {
		this.documents = documents;
	}
	
	public List<FacetField> getFacetFields() {
		return facetFields;
	}

	public void setFacetFields(List<FacetField> facetFields) {
		this.facetFields = facetFields;
	}

	public FreemarkerUtil getFreemarkerUtil() {
		return freemarkerUtil;
	}

	public void setFreemarkerUtil(FreemarkerUtil freemarkerUtil) {
		this.freemarkerUtil = freemarkerUtil;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}

	public SolrDocumentList getSimilarByEvent() {
		return similarByEvent;
	}

	public void setSimilarByEvent(SolrDocumentList similarByEvent) {
		this.similarByEvent = similarByEvent;
	}

	public SolrDocumentList getSimilarByTitle() {
		return similarByTitle;
	}

	public void setSimilarByTitle(SolrDocumentList similarByTitle) {
		this.similarByTitle = similarByTitle;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
}
