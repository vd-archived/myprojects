package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.OldImageVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ListObject;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ShowCartoonPage extends ActionSupport implements SessionAware, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6648526089446616457L;
	
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private String webroot;
	
	private String page;
	private List<OldImageVO> cartoonList = new ArrayList<OldImageVO>();
	private List<ListObject> pageNumberList = new ArrayList<ListObject>();
	private Map session;
	private UserVO user;
	
	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public List<OldImageVO> getCartoonList() 
	{
		return cartoonList;
	}

	public void setCartoonList(List<OldImageVO> cartoonList) 
	{
		this.cartoonList = cartoonList;
	}

	/**
	 * 
	 * @return
	 */
	public String cartoon() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getPage()==null)
		{
			setPage("1");
		}
		Integer imagePerPage = Utility.convertToInteger(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE), 15);
		Integer currentPage = Utility.convertToInteger(getPage(), 1);
		if(currentPage==1)
		{
			setPage("1");
		}
		File imageDir = new File(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.IMAGE.IMAGEDIRECTORY), "Cartoon");
		imageDir = new File(imageDir, "THUMB");
		
		File[]images = imageDir.listFiles();
		if(images != null)
		{
			Arrays.sort(images, new Comparator<File>()
					{
					    public int compare(File o1, File o2)
					    {
					        if (o1.lastModified() > o2.lastModified())
					        {
					            return -1;
					        }
					        else if (o1.lastModified() < o2.lastModified())
					        {
					            return +1;
					        }
					        else
					        {
					            return 0;
					        }
					    }
					});
			Integer startIndex = ((currentPage-1) * imagePerPage);
			for(int i = startIndex; i<images.length && i<(startIndex + imagePerPage); i++)
			{
				cartoonList.add(new OldImageVO(images[i].getName(),StringEscapeUtils.escapeHtml(Utility.getImageCaption(images[i]))));
			}
			this.setPageNumberBlock(ServletActionContext.getRequest(), currentPage, imagePerPage, images.length);
		}
		return SUCCESS;
	}

	public List<ListObject> getPageNumberList() {
		return pageNumberList;
	}

	public void setPageNumberList(List<ListObject> pageNumberList) {
		this.pageNumberList = pageNumberList;
	}
	
	private void setPageNumberBlock(HttpServletRequest request, Integer currentPage, Integer imagePerPage, Integer imageSize)
	{
		String[]excludeParams = {"page"};
		String requestedURL = Utility.getRequestedURLWithParameter(ServletActionContext.getRequest(), excludeParams);
		Integer pageCount = (int)Math.ceil(imageSize/(float)(imagePerPage));
		if (pageCount > 0)
		{
			currentPage = currentPage - 5;
			if(currentPage>1)
			{
				if((currentPage + 9)>=pageCount)
				{
					currentPage = pageCount - 10;
				}
				
				pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+currentPage, "Previous"));
			}
			else
			{
				currentPage = 0;
			}
			int i = 0;
			for (i = (currentPage+1); i < (currentPage + 11) && i <= pageCount; i++)
			{
				pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "" + i));
			}
			if ( i <= pageCount )
			{
				pageNumberList.add(ListObject.Factory.newInstance(requestedURL+"&page="+i, "Next"));
			}
		}
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
}