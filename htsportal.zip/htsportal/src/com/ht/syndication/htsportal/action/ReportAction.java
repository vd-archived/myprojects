package com.ht.syndication.htsportal.action;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.domain.TimeInterval;
import com.ht.syndication.htsportal.service.RevenueService;
import com.ht.syndication.htsportal.transfer.ClientRevenuesVO;
import com.ht.syndication.htsportal.transfer.ClientVO;
import com.ht.syndication.htsportal.transfer.PublicationRevenueVO;
import com.ht.syndication.htsportal.transfer.PublicationShortVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ListObject;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ReportAction extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5615069333369516229L;

	public String revenueshow() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		List<PublicationShortVO> tempPubList = ServiceLocator.instance().getUserService().getAllPublication(getUser().getUsername());
		if(getDate() == null || getDate().isEmpty())
		{
			Date tempDate = new Date();
			setDate(Utility.dateToString(tempDate, 4));
		}
		if(getDate() != null && !getDate().isEmpty())
		{
			pubRevenues = new ArrayList<PublicationRevenueVO>();
			RevenueService revenueService = ServiceLocator.instance().getRevenueService();
			if(getPublication() != null && !getPublication().equals(""))
			{
				pubRevenues.add(revenueService.getRevenueByPublicationDate(getPublication(), Utility.stringToDate(getDate(), 4)));
			}
			else
			{
				List<Integer>pubInts = new ArrayList<Integer>();
				for(PublicationShortVO tempPub: tempPubList)
				{
					pubInts.add(tempPub.getId());
				}
				pubRevenues.addAll(revenueService.getRevenueByPublicationDate(pubInts, Utility.stringToDate(getDate(), 4)));
			}
			for(PublicationRevenueVO temp: pubRevenues)
			{
				for(ClientRevenuesVO temp1: temp.getClients())
				{
					temp1.setName(temp1.getName() + " [" + TimeInterval.intervalName[temp1.getRevenueinterval()] + "]");
				}
			}
		}
		pubList = new ArrayList<PublicationShortVO>();
		pubList.add(new PublicationShortVO(null, null, "All Publication", null));
		pubList.addAll(tempPubList);
		return SUCCESS;
	}

	public String revenuemonthexport()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		List<PublicationShortVO> tempPubList = ServiceLocator.instance().getUserService().getAllPublication(getUser().getUsername());
		if(getDate() == null || getDate().isEmpty())
		{
			Date tempDate = new Date();
			setDate(Utility.dateToString(tempDate, 4));
		}
		if(getDate() != null && !getDate().isEmpty())
		{
			pubRevenues = new ArrayList<PublicationRevenueVO>();
			RevenueService revenueService = ServiceLocator.instance().getRevenueService();
			if(getPublication() != null && !getPublication().equals(""))
			{
				pubRevenues.add(revenueService.getRevenueByPublicationDate(getPublication(), Utility.stringToDate(getDate(), 4)));
			}
			else
			{
				List<Integer>pubInts = new ArrayList<Integer>();
				for(PublicationShortVO tempPub: tempPubList)
				{
					pubInts.add(tempPub.getId());
				}
				pubRevenues.addAll(revenueService.getRevenueByPublicationDate(pubInts, Utility.stringToDate(getDate(), 4)));
			}
		}
		if(pubRevenues.size() > 0)
		{
			try{
				ClientVO[]clients = ServiceLocator.instance().getClientService().getAllClient();
				Workbook wb = new HSSFWorkbook();

				CellStyle cellStyle = wb.createCellStyle();
				Font font = wb.createFont();
				font.setFontName(HSSFFont.FONT_ARIAL);
				font.setFontHeightInPoints((short) 11);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
				font.setColor(HSSFColor.BLACK.index);
				cellStyle.setFillBackgroundColor(HSSFColor.AQUA.index);
				cellStyle.setFont(font);

				CellStyle cellStyle1 = wb.createCellStyle();
				Font font1 = wb.createFont();
				font1.setFontName(HSSFFont.FONT_ARIAL);
				font1.setFontHeightInPoints((short) 11);
				font1.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				font1.setColor(HSSFColor.DARK_BLUE.index);
				cellStyle1.setFont(font1);
				cellStyle1.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
				cellStyle1.setAlignment(cellStyle1.ALIGN_CENTER);
				cellStyle1.setFillBackgroundColor(HSSFColor.BRIGHT_GREEN.index);
				cellStyle1.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
				
				CellStyle cellStyle2 = wb.createCellStyle();
				Font font2 = wb.createFont();
				font2.setFontName(HSSFFont.FONT_ARIAL);
				cellStyle2.setFont(font2);
				cellStyle2.setAlignment(cellStyle1.ALIGN_CENTER);


				Sheet workingSheet = wb.createSheet("Revenue");
				Integer rowIndex = 0;
				Integer coloumnIndex = 0;
				Row row = workingSheet.createRow(rowIndex++);
				Cell cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle1);
				cell.setCellValue("S.No");
				cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle1);
				cell.setCellValue("Publication");
				
				Map<String, Integer>clientMap = new HashMap<String, Integer>();
				for(ClientVO client: clients)
				{
					cell = row.createCell(coloumnIndex++);
					cell.setCellStyle(cellStyle1);
					cell.setCellValue(client.getName() + " [" + TimeInterval.intervalName[client.getRevenueinterval()] + "]");
					clientMap.put(client.getName(), cell.getColumnIndex());
				}
				for(PublicationRevenueVO publicationRevenueVO: pubRevenues)
				{
					coloumnIndex = 0;
					row = workingSheet.createRow(rowIndex++);
					cell = row.createCell(coloumnIndex++);
					cell.setCellStyle(cellStyle);
					cell.setCellValue((rowIndex - 1));

					cell = row.createCell(coloumnIndex++);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(publicationRevenueVO.getName());
					
			        for(ClientRevenuesVO  clientRevenue: publicationRevenueVO.getClients()) {
						Integer colIndex = clientMap.get(clientRevenue.getName());
						cell = row.createCell(colIndex);
						cell.setCellValue(clientRevenue.getRevenue());
						cell.setCellStyle(cellStyle2);
			        }
					cell = row.createCell(clients.length + 2);
					cell.setCellValue(publicationRevenueVO.getSum());
				}
				workingSheet.autoSizeColumn((short) 1);
				workingSheet.autoSizeColumn((short) 2);
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				wb.write(bos);
				downloadstream = new ByteArrayInputStream(bos.toByteArray());
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return SUCCESS;
	}
	
	public String revenueyearexport()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		List<PublicationShortVO> tempPubList = ServiceLocator.instance().getUserService().getAllPublication(getUser().getUsername());
		if(getDate() == null || getDate().isEmpty())
		{
			Date tempDate = new Date();
			setDate(Utility.dateToString(tempDate, 4));
		}
		if(getDate() != null && !getDate().isEmpty())
		{
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(Utility.stringToDate(getDate(), 4));
//			Date startDate = Utility.getFirstDayOfYear(calendar.get(Calendar.YEAR));
			Date startDate = Utility.getLastDayOfYear(calendar.get(Calendar.YEAR) - 1);
			Date endDate = Utility.getLastDayOfYear(calendar.get(Calendar.YEAR));
			pubRevenues = new ArrayList<PublicationRevenueVO>();
			RevenueService revenueService = ServiceLocator.instance().getRevenueService();
			if(getPublication() != null && !getPublication().equals(""))
			{
				pubRevenues.add(revenueService.getRevenueByPublicationDateRange(getPublication(), startDate, endDate));
			}
			else
			{
				List<Integer>pubInts = new ArrayList<Integer>();
				for(PublicationShortVO tempPub: tempPubList)
				{
					pubInts.add(tempPub.getId());
				}
				pubRevenues.addAll(revenueService.getRevenueByPublicationDateRange(pubInts, startDate, endDate));
			}
		}
		if(pubRevenues.size() > 0)
		{
			try{
				final int START_COLOMN = 2;
				Workbook wb = new HSSFWorkbook();
				CreationHelper createHelper = wb.getCreationHelper();
				
				CellStyle cellStyle = wb.createCellStyle();
				Font font = wb.createFont();
				font.setFontName(HSSFFont.FONT_ARIAL);
				font.setFontHeightInPoints((short) 11);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
				font.setColor(HSSFColor.BLACK.index);
				cellStyle.setFillForegroundColor(HSSFColor.AQUA.index);
				cellStyle.setFont(font);

				CellStyle cellStyle1 = wb.createCellStyle();
				Font font1 = wb.createFont();
				font1.setFontName(HSSFFont.FONT_ARIAL);
				font1.setFontHeightInPoints((short) 11);
				font1.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				font1.setColor(HSSFColor.DARK_BLUE.index);
				cellStyle1.setFont(font1);
				cellStyle1.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
				cellStyle1.setAlignment(cellStyle1.ALIGN_CENTER);
				cellStyle1.setFillBackgroundColor(HSSFColor.BRIGHT_GREEN.index);
				
				CellStyle cellStyle2 = wb.createCellStyle();
				Font font2 = wb.createFont();
				font2.setFontName(HSSFFont.FONT_ARIAL);
				cellStyle2.setFont(font2);
				cellStyle2.setAlignment(cellStyle1.ALIGN_CENTER);
				
				CellStyle dateCellStyle = wb.createCellStyle();
				dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MMMM yyyyy"));
				dateCellStyle.setFont(font1);
				dateCellStyle.setFillBackgroundColor(HSSFColor.GREY_25_PERCENT.index);
				dateCellStyle.setAlignment(dateCellStyle.ALIGN_CENTER);
				dateCellStyle.setFillBackgroundColor(HSSFColor.BRIGHT_GREEN.index);

				Sheet workingSheet = wb.createSheet("Revenue");
				Integer rowIndex = 0;
				Integer coloumnIndex = 0;
				Row row = workingSheet.createRow(rowIndex++);
				Cell cell = null;
				/*			cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle1);
				cell.setCellValue("S.No");*/
				cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle1);
				cell.setCellValue("Dataport");
				cell = row.createCell(coloumnIndex++);
				cell.setCellStyle(cellStyle1);
				cell.setCellValue("Publication");

				Calendar calendar = Calendar.getInstance();
				calendar.setTime(new java.util.Date());
				for (int i = 0; i < 12; i++) {
					calendar.set(Calendar.MONTH, i);
					cell = row.createCell(coloumnIndex++);
					cell.setCellValue(calendar.getTime());
					cell.setCellStyle(dateCellStyle);
				}
				for(PublicationRevenueVO pubRevenue: pubRevenues)
				{
					for(ClientRevenuesVO client: pubRevenue.getClients())
					{
						coloumnIndex = 0;
						row = workingSheet.createRow(rowIndex++);
						
						cell = row.createCell(coloumnIndex++);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(client.getName());

						cell = row.createCell(coloumnIndex++);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(pubRevenue.getName());

						for(ListObject valuePair: client.getRevenues())
						{
							calendar.setTime((Date)valuePair.getKey());
							cell = row.createCell(START_COLOMN + calendar.get(Calendar.MONTH));
							cell.setCellStyle(cellStyle2);
							cell.setCellValue((Double)valuePair.getValue());
						}
						if(!client.getRevenueinterval().equals(TimeInterval.MONTHLY))
						{
							for(int i=0; i<client.getRevenueinterval(); i++)
							{
								workingSheet.addMergedRegion(new CellRangeAddress((rowIndex-1), (rowIndex-1), ((12/client.getRevenueinterval()) * i ) + START_COLOMN, ((12/client.getRevenueinterval()) * (i + 1) ) + START_COLOMN - 1));
							}
						}
					}
				}

				workingSheet.autoSizeColumn((short) 1);
				workingSheet.autoSizeColumn((short) 2);
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				wb.write(bos);
				downloadstream = new ByteArrayInputStream(bos.toByteArray());
			}catch(Exception e)
			{

			}
		}
		return SUCCESS;
	}

	private Integer publication;
	private String date;
	private List<PublicationShortVO> pubList;
	private List<PublicationRevenueVO>pubRevenues;
	private InputStream downloadstream;

	public Integer getPublication() {
		return publication;
	}
	public void setPublication(Integer publication) {
		this.publication = publication;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<PublicationShortVO> getPubList() {
		return pubList;
	}
	public void setPubList(List<PublicationShortVO> pubList) {
		this.pubList = pubList;
	}
	public List<PublicationRevenueVO> getPubRevenues() {
		return pubRevenues;
	}
	public void setPubRevenues(List<PublicationRevenueVO> pubRevenues) {
		this.pubRevenues = pubRevenues;
	}
	public InputStream getDownloadstream() {
		return downloadstream;
	}

	public void setDownloadstream(InputStream downloadstream) {
		this.downloadstream = downloadstream;
	}

	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	public Map getSession() {
		return session;
	}
	public void setSession(Map session) {
		this.session = session;
	}
	public UserVO getUser() {
		return user;
	}
	public void setUser(UserVO user) {
		this.user = user;
	}
}