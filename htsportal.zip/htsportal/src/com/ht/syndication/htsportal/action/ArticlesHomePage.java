package com.ht.syndication.htsportal.action;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.util.NamedList;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.JDOMException;
import com.ht.syndication.htsportal.org.jdom.input.SAXBuilder;
import com.ht.syndication.htsportal.transfer.ArticleVO;
import com.ht.syndication.htsportal.transfer.PublicationTab;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.transfer.WidgetPanel;
import com.ht.syndication.htsportal.util.FreemarkerUtil;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ArticlesHomePage extends ActionSupport implements SessionAware, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4460216022479290013L;

	private static final Log LOGGER = LogFactory.getLog(ArticlesHomePage.class);
	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;
	
	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public String home()
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		try
		{
			SolrServer solrServer = new CommonsHttpSolrServer(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.URL));
			File categoryFile = new File(ServletActionContext.getServletContext().getRealPath(HTSPortal.SERVLETCONTEXT.getProperty("CATEGORY_INTRO_XML")));
			Document document = null;
			if(categoryFile.exists())
			{
				SAXBuilder builder = new SAXBuilder();
				try
				{
					document = builder.build(categoryFile);
					Element root = document.getRootElement();
					List categories = root.getChildren("category");
					for (int i = 0; i < categories.size(); i++) 
					{
						Element row = (Element) categories.get(i);
						String categoryName = row.getChildText("name");
						String categoryStatus = row.getChildText("status");
						if(categoryStatus.equals("1")) {
							WidgetPanel panel = new WidgetPanel();
							panel.setHeadline(categoryName);
	
							SolrQuery query = new SolrQuery();
						    query.setQuery("category:\"" + categoryName.trim() + "\" AND contentdate:[NOW-" + SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.DISPLAY_CONTENT) + " TO *]");
						    query.setStart(0);
						    query.setRows(4);
						    query.set("group", true);
						    query.set("group.field", "publication");
						    query.set("group.limit", 10);
	//					    query.addFilterQuery("category:electronics","store:amazon.com");
	//					    query.setFields("id","price","merchant","cat","store");
						    
						    QueryResponse response = solrServer.query(query);
						    NamedList respNL = response.getResponse();
							NamedList groupInfo = (NamedList) respNL.get("grouped"); 
							NamedList thisGroupInfo = (NamedList) groupInfo.get("publication"); 
	//						Number totalUngrouped = (Number) thisGroupInfo.get("matches"); 
	//						long totalNumberOfUngroupedDocuments = totalUngrouped.longValue(); 
							List<Object> groupData = (List<Object>) thisGroupInfo.get("groups"); 
							int numberOfGroupsReturnedOnThisPage = groupData.size();
							for(Object o : groupData) {
								
						        NamedList thisGroup = (NamedList) o;
						        String groupName = (String)thisGroup.get("groupValue");
						        SolrDocumentList sdl = (SolrDocumentList) thisGroup.get("doclist"); 
	//						        long totalDocsInThisGroup = sdl.getNumFound(); 
	//						        int totalDocsReturnedForThisGroup = sdl.size(); 
	//						        SolrDocument groupedDoc = sdl.get(0);
						        PublicationTab pubTab = new PublicationTab();
						        pubTab.setName(groupName);
						        if(groupName.length()>10 && groupData.size() > 3) {
						        	pubTab.setShortname(groupName.substring(0, 10) + "...");
						        }
						        else {
						        	pubTab.setShortname(groupName);
						        }
						        pubTab.setId(groupName.hashCode());
						        
						        for(SolrDocument groupedDoc : sdl) {
						        	ArticleVO articleVO = new ArticleVO();
						        	articleVO.setId(Utility.convertToInteger(groupedDoc.getFieldValue("id").toString(), 1));
						        	articleVO.setHeadline(groupedDoc.getFieldValue("headline").toString());
						        	for(Object news: groupedDoc.getFieldValues("news")) {
						        		if(news.toString().length()>110) {
						        			articleVO.getNews().add(news.toString().substring(0, 110) + "...");
								        }
								        else {
								        	articleVO.getNews().add(news.toString());
								        }
						        	}
						        	articleVO.setPublication(groupedDoc.getFieldValue("publication").toString());
						        	articleVO.setSource(groupedDoc.getFieldValue("source").toString());
						        	for(Object category: groupedDoc.getFieldValues("category")) {
						        		articleVO.getCategory().add(category.toString());
						        	}
						        	articleVO.setId(Utility.convertToInteger(groupedDoc.getFieldValue("id").toString(), 0));
						        	articleVO.setLocation(groupedDoc.getFieldValue("location").toString());
						        	pubTab.getArticles().add(articleVO);
						        }
						        if(pubTab.getArticles().size() > 0) {
						        	panel.getPublicationTabs().add(pubTab);
						        }
							}
							if(panel.getPublicationTabs().size() > 0) {
								getWidgetPanels().add(panel);
							}
						}
					}
				} catch (JDOMException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				} catch (IOException e) {
					LOGGER.error("ERROR: "+e.getMessage());
				}
			}
		}
		catch(Exception e)
		{
			LOGGER.error("ERROR: "+e.getMessage());
		}
		return SUCCESS;
	}
	
	private FreemarkerUtil freemarkerUtil = new FreemarkerUtil();
	private List<WidgetPanel>widgetPanels = new ArrayList<WidgetPanel>();

	public List<WidgetPanel> getWidgetPanels() {
		return widgetPanels;
	}

	public void setWidgetPanels(List<WidgetPanel> widgetPanels) {
		this.widgetPanels = widgetPanels;
	}

	public FreemarkerUtil getFreemarkerUtil() {
		return freemarkerUtil;
	}

	public void setFreemarkerUtil(FreemarkerUtil freemarkerUtil) {
		this.freemarkerUtil = freemarkerUtil;
	}
}
