package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.SourceVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class SourceAction extends ActionSupport implements SessionAware,
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9112736095823353438L;
	private Map session;
	private UserVO user;
	private String webroot;
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory
			.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	Properties property = HTSPortal.SERVLETCONTEXT;

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	SourceVO[] sources;
	private String sourceName, sourceDetails, sourcestatus, sourceOldName;
	private Integer sourceID;

	public String getSourceOldName() {
		return sourceOldName;
	}

	public void setSourceOldName(String sourceOldName) {
		this.sourceOldName = sourceOldName;
	}

	/**
	 * @return the sourceID
	 */
	public Integer getSourceID() {
		return sourceID;
	}

	/**
	 * @param sourceID
	 *            the sourceID to set
	 */
	public void setSourceID(Integer sourceID) {
		this.sourceID = sourceID;
	}

	/**
	 * @return the sourceName
	 */
	public String getSourceName() {
		return sourceName;
	}

	/**
	 * @param sourceName
	 *            the sourceName to set
	 */
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	/**
	 * @return the sourceDetails
	 */
	public String getSourceDetails() {
		return sourceDetails;
	}

	/**
	 * @param sourceDetails
	 *            the sourceDetails to set
	 */
	public void setSourceDetails(String sourceDetails) {
		this.sourceDetails = sourceDetails;
	}

	/**
	 * @return the sourcestatus
	 */
	public String getSourcestatus() {
		return sourcestatus;
	}

	/**
	 * @param sourcestatus
	 *            the sourcestatus to set
	 */
	public void setSourcestatus(String sourcestatus) {
		this.sourcestatus = sourcestatus;
	}

	public SourceVO[] getSources() {
		return sources;
	}

	public void setSources(SourceVO[] sources) {
		this.sources = sources;
	}

	/**
	 * @return
	 */

	public String create() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		if (getSourceName() != null) {
			if (validation()) {
				SourceVO sourceVO = ServiceLocator
						.instance()
						.getSourceService()
						.saveSource(
								new SourceVO(getSourceID(), getSourceName(),
										getSourceDetails(),
										Short.parseShort(getSourcestatus())),
								getUser().getUsername());
				addActionError("Source '" + getSourceName()
						+ "' created successfully...");
				Utility.resetContentSource();
				// Utility.saveIntroductionXML(HTSPortal.XMLFile.SOURCE,
				// sourceVO.getId(), sourceVO.getName(), sourceVO.getDetails(),
				// sourceVO.getStatus(), null, null);
				// Utility.saveMenu(HTSPortal.XMLFile.SOURCE, "",
				// sourceVO.getName(), sourceVO.getStatus(), null, null);
			}
		}
		return SUCCESS;
	}

	public String show() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		setSources(ServiceLocator.instance().getSourceService().getAllSource());
		return SUCCESS;
	}

	public String update() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		SourceVO sourceVO = null;
		if (getSourceID() != null) {
			sourceVO = ServiceLocator.instance().getSourceService()
					.getSource(getSourceID());
			if (getSourcestatus() != null) {
				if (this.validation()) {
					String oldName = sourceVO.getName();
					sourceVO.setName(getSourceName());
					sourceVO.setDetails(getSourceDetails());
					sourceVO.setStatus(Short.parseShort(getSourcestatus()));
					sourceVO = ServiceLocator.instance().getSourceService()
							.saveSource(sourceVO, getUser().getUsername());
					sourceVO.setOldName(oldName);
					addActionError("Source '" + sourceVO.getName()
							+ "' updated successfully...");
					Utility.resetContentSource();
					/*
					 * Utility.saveIntroductionXML(HTSPortal.XMLFile.SOURCE,
					 * sourceVO.getId(), sourceVO.getName(),
					 * sourceVO.getDetails(), sourceVO.getStatus(), null, null);
					 * Utility.saveMenu(HTSPortal.XMLFile.SOURCE,
					 * sourceVO.getOldName(), sourceVO.getName(),
					 * sourceVO.getStatus(), null, null);
					 */
				}
			}
		} else {
			addActionError("No Source found for updation");
		}
		if (sourceVO == null) {
			addActionError("No Source found for '" + getSourceName() + "'");
		} else {
			this.sources = new SourceVO[1];
			this.sources[0] = sourceVO;
		}
		return SUCCESS;
	}

	public String delete() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER
				.getProperty(HTSPortal.LINKURL));
		ServiceLocator.instance().getSourceService()
				.deleteSource(getSourceID());
		Utility.resetContentSource();
		return show();
	}

	/**
	 * 
	 * @return
	 */
	private Boolean validation() {
		Boolean isValid = Boolean.TRUE;
		if (getSourceName().equals("")) {
			addActionError("Name can not be empty");
			isValid = Boolean.FALSE;
		}
		if (getSourcestatus().equals("")) {
			addActionError("Status can not be empty");
			isValid = Boolean.FALSE;
		}
		if (getSourceName().length() > 45) {
			addActionError("Name can not exceed 45 character");
			isValid = Boolean.FALSE;
		}
		if (getSourceDetails().length() > 1000) {
			addActionError("Details can not exceed 1000 character");
			isValid = Boolean.FALSE;
		}

		return isValid;
	}
}