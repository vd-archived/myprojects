package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.filter.ElementFilter;
import com.ht.syndication.htsportal.transfer.ArticleVO;
import com.ht.syndication.htsportal.transfer.ImageFullVO;
import com.ht.syndication.htsportal.transfer.ImageVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.ListObject;
import com.ht.syndication.htsportal.util.Utility;
import com.ht.syndication.htsportal.util.XML_Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ShowArticleImagesPage extends ActionSupport implements SessionAware, Serializable
{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4774982593444087196L;

	private static final Log LOGGER = LogFactory.getLog(ShowArticleImagesPage.class);
	
	private static final ConfigurationReader SOLR_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.SOLR_PROFILE);
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	
	private String webroot;
	private String apage;
	private String ipage;
	private List<ImageVO> images = new ArrayList<ImageVO>();
	private List<ListObject>imagePageNumberList  = new ArrayList<ListObject>();
	private List<ListObject>articlePageNumberList  = new ArrayList<ListObject>();
	private Map session;
	private UserVO user;
	private String image_url   = Utility.getImageSolrSearchURL(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE));
	private String article_url = Utility.getArticleSolrSearchURL(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE));
	private List<ArticleVO> articles = new ArrayList<ArticleVO>();
	private String site_search_string;
	private String site_search_type = "all";
	private String[]excludeParams = {"page"};

	public String getApage() {
		return apage;
	}

	public void setApage(String apage) {
		this.apage = apage;
	}

	public String getIpage() {
		return ipage;
	}

	public void setIpage(String ipage) {
		this.ipage = ipage;
	}

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public List<ImageVO> getImages() 
	{
		return images;
	}

	public void setImages(List<ImageVO> images) 
	{
		this.images = images;
	}

	/**
	 * 
	 * @return
	 */
	public String site_search() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));

		if(getSite_search_string() != null && !getSite_search_string().trim().equals(""))
		{
			XML_Utility xmlUtility = ServiceLocator.instance().getXmlUtilityService();
			
			String imageParameter   = "&q=" + Utility.forcefullyURLEncoded(getSite_search_string());
			String articleParameter = "&q=" + Utility.forcefullyURLEncoded(getSite_search_string());
			
			Integer imagePerPage = Utility.convertToInteger(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Image.ROWS_PER_PAGE), 15);
			Integer articlePerPage = Utility.convertToInteger(SOLR_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Solr.Article.ROWS_PER_PAGE), 15);
			
			String pubStatus = "SHORT_ACCESS";
			Integer imageCurrentPage = Utility.convertToInteger(getIpage(), 1);
			Integer articleCurrentPage = Utility.convertToInteger(getApage(), 1);
			if(imageCurrentPage == 1)
			{
				setIpage("1");
			}
			if(articleCurrentPage == 1)
			{
				setApage("1");
			}
			
			if(imageCurrentPage > 0 )
			{
				imageParameter   += "&start="+((imageCurrentPage-1) * imagePerPage);
			}
			else
			{
				imageParameter   += "&start=0";
			}
			if(articleCurrentPage > 0 )
			{
				articleParameter += "&start="+((articleCurrentPage-1) * articlePerPage);
			}
			else
			{
				articleParameter += "&start=0";
			}
			String requestedURL = Utility.getRequestedURLWithParameter(ServletActionContext.getRequest(), excludeParams);
			if(getSite_search_type().equalsIgnoreCase("all") || getSite_search_type().equalsIgnoreCase("image"))
			{
				try
				{
					Document document = xmlUtility.getXMLDocument(new URL(image_url+imageParameter));
					processBodyPanel(document.getDescendants(new ElementFilter("doc")));
					Element ele = (Element)document.getDescendants(new ElementFilter("result")).next();
					this.setImagePageNumberList(this.setPageNumberBlock(requestedURL, imageCurrentPage, imagePerPage, Utility.convertToInteger(ele.getAttributeValue("numFound"), 0), "ipage"));
				}
				catch(Exception e)
				{
					LOGGER.error("ERROR: "+e.getMessage());
				}
			}
			if(getSite_search_type().equalsIgnoreCase("all") || getSite_search_type().equalsIgnoreCase("article"))
			{
				try
				{
					Document document = xmlUtility.getXMLDocument(new URL(article_url+articleParameter));
					this.setArticles(Utility.getArticlesFromIterator(document.getDescendants(new ElementFilter("doc")), pubStatus));
					Element ele = (Element)document.getDescendants(new ElementFilter("result")).next();
					this.setArticlePageNumberList(this.setPageNumberBlock(requestedURL, articleCurrentPage, articlePerPage, Utility.convertToInteger(ele.getAttributeValue("numFound"), 0), "apage"));
				}
				catch(Exception e)
				{
					LOGGER.error("ERROR: "+e.getMessage());
				}
			}
		}
		return SUCCESS;
	}

	private List<ListObject> setPageNumberBlock(String requestedURL, Integer currentPage, Integer imagePerPage, Integer imageSize, String pageAttr)
	{
		List<ListObject>pageList  = new ArrayList<ListObject>();
		Integer pageCount = (int)Math.ceil(imageSize/(float)(imagePerPage));
		if (pageCount > 1)
		{
			currentPage = currentPage - 5;
			if(currentPage>1)
			{
				if((currentPage + 9)>=pageCount)
				{
					currentPage = pageCount - 10;
				}
				if(currentPage < 1)
				{
					currentPage = 0;
				}
				else
				{
					pageList.add(ListObject.Factory.newInstance(requestedURL+"&"+pageAttr+"="+currentPage, "Previous"));
				}
			}
			else
			{
				currentPage = 0;
			}
			int i = 0;
			for (i = (currentPage+1); i < (currentPage + 11) && i <= pageCount; i++)
			{
				pageList.add(ListObject.Factory.newInstance(requestedURL+"&"+pageAttr+"="+i, "" + i));
			}
			if ( i <= pageCount )
			{
				pageList.add(ListObject.Factory.newInstance(requestedURL+"&"+pageAttr+"="+i, "Next"));
			}
		}
		return pageList;
	}
	
	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}
	
	public List<ListObject> getImagePageNumberList() {
		return imagePageNumberList;
	}

	public void setImagePageNumberList(List<ListObject> imagePageNumberList) {
		this.imagePageNumberList = imagePageNumberList;
	}

	public List<ListObject> getArticlePageNumberList() {
		return articlePageNumberList;
	}

	public void setArticlePageNumberList(List<ListObject> articlePageNumberList) {
		this.articlePageNumberList = articlePageNumberList;
	}

	private void processBodyPanel(Iterator iterator)
	{
		while(iterator.hasNext())
		{
			Element doc = (Element)iterator.next();
			ImageFullVO image = new ImageFullVO();
			List<Element>fieldList = doc.getChildren("arr");
			for(Element tempEle: fieldList)
			{
				String fieldName = tempEle.getAttributeValue("name");
				List<ListObject> tempList = new ArrayList<ListObject>();
				List<Element> tempArrEle = tempEle.getChildren();
				if(fieldName.equals("tags"))
				{
					tempList.clear();
					for(Element tempArrRecord: tempArrEle)
					{
						tempList.add(ListObject.Factory.newInstance(null, tempArrRecord.getTextNormalize()));
					}
					image.setTagsDetails(tempList);
				}
			}
			fieldList = doc.getChildren("str");
			for(Element tempEle: fieldList)
			{
				String fieldName = tempEle.getAttributeValue("name");
				if(fieldName.equals("id"))
				{
					image.setId(Utility.convertToInteger(tempEle.getTextNormalize(), -1));
				}
				else if(fieldName.equals("name"))
				{
					image.setName(tempEle.getTextNormalize().replaceAll("\n", " "));
				}
				else if(fieldName.equals("title"))
				{
					image.setTitle(tempEle.getTextNormalize());
				}
				else if(fieldName.equals("details"))
				{
					image.setDetails(tempEle.getTextNormalize().replaceAll("\n", " "));
				}
				else if(fieldName.equals("copyright"))
				{
					image.setCopyright(tempEle.getTextNormalize());
				}
				else if(fieldName.equals("author"))
				{
					image.setAuthor(tempEle.getTextNormalize().replaceAll("\n", " "));
				}
				else if(fieldName.equals("event"))
				{
					image.setEventDetails(ListObject.Factory.newInstance(null, tempEle.getTextNormalize().replaceAll("\n", " ")));
				}
			}
			this.images.add(image);
		}
	}

	public String getSite_search_string() {
		return site_search_string;
	}

	public void setSite_search_string(String site_search_string) {
		this.site_search_string = site_search_string;
	}

	public String getSite_search_type() {
		return site_search_type;
	}

	public void setSite_search_type(String site_search_type) {
		this.site_search_type = site_search_type;
	}

	public List<ArticleVO> getArticles() {
		return articles;
	}

	public void setArticles(List<ArticleVO> articles) {
		this.articles = articles;
	}
}