package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.transfer.ImagecategoryVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.ht.syndication.htsportal.util.Utility;
import com.opensymphony.xwork2.ActionSupport;

public class ImagecategoryAction extends ActionSupport implements SessionAware, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5764939261513976389L;
	ImagecategoryVO[] imagecategorys;
	private Map session;
	private UserVO user;
	private String  imagecategoryName, imagecategoryDetails, imagecategorystatus, imagecategoryOldName, imagecategoryHighlight, imagecategoryPriority;
	Integer imagecategoryID;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	

	
	
	/**
	 * @return the imagecategoryID
	 */
	public Integer getImagecategoryID() {
		return imagecategoryID;
	}

	/**
	 * @param imagecategoryID the imagecategoryID to set
	 */
	public void setImagecategoryID(Integer imagecategoryID) {
		this.imagecategoryID = imagecategoryID;
	}

	/**
	 * @return the imagecategoryName
	 */
	public String getImagecategoryName() {
		return imagecategoryName;
	}

	/**
	 * @param imagecategoryName the imagecategoryName to set
	 */
	public void setImagecategoryName(String imagecategoryName) {
		this.imagecategoryName = imagecategoryName;
	}

	/**
	 * @return the imagecategoryDetails
	 */
	public String getImagecategoryDetails() {
		return imagecategoryDetails;
	}

	/**
	 * @param imagecategoryDetails the imagecategoryDetails to set
	 */
	public void setImagecategoryDetails(String imagecategoryDetails) {
		this.imagecategoryDetails = imagecategoryDetails;
	}

	/**
	 * @return the imagecategorystatus
	 */
	public String getImagecategorystatus() {
		return imagecategorystatus;
	}

	/**
	 * @param imagecategorystatus the imagecategorystatus to set
	 */
	public void setImagecategorystatus(String imagecategorystatus) {
		this.imagecategorystatus = imagecategorystatus;
	}

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public ImagecategoryVO[] getImagecategorys() {
		return imagecategorys;
	}

	public void setImagecategorys(ImagecategoryVO[] imagecategorys) {
		this.imagecategorys = imagecategorys;
	}
	
	public String getImagecategoryOldName() 
	{
		return imagecategoryOldName;
	}

	public void setImagecategoryOldName(String imagecategoryOldName) 
	{
		this.imagecategoryOldName = imagecategoryOldName;
	}
	
	public String getImagecategoryHighlight() {
		return imagecategoryHighlight;
	}
	
	public void setImagecategoryHighlight(String imagecategoryHighlight) {
		this.imagecategoryHighlight = imagecategoryHighlight;
	}
	
	public String getImagecategoryPriority() {
		return imagecategoryPriority;
	}
	
	public void setImagecategoryPriority(String imagecategoryPriority) {
		this.imagecategoryPriority = imagecategoryPriority;
	}
	/**
	 * @return
	 */
	public String create() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getImagecategoryName() != null) 
		{
			if(this.validation())
			{
				ImagecategoryVO imagecategoryVO = ServiceLocator.instance().getOldImageService().saveImagecategory(new ImagecategoryVO(getImagecategoryID(),getImagecategoryName(), getImagecategoryDetails(), Short.parseShort(getImagecategorystatus()), Short.parseShort(getImagecategoryHighlight()), Integer.parseInt(getImagecategoryPriority())), getUser().getUsername());
				addActionError("Imagecategory '"+getImagecategoryName()+"' created successfully...");
			}
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	public String show() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		setImagecategorys(ServiceLocator.instance().getOldImageService().getAllImagecategory());
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	public String update() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (getImagecategorystatus() != null) 
		{
			if(this.validation())
			{
				ImagecategoryVO imagecategoryVO = ServiceLocator.instance().getOldImageService().saveImagecategory(new ImagecategoryVO(getImagecategoryID(),getImagecategoryName(), getImagecategoryDetails(), Short.parseShort(getImagecategorystatus()), Short.parseShort(getImagecategoryHighlight()), Integer.parseInt(getImagecategoryPriority())), getUser().getUsername());
				addActionError("Imagecategory '"+getImagecategoryName()+"' updated successfully...");
			}
		}
		if (getImagecategoryID() != null)
		{
			ImagecategoryVO imagecategory = ServiceLocator.instance().getOldImageService().getImagecategory(getImagecategoryID());
			if(imagecategory==null)
			{
				addActionError("No Imagecategory found for '"+getImagecategoryName()+"'");
			}
			else
			{
				this.imagecategorys = new ImagecategoryVO[1];
				this.imagecategorys[0] = imagecategory;
			}
		}
		else
		{
			addActionError("No image category found for updation");
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 */
	public String delete() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		ImagecategoryVO imagecategoryVO = ServiceLocator.instance().getOldImageService().deleteImagecategory(getImagecategoryID());
//		Utility.deleteIntroductionXML(HTSPortal.XMLFile.IMAGE, imagecategoryVO.getId());
//		Utility.deleteMenu(HTSPortal.XMLFile.IMAGE, imagecategoryVO.getName());
		return show();
	}


	/**
	 * 
	 * @return
	 */
	private Boolean validation()
	{
		Boolean isValid = Boolean.TRUE;
		if(getImagecategoryName().equals(""))
		{
			addActionError("Name can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getImagecategorystatus().equals(""))
		{
			addActionError("Status can not be empty");
			isValid = Boolean.FALSE;
		}
		if(getImagecategoryName().length()>45)
		{
			addActionError("Name can not exceed 45 character");
			isValid = Boolean.FALSE;
		}
		if(getImagecategoryDetails().length()>1000)
		{
			addActionError("Details can not exceed 1000 character");
			isValid = Boolean.FALSE;
		}
		
		if(!Utility.isNumeric(getImagecategoryPriority()))
		{
			addActionError("Priority should be numeric value");
			isValid = Boolean.FALSE;
		}
		return isValid;
	}
}