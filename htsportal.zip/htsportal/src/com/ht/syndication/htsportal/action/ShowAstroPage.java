package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.org.jdom.Document;
import com.ht.syndication.htsportal.org.jdom.Element;
import com.ht.syndication.htsportal.org.jdom.filter.ElementFilter;
import com.ht.syndication.htsportal.transfer.AstroVO;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class ShowAstroPage extends ActionSupport implements SessionAware, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5782967061155989513L;
	
	private Map session;
	private UserVO user;
	private String webroot;
	private List<AstroVO> astros;

	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private static final Log LOGGER = LogFactory.getLog(ShowAstroPage.class);

	public Map getSession() {
		return session;
	}

	public void setSession(Map session) {
		this.session = session;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	public String getWebroot() {
		return webroot;
	}

	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}

	public List<AstroVO> getAstros() {
		return astros;
	}

	public void setAstros(List<AstroVO> astros) {
		this.astros = astros;
	}

	public String astro() 
	{
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		try{
			setAstros(new ArrayList<AstroVO>());
			Document document = ServiceLocator.instance().getXmlUtilityService().getXMLDocument(new URL(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Astro.GANESHA)));
			if(document != null)
			{
				Iterator iterator = document.getDescendants(new ElementFilter("item"));
				while(iterator.hasNext())
				{
					AstroVO astro = new AstroVO();
					Element item = (Element)iterator.next();
					astro.setId(item.getChild("article_id").getTextNormalize());
					astro.setTitle(item.getChild("title").getTextNormalize());
					astro.setTimestamp(item.getChild("timestamp").getTextNormalize());
					astro.setProvider(item.getChild("provider").getTextNormalize());
					astro.setThumburl(item.getChild("thumburl").getTextNormalize());
					astro.setToday(item.getChild("today").getTextNormalize());
					astro.setThisweek(item.getChild("thisweek").getTextNormalize());
					astro.setThismonth(item.getChild("thismonth").getTextNormalize());
					astro.setThisyear(item.getChild("thisyear").getTextNormalize());
					getAstros().add(astro);
				}
			}
		}catch(Exception e)
		{
			LOGGER.error("Connection Error: URL:" + APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.Astro.GANESHA));
		}
		return SUCCESS;
	}
}
