package com.ht.syndication.htsportal.action;

import java.io.Serializable;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.domain.RoleStatus;
import com.ht.syndication.htsportal.transfer.UserVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class ShowLoginPage extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5935086608020469826L;
	private Map<String, Object> session;
	private UserVO user;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	
	/**
	 * @return
	 */
	public String execute() {
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if (user == null) 
		{
			return SUCCESS;
		}
		else if(user.getRole().equals(RoleStatus.SITE_ADMIN))
		{
			return "ADMIN";
		}
		else if(user.getRole().equals(RoleStatus.GRAPHICS_ADMIN))
		{
			return "GRAPHIC";
		}
		else if(user.getRole().equals(RoleStatus.CONTENT_ADMIN))
		{
			return "CONTENT";
		}
		else if(user.getRole().equals(RoleStatus.VENDOR))
		{
			return "VENDOR";
		}
		else if(user.getRole().equals(RoleStatus.REVENUEADMIN))
		{
			return "REVENUE";
		}
		else if(user.getRole().equals(RoleStatus.CLIENT))
		{
			return "CLIENT";
		}
		else if(user.getRole().equals(RoleStatus.VISITORS))
		{
			return "VISITOR";
		}
		else
		{
			return "USER";
		}
	}

	public String logout()
	{
		String result = SUCCESS;
		setUser((UserVO) getSession().get(HTSPortal.UserConst));
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getUser().getRole().equals(RoleStatus.VENDOR))
		{
			result = "VENDORSUCCESS";
		}
		session.remove(HTSPortal.UserConst);
		return result;
	}

	/**
	 * @return the session
	 */
	public Map<String, Object> getSession() {
		return session;
	}

	/**
	 * @param session the session to set
	 */
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	public UserVO getUser() {
		return user;
	}
	public void setUser(UserVO user) {
		this.user = user;
	}
}