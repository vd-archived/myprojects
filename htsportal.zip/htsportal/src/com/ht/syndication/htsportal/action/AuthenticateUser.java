
package com.ht.syndication.htsportal.action;
import java.io.Serializable;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ht.syndication.htsportal.ServiceLocator;
import com.ht.syndication.htsportal.common.ConfigurationReader;
import com.ht.syndication.htsportal.common.ConfigurationReaderFactory;
import com.ht.syndication.htsportal.service.UserService;
import com.ht.syndication.htsportal.transfer.LoginVO;
import com.ht.syndication.htsportal.util.HTSPortal;
import com.opensymphony.xwork2.ActionSupport;

public class AuthenticateUser extends ActionSupport implements SessionAware, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6291976266951299742L;

	/**
	 * @return
	 */
	public String execute() {
		setWebroot(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.LINKURL));
		if(getUserName()==null||getUserName().trim().equals(""))
		{
			addActionError("User name can not empty...");
			return ERROR;
		}
		if(getPassword()==null||getPassword().trim().equals(""))
		{
			addActionError("Password can not empty...");
			return ERROR;
		}
		UserService userService = ServiceLocator.instance().getUserService();
		user = userService.authenticate(getUserName(),  getPassword());
		if(user.getUser()==null){
			addActionError(user.getMessage());
			session.clear();
			return ERROR;
		}
		else{
			session.put(HTSPortal.UserConst, user.getUser());
			return SUCCESS;
		}
	}

	private String userName;
	private LoginVO user;
	private String password;
	private Map<String, Object> session;
	private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);
	private String webroot;
	
	public String getWebroot() {
		return webroot;
	}
	public void setWebroot(String webroot) {
		this.webroot = webroot;
	}
	

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public Map<String, Object> getSession() {
		return session;
	}

	public LoginVO getUser() {
		return user;
	}
	public void setUser(LoginVO user) {
		this.user = user;
	}
}