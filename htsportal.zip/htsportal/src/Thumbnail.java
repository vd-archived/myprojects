import java.util.ArrayList;

import org.im4java.core.CommandException;
import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;
import org.im4java.process.ProcessStarter;

/**
   Create a thumbnail from a given Image

   @version $Revision: 1.5 $
   @author  $Author: bablokb $
 */

public class Thumbnail {

	/**
     Main method.
	 */

	public static void main(String[] args)
	{
		/*if (args.length < 2) {
			System.err.println("usage: org.im4java.examples.Thumbnail infile outfile");
			System.exit(1);
		}*/
		String myPath="C:\\Program Files\\ImageMagick-6.7.6-Q16;C:\\Programs\\exiftool";
		ProcessStarter.setGlobalSearchPath(myPath);

		IMOperation op = new IMOperation();
		op.addImage();
		//op.thumbnail(100,100,'^');
		op.resize(2000);
		op.gravity("center");
//		op.extent(100,100);
		op.addImage();

		ConvertCmd convert = new ConvertCmd();
		// convert.setSearchPath("/usr/bin");
		args = new String[]{"C:\\Desert.jpg", "C:\\Desert.jpeg"};

		try {
			convert.run(op,(Object[]) args);
		} catch (CommandException ce) {
			ce.printStackTrace();
			ArrayList<String> cmdError = ce.getErrorText();
			for (String line:cmdError) {
				System.err.println(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}