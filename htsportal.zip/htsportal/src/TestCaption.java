import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Metadata;
import com.drew.metadata.iptc.IptcDirectory;


public class TestCaption
{
//    private static final ConfigurationReader APP_PROFILE_CONFIGURATION_READER = ConfigurationReaderFactory.getInstance().getReader(HTSPortal.APPLICATION_PROFILE);

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        try
        {

        	FileInputStream file = new FileInputStream(new File("D:\\DeclarationForm20112012.xls"));
            
        	//Get the workbook instance for XLS file
        	Workbook workbook = new HSSFWorkbook(file);
        	System.out.println("Able to read");
/*            Metadata metadata = ImageMetadataReader.readMetadata(new File(args[0]));
            IptcDirectory iptcDirectory = metadata.getDirectory(IptcDirectory.class);
            System.out.println("Before ::: "+iptcDirectory.getDescription(iptcDirectory.TAG_CAPTION));
            String caption = new String((iptcDirectory.getDescription(iptcDirectory.TAG_CAPTION)).getBytes(),"UTF-8");
            System.out.println("Validate:: "+caption.indexOf("ï¿½"));
            System.out.println("After :::"+replaceBadCharacter(caption));
*/  
            /*             String caption = "";
           Metadata metadata = ImageMetadataReader.readMetadata(new File("E:/HTS/HTSImage/16.jpg"));
//            Metadata metadata = ImageMetadataReader.readMetadata(new File("/opt/services/codersite/hts/16.jpg"));

            for(Directory dir:metadata.getDirectories())
            {
                if(dir.getName() == "Iptc")
                {
                    for(Tag tag:dir.getTags())
                    {
                        if(tag.getTagName() == "Caption/Abstract")
                        {
                            caption = replaceBadCharacter(tag.getDescription());
                        }
    
                    }
                }
    
            }
            System.out.println("Caption :: "+replaceBadCharacter(new String(caption.getBytes(),"UTF-8")));
*/            
/*            System.out.println(HTSPortal.MAIL.MAILSMTPHOST);
            System.out.println(APP_PROFILE_CONFIGURATION_READER.getProperty(HTSPortal.MAIL.MAILSMTPHOST));
*/
        
        }
        catch(Exception e)
        {
        	System.out.println("Unable to read");
        	e.printStackTrace();
        } 

    }
    public static String replaceBadCharacter(String line)
    {
        try 
        {
            line = line.replaceAll("â€“ ", "- ");
            line = line.replaceAll("ï¿½", "'");
            line = line.replaceAll("ï¿½", "\"");
            line = line.replaceAll("â€�", "\"");
            line = line.replaceAll("â€œ", "\"");
            line = line.replaceAll("â€˜", "'");
            line = line.replaceAll("â€™", "'");
            line = line.replaceAll("â€™", "'");
            line = line.replaceAll("â€”", "-");
            //line = line.replaceAll("Â©","(c)");
            line = line.replaceAll("â—�","*");
            line = line.replaceAll("â€¢","*");
            line = line.replaceAll("Ã©", "e");
            line = line.replaceAll("â€™", "'");
            line = line.replaceAll("â€™", "'");
            line = line.replaceAll("â€˜", "'");
            line = line.replaceAll("â€“", "-");
            line = line.replaceAll("Â£","&#163;");
            line = line.replaceAll("â€¦", ".");
            line = line.replaceAll("â‚¬","&#8364;");
            line = line.replaceAll("Â¥","&#x00A5");
            line = line.replaceAll("'", "'");
            line = line.replaceAll("Ã¢", "a");
            line = line.replaceAll("Ãƒ", "A");
            line = line.replaceAll("Ã¡", "a");
            line = line.replaceAll("Ã—", "x");
            line = line.replaceAll("Â´", "'");
            line = line.replaceAll("Ãª", "e");
            line = line.replaceAll("Ã¨", "e");
            line = line.replaceAll("Â§", "*");
            line = line.replaceAll("Ã¶", "o");
            line = line.replaceAll("Ã§", "c");
            line = line.replaceAll("Ã´", "o");
            line = line.replaceAll("Â°", "deg");
            line = line.replaceAll("Ã¤", "a");
            line = line.replaceAll("Ãº", "u");
            line = line.replaceAll("Â¥", "Euro");
            line = line.replaceAll("Ã¯", "i");
            line = line.replaceAll("Ã«", "e");
            line = line.replaceAll("Ã ", "a");
            line = line.replaceAll("Ã‚", "A");
            line = line.replaceAll("Â®", "(R)");
            line = line.replaceAll("_", "");
            line = line.replaceAll("Ù€", " ");
            line = line.replaceAll("Â©", "&#x00A9;");
            line = line.replace("Â¬", "");
            line= line.replace("Ä�", "a");
            line = line.replace("Â¯", "");
            line = line.replace("Âº", "&#186");

        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        
        return line;

  }


}
