import java.util.ArrayList;
import java.util.List;


public class Testing {
	public static void main(String args[]) {
		List<Point> points = new ArrayList<Point>();
		points.add(new Point(73.77976132,21.66075417));
		points.add(new Point(73.78003965,21.66090136));
		points.add(new Point(73.780316,21.66123416));
		points.add(new Point(73.78046579,21.66134388));
		points.add(new Point(73.78081603,21.66164763));
		points.add(new Point(73.78089285,21.66163624));
		points.add(new Point(73.78108962,21.66181823));
		points.add(new Point(73.78134932,21.66205826));
		points.add(new Point(73.78150648,21.66214869));
		points.add(new Point(73.78110272,21.66276007));
		points.add(new Point(73.78107137,21.66257085));
		points.add(new Point(73.78104224,21.662394));
		points.add(new Point(73.78041315,21.66216614));
		points.add(new Point(73.7787997,21.66113238));
		points.add(new Point(73.77884425,21.6608994));
		points.add(new Point(73.77898548,21.66073342));
		points.add(new Point(73.77921587,21.66065795));
		points.add(new Point(73.77976132,21.66075417));
		
		double sumY = 0;
		double sumX = 0;
		double partialSum = 0;
		double sum = 0;
		
		
		for(int i = 0; i< points.size() - 1; i++) {
			partialSum = points.get(i).getLongitude() * points.get(i+1).getLatitude() - points.get(i+1).getLongitude() * points.get(i).getLatitude();
	        sum += partialSum;
	        sumX += (points.get(i).getLongitude() + points.get(i+1).getLongitude()) * partialSum;
	        sumY += (points.get(i).getLatitude() + points.get(i+1).getLatitude()) * partialSum;
		}
		
		double area = 0.5 * sum;
		System.out.println(sumY/6/area);
		System.out.println(sumX/6/area);
	}
}

class Point {
	public Point(double latitude, double longitude) {
		super();
		this.longitude = longitude;
		this.latitude = latitude;
	}
	
	private double longitude;
	private double latitude;
	
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
}